"""structured_document — representación común de un documento extraído (suite fiscal).

Espejo dependency-light (dataclasses, stdlib) de los schemas de `persona_tax/app/schemas`
(StructuredDocument / StructuredPage / StructuredTable). Es el contenedor neutro entre la
conversión (Docling/pdfplumber, vía `ocr_client` por HTTP) y la extracción de dominio.
"""
from __future__ import annotations

from dataclasses import asdict, dataclass, field
from typing import Any, Dict, List, Optional


@dataclass
class StructuredTable:
    table_id: str
    page: int
    source: str
    header: List[Optional[str]] = field(default_factory=list)
    rows: List[List[Optional[str]]] = field(default_factory=list)


@dataclass
class StructuredPage:
    page: int
    text: str = ""
    tables: List[StructuredTable] = field(default_factory=list)


@dataclass
class StructuredDocument:
    source_type: str  # PDF / IMAGE / CSV / XLSX / DOCX / TEXT / UNKNOWN
    backend: str      # pdfplumber / docling / csv / xlsx / text / unknown
    pages: List[StructuredPage] = field(default_factory=list)
    metadata: Dict[str, Any] = field(default_factory=dict)

    @property
    def text(self) -> str:
        return "\n".join(p.text for p in self.pages)

    @property
    def n_tablas(self) -> int:
        return sum(len(p.tables) for p in self.pages)

    def to_dict(self) -> dict:
        return asdict(self)


def from_convert_response(resp: dict, source_type: str = "PDF") -> StructuredDocument:
    """Respuesta de `/convert-document` (markdown + recuentos) -> StructuredDocument.

    El endpoint devuelve `markdown` + `tables_count`/`pages_count` (no las celdas), así que se
    modela como **una página** con el markdown completo; los recuentos van a `metadata`.
    """
    md = resp.get("markdown") or ""
    backend = resp.get("backend") or "unknown"
    pages_count = int(resp.get("paginas") or resp.get("pages_count") or (1 if md else 0))
    pages = [StructuredPage(page=1, text=md)] if md else []
    meta = {
        "tables_count": int(resp.get("tablas") or resp.get("tables_count") or 0),
        "pages_count": pages_count,
        "warnings": list(resp.get("warnings") or []),
        "url": resp.get("url"),
    }
    return StructuredDocument(source_type=source_type, backend=backend, pages=pages, metadata=meta)
