# parser-core — núcleo compartido de la suite fiscal

> Realiza el objetivo "módulos replicables para suite fiscal" del `CLAUDE.md`: el **núcleo genérico**
> de conversión/representación/cobertura que consumen **ambos** servicios (IS200 · Sociedades y
> IRPF/M720 · `persona_tax`). Cada impuesto aporta solo **sus** schemas de dominio y **sus** reglas
> deterministas; esto es lo común.

## Qué contiene (genérico, dependency-light)

| Módulo | Qué es | Origen / paridad |
|---|---|---|
| `structured_document` | `StructuredDocument` / `StructuredPage` / `StructuredTable` (dataclasses) + `from_convert_response` | Espejo de `persona_tax/app/schemas` (mismas formas) |
| `coverage` | `Coverage` (found/extracted/orphaned/skipped + %) + `cobertura_pgc` (forma estable para la UI) | Generaliza `canonical_v2.ExtractionCoverage` + *Coverage Warnings* |

Sin dependencias nuevas (solo `dataclasses` + stdlib) → **liftable** a cualquier servicio Python.

## Quién lo consume (hoy, en IS200)

- `engine_service/ocr_client.py` → adjunta un `documento` (StructuredDocument) a la respuesta de OCR.
- `Extractor-parseador/scripts/tablas_salida.py` → la **cobertura** del mapeo PGC sale de
  `parser_core.coverage.cobertura_pgc` (single source del patrón).

## Plan de *lift* (migración de `persona_tax` a este core) — pendiente, NO hecho aquí

No se ha tocado el repo `persona_tax` (producción en Railway). La migración, cuando se aborde:

1. **Empaquetar** `parser_core` (p.ej. `pip install -e parser-core/` o publicar en un índice privado),
   o moverlo a un monorepo que ambos servicios importen.
2. En `persona_tax`, sustituir `app/schemas.StructuredDocument/Page/Table` por re-exports de
   `parser_core.structured_document` (las formas ya coinciden → cambio mecánico).
3. Sustituir `canonical_v2.ExtractionCoverage` por `parser_core.coverage.Coverage` (superset).
4. El `docling_converter` de `persona_tax` se queda como **backend de conversión** (Docling local);
   IS200 lo consume por HTTP (`/convert-document`) vía `ocr_client` — mismo contrato.

> Mientras tanto, IS200 ya consume el core localmente y `persona_tax` sigue intacto: cero acoplamiento,
> el contrato `/convert-document` es la frontera estable entre ambos.

## Pruebas

```bash
python3 -m pytest parser_core/tests -q
```
