"""parser-core — núcleo compartido de la suite fiscal (IS200 · Sociedades + IRPF/M720).

Piezas **genéricas y sin acoplamiento de dominio**, pensadas para que **ambos** servicios las
consuman (realiza el objetivo "módulos replicables para suite fiscal" del CLAUDE.md):

  - `structured_document` : representación común documento/página/tabla (espejo de
    `persona_tax/app/schemas` StructuredDocument/Page/Table) + `from_convert_response`.
  - `coverage`            : calidad/cobertura de extracción (patrón *Coverage Warnings*) + gating HITL.

Cada impuesto aporta solo SUS schemas de dominio (casillas Modelo 200 vs claves M720) y SUS reglas
deterministas; el núcleo de conversión/representación/cobertura es éste, único.

Sin dependencias nuevas (dataclasses + stdlib) → **liftable** a cualquier servicio Python. Ver
`README.md` para el plan de migración (que `persona_tax` pase a consumir este core).
"""
from .coverage import Coverage, QualityReport, calidad_desde_resumen, cobertura_pgc
from .structured_document import (
    StructuredDocument,
    StructuredPage,
    StructuredTable,
    from_convert_response,
)

__all__ = [
    "StructuredDocument",
    "StructuredPage",
    "StructuredTable",
    "from_convert_response",
    "Coverage",
    "QualityReport",
    "calidad_desde_resumen",
    "cobertura_pgc",
]
