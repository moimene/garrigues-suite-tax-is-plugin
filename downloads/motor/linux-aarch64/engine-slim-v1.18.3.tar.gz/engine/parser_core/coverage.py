"""coverage — calidad/cobertura de extracción (patrón *Coverage Warnings* de persona_tax).

Generaliza `ExtractionCoverage` (rows_found/extracted/orphaned/skipped) y añade avisos por campo no
recuperado, para alimentar el gating HITL de toda la suite. `cobertura_pgc` es la forma estable que
consume la ingesta de IS200 (tablas de salida / UI).
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Callable, List


@dataclass
class Coverage:
    found: int
    extracted: int
    orphaned: int = 0
    skipped: int = 0
    warnings: List[str] = field(default_factory=list)

    @property
    def pct_extracted(self) -> float:
        return round(100.0 * self.extracted / self.found, 1) if self.found else 100.0

    def to_dict(self) -> dict:
        return {
            "found": self.found,
            "extracted": self.extracted,
            "orphaned": self.orphaned,
            "skipped": self.skipped,
            "pct_extracted": self.pct_extracted,
            "warnings": self.warnings,
        }


def cobertura_pgc(canonico: list, saldo_fn: Callable[[dict], float]) -> dict:
    """Cobertura del mapeo PGC de una lista canónica. Forma estable (consumida por la UI):
    {cuentas, mapeadas, no_mapeadas, pct_cuentas, pct_saldo, warnings}.
    """
    canonico = canonico or []
    n = len(canonico)
    mapeadas = [c for c in canonico if c.get("codigo_canonico")]
    saldo_total = sum(abs(saldo_fn(c)) for c in canonico)
    saldo_cubierto = sum(abs(saldo_fn(c)) for c in mapeadas)
    warnings = [
        f"{c.get('cuenta') or c.get('denom') or '(sin id)'}: sin mapeo PGC"
        for c in canonico
        if not c.get("codigo_canonico")
    ]
    return {
        "cuentas": n,
        "mapeadas": len(mapeadas),
        "no_mapeadas": n - len(mapeadas),
        "pct_cuentas": round(100.0 * len(mapeadas) / n, 1) if n else 100.0,
        "pct_saldo": round(100.0 * saldo_cubierto / saldo_total, 1) if saldo_total else 100.0,
        "warnings": warnings[:50],
    }


@dataclass
class QualityReport:
    """Calidad/HITL de una extracción (patrón *QualityReport* de persona_tax) — genérico, sin dominio.
    Resume la confianza global y el reparto por rama de revisión (auto / revisión / bloqueo) que produce el
    normalizador, para alimentar el gating HITL de toda la suite. `apto_auto` = nada exige humano."""
    confianza_media: float
    n_auto: int = 0
    n_revision: int = 0
    n_bloqueo: int = 0
    recomendaciones: List[str] = field(default_factory=list)

    @property
    def apto_auto(self) -> bool:
        return self.n_revision == 0 and self.n_bloqueo == 0

    def to_dict(self) -> dict:
        return {
            "confianza_media": self.confianza_media,
            "n_auto": self.n_auto,
            "n_revision": self.n_revision,
            "n_bloqueo": self.n_bloqueo,
            "apto_auto": self.apto_auto,
            "recomendaciones": self.recomendaciones,
        }


def calidad_desde_resumen(resumen: dict) -> QualityReport:
    """Construye el `QualityReport` desde el `resumen` del normalizador PGC (auto / en_revision / bloqueos +
    confianza_media). Forma estable que consume la UI / el gating HITL."""
    r = resumen or {}
    recs = []
    if r.get("bloqueos"):
        recs.append(f"{r['bloqueos']} cuenta(s) sin mapeo o con importe ilegible: requieren decisión (bloqueo).")
    if r.get("en_revision"):
        recs.append(f"{r['en_revision']} cuenta(s) mapean pero un eje va flojo: confirmar (revisión).")
    return QualityReport(
        confianza_media=float(r.get("confianza_media", 1.0)),
        n_auto=int(r.get("auto", 0)),
        n_revision=int(r.get("en_revision", 0)),
        n_bloqueo=int(r.get("bloqueos", 0)),
        recomendaciones=recs,
    )
