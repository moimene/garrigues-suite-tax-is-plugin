---
documento: PRD
modulo: Extractor-Parseador Contable IS (Modelo 200 — parte contable)
codename: EPC-IS
esfera: garrigues
proyecto_host: is200transmittalAPP (Suite Tax IS)
referencia_arquitectonica: persona_tax (services/parser + modelo canónico)
version_prd: 0.1.0
fecha: 2026-06-06
autor: Moi64 + Claude
estado: PIPELINE COMPLETO Y ESTABLE · XML VÁLIDO CONTRA EL XSD OFICIAL · VERSIONADO POR CAMPAÑA (17/17 tests) — ver ESTADO_Pipeline_Completo_2026-06-06.md
fase_actual: pipeline end-to-end + validación XSD oficial (mod2002024.xsd) + versionado por campaña (data/campaigns/<ejercicio>/, onboarding desde XSD oficial)
fase_siguiente: XSD 2025 oficial + esquema completo (ramas no-Normal) + afinar mapeo/reglas + frontend React/Supabase de producción
semaforo: 🟢 verde (cuadre por construcción + XML válido contra el esquema oficial AEAT, verificado con GIP real y fixture)
decisiones_cerradas:
  - alcance_salida: "solo contable — XML mod200xxxx.xsd + XLS formato AEAT (Balance/PyG/ECPN). SIN liquidación."
  - integracion: "módulo independiente (frontend + parser propios); handoff opcional a suite-is."
  - stack: "React/TS + Supabase (frontend) + motor de parsing Python."
  - referencia: "se replica el patrón de persona_tax (canónico + extractores por clase + LLM fallback + exporter + lineage)."
  - motor_sys: "normalización del SyS = pipeline Harvey de 2 etapas (6 fases de validación + agrupado 4 dígitos). El XLS canónico es el formato plantilla A3 (6 columnas). Ver referencias/PROMPTS_Harvey_SyS_a_A3.md y §9A."
pendientes_para_siguiente:
  - "Confirmar este PRD (alcance, no-objetivos, fases)."
  - "Incorporar el maestro PGC oficial (1/2/3/4 dígitos + denominación) como dato versionado (data/pgc_maestro.csv) y el catálogo de reglas guía 5.1."
  - "Conseguir un .200/XML contable real de un ejercicio anterior para el motor determinista."
  - "Generar el inventario de campos del XSD (mod2002024.xsd / mod2002025.xsd) — schema-first."
---

# PRD — Extractor-Parseador Contable IS (Modelo 200, parte contable)

> **Documento de memoria / continuidad.** Resume el problema, el alcance, la arquitectura y el plan
> para que una conversación nueva pueda continuar sin contexto previo. Lee primero el frontmatter
> (decisiones cerradas + pendientes). Documentos hermanos relevantes: `PRDis200suite.md` (suite fiscal
> host), `suite-is/CLAUDE.md` (plugin IS), y el fichero de investigación AEAT/A3 subido por el usuario
> (`Necesito buscar información sobre los ficheros de…`).

## 0. TL;DR

Construir un **módulo independiente** que convierte la documentación contable heterogénea de una
sociedad (cuentas anuales, balance de sumas y saldos, declaración del ejercicio anterior, e información
clave complementaria) en los **dos artefactos contables oficiales de la AEAT para el Modelo 200**:

1. el **XML de datos contables** conforme al esquema `mod200<ejercicio>.xsd` (bloques `Balance`,
   `CuentaPyG`, `CambiosPN`), que Sociedades WEB importa al crear una nueva declaración; y
2. una **hoja XLS en formato AEAT** (estados contables páginas 3–11), revisable por humano, que sirve
   de paso intermedio y de respaldo.

Se replica el patrón probado de **persona_tax**: documentos → **modelo canónico contable** → proyección
a formato AEAT, con un **harness que se adapta a cada clase de documento** (parseo determinista cuando
el documento ya es estructurado; inferencia cuando no lo es), filtrado/cuadre automático, validación
contra el XSD y **trazabilidad completa** de cada importe hasta su cuenta y su documento de origen.

**El sistema NO calcula la liquidación.** No toca ajustes fiscales, bases imponibles, deducciones,
BINs ni casillas de liquidación (páginas 12+ del Modelo 200). Su frontera es el resultado contable y los
tres estados financieros. La liquidación la realiza, aguas abajo, la Suite IS o el propio Sociedades WEB.

---

## 1. Contexto y origen

### 1.1 De dónde viene

- **persona_tax** (`/DESARROLLO/persona_tax`) es la plataforma fiscal multi-modelo de Garrigues para
  patrimonio (modelos 720/714/718/100). Su núcleo es un **extractor-parseador** que transforma
  documentación heterogénea del cliente en un **modelo canónico** único, del que se derivan las
  declaraciones como *proyecciones* deterministas y trazables. Es el patrón que aquí se reutiliza.
- **is200transmittalAPP / Suite Tax IS** es el sistema de gestión del Impuesto sobre Sociedades
  (Modelos 200/202/222) para Garrigues. Ya dispone de un *harness* documental y un pipeline fiscal
  (`suite-is/`: intake → motor de issues → liquidación → export), scripts de normalización de balance
  y un exportador SyS→A3. Hoy la preparación de la **parte contable** del 200 se externaliza a **A3**.
- El usuario quiere **prescindir de A3 en la preparación de los datos contables** y generar él mismo el
  fichero que la AEAT importa, a partir de los documentos del cliente. La carpeta `Extractor-parseador/`
  (vacía) es el sitio reservado para este módulo.

### 1.2 Qué hace A3 hoy (y qué replicamos)

A3 toma la contabilidad ya mapeada y **genera el fichero contable que Sociedades WEB importa**. La
investigación previa (fichero subido) concluye que el contrato real no es propietario de A3, sino un
estándar público de la AEAT: el **XML de datos contables** validado contra `mod200<ejercicio>.xsd`.
Otras aplicaciones (TeamSystem/Aplifisa, DELSOL/Contasol, ClassicConta) siguen el mismo patrón:
*software contable → XML contable AEAT → importación en Sociedades WEB*. No existe librería pública
reutilizable; el activo común es el **XSD oficial**. Por tanto el diseño correcto es **schema-first**.

### 1.3 Relación con la Suite IS (módulo independiente, con handoff)

Por decisión de producto, EPC-IS es un **módulo autónomo** (frontend + motor propios) que entrega los
ficheros contables AEAT. **No depende** del pipeline fiscal de la Suite IS. Punto de integración
opcional, no obligatorio: la salida canónica contable puede **alimentar la Fase 1 (intake) de la
Suite IS** (balance normalizado + estados contables), evitando recapturar datos cuando, además de la
parte contable, se quiera preparar la liquidación. Ese handoff se documenta, pero el módulo es útil por
sí solo.

---

## 2. Problema

La preparación de la parte contable del Modelo 200 es hoy **manual, frágil y dependiente de A3**:

- Los documentos de origen son **heterogéneos**: cuentas anuales en PDF (depósito en Registro o formato
  libre), balances de sumas y saldos en Excel con estructuras dispares (PGC normal vs abreviado, 3/4/5
  dígitos, signos inconsistentes, subtotales mezclados), y la declaración del ejercicio anterior en
  PDF o en fichero de exportación.
- El mapeo **cuenta PGC → partida del Balance/PyG/ECPN de la AEAT** se hace a mano o dentro de A3, sin
  trazabilidad propia ni reproducibilidad.
- No hay **validación previa** propia contra el esquema oficial: los errores aparecen tarde, al importar
  en Sociedades WEB.
- La dependencia de A3 añade **coste, fricción y una caja negra** en mitad del proceso.

**Oportunidad:** un módulo schema-first que ingiera los documentos, infiera o parsee según el caso,
cuadre y normalice la contabilidad, la mapee a las partidas oficiales y emita el XML/XLS contable
validado, con trazabilidad de inspección.

---

## 3. Objetivos y propuesta de valor

### 3.1 Objetivo

Dado un conjunto de documentos contables de una sociedad para un ejercicio, **producir los ficheros
contables oficiales del Modelo 200** (XML conforme al XSD + XLS en formato AEAT), correctos, cuadrados,
validados y trazables, **sin intervención de A3** y **sin calcular la liquidación**.

### 3.2 Propuesta de valor

- **Independencia de A3** en la parte contable, con un contrato público y estable (el XSD anual).
- **Reproducibilidad y auditabilidad**: mismo input aprobado → mismo XML byte a byte; cada importe de
  cada partida AEAT enlaza a las cuentas PGC que lo componen y al documento/página de origen.
- **Robustez ante la heterogeneidad**: parseo determinista cuando el documento ya es estructurado;
  inferencia asistida cuando no lo es; siempre con revisión humana antes de aprobar.
- **Encaje Garrigues**: identidad visual y disciplina de trazabilidad heredadas de persona_tax
  ("cada cifra explica su procedencia").

### 3.3 Principios de diseño (heredados de persona_tax)

1. **Schema-first**: el XSD oficial manda. El sistema nunca escribe nodos/campos que no existan en el
   esquema del ejercicio. El inventario de campos se **extrae del XSD**, no se inventa.
2. **El extractor no es la fuente de verdad**: lo extraído es un *borrador para revisión*. La fuente de
   verdad es el **snapshot canónico contable aprobado** por el profesional.
3. **Canónico único + proyección**: los documentos se consolidan en un modelo canónico contable; el
   XML y el XLS son proyecciones deterministas de ese canónico.
4. **Determinismo en la frontera de salida**: importes formateados según tipo del XSD (decimales,
   signo), orden de elementos según `xs:sequence`, codificación del esquema (ISO-8859-1).
5. **Versionado por campaña**: layouts y mapeos separados por ejercicio (`2024/`, `2025/`, `2026/`).
6. **Trazabilidad como propiedad, no como feature**: lineage documento→cuenta→partida→campo XSD.
7. **No inventar datos**: si falta información esencial, baja la confianza y se solicita al usuario;
   nunca se rellena un importe sin origen.

---

## 4. Alcance

### 4.1 Dentro de alcance (v1)

- **Entrada** de documentos por clase (ver §6), con subida en frontend.
- **Detección de clase** y enrutado al motor de extracción adecuado (harness adaptativo).
- **Extracción** determinista (estructurados) e inferida (no estructurados, vía Docling + LLM).
- **Aduana contable**: limpieza, normalización PGC, resolución de signos, cuadres.
- **Modelo canónico contable** revisable (cuentas, saldos, mapeo a partidas AEAT).
- **Mapeo PGC → partida AEAT** (Balance, PyG, ECPN), versionado por campaña, editable/auditable.
- **Generación de salidas**: XML `mod200<ejercicio>.xsd` (validado) + XLS en formato AEAT (páginas
  contables 3–11) + informe de cuadres + lineage.
- **Validación**: contra el XSD (estructural) y de negocio (cuadres contables, obligatoriedad,
  coherencia entre estados).
- **Trazabilidad** completa y exportable.
- **Datos clave complementarios** (caracteres del modelo, estado de cuentas, NIF, ejercicio/periodo):
  formulario de solicitud cuando falten, porque condicionan la rama del XSD y la validación.

### 4.2 Fuera de alcance (no-objetivos, explícitos)

- ❌ **Cálculo de la liquidación** del Impuesto: resultado fiscal, ajustes (art. 15 LIS), exenciones,
  BINs, gastos financieros, deducciones, reservas, tipo, cuota. **Frontera dura.**
- ❌ **Páginas 12+ del Modelo 200** (liquidación) y casillas fiscales. Solo se tratan las páginas
  contables (3–11): Balance, Cuenta de PyG y ECPN.
- ❌ **Fichero declarativo completo / diseño de registro `DR200e25` de extremo a extremo** (el fichero
  `<T200…>` posicional con liquidación). Se usa el DR200 solo como **referencia** del layout de las
  páginas contables. *(Pendiente decidir si v2 lo incorpora — ver §13.)*
- ❌ **Presentación electrónica** ante la AEAT. El módulo entrega ficheros; la importación/presentación
  la hace el usuario en Sociedades WEB.
- ❌ **Memoria de las cuentas anuales** (texto) y depósito de cuentas en el Registro Mercantil.
- ❌ Modelos 202/222 y consolidación (Modelo 220) — los cubre, en su caso, la Suite IS.

---

## 5. Usuarios y casos de uso

**Usuario primario:** profesional fiscal/contable de Garrigues que prepara el Modelo 200 de una
sociedad y hoy usa A3 para la parte contable. Trabaja por expedientes (cliente × ejercicio).

**Casos de uso principales:**

1. *"Tengo las cuentas anuales y el sumas y saldos de esta sociedad: genérame el fichero contable para
   importar en Sociedades WEB."* → subir documentos → revisar canónico → exportar XML + XLS.
2. *"Tengo el fichero del ejercicio anterior: aprovéchalo para arrancar este."* → parseo determinista
   de la declaración previa → precarga de estructura y arrastres → diferencias con el ejercicio actual.
3. *"Solo tengo el balance de sumas y saldos."* → mapeo PGC→AEAT → balance y PyG; el módulo señala qué
   datos faltan (p. ej. ECPN, caracteres) y los solicita.
4. *"Quiero auditar de dónde sale el importe de esta partida del balance."* → drilldown partida →
   cuentas PGC → documento/página de origen.

---

## 6. Documentos de entrada y estrategia por clase

El corazón del módulo es que **cada clase de documento usa la estrategia adecuada** (réplica directa de
los "4 motores" de persona_tax). Inferencia cuando el documento no es estructurado; parseo directo
cuando ya lo es.

| Clase de documento | Formato típico | Motor | Estrategia | Salida hacia el canónico |
|---|---|---|---|---|
| **Balance de sumas y saldos** | XLS/XLSX/CSV | Estructurado determinista | Detecta cabeceras (Cuenta, Descripción, Debe, Haber, Saldos), normaliza PGC a N dígitos, resuelve signos | Líneas de cuenta tipadas con saldos |
| **Cuentas anuales** (Balance, PyG, ECPN, memoria) | PDF (depósito o libre) | Orquestación + **inferencia** | Docling → estructura; LLM mapea epígrafes a partidas AEAT; cruza páginas/notas | Estados contables por partida (borrador, confianza) |
| **Declaración ejercicio anterior — fichero de exportación** | `.200` / XML contable `mod200` | **Determinista** | Parseo directo del fichero (lee páginas/campos ya generados) | Estados del ejercicio previo (arrastre, comparativa) |
| **Declaración ejercicio anterior — PDF** | PDF AEAT | Orquestación + inferencia | Docling + LLM localizan páginas contables y casillas | Estados del ejercicio previo (borrador) |
| **Datos clave complementarios** | Formulario / entrada manual | — | Solicitud explícita de lo que condiciona el XSD | NIF, ejercicio, periodo, **caracteres/tipo de entidad**, **estado de cuentas (normal/abreviado/PYMES)** |

**Regla de oro (decisión del usuario):** *unas cuentas anuales pueden implicar inferencia; la
declaración del ejercicio anterior, si es el archivo de exportación, se parsea directamente.* El harness
elige el camino: si el documento ya es un artefacto estructurado/oficial → motor determinista; si es
prosa/tabla heterogénea → motor de inferencia con revisión.

**Información clave a solicitar (porque condiciona la salida):**

- **Caracteres del modelo / tipo de entidad** → selecciona la **rama del XSD** (`Normal`, `BancoEspana`,
  `Seguros`, `SociedadGarantia`, `InstitucionesInversionColectiva`). v1 cubre `Normal`.
- **Estado de cuentas** (normal / abreviado / PYMES) → la AEAT valida el XML contra este estado.
- **NIF, denominación, ejercicio y periodo impositivo** → identificación.
- **Balance de cierre vs pre-cierre** y tratamiento de la cuenta **129 Resultado del ejercicio**
  (regla A3: el sumas y saldos importable suele ir antes del cierre; la 1290 no lleva saldo final).

---

## 7. Arquitectura

### 7.1 Visión (réplica de persona_tax, adaptada a contable)

```
Documentos (cuentas anuales, SyS, declaración previa, datos clave)
        │
        ▼  [1] Subida por clase  (frontend React/TS + Supabase Storage)
        ▼  [2] Detección de clase + enrutado            ── Harness adaptativo
        ▼  [3] Extracción por motor (determinista | inferencia)
        ▼  [4] Aduana contable (limpieza, PGC, signos, cuadres)
        ▼  [5] Modelo canónico contable  ◀── REVISIÓN HUMANA (fuente de verdad al aprobar)
        ▼  [6] Mapeo PGC → partida AEAT (Balance/PyG/ECPN), por campaña
        ▼  [7] Proyección (builder schema-first)
        ▼  [8] Validación: XSD + cuadres de negocio
        ▼  [9] Salidas: XML mod200xxxx + XLS AEAT + informe + lineage
```

Cada flecha deja **lineage** (qué motor, qué versión, qué confianza, qué evidencia).

### 7.2 Componentes y mapeo con persona_tax

| persona_tax (referencia) | EPC-IS (este módulo) | Función |
|---|---|---|
| `services/parser/app/harvey_engine.py` | `harness/orquestador` | Detecta clase, planifica y enruta la extracción |
| `extractors/{jpmorgan,goldman,pictet,citi}.py` + `llm_fallback.py` | `extractors/{sumas_saldos, cuentas_anuales, declaracion_previa}.py` + `llm_fallback.py` | Extractor por clase + inferencia de respaldo |
| `docling_converter.py` | `docling_converter.py` | PDF → estructura para inferencia |
| `engines/` (anthropic/openai, v3) + `services/model_policy.py` | mismo (routing de modelos por coste/complejidad) | LLM solo donde aporta |
| "Aduana Matemática" (7 capas dedup) | **"Aduana contable"** (cuadres + PGC + signos) | Limpieza determinista previa al canónico |
| `schemas/canonical_v2.py` (instruments/holdings/snapshots) | `schemas/canonico_contable.py` (cuentas/saldos/partidas) | Modelo canónico |
| `canonical_registry.py` | `registro_canonico.py` | Promoción staging → canónico aprobado |
| proyección `model_projection_{720,714,718,100}` | proyección `Balance/CuentaPyG/CambiosPN` (XSD) | Canónico → partidas AEAT |
| `exporters/excel_m720_v2.py` (TXT .720 + hash) | `exporters/xml_mod200.py` + `exporters/xls_aeat.py` | XML XSD + XLS, con hash de reproducibilidad |
| validación Luhn ISIN + confianza | validación PGC + **cuadre balance** + confianza | Calidad antes de aprobar |
| tablas `xtr_*` (lineage) | tablas `epc_*` (lineage) en Supabase | Auditabilidad |
| `apps/web/src/features/{documents,extractor,extraction,canonical,models,export,validation}` | mismas features, adaptadas | Frontend |

### 7.3 Frontend (React/TS + Supabase)

- Reutiliza el stack del host (`is200transmittalAPP`: React 18, TypeScript, Vite, Tailwind, Supabase) y
  el design system Garrigues (verde Pantone 3308 C, Montserrat, "Audit Workbench"; ver `DESIGN.md` de
  persona_tax como referencia visual).
- **Features (pantallas):**
  - `documents` — subida por **clase** (drag-drop), con detección y estado por documento.
  - `extraction` — revisión del borrador extraído por documento (confianza, evidencia página).
  - `canonical` — **balance/estados canónicos** editables; aprobar = fijar fuente de verdad.
  - `mapping` — tabla de mapeo PGC→partida AEAT, editable y versionada.
  - `validation` — panel de cuadres y validación XSD (issues con severidad + icono).
  - `export` — generación y descarga de XML + XLS + informe; hash de reproducibilidad.
- **Supabase**: Auth (acceso profesional), Storage (documentos, ficheros generados), Postgres
  (expedientes, canónico, lineage), RLS por expediente/cliente.

### 7.4 Motor de parsing (Python)

- Servicio Python (FastAPI, como persona_tax) **o** conjunto de scripts invocables — *decisión de §13*.
  Recomendación: servicio para encapsular Docling + LLM + validación XSD; el frontend llama por API.
- Librerías: `openpyxl`/`xlrd`/`pandas` (XLS/XLSX), `docling` (PDF→estructura), `lxml` (serialización +
  **validación XSD**), cliente LLM (Anthropic/OpenAI) para inferencia con *fallback*.
- **Validación XSD local**: cargar `mod200<ejercicio>.xsd` y validar el XML antes de entregarlo (Sociedades
  WEB rechaza si no valida; no esperar a producción para enterarse).

### 7.5 Datos clave AEAT confirmados (para el builder)

Del análisis del XSD (investigación previa) y del **`DR200e25.xls` oficial** (verificado en este
trabajo), la parte contable es:

| Bloque XSD (rama `Normal`) | Páginas XSD | Páginas DR200 (registro) | Contenido |
|---|---|---|---|
| `Balance` | Pagina03–06 | DP200003 (Activo I), DP200004 (Activo II), DP200005 (PN y Pasivo I), DP200006 (PN y Pasivo II) | Balance |
| `CuentaPyG` | Pagina07–08 | DP200007–DP200008 (PyG, operaciones continuadas) | Cuenta de pérdidas y ganancias |
| `CambiosPN` | Pagina09–11 | DP200009 (ECPN I), DP200010 (ECPN II), DP200011 (ECPN III) | Estado de cambios en el patrimonio neto |

- Raíz `MOD200<ejercicio>`; `xs:choice` de **una** rama (v1 → `Normal`); orden de bloques `Balance` →
  `CuentaPyG` → `CambiosPN`; campos técnicos `T#####`; importes con tipo `tipo_ImpNegativo` /
  `tipo_ImpPositivo` (dos decimales, signo); codificación **ISO-8859-1**; emitir solo campos con valor
  (la mayoría `minOccurs="0"`).
- **Schema-first obligatorio**: un *extractor del XSD* genera el inventario por página (campo, tipo,
  orden, cardinalidad) → `catalog.<ejercicio>.json`. El builder solo escribe campos de ese catálogo.
- **Versionado por campaña**: `mod2002024.xsd` (ej. 2024), `mod2002025.xsd` (ej. 2025), etc. El `DR200e25.xls`
  corresponde al ejercicio 2025.

---

## 8. Modelo canónico contable

Un único registro contable del ejercicio, del que se derivan las proyecciones. Entidades mínimas:

- **`cuenta`** — cuenta del PGC tal como viene del origen: código (normalizado a N dígitos),
  descripción, naturaleza (deudora/acreedora derivable de la clase), origen documental.
- **`saldo`** — por cuenta y ejercicio: saldo inicial, debe, haber, saldo final (sin signo interno +
  signo resuelto), divisa (EUR).
- **`partida_aeat`** — partida del Balance/PyG/ECPN (campo `T#####` del XSD) con su importe agregado.
- **`mapeo`** — regla cuenta/rango PGC → `partida_aeat`, con signo y agregación (versión por campaña).
- **`estado_contable`** — agregación por bloque (Balance/PyG/ECPN) lista para proyectar.
- **`snapshot_contable`** — versión aprobada e inmutable del canónico del ejercicio (fuente de verdad;
  base de la reproducibilidad).

Reglas:

- Las proyecciones (XML/XLS) **leen** el canónico, **nunca** lo modifican (igual que persona_tax).
- Corregir una cuenta/mapeo invalida las salidas afectadas → regeneración determinista.
- Al cerrar el expediente, el `snapshot_contable` queda inmutable; una rectificación abre uno nuevo.

---

## 9. Aduana contable (limpieza y cuadre previos)

Análogo a la "Aduana Matemática" de persona_tax, pero para contabilidad. Pipeline determinista antes de
promover nada al canónico:

1. **Normalización PGC**: código a N dígitos (4 por defecto; configurable a plan ampliado), relleno de
   ceros, descripción opcional pero columna presente.
2. **Resolución de signos**: saldo acreedor → negativo en saldo final/inicial (regla AEAT/A3);
   deudor → positivo.
3. **Filtro de agregaciones/ruido**: descartar subtotales, totales de grupo, líneas de pie ("Página X
   de Y") que no son cuentas.
4. **Tratamiento de la cuenta 129 / 1290**: por defecto **no informar saldo final** (balance pre-cierre,
   regla A3); parametrizable y testeable.
5. **Cuadres** (alimentan el panel de validación, no el fichero):
   - Total Debe = Total Haber.
   - Σ saldos deudores = Σ saldos acreedores.
   - Resultado contable reconstruido (PyG) coherente con el balance.
6. **Confianza por línea**: cuentas con código válido y cuadre → alta; ambigüedades (descripción
   truncada, sin código, descuadre local) → baja confianza → revisión humana.

---

## 9A. Motor de normalización del Sumas y Saldos (2 etapas, human-in-the-loop)

> **Spec operativa = `referencias/PROMPTS_Harvey_SyS_a_A3.md`** (los 2 prompts de Harvey hoy en
> producción, verbatim). Es el motor que produce el **canónico contable** a partir del sumas y saldos en
> bruto y encarna el principio persona_tax "el extractor no es la fuente de verdad": entrega un borrador,
> el humano lo fija. Cubre los pasos [3]–[5] del pipeline (§7.1) para la clase *Sumas y Saldos*.

**Etapa A — Validación PGC (fases 1–6; se detiene para revisión):**

1. **Detección de columnas** (código, descripción, importe/saldo, Debe, Haber, Saldo inicial). Si hay
   Debe/Haber separados: `saldo neto = Debe − Haber`. No se alteran filas/columnas originales.
2. **Truncado** a `Código_4d` / `Código_3d` (vacío o no numérico → `"sin código"`; el código original no se modifica).
3. **Maestro PGC oficial** (cuentas a 1/2/3/4 dígitos + denominación) como única referencia. No se inventan códigos.
4. **Match por fila**: `4d directo` → `3d directo` → `no identificada`. Aunque el código exista, si hay
   incoherencia clara entre código / descripción / signo / naturaleza → pasa a la fase 5.
5. **Análisis razonado**: reasignación por descripción (reglas guía: `280x/281x` amortización acumulada
   ≠ `290x/291x` deterioro; `480` gastos anticipados; `485` ingresos anticipados; `572/573` tesorería
   €/divisa; `630/639` impuesto beneficios/ajustes) + **validación de signo** (naturaleza deudora/
   acreedora vs signo observado; el signo detecta errores, no reclasifica por sí solo).
6. **Tabla de validación interactiva** solo con las filas dudosas (las `4d/3d directo` limpias no entran).

**Gate humano:** por fila, `✅ Validar` (`Validado`) o `✏️ Corregir` (`codigo cuenta = <código>`). Esto
fija el canónico (pantalla `extraction`/`validation` del frontend).

**Etapa B — Correcciones + agrupado (tras la validación):**

- Aplica las correcciones **verificando contra el PGC** (si el código no existe, mantiene la mejor
  asignación previa y lo anota en Notas).
- **Agrupa a 4 dígitos** (si no hay cuenta a 4d en el PGC, la de 3d se convierte a 4d añadiendo `0`
  final: `100` → `1000`), **suma por `Código_PGC_asignado`** y añade la denominación oficial.
- **Formato español** de números (`1.234,56`).
- **Salida** = tabla `Cuenta / Descripción / Saldo Final / Debe / Haber / Saldo Inicial` = **formato de
  la plantilla A3 "Sumas y Saldos"** = **canónico contable** del ejercicio en EPC-IS.

**Tabla de validación (spec de UI):** 14 columnas — `Código original | Descripción | Importe/Saldo
observado | Cuenta detectada | Naturaleza esperada | Signo observado | Cuenta PGC propuesta |
Denominación PGC propuesta | Tipo de resolución | Motivo | Alternativas consideradas | Notas | ✅ Validar
| ✏️ Corregir`. Las filas con `posible signo equivocado` se destacan siempre.

**Productización (lo que los prompts no fijan y debe decidir EPC-IS):**

- **Capa determinista + LLM selectivo**: fases 1–2 y 4 (detección, truncado, match exacto contra maestro)
  deterministas; la fase 5 (descripción/signo) con LLM solo en lo ambiguo (model policy por coste, como
  persona_tax). Esto convive con `suite-is/scripts/normalizar_balance.py`, que es el embrión determinista.
- **Maestro PGC** como dato versionado del módulo (`data/pgc_maestro.csv`), no re-extraído por pasada.
- **Reglas guía 5.1** en catálogo editable/versionado, no hardcodeadas en el prompt.
- **Lineage por fila**: original → propuesta → resolución → validación humana.
- Tras agrupar, ejecutar los **cuadres** de la Aduana contable (§9) y el tratamiento de la 129/1290
  antes de promover a canónico.

**Frontera con A3:** este motor **sustituye la limpieza/normalización que hoy hace A3 al importar**. El
paso siguiente (mapeo PGC→partida AEAT, §10, y builder XSD, §7.5/§11) sustituye lo que A3 hace
internamente para generar el fichero contable. Resultado: el flujo completo sin A3.

---

## 10. Mapeo PGC → partida AEAT

- **Repositorio de mapeo por campaña**: `mappings/<ejercicio>/normal.json`. Cada regla apunta a un
  `T#####` real del catálogo extraído del XSD (nunca a una etiqueta inventada).
- Estructura de regla: `id`, `targetPage` (Pagina03…11), `targetField` (T#####), `accountPrefixes`/
  `accountRanges`, `sign` (+1/−1), `aggregation` (suma saldo final / inicial / fórmula), `notes`.
- **Editable y auditable** en frontend (`mapping`): el profesional puede ajustar el mapeo y queda
  versionado; el sistema avisa de cuentas sin mapear y de partidas obligatorias a cero.
- El mapeo es **la capa de criterio contable**; el XSD es **el contrato de forma**. Separados a
  propósito para soportar cambios anuales sin tocar el builder.

---

## 11. Salidas (entregables)

1. **XML de datos contables** `mod200<ejercicio>` — validado contra el XSD, ISO-8859-1, importable en
   Sociedades WEB al crear una nueva declaración (rama `Normal` en v1).
2. **XLS en formato AEAT** — estados contables (páginas 3–11) en una hoja revisable; *(decisión §13:
   plantilla A3 "Sumas y Saldos" vs réplica de páginas DR200)*. Sirve de paso intermedio y respaldo.
3. **Informe de cuadres y validación** — Debe/Haber, deudor/acreedor, resultado, partidas a cero,
   avisos; con semáforo.
4. **Lineage / trazabilidad** — por importe de partida: cuentas PGC que lo componen → documento(s) y
   página(s) de origen → motor y versión → confianza. Exportable.
5. **Hash de reproducibilidad** — SHA-256 del XML sobre bytes ISO-8859-1, almacenado con el snapshot.

---

## 12. Validación y *gating*

- **Estructural (XSD)**: raíz `MOD200<ejercicio>`, una sola rama del `xs:choice`, bloques y páginas en el
  orden del esquema, cada `T#####` en su página, tipos/decimales/signos correctos, omitir campos sin
  valor. Validación con `mod200<ejercicio>.xsd` local **antes** de entregar.
- **De negocio**: balance cuadrado; coherencia activo = PN + pasivo; coherencia PyG ↔ ECPN cuando
  aplique; estado de cuentas compatible con la rama; partidas obligatorias presentes aunque vayan a cero;
  caracteres/tipo de entidad informados.
- **Gating** (heredado de la Suite IS): con cuadres 🔴 sin resolver **no** se habilita la exportación
  del XML; los 🟡 los confirma el profesional. Nada se aprueba con confianza baja sin revisión.

---

## 13. Decisiones abiertas (para resolver tras validar el PRD)

1. **XLS objetivo** — *resuelto-tendencia.* El motor SyS (§9A, prompts Harvey) ya produce la **plantilla
   A3 "Sumas y Saldos"** (6 columnas: Cuenta, Descripción, Saldo Final, Debe, Haber, Saldo Inicial): ese
   es el **canónico contable** y el primer formato XLS de exportación. Pendiente menor: decidir si además
   se ofrece una hoja que **replique las páginas 3–11 del DR200** como segundo formato XLS.
2. **Servicio vs scripts**: ¿motor Python como **servicio FastAPI** (recomendado) o como scripts
   invocados por el frontend/Supabase Edge Functions?
3. **Alcance v2**: ¿incorporar el **diseño de registro DR200 completo** (fichero `<T200…>` posicional con
   liquidación) para sustituir A3 de extremo a extremo? Hoy fuera de alcance por la regla "sin
   liquidación", pero es la extensión natural si se quiere reemplazar A3 al 100%.
4. **Handoff a Suite IS**: ¿exponer la salida canónica como **Fase 0 contable** que alimente el intake
   de la Suite IS, o dejar solo exportación de ficheros?
5. **Multi-rama XSD**: v1 cubre `Normal`. ¿Cuándo `Seguros`/`BancoEspana`/etc. (clientes Garrigues)?
6. **Ejercicio objetivo del piloto**: ¿2024 (`mod2002024.xsd`, ya analizado) o 2025 (`DR200e25.xls`,
   XSD por confirmar disponibilidad)?

---

## 14. Stack técnico

- **Frontend**: React 18 + TypeScript + Vite + Tailwind (design system Garrigues) — sobre el host
  `is200transmittalAPP` o app dedicada en monorepo.
- **Backend datos**: Supabase (Auth, Storage, Postgres + RLS).
- **Motor de parsing**: Python (FastAPI recomendado). Docling (PDF→estructura), openpyxl/xlrd/pandas
  (XLS), lxml (serialización + validación XSD), cliente LLM con *fallback* y *model policy* por coste.
- **Schema-first tooling**: extractor del XSD → `catalog.<ejercicio>.json`; `mappings/<ejercicio>/normal.json`.
- **Trazabilidad**: tablas `epc_*` (source_documents con SHA-256, extraction_runs, extracted_records,
  evidence, quality_reviews, promotion_events) — calco del esquema `xtr_*` de persona_tax.

---

## 15. Roadmap por fases

**Fase 0 — Cimientos schema-first**
- Extractor del XSD (`mod2002024.xsd` y/o `mod2002025.xsd`) → catálogo de campos por página.
- Parser del `DR200e25.xls` (páginas 3–11) como referencia de layout del XLS AEAT.
- Estructura del modelo canónico contable + esquema Supabase + lineage.

**Fase 1 — MVP determinista (sumas y saldos → salidas)**
- Extractor de **balance de sumas y saldos** (XLS/XLSX/CSV) + Aduana contable + cuadres.
- Mapeo PGC→AEAT (rama `Normal`, ejercicio piloto) editable.
- Builder + serializador XML (schema-first) + validación XSD + XLS formato AEAT.
- Frontend mínimo: subida SyS → revisión canónico → export.
- Caso de referencia: usar **GIP** (la Suite IS ya tiene SyS y CCAA de GIP) para validar end-to-end.

**Fase 2 — Inferencia (cuentas anuales)**
- Docling + LLM para cuentas anuales en PDF → estados contables (borrador con confianza/evidencia).
- Pantalla de revisión con drilldown a página de origen.

**Fase 3 — Motor determinista de declaración previa**
- Parseo directo del `.200`/XML contable del ejercicio anterior → arrastre y comparativa.
- Conseguir un fichero real para fijar el parser.

**Fase 4 — Endurecimiento y multi-rama**
- Reglas de signo/obligatoriedad por campo, partidas a cero, casos límite.
- Soporte de más ramas del XSD según necesidad (Garrigues).
- *(Opcional v2)* diseño de registro DR200 completo.

---

## 16. Métricas de éxito

- **Validez**: % de XML generados que validan a la primera contra el XSD (objetivo ≥ 99%).
- **Cuadre**: % de expedientes con balance cuadrado automáticamente (Debe=Haber, deudor=acreedor).
- **Cobertura sin A3**: % de expedientes contables preparados de extremo a extremo sin A3.
- **Esfuerzo**: tiempo medio "documentos → fichero importable" vs proceso actual con A3.
- **Trazabilidad**: % de partidas con lineage completo hasta documento/página.
- **Calidad de inferencia**: precisión del mapeo automático de cuentas anuales vs revisión humana.
- **Reproducibilidad**: regeneración byte a byte del XML desde el snapshot aprobado (debe ser 100%).

---

## 17. Riesgos y mitigaciones

| Riesgo | Impacto | Mitigación |
|---|---|---|
| El XSD cambia cada campaña | Salidas inválidas | Versionado por campaña; catálogo extraído del XSD; tests contra el XSD del año |
| Heterogeneidad de los sumas y saldos | Mapeo erróneo | Aduana contable + mapeo editable + confianza + revisión humana |
| Inferencia de cuentas anuales imperfecta | Datos incorrectos | Borrador con confianza/evidencia; aprobación humana obligatoria; nunca auto-aprobar |
| No disponer de un `.200`/XML real previo | Parser determinista sin fijar | Conseguir un fichero real; aislar Fase 3 hasta tenerlo |
| Codificación/orden del XML (ISO-8859-1, `xs:sequence`) | Rechazo en Sociedades WEB | Serializador determinista + validación XSD local previa |
| Confusión con el alcance ("¿calcula impuestos?") | Expectativas erróneas | No-objetivos explícitos (§4.2); frontera dura en el resultado contable |
| Dependencia de LLM (coste/latencia) | Coste | Determinista por defecto; LLM solo en inferencia; model policy por coste |
| Datos sensibles (financieros de clientes) | Cumplimiento | Supabase RLS, cifrado, hash, lineage; sin secretos en repo |

---

## 18. Glosario

- **SyS / Sumas y Saldos**: balance de comprobación de sumas y saldos.
- **CCAA**: cuentas anuales (Balance, PyG, ECPN, memoria).
- **ECPN**: estado de cambios en el patrimonio neto.
- **XSD `mod200<ejercicio>.xsd`**: esquema oficial AEAT del XML de datos contables del Modelo 200.
- **DR200e25.xls**: diseño de registro del Modelo 200, ejercicio 2025 (77 hojas; contables = páginas 3–11).
- **Sociedades WEB**: formulario AEAT que importa el XML contable al crear la declaración.
- **Rama del XSD**: `Normal`, `BancoEspana`, `Seguros`, `SociedadGarantia`, `InstitucionesInversionColectiva`.
- **Canónico contable**: registro único del ejercicio del que se derivan las proyecciones.
- **Harness**: orquestador que detecta la clase de cada documento y enruta su extracción.
- **Aduana contable**: pipeline determinista de limpieza/normalización/cuadre previo al canónico.
- **Lineage**: rastro de procedencia (documento→cuenta→partida→campo) para auditoría.

---

## 19. Referencias

- **AEAT — Diseños de registro Modelos 200–299**: https://sede.agenciatributaria.gob.es/Sede/ayuda/disenos-registro/modelos-200-299.html
- **AEAT — XSD datos contables (ej. 2024)**: https://sede.agenciatributaria.gob.es/static_files/AEAT_Desarrolladores/EEDD/Modelo_200/2024/mod2002024.xsd
- **AEAT — Importar datos contables (Sociedades WEB)**: https://sede.agenciatributaria.gob.es/Sede/ayuda/consultas-informaticas/impuesto-sobre-sociedades-ayuda-tecnica/sociedades-web/importar-datos-contables-modelo-200.html
- **A3 — Importar Sumas y Saldos en Excel**: https://a3responde.wolterskluwer.com/es/s/article/como-importar-un-sumas-y-saldos-en-formato-excel
- **A3 — Modelo 200, chequeos y validaciones**: https://a3responde.wolterskluwer.com/es/s/article/modelo-200-chequeos-y-validaciones
- **Referencia arquitectónica interna**: `persona_tax/docs/arquitectura/{extractor-y-parser,modelo-canonico,motor-de-reglas}.md`
- **Investigación previa (usuario)**: fichero `Necesito buscar información sobre los ficheros de…(1).md` (análisis AEAT/A3 + spec técnica borrador).
- **Prompts Harvey SyS→A3 (motor SyS, verbatim)**: `Extractor-parseador/referencias/PROMPTS_Harvey_SyS_a_A3.md` (define §9A).
- **Host**: `is200transmittalAPP/` (`PRDis200suite.md`, `suite-is/CLAUDE.md`, scripts `normalizar_balance.py`, `generar_export_modelo200.py`, `exportar_sys_a3.py`).
