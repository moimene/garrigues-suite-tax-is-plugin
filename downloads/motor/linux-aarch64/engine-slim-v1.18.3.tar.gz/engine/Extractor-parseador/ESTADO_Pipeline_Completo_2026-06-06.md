---
documento: ESTADO / memoria de continuidad
modulo: Extractor-Parseador Contable IS (EPC-IS)
fecha: 2026-06-06
estado: ✅ pipeline contable completo y estable · 12/12 tests verdes
alcance: parte contable del Modelo 200 (XML mod200 + XLS AEAT). SIN liquidación.
---

# EPC-IS — Pipeline contable completo (estado)

## Qué está construido y verde

Pipeline end-to-end **documentos → ficheros AEAT contables**, replicando el patrón persona_tax
(canónico → proyección), con cuadre por construcción y validación. Todo en `Extractor-parseador/`.

```
scripts/   campaign.py · catalogo_contable.py · gen_xsd_normal.py · gen_mapeo_pgc_aeat.py ·
           motor_sys.py · builder.py · validador.py · parser_declaracion_previa.py ·
           extractor_ccaa.py · harness.py · pipeline.py · service.py
data/
  pgc_maestro.csv                       (PGC RD 1514/2007; compartido)
  campaigns/2024/   mod2002024_normal.xsd · xsd_campos.json (451) · mapeo_pgc_aeat.json · campaign.json
  campaigns/2025/   ... (provisional = 2024) + catalogo_contable.json (etiquetas DR200e25)
web/       index.html (subida por clase → procesar → descargar)
tests/     test_epc_is.py (17 tests) · fixtures/sys_min.csv · conftest.py
salidas/   GIP_2024/ · GIP_2025/ · _runs/ (servicio)
referencias/ PROMPTS_Harvey_SyS_a_A3.md
README.md · requirements.txt
```

### Etapas (todas funcionando)

1. **Catálogo schema-first** — parsea el DR200e25.xls (págs. 3-11) → 574 campos con casilla↔T-code
   (T = "T" + casilla; confirmado: 00103→T00103, 00700→T00700).
2. **Motor SyS** (determinista) — sumas y saldos → canónico agrupado 4d (formato A3) + tabla de
   validación (Etapa A, human-in-the-loop) + cuadres. Lector robusto (calamine para JasperReports).
3. **Mapeo PGC→casilla** — 227 reglas (cuenta/rango → casilla, bloque, sección/grupo PyG). Signo por
   bloque: Activo +saldo; PN/Pasivo −saldo; PyG −saldo.
4. **Builder** — canónico + mapeo + catálogo → XML mod200 (MOD200/Normal/Balance/CuentaPyG/CambiosPN,
   ISO-8859-1, solo casillas con valor) + XLS estados contables + lineage. Resultado y subtotales
   calculados; cuadre TOTAL ACTIVO == TOTAL PN+PASIVO por construcción.
5. **Validador** — estructural (catálogo), cuadres de negocio, XSD (si se aporta `data/mod200xxxx.xsd`).
6. **Declaración previa** (determinista) — parsea XML mod200 → casillas + comparativa. Round-trip exacto.
7. **Cuentas anuales** (inferencia) — PDF → borrador; hook LLM (model policy); fallback determinista.
8. **Harness + orquestador** — clasifica documentos y ejecuta todo; `manifest.json` + `INFORME.md`.
9. **Servicio FastAPI + web** — subir por clase → procesar → descargar.

## Versionado por campaña (cerrado)

La AEAT publica el diseño/esquema **cada ejercicio**, con posibles cambios de casillas. El sistema está
versionado por campaña: **el ejercicio es el único selector** y resuelve todos los artefactos.

- `data/campaigns/<ejercicio>/`: `mod200<ej>.xsd` (+ subesquema Normal) · `xsd_campos.json` ·
  `mapeo_pgc_aeat.json` · `catalogo_contable.json` (etiquetas) · `campaign.json` (manifest con fuente,
  hash del XSD, base y flags `provisional`). El `pgc_maestro.csv` es compartido (PGC), con override opcional.
- `scripts/campaign.py`: `resolve(ejercicio)` (usado por builder/pipeline/validador/tests),
  `parse_official_xsd()` (extrae las casillas por página de un **XSD oficial real**, en orden),
  `onboard()` (alta de un año nuevo) y `diff(a,b)` (qué casillas cambió la AEAT).
- **Alta de un ejercicio nuevo = una orden**:
  `python3 scripts/campaign.py onboard --ejercicio 2026 --xsd mod2002026.xsd --base 2025`
  → parsea el XSD oficial, genera campos + subesquema, copia el mapeo de la base y emite `ONBOARDING.md`
  con el diff (casillas nuevas sin mapear / reglas huérfanas a remapear). Sin tocar código.
- Verificado: el **parser del XSD oficial reproduce exactamente** las 451 casillas de la rama Normal;
  `diff 2024↔2025` = 0 (2025 provisional). 2024 = XSD oficial aportado; 2025 = provisional hasta su XSD.

## Validación XSD oficial (cerrado)

Con el `mod2002024.xsd` oficial aportado se cerró la validación formal:

- Se extrajeron las **451 casillas importables de la rama Normal** (con su orden `xs:sequence`) →
  `scripts/gen_xsd_normal.py` → `data/xsd_campos_2024.json` + subesquema válido `data/mod2002024_normal.xsd`.
- **Hallazgo clave**: el XSD **NO admite subtotales/totales/resultados calculados** (00101, 00136, 00180,
  00185, 00210, 00228, 00252, 00296, 00324, 00500…; `T00180` está comentado). Los recompone la AEAT.
  El builder se corrigió para **emitir solo casillas-hoja del XSD, en su orden**; los totales se calculan
  para el informe de cuadres pero no van al XML.
- Se remapearon 24 reglas del mapeo que apuntaban a casillas-header no importables → casillas-hoja válidas
  (cross-check: **0 casillas del mapeo fuera del XSD**).
- **Resultado: el XML de GIP valida ✅ contra el esquema oficial** (lxml `XMLSchema.validate` = True).

## Verificación

- **GIP (real, ejercicio 2024 contra XSD oficial)**: 206 filas → 60 cuentas 4d · 0 no identificadas ·
  Debe=Haber y deudor=acreedor ✅ · **TOTAL ACTIVO = TOTAL PN+PASIVO = 561.111.165,52** (dif 0,00) ·
  Resultado 147.417.876,97 · XML **41 casillas, VÁLIDO contra `mod2002024.xsd`**.
- **Tests**: `pytest tests/ -q` → **17 passed** (catálogo, mapeo, motor, builder, validador, round-trip,
  **validez XSD con lxml**, pipeline, servicio, fmt español, GIP end-to-end, y **4 de campaña**: resolve,
  parser del XSD oficial, mapeo⊆XSD, diff). Fixture sintético independiente.

## Límites conscientes (no bloquean el pipeline)

- **XSD 2025**: el esquema aportado es 2024; 2025 está **provisional** (= casillas 2024). En cuanto la AEAT
  publique `mod2002025.xsd`: `campaign.py onboard --ejercicio 2025 --xsd mod2002025.xsd --base 2024` y revisar
  el `ONBOARDING.md` (diff de casillas). Sin tocar código.
- **Esquema completo**: validamos contra el subesquema de la rama **Normal** (suficiente para sociedades
  ordinarias). Para Seguros/BancoEspaña/etc., dejar el `mod2002024.xsd` completo en `data/`.
- **ECPN**: se rellena parcialmente desde el SyS (resultado); el detalle de movimientos vendría de las CCAA.
- **Extractor CCAA**: requiere PDF con texto; el de GIP es escaneado (0 candidatos) → vía cuadrada = SyS.
- **Reglas guía 5.1 / mapeo**: cobertura estándar + GIP; afinar casos límite (p.ej. 700 holding→760,
  5410 banco vs valores) por catálogo editable. El gate humano (Etapa A) los recoge.
- **Frontend de producción**: la web incluida es funcional/mínima; la app React/Supabase de la PRD es
  el siguiente incremento.

## Cómo retomar

```bash
cd Extractor-parseador && pip install -r requirements.txt
python3 -m pytest tests/ -q                       # debe dar 12 passed
python3 scripts/pipeline.py --empresa GIP --ejercicio 2025 --outdir salidas/GIP_2025 \
  --docs "../GIP 2025/GIP-SUMAS Y SALDOS GIP EUROS 311225 VERSION 230426.xls"
```

## Siguientes pasos sugeridos

1. Conseguir `mod2002025.xsd` (AEAT) → activar validación XSD + cuadrar casilla↔T-code.
2. Validación cruzada del XML/XLS contra lo que A3 genera hoy para GIP.
3. Afinar mapeo PGC→casilla y reglas 5.1 (catálogo editable/versionado).
4. Frontend React/Supabase de producción sobre el servicio.
5. Multi-rama del XSD (Seguros/BancoEspana) si el negocio lo pide.
