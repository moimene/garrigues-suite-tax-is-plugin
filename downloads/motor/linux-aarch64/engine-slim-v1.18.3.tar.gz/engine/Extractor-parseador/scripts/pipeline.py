#!/usr/bin/env python3
"""pipeline.py — Orquestador end-to-end del Extractor-Parseador Contable IS (PRD §7).

Documentos (por clase) -> harness -> motores -> canónico -> mapeo+builder -> validación -> salidas.

Para un expediente (cliente × ejercicio):
  - clasifica cada documento (harness);
  - Sumas y Saldos -> motor_sys -> canónico (agrupado 4d) + tabla de validación + cuadres;
  - canónico -> builder -> XML mod200 contable + XLS estados contables AEAT;
  - valida el XML (estructural + cuadres + XSD si se aporta);
  - Declaración previa (.xml) -> parser determinista -> comparativa;
  - Cuentas anuales (.pdf) -> extractor inferencia -> borrador (informativo);
  - escribe manifest.json + INFORME.md.

Uso:
  python3 pipeline.py --docs <doc1> <doc2> ... --outdir <salida> --empresa "GIP" --ejercicio 2025
"""
from __future__ import annotations
import argparse, json, sys
from datetime import datetime, timezone
from pathlib import Path

SCRIPTS = Path(__file__).resolve().parent
DATA = SCRIPTS.parent / "data"
sys.path.insert(0, str(SCRIPTS))

import harness, motor_sys, builder, validador, parser_declaracion_previa as pdp, extractor_ccaa, campaign  # noqa: E402
import reconciliador  # noqa: E402  (gate fail-closed de cuadre, B3)

def _limpiar_aeat_stale(out, ejercicio, man):
    """Borra del outdir los artefactos AEAT numéricos PREVIOS (rerun descuadrado tras uno cuadrado): un
    descuadre (bruto o de proyección) no debe dejar NINGÚN fichero numérico importable a mano (Codex B3)."""
    for nombre in (f"modelo200_contable_{ejercicio}.xml", "estados_contables_aeat.xlsx", "agrupado_4d.xlsx"):
        fp = out / nombre
        if fp.exists():
            fp.unlink()
            man.setdefault("limpiados", []).append(nombre)
    for fp in list(out.glob("SyS_A3_*.xlsx")):
        fp.unlink()
        man.setdefault("limpiados", []).append(fp.name)


def run(docs, outdir, empresa="", ejercicio="2025", maestro=None, mapeo=None, catalogo=None, xsd=None):
    out = Path(outdir); out.mkdir(parents=True, exist_ok=True)
    camp = campaign.resolve(ejercicio)                 # versionado por campaña: el ejercicio resuelve todo
    maestro = maestro or camp["maestro"]
    mapeo = mapeo or camp["mapeo"]
    catalogo = catalogo or camp["catalogo"]
    xsd = xsd or camp["xsd"]
    xsd_campos = camp["xsd_campos"]
    man = dict(empresa=empresa, ejercicio=str(ejercicio),
               campania=dict(dir=camp["dir"], provisional=camp["provisional"]),
               generado=datetime.now(timezone.utc).isoformat(timespec="seconds"),
               documentos=[], etapas={}, salidas=[], estado="en_proceso")

    clasif = [(d, *harness.detectar_clase(d)) for d in docs]
    man["documentos"] = [dict(fichero=Path(d).name, clase=c, motor=m) for d, c, m in clasif]

    # --- 1) Sumas y Saldos -> canónico ---
    sys_doc = next((d for d, c, m in clasif if c == "sumas_y_saldos"), None)
    canonico_csv = None
    if sys_doc:
        filas = motor_sys.leer_filas(sys_doc)
        mae = motor_sys.cargar_maestro(maestro)
        hidx, col, grupos, revision, lineage, n = motor_sys.procesar(filas, mae)
        s = motor_sys.escribir(out, empresa, ejercicio, sys_doc, hidx, col, grupos, revision, lineage, n)
        canonico_csv = str(out / "agrupado_4d.csv")
        man["etapas"]["motor_sys"] = dict(filas=s["n"], cuentas4d=s["grupos"], revision=s["rev"],
                                          cuadra_debe_haber=abs(s["td"] - s["th"]) < 0.01,
                                          cuadra_deudor_acreedor=abs(s["sd"] - s["sa"]) < 0.01)
        man["salidas"] += ["agrupado_4d.csv", "validacion.md", "resumen_cuadres.md"]
        # GATE FAIL-CLOSED de cuadre (B3 / EPIC B), céntimos exactos tol=0, ANTES de emitir NINGÚN artefacto
        # numérico (A3 xlsx, XML, XLS estados): ninguna ruta (CLI/pipeline incluida) emite AEAT de un
        # descuadre, ni de 0,01. El A3 xlsx también es número-importable, por eso va tras el gate.
        _rec = reconciliador.reconciliar(builder.cargar_canonico(canonico_csv))
        man["etapas"]["reconciliador"] = {"ok": _rec["ok"], "errores": _rec["errores"],
                                          "avisos": _rec.get("avisos", [])}
        if not _rec["ok"]:
            man["estado"] = "revisar"
            canonico_csv = None   # no continuar: no se emite A3 xlsx ni XML/XLS de un descuadre
            _limpiar_aeat_stale(out, ejercicio, man)
        else:
            # fichero de importación A3 (xlsx) — solo si cuadra (gate B3) + fail-closed propio del emisor
            a3 = motor_sys.escribir_a3_xlsx(out, empresa, ejercicio, grupos)
            man["etapas"]["a3_xlsx"] = {k: a3[k] for k in ("ok", "control", "avisos") if k in a3}
            if a3["ok"]:
                man["salidas"] += ["agrupado_4d.xlsx"]
            else:
                man["etapas"]["a3_xlsx"]["motivo"] = a3["motivo"]

    # --- 2) canónico -> builder (XML + XLS) ---
    if canonico_csv:
        try:
            # B3: builder.build levanta si la PROYECCIÓN AEAT descuadra (00180≠00252 o no_map) aunque el SyS
            # (raw) cuadre. En ese caso NO se emite el XML/XLS AEAT (el A3=SyS, raw cuadrado, sí salió).
            cuadre = builder.build(canonico_csv, mapeo, catalogo, out, empresa, ejercicio, xsd_campos)
        except reconciliador.CanonicoDescuadradoError as e:
            man["estado"] = "revisar"
            man["etapas"]["builder"] = {"emitido": False, "motivo": str(e)}
            _limpiar_aeat_stale(out, ejercicio, man)   # B3: tampoco dejar stale tras fallo de proyección
        else:
            man["etapas"]["builder"] = dict(casillas=cuadre["n_casillas"], cuadra=cuadre["cuadra"],
                                            total_activo=cuadre["total_activo"],
                                            total_pnpasivo=cuadre["total_pnpasivo"],
                                            resultado=cuadre["resultado"], sin_mapear=cuadre["no_map"])
            man["salidas"] += [f"modelo200_contable_{ejercicio}.xml", "estados_contables_aeat.xlsx",
                               "casillas.csv", "lineage_casillas.csv", "cuadres_builder.md"]
            # --- 3) validación ---
            xml_path = str(out / f"modelo200_contable_{ejercicio}.xml")
            res = validador.validar(xml_path, catalogo, xsd)
            validador.escribir(res, out / "validacion_xml.md")
            man["etapas"]["validacion"] = dict(apto=res["ok"], casillas=res["n"], xsd=res["xsd"],
                                               errores=res["errores"][:10])
            man["salidas"].append("validacion_xml.md")

    # --- 4) Declaración previa (determinista) ---
    prev_doc = next((d for d, c, m in clasif if c == "declaracion_previa" and d.lower().endswith(".xml")), None)
    if prev_doc:
        prev = pdp.parse_xml(prev_doc)
        difs = pdp.comparar(prev, str(out / "casillas.csv")) if canonico_csv else []
        (out / "comparativa_previo.json").write_text(json.dumps(
            dict(ejercicio_previo=prev["ejercicio"], casillas_previo=prev["casillas"], diferencias=difs),
            ensure_ascii=False, indent=1), encoding="utf-8")
        man["etapas"]["declaracion_previa"] = dict(ejercicio=prev["ejercicio"], casillas=len(prev["casillas"]))
        man["salidas"].append("comparativa_previo.json")

    # --- 5) Cuentas anuales (inferencia, informativo) ---
    ccaa_doc = next((d for d, c, m in clasif if c == "cuentas_anuales"), None)
    if ccaa_doc:
        texto, motor = extractor_ccaa.extraer_texto(ccaa_doc, 40)
        cands = extractor_ccaa.candidatos(texto)
        import csv as _csv
        with open(out / "ccaa_borrador.csv", "w", encoding="utf-8-sig", newline="") as f:
            w = _csv.writer(f, delimiter=";")
            w.writerow(["etiqueta_detectada", "importe", "casilla_propuesta", "confianza", "nota"])
            for et, val in cands:
                w.writerow([et, round(val, 2), "", "baja", "requiere revisión humana o usar SyS"])
        man["etapas"]["cuentas_anuales"] = dict(extractor=motor, candidatos=len(cands),
                                                nota="borrador informativo; vía cuadrada = SyS")
        man["salidas"].append("ccaa_borrador.csv")

    # estado global
    apto = man["etapas"].get("validacion", {}).get("apto", False)
    man["estado"] = "ok" if apto else ("sin_sumas_y_saldos" if not sys_doc else "revisar")
    (out / "manifest.json").write_text(json.dumps(man, ensure_ascii=False, indent=1), encoding="utf-8")
    _informe(out, man)
    return man

def _informe(out, man):
    e = man["etapas"]
    md = [f"# Informe del pipeline · {man['empresa']} {man['ejercicio']}", "",
          f"Generado: {man['generado']}  ·  Estado: **{man['estado']}**", "",
          "## Documentos", ""]
    for d in man["documentos"]:
        md.append(f"- `{d['fichero']}` → {d['clase']} ({d['motor']})")
    md += ["", "## Etapas", ""]
    if "motor_sys" in e:
        m = e["motor_sys"]
        md.append(f"- **Motor SyS**: {m['filas']} filas → {m['cuentas4d']} cuentas 4d · "
                  f"revisión {m['revision']} · Debe=Haber {'✅' if m['cuadra_debe_haber'] else '🔴'} · "
                  f"deudor=acreedor {'✅' if m['cuadra_deudor_acreedor'] else '🔴'}")
    if "builder" in e:
        m = e["builder"]
        if m.get("emitido") is False:   # B3: proyección AEAT descuadrada -> no se emitió el XML/XLS
            md.append(f"- **Builder**: 🔴 NO emitido — {m.get('motivo', 'proyección descuadrada')}")
        else:
            md.append(f"- **Builder**: {m['casillas']} casillas · cuadre {'✅' if m['cuadra'] else '🔴'} · "
                      f"resultado {m['resultado']:.2f}")
    if "validacion" in e:
        m = e["validacion"]
        md.append(f"- **Validación XML**: {'✅ APTO' if m['apto'] else '🔴 NO APTO'} · XSD: {m['xsd']}")
    if "declaracion_previa" in e:
        m = e["declaracion_previa"]
        md.append(f"- **Declaración previa**: ejercicio {m['ejercicio']} · {m['casillas']} casillas")
    if "cuentas_anuales" in e:
        m = e["cuentas_anuales"]
        md.append(f"- **Cuentas anuales (inferencia)**: {m['candidatos']} candidatos ({m['extractor']}) — {m['nota']}")
    md += ["", "## Salidas", ""] + [f"- `{s}`" for s in man["salidas"]]
    (out / "INFORME.md").write_text("\n".join(md) + "\n", encoding="utf-8")

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--docs", nargs="+", required=True)
    ap.add_argument("--outdir", required=True)
    ap.add_argument("--empresa", default="")
    ap.add_argument("--ejercicio", default="2025")
    ap.add_argument("--xsd", default=None)
    a = ap.parse_args()
    man = run(a.docs, a.outdir, a.empresa, a.ejercicio, xsd=a.xsd)
    print(f"PIPELINE · estado={man['estado']}")
    for k, v in man["etapas"].items():
        print(f"  {k}: {v}")

if __name__ == "__main__":
    main()
