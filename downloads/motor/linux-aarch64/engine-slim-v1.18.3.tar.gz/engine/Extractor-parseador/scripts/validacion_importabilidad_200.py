#!/usr/bin/env python3
"""Capa de validacion de importabilidad del Modelo 200.

Esta capa no sustituye al DR ni al importador real de Sociedades WEB. Ordena los controles locales que hemos
aprendido en importaciones reales:

- estructura fisica DR;
- autocontrol historico;
- errores pegados desde Sociedades WEB/Open;
- reglas comunes de liquidacion, DID, B.2 y gastos financieros.

La salida es un informe estructurado apto para flujo HITL. Las correcciones nunca se aplican aqui: este modulo
solo diagnostica y clasifica cada hallazgo como `auto_seguro`, `hitl_requerido` o `no_local`.
"""
from __future__ import annotations

import argparse
import json
import os
import re
import sys
import unicodedata
from decimal import Decimal, ROUND_HALF_UP
from pathlib import Path
from typing import Any

import dr200
import modelo200_parser as mp


TOL = Decimal("0.01")
GF_FLOOR = Decimal("1000000.00")
PERCENT_CASILLAS = {"00558", "00625", "00626", "00627", "00628", "00629"}

PAGE_LABELS = {
    "01": "DP200001",
    "01B": "DP200001B",
    "02": "DP200002",
    "02B": "DP200002B",
    "03": "DP200003",
    "04": "DP200004",
    "05": "DP200005",
    "06": "DP200006",
    "07": "DP200007",
    "08": "DP200008",
    "09": "DP200009",
    "10": "DP200010",
    "11": "DP200011",
    "12": "DP200012",
    "13": "DP200013",
    "14": "DP200014",
    "14BIS": "DP200014B",
    "14B": "DP200014B",
    "15": "DP200015",
    "20": "DP200020",
    "20BIS": "DP200020B",
    "20B": "DP200020B",
    "20D": "DP200020D",
    "DID": "DP200DID",
}

CODE_TO_CASILLA = {
    "EMAL501": "00501",
    "EMAL00501": "00501",
    "EMALP13_2": "00550",
    "EMAL500_12": "00500",
    "E25400417": "00417",
    "E25400418": "00418",
    "E25400552": "00552",
    "E25401330": "01330",
    "EPOR00558": "00558",
    "E25400562": "00562",
    "E25400582": "00582",
    "E25400592": "00592",
    "E25400599": "00599",
    "E25400611": "00611",
    "E25401586": "01586",
    "E25400621": "00621",
    "E25402369": "02369",
}

POST_IMPORT_FISCAL_CATEGORIES = {
    "correcciones_liquidacion",
    "foral",
    "gastos_financieros",
    "tipo_declaracion",
}
POST_IMPORT_FISCAL_CODES = {
    "EPOR00558",
    "E25400417",
    "E25400418",
    "E25400420",
    "E25400426",
    "E25400474",
    "E25400476",
    "E25400494",
    "E25400496",
    "E25400600",
    "E25400612",
    "E25400619",
    "E25400622",
    "E25401214",
    "E25401216",
    "E25401249",
    "E25401260",
    "E25401587",
    "E25401624",
    "E25401629",
    "E25402301",
    "E25402303",
    "E25402306",
    "E25402308",
    "E25402310",
    "E25402369",
    "FORAL-00599",
    "FORAL-00600",
    "FORAL-00602",
    "FORAL-00604",
    "FORAL-00606",
    "FORAL-00622",
    "FORAL-PAG26-AUSENTE",
    "FORAL-PCT-100",
    "FORAL-PCT-VOLUMENES",
    "FORAL-SIN-00028",
    "INT-GF-RE",
    "15525",
    "22820",
    "22880",
    "22890",
    "22925",
    "22940",
    "35100",
    "9417",
    "9421",
    "9460",
    "9461",
}

ERROR_CODE_RE = re.compile(
    r"^(?:FRECH|EMAL[A-Z0-9_]*|E254[A-Z0-9_]*|EPOR[A-Z0-9_]*|DID[0-9A-Z][A-Z0-9_]*|"
    r"EMALEJER[A-Z0-9_]*|EMR[A-Z0-9_]*|[0-9]{3,7})$"
)
OPEN_TAG_RE = re.compile(r"<(T200[0-9A-Z]+)>")


def _norm(text: str | None) -> str:
    raw = text or ""
    return unicodedata.normalize("NFKD", raw).encode("ascii", "ignore").decode("ascii").lower()


def _normalizar_numero(value: Any) -> str:
    s = str(value if value is not None else "0").strip()
    if not s:
        return "0"
    s = s.replace(" ", "")
    if "," in s:
        s = s.replace(".", "").replace(",", ".")
    elif s.count(".") > 1:
        parts = s.split(".")
        s = "".join(parts[:-1]) + "." + parts[-1]
    s = re.sub(r"[^0-9.\-]", "", s)
    return s or "0"


def dec(value: Any) -> Decimal:
    try:
        return Decimal(_normalizar_numero(value)).quantize(TOL, rounding=ROUND_HALF_UP)
    except Exception:
        return Decimal("0.00")


def money(value: Any) -> str:
    return f"{dec(value):.2f}"


def eq(a: Any, b: Any) -> bool:
    return abs(dec(a) - dec(b)) <= TOL


def _looks_like_x100(calculado: Any, importado: Any) -> bool:
    calc = dec(calculado)
    imp = dec(importado)
    if not calc:
        return False
    return abs(imp - (calc * Decimal("100"))) <= max(Decimal("1.00"), abs(calc) * Decimal("0.001"))


def _casilla_from_code(code: str, desc: str = "") -> str:
    if code in CODE_TO_CASILLA:
        return CODE_TO_CASILLA[code]
    m = re.search(r"(?:partida|casilla)\s+\[?([0-9]{5})\]?", desc, re.I)
    if m:
        return m.group(1)
    m = re.search(r"(?:E254|EPOR|EMAL)([0-9]{5})", code)
    if m:
        return m.group(1)
    return ""


def page_for_error_label(label: str) -> str:
    clean = (label or "").strip().upper()
    return PAGE_LABELS.get(clean, "")


def parsear_errores_aeat(texto: str | None) -> list[dict[str, Any]]:
    """Extrae codigos, pagina, casilla y valores desde el texto pegado de Sociedades WEB/Open."""
    if not texto:
        return []
    lines = [line.strip() for line in texto.splitlines() if line.strip()]
    out: list[dict[str, Any]] = []
    for i, line in enumerate(lines):
        code = line.strip()
        if not ERROR_CODE_RE.fullmatch(code):
            continue
        severidad = "error"
        icono_seen = False
        for j in range(i - 1, max(-1, i - 6), -1):
            upper = lines[j].upper()
            if upper == "ICONO - AVISO":
                severidad = "aviso"
                icono_seen = True
                break
            if upper == "ICONO - ERROR":
                severidad = "error"
                icono_seen = True
                break
        if re.fullmatch(r"[0-9]{3,5}", code) and not icono_seen:
            continue
        label = ""
        for j in range(i - 1, max(-1, i - 4), -1):
            if lines[j].upper() not in {"ICONO - ERROR", "ICONO - AVISO", "-"}:
                label = lines[j]
                break
        desc = lines[i + 1] if i + 1 < len(lines) else ""
        casilla = _casilla_from_code(code, desc)
        m_calc = re.search(r"calculado un valor:\s*([-+0-9.,]+)", desc, re.I)
        m_imp = re.search(r"importar es:\s*([-+0-9.,]+)", desc, re.I)
        out.append({
            "codigo": code,
            "pagina_label": label,
            "pagina": page_for_error_label(label),
            "casilla": casilla,
            "descripcion": desc,
            "severidad": severidad,
            "calculado_aeat": money(m_calc.group(1)) if m_calc else None,
            "importado_aeat": money(m_imp.group(1)) if m_imp else None,
        })
    return out


def values_by_page(parsed: dict) -> dict[str, dict[str, Decimal]]:
    cpp = mp.casillas_por_pagina(parsed, significant_only=False)
    out: dict[str, dict[str, Decimal]] = {}
    for page, casillas in cpp.items():
        out[page] = {}
        for casilla, entries in casillas.items():
            out[page][casilla] = dec(entries[0]["valor"] if entries else "0")
    return out


def get(vals: dict[str, dict[str, Decimal]], page: str, casilla: str) -> Decimal:
    return vals.get(page, {}).get(casilla, Decimal("0.00"))


def pct_get(vals: dict[str, dict[str, Decimal]], page: str, casilla: str) -> Decimal:
    """Porcentajes DR codificados como `Num` sin coma: 2500 = 25,00."""
    value = get(vals, page, casilla)
    if page == "DP200026" and casilla in {"00625", "00626", "00627", "00628", "00629"}:
        return (value / Decimal("100")).quantize(TOL, rounding=ROUND_HALF_UP)
    if casilla in PERCENT_CASILLAS and abs(value) > Decimal("100.00"):
        return (value / Decimal("100")).quantize(TOL, rounding=ROUND_HALF_UP)
    return value


def _field(parsed: dict, page: str, num: int | str) -> dict[str, Any] | None:
    snum = str(num)
    for rec in parsed.get("records", []):
        if rec.get("page") != page:
            continue
        for f in rec.get("fields", []):
            if str(f.get("num")) == snum:
                return f
    return None


def _field_value(parsed: dict, page: str, num: int | str) -> str:
    f = _field(parsed, page, num)
    return str(f.get("valor") if f else "").strip()


def _field_raw(parsed: dict, page: str, num: int | str) -> str:
    f = _field(parsed, page, num)
    return str(f.get("raw") if f else "").strip()


def _is_numeric_field(field: dict[str, Any]) -> bool:
    return (field.get("tipo") or "").strip().lower().startswith("num") or (field.get("tipo") or "").strip().lower() == "n"


def _field_significant(field: dict[str, Any]) -> bool:
    raw = field.get("raw") or ""
    if not raw.strip():
        return False
    if _is_numeric_field(field):
        digits = re.sub(r"\D", "", raw)
        return bool(digits) and int(digits) != 0
    return bool(raw.strip())


def _page_field_significant(parsed: dict, page: str, num: int | str) -> bool:
    field = _field(parsed, page, num)
    return bool(field and _field_significant(field))


def _missing_fields(parsed: dict, page: str, nums: list[int]) -> list[int]:
    return [num for num in nums if not _page_field_significant(parsed, page, num)]


def _is_post_import_fiscal(item: dict[str, Any]) -> bool:
    code = str(item.get("codigo") or "")
    category = str(item.get("categoria") or "")
    # OpenWeb rejects these before any fiscal review is possible: if 00028 is marked, the physical .200 must
    # include page 26. The content of the repartition is HITL, but the page requirement is an importability gate.
    if code in {"FORAL-PAG26-AUSENTE", "15525"}:
        return False
    if code.startswith("FORAL-P26-"):
        return False
    if category in POST_IMPORT_FISCAL_CATEGORIES or code in POST_IMPORT_FISCAL_CODES:
        return True
    # Hallazgos del AUTOCONTROL (categoria="autocontrol") que son FISCALES por su PÁGINA: la limitación de
    # gastos financieros (art. 16 LIS → pág. 20, DP200020*) y la tributación foral (pág. 26, DP200026*) son
    # criterio fiscal del abogado (Fase 2), no estructura de importabilidad. Sin esto, p.ej. la regla GF
    # `22895` (01257≤01248−02369) tumbaba `importabilidad_probable` en el caso GF≈0 / suelo 1M (la mayoría de
    # sociedades) — un falso bloqueo pre-import. Se difieren a Fase 2 igual que los homónimos del validador.
    # Un error REAL de Open en esas páginas SÍ cuenta: `_apply_phase_policy` lo bloquea vía `aeat_evidence`.
    pagina = str(item.get("pagina") or "")
    if pagina.startswith("DP200020") or pagina.startswith("DP200026"):
        return True
    return False


def _apply_phase_policy(item: dict[str, Any], *, aeat_evidence: bool = False) -> dict[str, Any]:
    """Etiqueta fase y gate de importabilidad sin borrar el contrato historico `bloqueante`.

    `bloqueante` conserva la severidad fiscal/operativa antigua. El gate de pre-import usa
    `bloquea_importacion`: los pendientes fiscales locales se difieren a Fase 2; un error real de AEAT/Open
    sigue evidenciando que ese fichero concreto no importo.
    """
    if _is_post_import_fiscal(item):
        item["fase"] = "post_import_fiscal"
        item.setdefault(
            "nota_fase",
            "Diferir a Fase 2: completar en Sociedades WEB despues de una importacion positiva.",
        )
        if not aeat_evidence:
            item["bloqueante_fiscal"] = bool(item.get("bloqueante", item.get("severidad") == "bloqueante"))
            item["bloqueante"] = False
            if item.get("severidad") == "bloqueante":
                item["severidad"] = "pendiente_fiscal"
        item["bloquea_importacion"] = bool(aeat_evidence and item.get("bloqueante", item.get("severidad") != "aviso"))
    else:
        item.setdefault("fase", "pre_import")
        item["bloquea_importacion"] = bool(item.get("bloqueante", True))
    if item.get("severidad") == "aviso":
        item["bloquea_importacion"] = False
    return item


def add_finding(findings: list[dict[str, Any]], **kwargs: Any) -> None:
    base = {
        "codigo": "IMPORT200",
        "severidad": "bloqueante",
        "categoria": "importabilidad",
        "pagina": "",
        "casilla": "",
        "valor_200": "",
        "esperado_local": "",
        "mensaje": "",
        "fuente": "validacion_importabilidad_200.py",
        "modo": "hitl_requerido",
        "bloqueante": True,
        "fase": "pre_import",
        "bloquea_importacion": True,
        "accion_propuesta": "",
    }
    base.update(kwargs)
    if base["severidad"] != "bloqueante":
        base["bloqueante"] = False
    _apply_phase_policy(base)
    findings.append(base)


def _dedupe_findings(findings: list[dict[str, Any]]) -> list[dict[str, Any]]:
    seen: set[tuple[str, str, str]] = set()
    out: list[dict[str, Any]] = []
    for h in findings:
        key = (h.get("codigo") or "", h.get("pagina") or "", h.get("casilla") or "")
        if key in seen:
            continue
        seen.add(key)
        out.append(h)
    return out


def validar_estructura(texto: str, dr: dict, parsed: dict | None = None) -> list[dict[str, Any]]:
    parsed = parsed or mp.parse_text(texto, dr, include_fields=True)
    structure: list[dict[str, Any]] = []
    page_by_tag = mp.tag_to_page(dr)
    wrapper_tag = (parsed.get("meta") or {}).get("tag")
    allowed = set(page_by_tag)
    if wrapper_tag:
        allowed.add(wrapper_tag)
    for tag in OPEN_TAG_RE.findall(texto):
        if tag not in allowed:
            structure.append({
                "codigo": "DR-TAG-DESCONOCIDO",
                "tag": tag,
                "mensaje": f"Etiqueta {tag} no reconocida por el DR cargado.",
                "bloqueante": True,
            })
    for rec in parsed.get("records", []):
        fields = [c for c in dr.get(rec["page"], []) if c.get("posicion") and c.get("longitud")]
        expected_len = max(c["posicion"] + c["longitud"] - 1 for c in fields) if fields else 0
        if rec["record_len"] != expected_len or not rec.get("closed"):
            structure.append({
                "codigo": "DR-LONGITUD",
                "pagina": rec["page"],
                "tag": rec["tag"],
                "longitud_esperada": expected_len,
                "longitud_real": rec["record_len"],
                "cerrado": rec.get("closed"),
                "mensaje": "Registro con longitud o cierre distinto del DR.",
                "bloqueante": True,
            })
    return structure


def _autocontrol_to_findings(violaciones: list[dict[str, Any]]) -> list[dict[str, Any]]:
    findings: list[dict[str, Any]] = []
    for v in violaciones:
        code = v.get("error_aeat") or "AUTOCONTROL"
        code = {"EMAL501": "EMAL00501"}.get(code, code)
        casilla = _casilla_from_code(code, v.get("detalle") or v.get("regla") or "")
        bloqueante = bool(v.get("bloqueante", True))
        add_finding(
            findings,
            codigo=code,
            severidad="bloqueante" if bloqueante else "aviso",
            categoria="autocontrol",
            pagina=v.get("pagina") or "",
            casilla=casilla,
            valor_200="",
            esperado_local="",
            mensaje=f"{v.get('regla') or ''}: {v.get('detalle') or ''}".strip(": "),
            fuente="autocontrol_200.py",
            modo="auto_seguro" if bloqueante else "hitl_requerido",
            bloqueante=bloqueante,
            accion_propuesta="Reemitir respetando la formula local antes de importar."
            if bloqueante else "Revisar criterio fiscal antes de firmar.",
        )
    return findings


def _sum_correcciones(dr: dict, vals: dict[str, dict[str, Decimal]], lado: str) -> Decimal:
    total = Decimal("0.00")
    excluded = {"00500", "00501", "00301", "00302", "00004", "00417", "00418"}
    lado_norm = "aument" if lado == "aumento" else "disminuc"
    for page in ("DP200012", "DP200013"):
        for campo in dr.get(page, []):
            cas = campo.get("casilla")
            if not cas or cas in excluded:
                continue
            desc = _norm(campo.get("descripcion"))
            if "liquidacion" not in desc or lado_norm not in desc:
                continue
            total += get(vals, page, cas)
    return total.quantize(TOL, rounding=ROUND_HALF_UP)


def check_liquidacion_comun(
    vals: dict[str, dict[str, Decimal]],
    dr: dict,
    present_pages: set[str],
) -> list[dict[str, Any]]:
    findings: list[dict[str, Any]] = []
    v500 = get(vals, "DP200012", "00500")
    if "DP200012" not in present_pages:
        return findings

    v619 = get(vals, "DP200014B", "00619")
    if v619 and (get(vals, "DP200001", "00009") or get(vals, "DP200001", "00010")):
        add_finding(
            findings,
            codigo="E25400619",
            categoria="grupo_fiscal",
            pagina="DP200014B",
            casilla="00619",
            valor_200=money(v619),
            esperado_local="vacio/cero en el 200 individual del grupo fiscal",
            mensaje="La cuota minima art.30bis no debe emitirse en el 200 individual de un grupo fiscal.",
            fuente="Sociedades WEB Open / import GRUMASA 2025",
            modo="auto_seguro",
            accion_propuesta="Eliminar 00619; la cuota minima, si procede, se trata en la liquidacion del grupo.",
        )

    # EMAL500_12: resultado de PyG importado previamente no coincide con la pagina 12.
    for source_page in ("DP200008", "DP200009", "DP200030", "DP200040", "DP200046", "DP200051"):
        if source_page in present_pages:
            src = get(vals, source_page, "00500")
            if (v500 or src) and not eq(v500, src):
                add_finding(
                    findings,
                    codigo="EMAL500_12",
                    categoria="contabilidad_liquidacion",
                    pagina="DP200012",
                    casilla="00500",
                    valor_200=money(v500),
                    esperado_local=money(src),
                    mensaje=f"00500 de liquidacion no coincide con el resultado PyG importado en {source_page}.",
                    fuente="Sociedades WEB / Manual Cap. 5",
                    modo="hitl_requerido",
                    accion_propuesta="Cuadrar estados contables y pagina 12; no parchear solo la liquidacion.",
                )
            break

    v301 = get(vals, "DP200012", "00301")
    v302 = get(vals, "DP200012", "00302")
    v004 = get(vals, "DP200012", "00004")
    exp501 = (v500 + v301 - v302 + v004).quantize(TOL, rounding=ROUND_HALF_UP)
    if (v500 or get(vals, "DP200012", "00501")) and not eq(get(vals, "DP200012", "00501"), exp501):
        add_finding(
            findings,
            codigo="EMAL00501",
            categoria="liquidacion",
            pagina="DP200012",
            casilla="00501",
            valor_200=money(get(vals, "DP200012", "00501")),
            esperado_local=money(exp501),
            mensaje="00501 debe ser 00500 + 00301 - 00302 + 00004.",
            fuente="Manual Cap. 5",
            modo="auto_seguro",
            accion_propuesta="Recalcular 00501 desde sus determinantes DR.",
        )

    suma_aum = _sum_correcciones(dr, vals, "aumento")
    suma_dis = _sum_correcciones(dr, vals, "disminucion")
    v417 = get(vals, "DP200013", "00417")
    v418 = get(vals, "DP200013", "00418")
    if (v417 or suma_aum) and not eq(v417, suma_aum):
        add_finding(
            findings,
            codigo="E25400417",
            categoria="calculada_no_importable",
            pagina="DP200013",
            casilla="00417",
            valor_200=money(v417),
            esperado_local=money(suma_aum),
            mensaje="00417 es total de aumentos. Si se rellena sin detalle, Open lo recalcula o rechaza.",
            fuente="DR pagina 13 / experiencia ARIOSO",
            modo="hitl_requerido",
            accion_propuesta="Mover el importe a la casilla especifica de ajuste; si es gasto IS, usar 00301.",
        )
    if (v418 or suma_dis) and not eq(v418, suma_dis):
        add_finding(
            findings,
            codigo="E25400418",
            categoria="calculada_no_importable",
            pagina="DP200013",
            casilla="00418",
            valor_200=money(v418),
            esperado_local=money(suma_dis),
            mensaje="00418 es total de disminuciones. Debe venir soportado por detalle.",
            fuente="DR pagina 13",
            modo="hitl_requerido",
            accion_propuesta="Mover el importe a la casilla especifica de disminucion.",
        )

    exp550 = (exp501 + v417 - v418).quantize(TOL, rounding=ROUND_HALF_UP)
    if (get(vals, "DP200014", "00550") or exp550) and not eq(get(vals, "DP200014", "00550"), exp550):
        add_finding(
            findings,
            codigo="EMALP13_2",
            categoria="liquidacion",
            pagina="DP200014",
            casilla="00550",
            valor_200=money(get(vals, "DP200014", "00550")),
            esperado_local=money(exp550),
            mensaje="00550 debe ser 00501 + 00417 - 00418, salvo claves/regimenes especiales.",
            fuente="Manual Cap. 5",
            modo="auto_seguro",
            accion_propuesta="Recalcular la cascada, no parchear solo 00550.",
        )

    exp552 = (exp550 - get(vals, "DP200014", "01032") - get(vals, "DP200014", "00547")).quantize(TOL, rounding=ROUND_HALF_UP)
    if (get(vals, "DP200014", "00552") or exp552) and not eq(get(vals, "DP200014", "00552"), exp552):
        add_finding(
            findings,
            codigo="E25400552",
            categoria="liquidacion",
            pagina="DP200014",
            casilla="00552",
            valor_200=money(get(vals, "DP200014", "00552")),
            esperado_local=money(exp552),
            mensaje="00552 debe seguir 00550 - 01032 - 00547.",
            fuente="Manual Cap. 5",
            modo="auto_seguro",
            accion_propuesta="Recalcular desde BI previa, reserva de capitalizacion y BINs.",
        )

    exp1330 = (exp552 + get(vals, "DP200014", "01033") - get(vals, "DP200014", "01034")).quantize(TOL, rounding=ROUND_HALF_UP)
    if (get(vals, "DP200014", "01330") or exp1330) and not eq(get(vals, "DP200014", "01330"), exp1330):
        add_finding(
            findings,
            codigo="E25401330",
            categoria="liquidacion",
            pagina="DP200014",
            casilla="01330",
            valor_200=money(get(vals, "DP200014", "01330")),
            esperado_local=money(exp1330),
            mensaje="01330 debe recoger la base imponible tras reserva de nivelacion.",
            fuente="Manual Cap. 5",
            modo="auto_seguro",
            accion_propuesta="Recalcular 01330 desde 00552, 01033 y 01034.",
        )

    current_tipo = pct_get(vals, "DP200014", "00558")
    tipo = current_tipo if current_tipo else Decimal("25.00")
    if exp1330 > 0 and not current_tipo:
        add_finding(
            findings,
            codigo="EPOR00558",
            categoria="liquidacion",
            pagina="DP200014",
            casilla="00558",
            valor_200="0.00",
            esperado_local="25.00",
            mensaje="Tipo de gravamen a cero con base positiva. 25% es el caso comun; confirmar regimen.",
            fuente="Manual Cap. 6",
            modo="hitl_requerido",
            accion_propuesta="Confirmar regimen/tipo y emitir 00558.",
        )
    exp562 = Decimal("0.00") if exp1330 <= 0 else (exp1330 * tipo / Decimal("100")).quantize(TOL, rounding=ROUND_HALF_UP)
    if (get(vals, "DP200014", "00562") or exp562) and not eq(get(vals, "DP200014", "00562"), exp562):
        add_finding(
            findings,
            codigo="E25400562",
            categoria="liquidacion",
            pagina="DP200014",
            casilla="00562",
            valor_200=money(get(vals, "DP200014", "00562")),
            esperado_local=money(exp562),
            mensaje="00562 debe ser base positiva por tipo de gravamen.",
            fuente="Manual Cap. 6",
            modo="hitl_requerido",
            accion_propuesta="Confirmar tipo y recalcular cuota integra.",
        )

    exp582 = exp562
    if (get(vals, "DP200014", "00582") or exp582) and not eq(get(vals, "DP200014", "00582"), exp582):
        add_finding(
            findings,
            codigo="E25400582",
            categoria="liquidacion",
            pagina="DP200014",
            casilla="00582",
            valor_200=money(get(vals, "DP200014", "00582")),
            esperado_local=money(exp582),
            mensaje="00582 se aparta de la cuota integra ajustada comun.",
            fuente="Manual Cap. 6",
            modo="hitl_requerido",
            accion_propuesta="Confirmar bonificaciones/DDI antes de parchear.",
        )

    exp592 = exp582
    if (get(vals, "DP200014B", "00592") or exp592) and not eq(get(vals, "DP200014B", "00592"), exp592):
        add_finding(
            findings,
            codigo="E25400592",
            categoria="liquidacion",
            pagina="DP200014B",
            casilla="00592",
            valor_200=money(get(vals, "DP200014B", "00592")),
            esperado_local=money(exp592),
            mensaje="00592 se aparta de la cuota liquida comun.",
            fuente="Manual Cap. 6",
            modo="hitl_requerido",
            accion_propuesta="Confirmar deducciones y cuota minima antes de parchear.",
        )

    if get(vals, "DP200001", "00028"):
        # En tributacion conjunta Estado/Foral, OpenWeb no aplica la cascada comun solo-Estado a
        # 00599/00611/01586/00621. El reparto se valida en la pagina 26 y en `check_foral`.
        return findings

    pct_estado = pct_get(vals, "DP200026", "00625") if "DP200026" in present_pages else Decimal("100.00")
    retenciones = get(vals, "DP200014B", "01766") + get(vals, "DP200014B", "01784")
    exp599 = ((exp592 - retenciones) * pct_estado / Decimal("100")).quantize(TOL, rounding=ROUND_HALF_UP)
    if (get(vals, "DP200014B", "00599") or exp599) and not eq(get(vals, "DP200014B", "00599"), exp599):
        add_finding(
            findings,
            codigo="E25400599",
            categoria="liquidacion",
            pagina="DP200014B",
            casilla="00599",
            valor_200=money(get(vals, "DP200014B", "00599")),
            esperado_local=money(exp599),
            mensaje="00599 debe seguir cuota liquida, retenciones y porcentaje Estado.",
            fuente="Manual Cap. 6",
            modo="hitl_requerido",
            accion_propuesta="Confirmar retenciones/forales y recalcular cuota del ejercicio.",
        )

    pagos = get(vals, "DP200014B", "00601") + get(vals, "DP200014B", "00603") + get(vals, "DP200014B", "00605")
    exp611 = (exp599 - pagos).quantize(TOL, rounding=ROUND_HALF_UP)
    if (get(vals, "DP200014B", "00611") or exp611) and not eq(get(vals, "DP200014B", "00611"), exp611):
        add_finding(
            findings,
            codigo="E25400611",
            categoria="liquidacion",
            pagina="DP200014B",
            casilla="00611",
            valor_200=money(get(vals, "DP200014B", "00611")),
            esperado_local=money(exp611),
            mensaje="00611 debe ser 00599 menos pagos fraccionados Estado.",
            fuente="Manual Cap. 6 / datos M202",
            modo="hitl_requerido",
            accion_propuesta="Revisar pagos fraccionados 00601/00603/00605 y recalcular.",
        )

    exp1586 = (
        exp611
        + get(vals, "DP200014B", "00615")
        + get(vals, "DP200014B", "00633")
        + get(vals, "DP200014B", "00617")
        - get(vals, "DP200014B", "00083")
        - get(vals, "DP200014B", "01042")
        - get(vals, "DP200014B", "01893")
    ).quantize(TOL, rounding=ROUND_HALF_UP)
    for casilla, codigo in (("01586", "E25401586"), ("00621", "E25400621")):
        if (get(vals, "DP200014B", casilla) or exp1586) and not eq(get(vals, "DP200014B", casilla), exp1586):
            add_finding(
                findings,
                codigo=codigo,
                categoria="liquidacion",
                pagina="DP200014B",
                casilla=casilla,
                valor_200=money(get(vals, "DP200014B", casilla)),
                esperado_local=money(exp1586),
                mensaje=f"{casilla} debe seguir la cascada final de autoliquidacion.",
                fuente="Manual Cap. 6",
                modo="hitl_requerido",
                accion_propuesta="Recalcular resultado de autoliquidacion y DID.",
            )
    return findings


def check_formales(
    parsed: dict,
    vals: dict[str, dict[str, Decimal]],
    present_pages: set[str],
) -> list[dict[str, Any]]:
    """Controles formales aprendidos de importaciones Open.

    No inventan datos: si falta CNAE, tramo INCN, representante, titular real o matriz, el motor solo prepara
    la intervencion humana.
    """
    findings: list[dict[str, Any]] = []

    if "DP200001" in present_pages:
        if not _page_field_significant(parsed, "DP200001", 18):
            add_finding(
                findings,
                codigo="196",
                severidad="aviso",
                categoria="cnae",
                pagina="DP200001",
                casilla="",
                valor_200=_field_value(parsed, "DP200001", 18) or "blanco",
                esperado_local="CNAE principal",
                mensaje="Falta CNAE principal en la pagina 1.",
                fuente="Sociedades WEB / hilos importacion 2025",
                modo="hitl_requerido",
                bloqueante=False,
                accion_propuesta="Pedir CNAE validado y emitir el campo 18 de DP200001.",
            )

        incn_fields = [102, 103, 104]
        selected = [num for num in incn_fields if _page_field_significant(parsed, "DP200001", num)]
        if len(selected) != 1:
            add_finding(
                findings,
                codigo="7011",
                categoria="incn",
                pagina="DP200001",
                casilla="",
                valor_200=json.dumps({str(n): _field_raw(parsed, "DP200001", n) for n in incn_fields}),
                esperado_local="exactamente un tramo INCN",
                mensaje="Debe marcarse exactamente un tramo de importe neto de cifra de negocios.",
                fuente="Sociedades WEB / hilos importacion 2025",
                modo="hitl_requerido",
                accion_propuesta="Seleccionar un unico tramo INCN en DP200001 campos 102-104.",
            )

    matrix_nums = [9, 10, 11, 12, 13]
    matrix_active = bool(get(vals, "DP200001", "00082")) or any(
        _page_field_significant(parsed, "DP200001B", num) for num in matrix_nums
    )
    if matrix_active:
        missing = _missing_fields(parsed, "DP200001B", matrix_nums)
        if missing:
            add_finding(
                findings,
                codigo="10034",
                categoria="matriz_ultima",
                pagina="DP200001B",
                casilla="00082",
                valor_200=json.dumps({str(n): _field_value(parsed, "DP200001B", n) for n in matrix_nums}),
                esperado_local="NIF, razon, grupo, pais y TIN de matriz ultima",
                mensaje="La informacion de matriz ultima esta marcada o parcialmente rellena, pero incompleta.",
                fuente="Sociedades WEB / hilos importacion 2025",
                modo="hitl_requerido",
                accion_propuesta="Completar datos de matriz ultima o desmarcar 00082 si no aplica.",
                detalle={"faltan_campos_posicion": missing},
            )

    if "DP200002B" in present_pages:
        titular_nums = [145, 146, 147, 149, 150, 151]   # 148 (país de expedición) = NO REQUERIDO por la AEAT (02B1480)
        titular_exento = _page_field_significant(parsed, "DP200002B", 144)
        titular_tocado = any(_page_field_significant(parsed, "DP200002B", num) for num in titular_nums)
        if titular_tocado and not titular_exento:
            missing = _missing_fields(parsed, "DP200002B", titular_nums)
            if missing:
                add_finding(
                    findings,
                    codigo="2830",
                    categoria="titular_real",
                    pagina="DP200002B",
                    casilla="",
                    valor_200=json.dumps({str(n): _field_value(parsed, "DP200002B", n) for n in titular_nums}),
                    esperado_local="bloque completo o marca de exencion",
                    mensaje="El bloque de titular real esta parcialmente relleno.",
                    fuente="Sociedades WEB / hilos importacion 2025",
                    modo="hitl_requerido",
                    accion_propuesta="Completar identificacion, nacimiento, residencia y nacionalidad; o marcar exencion si procede.",
                    detalle={"faltan_campos_posicion": missing},
                )

        secretario_nums = [152, 153]
        secretario_tocado = any(_page_field_significant(parsed, "DP200002B", num) for num in secretario_nums)
        representante_tocado = any(
            _page_field_significant(parsed, "DP200002B", num)
            for num in (154, 155, 156, 157, 158, 159, 160, 161, 162, 163, 164, 165)
        )
        missing_secretario = _missing_fields(parsed, "DP200002B", secretario_nums)
        if (secretario_tocado or representante_tocado) and missing_secretario:
            add_finding(
                findings,
                codigo="144",
                categoria="secretario",
                pagina="DP200002B",
                casilla="",
                valor_200=json.dumps({str(n): _field_value(parsed, "DP200002B", n) for n in secretario_nums}),
                esperado_local="nombre y NIF del secretario",
                mensaje="Debe cumplimentarse el secretario cuando se informa el bloque G de DP200002B.",
                fuente="Sociedades WEB / importacion SUN 2025",
                modo="hitl_requerido",
                accion_propuesta="Aportar nombre y NIF del secretario del consejo o corregir/vaciar el bloque G si no aplica.",
                detalle={"faltan_campos_posicion": missing_secretario},
            )

        for idx, nums in enumerate(([154, 155, 156, 157], [158, 159, 160, 161], [162, 163, 164, 165]), start=1):
            touched = any(_page_field_significant(parsed, "DP200002B", num) for num in nums)
            if not touched:
                continue
            missing = _missing_fields(parsed, "DP200002B", nums)
            if missing:
                add_finding(
                    findings,
                    codigo=str(152 + idx),
                    categoria="representante",
                    pagina="DP200002B",
                    casilla="",
                    valor_200=json.dumps({str(n): _field_value(parsed, "DP200002B", n) for n in nums}),
                    esperado_local="nombre, NIF, fecha poder y notaria/otros",
                    mensaje=f"Representante {idx} parcialmente relleno.",
                    fuente="Sociedades WEB / hilos importacion 2025",
                    modo="hitl_requerido",
                    accion_propuesta="Completar todos los campos del representante o vaciar el bloque.",
                    detalle={"faltan_campos_posicion": missing},
                )

    return findings


def check_estados_contables_importabilidad(
    parsed: dict,
    vals: dict[str, dict[str, Decimal]],
    present_pages: set[str],
    ejercicio: str = "2025",
) -> list[dict[str, Any]]:
    findings: list[dict[str, Any]] = []

    v208 = get(vals, "DP200005", "00208")
    if v208:
        add_finding(
            findings,
            codigo="E25400208",
            categoria="calculada_no_importable",
            pagina="DP200005",
            casilla="00208",
            valor_200=money(v208),
            esperado_local="vacio/cero; 00209 soporta el importe importable",
            mensaje="OpenWeb recalcula 00208 y rechaza contenido no cero en el .200.",
            fuente="Sociedades WEB Open / import Lanzarote 2025",
            modo="auto_seguro",
            accion_propuesta="No emitir 00208 en el .200 normal; mantener 00209 si hay subvenciones.",
        )

    activo = get(vals, "DP200004", "00180")
    pn_pasivo = get(vals, "DP200006", "00252")
    if (activo or pn_pasivo) and not eq(activo, pn_pasivo):
        add_finding(
            findings,
            codigo="16053",
            categoria="balance",
            pagina="DP200004/DP200006",
            casilla="00180/00252",
            valor_200=f"00180={money(activo)}; 00252={money(pn_pasivo)}",
            esperado_local="00180 = 00252",
            mensaje="El total activo no coincide con patrimonio neto y pasivo.",
            fuente="Sociedades WEB / hilos importacion 2025",
            modo="hitl_requerido",
            accion_propuesta="Recalcular balance desde componentes; no forzar solo los totales.",
        )

    # ECPN G.4 (00632 capital cierre y 00645 patrimonio cierre): la AEAT RECALCULA el ECPN al importar. SOLO lo
    # rechaza (E25400632/E25400645 «no puede tener contenido» / «calculado X ≠ 0») cuando la hoja NO reconcilia,
    # es decir, cuando faltan los SALDOS DE APERTURA (saldo inicial): apertura 0 + cierre con contenido → la AEAT
    # recalcula la apertura (cierre del año anterior ≠ 0) y choca. Si el ECPN trae apertura (00380 capital ap /
    # 00393 patrimonio ap) la hoja cuadra y la AEAT la ACEPTA con esos cierres (PROBADO: REDEVCO importó limpio
    # con la apertura tomada de la columna N-1 de la CCAA, 2026-06-28). Por eso solo se señala si FALTA apertura.
    ecpn_model_mark = _page_field_significant(parsed, "DP200001B", 15)
    _ctx_mark = " (incluso con el modelo ECPN marcado: la AEAT la recalcula)" if ecpn_model_mark else \
                " (sin modelo ECPN marcado en DP200001B)"
    ecpn_apertura = bool(get(vals, "DP200010", "00380")) or bool(get(vals, "DP200011", "00393")) \
        or bool(get(vals, "DP200011", "00387"))   # saldo inicial (apertura) capital / patrimonio / resultado
    ecpn_00632 = get(vals, "DP200010", "00632")
    ecpn_00645 = get(vals, "DP200011", "00645")
    if (ecpn_00632 or ecpn_00645) and not ecpn_apertura:
        add_finding(
            findings,
            codigo="E25400632",
            categoria="ecpn",
            pagina="DP200010",
            casilla="00632",
            valor_200=money(ecpn_00632),
            esperado_local="vacio (casilla ECPN que la AEAT computa al importar)",
            mensaje="Hay contenido en una casilla ECPN que la AEAT recalcula al importar" + _ctx_mark + ".",
            fuente="Sociedades WEB / hilos importacion 2025",
            modo="hitl_requerido",
            accion_propuesta="Recalcular ECPN con apertura real N-1; no podar la pagina obligatoria ni picar cierres a mano.",
        )
        if ecpn_00645:
            add_finding(
                findings,
                codigo="E25400645",
                categoria="ecpn",
                pagina="DP200011",
                casilla="00645",
                valor_200=money(ecpn_00645),
                esperado_local="vacio (total ECPN que la AEAT computa al importar)",
                mensaje="El total ECPN arrastra contenido que la AEAT recalcula al importar" + _ctx_mark + ".",
                fuente="Sociedades WEB / hilos importacion 2025",
                modo="hitl_requerido",
                accion_propuesta="Recalcular el ECPN completo desde balance N/N-1; la pagina 11 es obligatoria.",
            )

    perfiles = cargar_perfiles_estados(ejercicio)
    if perfiles:
        familias = {
            "balance": _perfil_estado_codigo(_field_value(parsed, "DP200001B", 14)),
            "ecpn": _perfil_estado_codigo(_field_value(parsed, "DP200001B", 15)),
            "pyg": _perfil_estado_codigo(_field_value(parsed, "DP200001B", 16)),
        }
        letra = {"abreviado": "A", "pymes": "P"}
        casillas_info = perfiles.get("casillas") or {}
        rollups = cargar_rollups_estados(ejercicio)
        targets_by_profile = rollups.get("targets") or {}
        paginas_familia = {
            fam: set((perfiles.get("familias") or {}).get(fam, {}).get("paginas") or [])
            for fam in familias
        }
        for familia, perfil in familias.items():
            if perfil not in letra:
                continue
            marca = letra[perfil]
            targets = set(((targets_by_profile.get(perfil) or {}).get(familia) or {}).keys())
            for page in paginas_familia.get(familia, set()) & present_pages:
                for casilla, valor in (vals.get(page) or {}).items():
                    if not valor:
                        continue
                    info = casillas_info.get(casilla) or {}
                    modelos = set(info.get("modelos") or [])
                    if modelos and marca not in modelos and casilla not in targets:
                        add_finding(
                            findings,
                            codigo=f"PERFIL-{perfil.upper()}-{casilla}",
                            categoria="perfil_estados",
                            pagina=page,
                            casilla=casilla,
                            valor_200=money(valor),
                            esperado_local=f"vacio/cero; casilla no emitible en perfil {perfil}",
                            mensaje=(
                                f"La casilla {casilla} pertenece al modelo normal, pero DP200001B declara "
                                f"{perfil} para {familia}."
                            ),
                            fuente="estados_contables_perfiles.json / Sociedades WEB Open",
                            modo="auto_seguro",
                            accion_propuesta=(
                                "Aplicar la proyeccion de perfil antes de emitir el .200: plegar el importe "
                                "en su carrier y no emitir la casilla bloqueada."
                            ),
                        )

    return findings


def check_paginas_obligatorias(present_pages: set[str], modelo_balance: str = "") -> list[dict[str, Any]]:
    """EMALOBL — un `.200` que trae BALANCE (es una declaración, no un fragmento) pero le faltan las páginas
    de LIQUIDACIÓN obligatorias: la AEAT lo rechaza al importarlo como declaración («debe incluir la página
    X»). Es el patrón del `.200` contable-solo (incidencia document-6, 2026-06-28: el lote emitía sin páginas
    de liquidación). Bloqueo de importabilidad ESTRUCTURAL (Fase 1, pre_import); no es juicio fiscal.

    `modelo_balance` = DP200001B campo 14 (modelo de cuentas: 1 normal · 2 abreviado · 3 PYMES). El ECPN
    (DP200009/10/11) SOLO es obligatorio en modelo NORMAL; en abreviado/PYMES es VOLUNTARIO (regla fiscal) y su
    ausencia NO es finding. La liquidación obligatoria NO se gatea (red de seguridad document-6)."""
    findings: list[dict[str, Any]] = []
    if not ({"DP200004", "DP200006"} & set(present_pages)):   # sin balance no es una declaración completa
        return findings
    try:
        import dr200 as _dr
        liq_oblig = list(getattr(_dr, "PAGINAS_LIQUIDACION", ()) or [])
    except Exception:   # noqa: BLE001
        liq_oblig = ["DP200012", "DP200013", "DP200014", "DP200014B", "DP200DID"]
    faltan = [p for p in liq_oblig if p not in present_pages]
    if faltan:
        add_finding(
            findings,
            codigo="EMALOBL",
            categoria="estructura_paginas",
            pagina=",".join(faltan),
            casilla="",
            valor_200=f"liquidacion_presentes={sorted(set(present_pages) & set(liq_oblig))}",
            esperado_local="paginas de liquidacion obligatorias: " + ", ".join(liq_oblig),
            mensaje="El `.200` trae balance pero faltan paginas de liquidacion obligatorias: " + ", ".join(faltan) + ".",
            fuente="Sociedades WEB / EMALOBL (incidencia document-6 2026-06-28)",
            modo="hitl_requerido",
            accion_propuesta="Emitir el `.200` con liquidacion base (exportar_base o lote con liquidacion_base), no contable-solo.",
        )
    # ECPN obligatorio SOLO en modelo de cuentas NORMAL (campo 14 = "1"). En abreviado/PYMES (2/3) y sin modelo
    # declarado, el ECPN es voluntario -> no se exige (corrige el falso positivo sobre RHVS abreviado, 2026-06-30).
    ecpn_oblig = ["DP200009", "DP200010", "DP200011"]
    faltan_ecpn = [p for p in ecpn_oblig if p not in present_pages]
    if faltan_ecpn and str(modelo_balance).strip() == "1":
        add_finding(
            findings,
            codigo="EMALOBL",
            categoria="estructura_paginas",
            pagina=",".join(faltan_ecpn),
            casilla="",
            valor_200=f"ecpn_presentes={sorted(set(present_pages) & set(ecpn_oblig))}",
            esperado_local="paginas ECPN obligatorias: " + ", ".join(ecpn_oblig),
            mensaje="El `.200` trae balance pero faltan paginas ECPN obligatorias: " + ", ".join(faltan_ecpn) + ".",
            fuente="Sociedades WEB / EMALOBL RHVS 2026-06-28",
            modo="hitl_requerido",
            accion_propuesta="Emitir DP200009/DP200010/DP200011 con ECPN reconciliado desde balance N/N-1; no omitirlas.",
        )
    return findings


def check_b2(parsed: dict) -> list[dict[str, Any]]:
    findings: list[dict[str, Any]] = []
    recs = [r for r in parsed.get("records", []) if r.get("page") == "DP200002"]
    if not recs:
        return findings
    by_slot: dict[str, dict[str, dict[str, Any]]] = {}
    for f in recs[0].get("fields", []):
        desc = f.get("descripcion") or ""
        m = re.search(r"B\.2\..*? - ([1-6]) - (.+)$", desc)
        if not m:
            continue
        slot, label = m.group(1), m.group(2).strip()
        by_slot.setdefault(slot, {})[label] = f
    required = ["n.i.f.", "f/j/otra", "apellidos", "codigo provincia", "nominal", "% particip"]
    for slot, fields in by_slot.items():
        significant = [
            f for label, f in fields.items()
            if "RPTE" not in label and _field_significant(f)
        ]
        if not significant:
            continue
        missing = []
        for pattern in required:
            matches = [f for label, f in fields.items() if pattern in _norm(label)]
            if matches and not _field_significant(matches[0]):
                missing.append(matches[0].get("descripcion") or pattern)
        if missing:
            add_finding(
                findings,
                codigo="EMALR31",
                categoria="grupo_obligatorio",
                pagina="DP200002",
                casilla="",
                valor_200=f"B.2 registro {slot}",
                esperado_local="bloque completo",
                mensaje="Participacion B.2 parcialmente rellena.",
                fuente="Sociedades WEB / grupo DP200002 B.2",
                modo="hitl_requerido",
                accion_propuesta="Completar NIF, F/J/Otra, razon, provincia/pais, nominal y porcentaje, o vaciar la fila.",
                detalle={"faltan": missing},
            )
    return findings


def check_b1_totales(parsed: dict) -> list[dict[str, Any]]:
    """B.1 participadas: aceptar bloque simple; bloquear continuaciones/totales frágiles.

    Evidencia real:
    - Lanzarote/otros: B.1 simple puede importar, aunque OpenWeb avise 44/45/46 por subapartados no informados.
    - SUN: B.1 con continuaciones y totales 01501/01502/01503 parciales rechaza con E254R2C*T/02009x0.
    """
    findings: list[dict[str, Any]] = []
    recs = [r for r in parsed.get("records", []) if r.get("page") == "DP200002"]
    if not recs:
        return findings

    def by_num(rec):
        return {int(f.get("num")): f for f in rec.get("fields", []) if str(f.get("num") or "").isdigit()}

    def raw_num(raw: str | None) -> Decimal | None:
        s = str(raw or "")
        if not s.strip():
            return None
        neg = s.startswith("N")
        if neg:
            s = s[1:]
        if not s.isdigit():
            return None
        val = (Decimal(s) / Decimal("100")).quantize(TOL, rounding=ROUND_HALF_UP)
        return -val if neg else val

    b1_rows: list[dict[str, Any]] = []
    first_totals: dict[int, Decimal | None] | None = None
    records_with_b1: set[int] = set()
    for rec_idx, rec in enumerate(recs, start=1):
        fields = by_num(rec)
        for base in (36, 54, 72):
            identidad = any(str((fields.get(n) or {}).get("raw") or "").strip() for n in (base, base + 1, base + 2))
            if not identidad:
                continue
            records_with_b1.add(rec_idx)
            b1_rows.append({
                "rec": rec_idx,
                "base": base,
                "nif": str((fields.get(base) or {}).get("raw") or "").strip(),
                "pais": str((fields.get(base + 2) or {}).get("raw") or "").strip(),
                "nominal": raw_num((fields.get(base + 4) or {}).get("raw")),
                "valor_libros": raw_num((fields.get(base + 5) or {}).get("raw")),
                "dividendos": raw_num((fields.get(base + 6) or {}).get("raw")),
            })
        if first_totals is None:
            first_totals = {n: raw_num((fields.get(n) or {}).get("raw")) for n in (90, 91, 92)}
    if not b1_rows:
        return findings

    simple = len(b1_rows) <= 3 and records_with_b1 == {1} and all(
        len(r["nif"]) >= 5 and r["pais"] for r in b1_rows
    )
    totals = first_totals or {}
    expected = {
        90: sum((r["nominal"] or Decimal("0.00")) for r in b1_rows).quantize(TOL),
        91: sum((r["valor_libros"] or Decimal("0.00")) for r in b1_rows).quantize(TOL),
        92: sum((r["dividendos"] or Decimal("0.00")) for r in b1_rows).quantize(TOL),
    }
    totals_ok = all((totals.get(n) or Decimal("0.00")) == expected[n] for n in (90, 91, 92))
    if simple and totals_ok:
        return findings

    add_finding(
        findings,
        codigo="B1-DR-COMPLEJO",
        categoria="b1_participadas",
        pagina="DP200002",
        casilla="01501/01502/01503",
        valor_200=json.dumps({str(n): money(totals.get(n) or Decimal("0.00")) for n in (90, 91, 92)}, ensure_ascii=False),
        esperado_local=json.dumps({str(n): money(expected[n]) for n in (90, 91, 92)}, ensure_ascii=False),
        mensaje="B.1 no es bloque simple o sus totales no cuadran con el detalle; OpenWeb puede rechazarlo como SUN.",
        fuente="Sociedades WEB / import SUN 2025",
        modo="auto_seguro",
        accion_propuesta="No emitir B.1 complejo en DP200002; conservarlo como JSON/HITL post-import.",
        detalle={"n_participadas": len(b1_rows), "registros_con_b1": sorted(records_with_b1)},
    )
    return findings


def check_gastos_financieros(
    vals: dict[str, dict[str, Decimal]],
    present_pages: set[str],
) -> list[dict[str, Any]]:
    findings: list[dict[str, Any]] = []
    if "DP200020" not in present_pages:
        return findings
    g = lambda c: get(vals, "DP200020", c)

    bo = (g("01250") - g("01251") - g("01252") - g("01253") + g("01254") - g("02368")).quantize(
        TOL, rounding=ROUND_HALF_UP
    )
    expected_1249 = (bo * Decimal("0.30")).quantize(TOL, rounding=ROUND_HALF_UP)
    if (g("01249") or bo) and not eq(g("01249"), expected_1249):
        add_finding(
            findings,
            codigo="E25401249",
            categoria="gastos_financieros",
            pagina="DP200020",
            casilla="01249",
            valor_200=money(g("01249")),
            esperado_local=money(expected_1249),
            mensaje="01249 debe ser el 30% del beneficio operativo de la pagina 20.",
            fuente="Manual Cap. 5 art. 16 / evidencia Open",
            modo="hitl_requerido",
            accion_propuesta="Confirmar 01250-01254/02368 y recalcular el limite 30% BO.",
        )

    expected_2369 = max(max(expected_1249, Decimal("0.00")) + g("01255"), GF_FLOOR)
    page20_has_signal = "DP200020" in present_pages or any(
        g(c) for c in ("01249", "01250", "01255", "01256", "01257", "01260", "02369")
    )
    if page20_has_signal and not eq(g("02369"), expected_2369):
        add_finding(
            findings,
            codigo="E25402369",
            categoria="gastos_financieros",
            pagina="DP200020",
            casilla="02369",
            valor_200=money(g("02369")),
            esperado_local=money(expected_2369),
            mensaje="02369 debe recoger el limite total de GF, con suelo comun de 1.000.000 si procede.",
            fuente="Manual Cap. 5 art. 16 / evidencia Open",
            modo="hitl_requerido",
            accion_propuesta="Confirmar beneficio operativo, adiciones y prorrata; emitir limite coherente.",
        )

    if g("01256") and g("02369") and g("01256") > g("02369") + TOL:
        add_finding(
            findings,
            codigo="22890",
            categoria="gastos_financieros",
            pagina="DP200020",
            casilla="01256",
            valor_200=money(g("01256")),
            esperado_local=f"<= {money(g('02369'))}",
            mensaje="01256 no puede superar el limite total 02369.",
            fuente="Sociedades WEB / art. 16",
            modo="auto_seguro",
            accion_propuesta="Recalcular split deducible/no deducible de GF.",
        )

    expected_1248 = (g("01256") + g("01257")).quantize(TOL, rounding=ROUND_HALF_UP)
    if g("01248") and not eq(g("01248"), expected_1248):
        add_finding(
            findings,
            codigo="22880",
            categoria="gastos_financieros",
            pagina="DP200020",
            casilla="01248",
            valor_200=money(g("01248")),
            esperado_local=money(expected_1248),
            mensaje="01248 debe cuadrar con 01256 + 01257 cuando se emite.",
            fuente="Autocontrol art. 16 / Sociedades WEB",
            modo="auto_seguro",
            accion_propuesta="Emitir el bloque GF completo y coherente, o no emitir la casilla calculada.",
        )

    expected_1257 = (g("01248") - g("01256")).quantize(TOL, rounding=ROUND_HALF_UP)
    if g("01248") and (g("01257") or expected_1257) and not eq(g("01257"), expected_1257):
        add_finding(
            findings,
            codigo="22925",
            categoria="gastos_financieros",
            pagina="DP200020",
            casilla="01257",
            valor_200=money(g("01257")),
            esperado_local=money(expected_1257),
            mensaje="01257 debe reconciliarse como diferencia entre gastos financieros netos y deducibles.",
            fuente="Sociedades WEB / art. 16",
            modo="auto_seguro",
            accion_propuesta="Recalcular 01257 desde 01248 - 01256 y propagar espejos 03587/01216.",
        )

    expected_1260 = (g("01243") + g("01257")).quantize(TOL, rounding=ROUND_HALF_UP)
    if (g("01260") or expected_1260) and not eq(g("01260"), expected_1260):
        add_finding(
            findings,
            codigo="E25401260",
            categoria="gastos_financieros",
            pagina="DP200020",
            casilla="01260",
            valor_200=money(g("01260")),
            esperado_local=money(expected_1260),
            mensaje="01260 debe ser 01243 + 01257.",
            fuente="Manual Cap. 5 art. 16 / GIP",
            modo="auto_seguro",
            accion_propuesta="Recalcular total de GF no deducible.",
        )

    for mirror, source, codigo in (
        ("01214", "01256", "E25401214"),
        ("03585", "01256", "22820"),
        ("03587", "01257", "22940"),
        ("01216", "01257", "E25401216"),
    ):
        if (g(mirror) or g(source)) and not eq(g(mirror), g(source)):
            add_finding(
                findings,
                codigo=codigo,
                categoria="gastos_financieros",
                pagina="DP200020",
                casilla=mirror,
                valor_200=money(g(mirror)),
                esperado_local=money(g(source)),
                mensaje=f"{mirror} debe ser espejo de {source} en el bloque GF.",
                fuente="Autocontrol art. 16 / Sociedades WEB",
                modo="auto_seguro",
                accion_propuesta="Reemitir pagina 20 completa y coherente.",
            )

    expected_0364 = (g("01258") + g("01259")).quantize(TOL, rounding=ROUND_HALF_UP)
    if (get(vals, "DP200012", "00364") or expected_0364) and not eq(get(vals, "DP200012", "00364"), expected_0364):
        add_finding(
            findings,
            codigo="9461",
            categoria="gastos_financieros",
            pagina="DP200012",
            casilla="00364",
            valor_200=money(get(vals, "DP200012", "00364")),
            esperado_local=money(expected_0364),
            mensaje="00364 debe coincidir con 01258 + 01259.",
            fuente="Autocontrol art. 16",
            modo="hitl_requerido",
            accion_propuesta="Confirmar reversión/aplicación de GF de ejercicios anteriores.",
        )

    ajuste_0363 = get(vals, "DP200012", "00363")
    if g("01260") and not eq(ajuste_0363, g("01260")):
        add_finding(
            findings,
            codigo="9460",
            categoria="gastos_financieros",
            pagina="DP200012",
            casilla="00363",
            valor_200=money(ajuste_0363),
            esperado_local=money(g("01260")),
            mensaje="El GF no deducible 01260 debe reconciliarse con el ajuste positivo 00363.",
            fuente="Ingenieria inversa Open / criterio GF",
            modo="hitl_requerido",
            accion_propuesta="Confirmar criterio GF del abogado y acoplar 00363 -> 00417 -> 00550 si procede.",
        )

    if "DP200007" in present_pages:
        pyg_284 = get(vals, "DP200007", "00284")
        if (g("01251") or pyg_284) and not eq(abs(g("01251")), abs(pyg_284)):
            add_finding(
                findings,
                codigo="9417",
                severidad="aviso",
                categoria="gastos_financieros",
                pagina="DP200020/DP200007",
                casilla="01251",
                valor_200=money(g("01251")),
                esperado_local=f"conciliar con 00284={money(pyg_284)}",
                mensaje="01251 no concilia con la magnitud contable 00284 usada por Open para GF.",
                fuente="Hilos importacion 2025 / criterio GF",
                modo="hitl_requerido",
                bloqueante=False,
                accion_propuesta="Confirmar si 00284 debe entrar con signo o ajuste en beneficio operativo GF.",
            )

        pyg_287 = get(vals, "DP200007", "00287")
        if (g("01253") or pyg_287) and not eq(abs(g("01253")), abs(pyg_287)):
            add_finding(
                findings,
                codigo="9421",
                severidad="aviso",
                categoria="gastos_financieros",
                pagina="DP200020/DP200007",
                casilla="01253",
                valor_200=money(g("01253")),
                esperado_local=f"conciliar con 00287={money(pyg_287)}",
                mensaje="01253 no concilia con la magnitud contable 00287 usada por Open para GF.",
                fuente="Hilos importacion 2025 / criterio GF",
                modo="hitl_requerido",
                bloqueante=False,
                accion_propuesta="Confirmar criterio de dividendos/participaciones en beneficio operativo GF.",
            )

        pyg_296 = get(vals, "DP200007", "00296")
        if (g("01250") or pyg_296) and not eq(g("01250"), pyg_296):
            add_finding(
                findings,
                codigo="INT-GF-RE",
                severidad="aviso",
                categoria="gastos_financieros",
                pagina="DP200020/DP200007",
                casilla="01250",
                valor_200=money(g("01250")),
                esperado_local=money(pyg_296),
                mensaje="01250 no concilia con el resultado de explotacion 00296. Es decision de criterio GF.",
                fuente="Addendum criterio GF / import real GIP",
                modo="hitl_requerido",
                bloqueante=False,
                accion_propuesta="Pedir criterio leniente/estricto antes de modificar 00363 o 02369.",
            )
    return findings


def check_foral(
    vals: dict[str, dict[str, Decimal]],
    present_pages: set[str],
) -> list[dict[str, Any]]:
    findings: list[dict[str, Any]] = []
    foral_mark = get(vals, "DP200001", "00028")
    p26_present = "DP200026" in present_pages
    foral_values = any(get(vals, "DP200014B", c) for c in ("00600", "00602", "00604", "00606", "00622"))
    foral_values = foral_values or any(pct_get(vals, "DP200026", c) for c in ("00626", "00627", "00628", "00629"))
    foral_active = bool(foral_mark or p26_present or foral_values)
    if not foral_active:
        return findings

    if foral_values and not foral_mark:
        add_finding(
            findings,
            codigo="FORAL-SIN-00028",
            categoria="foral",
            pagina="DP200001",
            casilla="00028",
            valor_200=money(foral_mark),
            esperado_local="1",
            mensaje="Hay importes/porcentajes forales pero no esta marcada la tributacion conjunta 00028.",
            fuente="Manual Cap. 14 / DR DP200001",
            modo="hitl_requerido",
            accion_propuesta="Confirmar tributacion conjunta y marcar 00028, o eliminar los datos forales.",
        )

    if foral_mark and not p26_present:
        add_finding(
            findings,
            codigo="FORAL-PAG26-AUSENTE",
            categoria="foral",
            pagina="DP200026",
            casilla="",
            valor_200="ausente",
            esperado_local="presente",
            mensaje="00028 exige pagina 26 con volumenes, porcentajes y reparto por Administracion.",
            fuente="Manual Cap. 14",
            modo="hitl_requerido",
            accion_propuesta="Pedir reparto territorial y emitir DP200026, o no emitir liquidacion foral.",
        )
        return findings

    pct_estado = pct_get(vals, "DP200026", "00625")
    pct_foral = sum(pct_get(vals, "DP200026", c) for c in ("00626", "00627", "00628", "00629"))
    pct_total = (pct_estado + pct_foral).quantize(TOL, rounding=ROUND_HALF_UP)
    if not eq(pct_total, Decimal("100.00")):
        add_finding(
            findings,
            codigo="FORAL-PCT-100",
            categoria="foral",
            pagina="DP200026",
            casilla="00625-00629",
            valor_200=money(pct_total),
            esperado_local="100.00",
            mensaje="La suma de porcentajes Estado/Diputaciones/Navarra debe ser 100%.",
            fuente="Manual Cap. 14",
            modo="hitl_requerido",
            accion_propuesta="Recalcular porcentajes desde volumenes 00050-00056 con ajuste de redondeo.",
        )

    denom = get(vals, "DP200026", "00050") - get(vals, "DP200026", "00051")
    if denom > 0:
        expected_pcts = {
            "00625": get(vals, "DP200026", "00056") * Decimal("100") / denom,
            "00626": get(vals, "DP200026", "00052") * Decimal("100") / denom,
            "00627": get(vals, "DP200026", "00053") * Decimal("100") / denom,
            "00628": get(vals, "DP200026", "00054") * Decimal("100") / denom,
            "00629": get(vals, "DP200026", "00055") * Decimal("100") / denom,
        }
        if any(abs(pct_get(vals, "DP200026", c) - v.quantize(TOL, rounding=ROUND_HALF_UP)) > Decimal("0.02")
               for c, v in expected_pcts.items()):
            add_finding(
                findings,
                codigo="FORAL-PCT-VOLUMENES",
                categoria="foral",
                pagina="DP200026",
                casilla="00625-00629",
                valor_200="porcentajes emitidos",
                esperado_local="porcentajes derivados de 00050-00056",
                mensaje="Los porcentajes forales no derivan de los volumenes declarados.",
                fuente="Manual Cap. 14",
                modo="hitl_requerido",
                accion_propuesta="Revisar volumenes territoriales y aplicar regla de redondeo del Manual.",
            )

    base_cuota = get(vals, "DP200014B", "00592") - get(vals, "DP200014B", "01766") - get(vals, "DP200014B", "01784")
    expected_599 = (base_cuota * pct_estado / Decimal("100")).quantize(TOL, rounding=ROUND_HALF_UP)
    expected_600 = (base_cuota * pct_foral / Decimal("100")).quantize(TOL, rounding=ROUND_HALF_UP)
    if (get(vals, "DP200014B", "00599") or expected_599) and not eq(get(vals, "DP200014B", "00599"), expected_599):
        add_finding(
            findings,
            codigo="FORAL-00599",
            categoria="foral",
            pagina="DP200014B",
            casilla="00599",
            valor_200=money(get(vals, "DP200014B", "00599")),
            esperado_local=money(expected_599),
            mensaje="00599 debe ser cuota Estado segun 00625.",
            fuente="Manual Cap. 6",
            modo="hitl_requerido",
            accion_propuesta="Recalcular reparto Estado/Forales antes de reemitir 14BIS.",
        )
    if (get(vals, "DP200014B", "00600") or expected_600) and not eq(get(vals, "DP200014B", "00600"), expected_600):
        add_finding(
            findings,
            codigo="FORAL-00600",
            categoria="foral",
            pagina="DP200014B",
            casilla="00600",
            valor_200=money(get(vals, "DP200014B", "00600")),
            esperado_local=money(expected_600),
            mensaje="00600 debe ser cuota D. Forales/Navarra segun 00626-00629.",
            fuente="Manual Cap. 6",
            modo="hitl_requerido",
            accion_propuesta="Recalcular reparto foral y pagina 26.",
        )

    pcts_admin = {
        "araba": pct_get(vals, "DP200026", "00626"),
        "gipuzkoa": pct_get(vals, "DP200026", "00627"),
        "bizkaia": pct_get(vals, "DP200026", "00628"),
        "navarra": pct_get(vals, "DP200026", "00629"),
    }
    cuota_admin = {k: (base_cuota * v / Decimal("100")).quantize(TOL, rounding=ROUND_HALF_UP)
                   for k, v in pcts_admin.items()}
    pagos1 = {"araba": "00402", "gipuzkoa": "00442", "bizkaia": "00443", "navarra": "00444"}
    pagos2 = {"araba": "00445", "gipuzkoa": "00446", "bizkaia": "00447", "navarra": "00448"}
    pagos3 = {"araba": "00449", "gipuzkoa": "00450", "bizkaia": "00451", "navarra": "00465"}
    dif_admin = {
        k: (cuota_admin[k] - get(vals, "DP200026", pagos1[k]) - get(vals, "DP200026", pagos2[k])
            - get(vals, "DP200026", pagos3[k])).quantize(TOL, rounding=ROUND_HALF_UP)
        for k in pcts_admin
    }
    checks_admin = {
        "00420": cuota_admin["araba"], "00421": cuota_admin["gipuzkoa"],
        "00426": cuota_admin["bizkaia"], "00427": cuota_admin["navarra"],
        "00474": dif_admin["araba"], "00475": dif_admin["gipuzkoa"],
        "00476": dif_admin["bizkaia"], "00477": dif_admin["navarra"],
        "01624": dif_admin["araba"], "01625": dif_admin["gipuzkoa"],
        "01629": dif_admin["bizkaia"], "01630": dif_admin["navarra"],
        "00494": dif_admin["araba"], "00495": dif_admin["gipuzkoa"],
        "00496": dif_admin["bizkaia"], "00497": dif_admin["navarra"],
    }
    for cas, expected in checks_admin.items():
        actual = get(vals, "DP200026", cas)
        if (actual or expected) and not eq(actual, expected):
            add_finding(
                findings,
                codigo=f"FORAL-P26-{cas}",
                categoria="foral",
                pagina="DP200026",
                casilla=cas,
                valor_200=money(actual),
                esperado_local=money(expected),
                mensaje=f"{cas} debe cuadrar con el porcentaje territorial y pagos fraccionados forales.",
                fuente="Sociedades WEB / import SUN 2025",
                modo="auto_seguro",
                accion_propuesta="Reemitir pagina 26 con casillas provinciales coherentes con 00626-00629.",
            )

    for cas in ("00602", "00604", "00606", "00622"):
        p26 = get(vals, "DP200026", cas)
        p14 = get(vals, "DP200014B", cas)
        if (p26 or p14) and not eq(p14, p26):
            add_finding(
                findings,
                codigo=f"FORAL-{cas}",
                categoria="foral",
                pagina="DP200014B/DP200026",
                casilla=cas,
                valor_200=money(p14),
                esperado_local=money(p26),
                mensaje=f"{cas} en 14BIS debe cuadrar con el total de pagina 26.",
                fuente="DR DP200026 + Manual Cap. 14",
                modo="hitl_requerido",
                accion_propuesta="Reemitir totales forales desde la pagina 26.",
            )
    return findings


def check_did(
    parsed: dict,
    vals: dict[str, dict[str, Decimal]],
    ejercicio: str,
    present_pages: set[str],
) -> list[dict[str, Any]]:
    findings: list[dict[str, Any]] = []
    if "DP200DID" not in present_pages:
        return findings

    cct = _field_raw(parsed, "DP200DID", 6)
    if cct not in {"0", "1"}:
        add_finding(
            findings,
            codigo="DID0060",
            categoria="did",
            pagina="DP200DID",
            casilla="",
            valor_200=cct or "blanco",
            esperado_local="0 o 1",
            mensaje="Cuenta corriente tributaria DID sin marca valida.",
            fuente="DR DP200DID",
            modo="auto_seguro",
            accion_propuesta="Emitir 0 si no se usa cuenta corriente tributaria.",
        )

    ej = _field_value(parsed, "DP200DID", 7)
    if ej != str(ejercicio):
        add_finding(
            findings,
            codigo="EMALEJER1",
            categoria="did",
            pagina="DP200DID",
            casilla="",
            valor_200=ej or "blanco",
            esperado_local=str(ejercicio),
            mensaje="DID no contiene el ejercicio correcto.",
            fuente="DR DP200DID",
            modo="auto_seguro",
            accion_propuesta="Emitir el ejercicio de devengo en DP200DID.",
        )

    tipo = _field_value(parsed, "DP200DID", 8)
    periodo = _field_raw(parsed, "DP200DID", 9)
    if periodo == "0A" and tipo != "1":
        add_finding(
            findings,
            codigo="EMALEJER9",
            categoria="did",
            pagina="DP200DID",
            casilla="",
            valor_200=tipo or "blanco",
            esperado_local="1",
            mensaje="DID tiene tipo de ejercicio invalido para periodo 0A.",
            fuente="DR DP200DID",
            modo="auto_seguro",
            accion_propuesta="Emitir tipo 1 para ejercicio natural completo, salvo periodo partido confirmado.",
        )

    yy = str(ejercicio)[-2:]
    expected_period = {
        "periodo": "0A",
        "inicio_dia": "1",
        "inicio_mes": "1",
        "inicio_ano": yy,
        "fin_dia": "31",
        "fin_mes": "12",
        "fin_ano": yy,
    }
    actual_period = {
        "periodo": periodo,
        "inicio_dia": _field_value(parsed, "DP200DID", 10),
        "inicio_mes": _field_value(parsed, "DP200DID", 11),
        "inicio_ano": _field_value(parsed, "DP200DID", 12),
        "fin_dia": _field_value(parsed, "DP200DID", 13),
        "fin_mes": _field_value(parsed, "DP200DID", 14),
        "fin_ano": _field_value(parsed, "DP200DID", 15),
    }
    if periodo != "0A" or any(actual_period[k] != v for k, v in expected_period.items() if k != "periodo"):
        add_finding(
            findings,
            codigo="DID0090",
            categoria="did",
            pagina="DP200DID",
            casilla="",
            valor_200=json.dumps(actual_period, ensure_ascii=False),
            esperado_local=json.dumps(expected_period, ensure_ascii=False),
            mensaje="DID tiene periodo o fechas incoherentes para periodo natural 0A.",
            fuente="DR DP200DID",
            modo="hitl_requerido",
            accion_propuesta="Confirmar si es periodo partido; si no, emitir 0A y fechas 01/01-31/12.",
        )

    mirrors = [
        ("00552", "DP200014", "00552"),
        ("00562", "DP200014", "00562"),
        ("01586", "DP200014B", "01586"),
        ("00621", "DP200014B", "00621"),
    ]
    for cas, src_page, src_cas in mirrors:
        src = get(vals, src_page, src_cas)
        dst = get(vals, "DP200DID", cas)
        if (src or dst) and not eq(src, dst):
            add_finding(
                findings,
                codigo=f"DID{cas}",
                categoria="did",
                pagina="DP200DID",
                casilla=cas,
                valor_200=money(dst),
                esperado_local=money(src),
                mensaje=f"DID/{cas} debe ser espejo de {src_page}/{src_cas}.",
                fuente="DR DP200DID + liquidacion",
                modo="auto_seguro",
                accion_propuesta="Reemitir DID desde la liquidacion final, no corregirlo a mano.",
            )
    ingreso = dec(_field_value(parsed, "DP200DID", 34))
    c621 = get(vals, "DP200014B", "00621")
    grupo_fiscal = bool(get(vals, "DP200001", "00009")) or bool(get(vals, "DP200001", "00010"))
    if c621 > 0 and not grupo_fiscal and not eq(ingreso, c621):
        add_finding(
            findings,
            codigo="EMALID10",
            categoria="did",
            pagina="DP200DID",
            casilla="00621",
            valor_200=money(ingreso),
            esperado_local=money(c621),
            mensaje="Importe a ingresar DID debe coincidir con 00621 si el resultado es a ingresar.",
            fuente="DR DP200DID",
            modo="auto_seguro",
            accion_propuesta="Actualizar modalidad/importe de ingreso desde 00621.",
        )
    return findings


def annotate_aeat_errors(
    errors: list[dict[str, Any]],
    vals: dict[str, dict[str, Decimal]],
) -> list[dict[str, Any]]:
    annotated: list[dict[str, Any]] = []
    formal_families = {
        "2830": ("titular_real", "Completar bloque de titular real o marcar exencion si procede."),
        "10034": ("matriz_ultima", "Completar matriz ultima en DP200001B o desmarcar 00082."),
        "21200": ("matriz_ultima", "Revisar coherencia de pertenencia a grupo y matriz ultima."),
        "7011": ("incn", "Seleccionar un unico tramo INCN en DP200001."),
        "153": ("representante", "Completar o vaciar el primer representante."),
        "154": ("representante", "Completar o vaciar el segundo representante."),
        "155": ("representante", "Completar o vaciar el tercer representante."),
        "15525": ("foral", "Si hay tributacion conjunta, emitir pagina 26; si no aplica, retirar 00028/datos forales."),
        "16053": ("balance", "Recalcular balance completo hasta que 00180 coincida con 00252."),
        "35100": ("tipo_declaracion", "Revisar tipo de declaracion frente al signo del resultado y modalidad DID."),
    }
    aviso_families = {
        "196": ("cnae", "Informar CNAE principal validado."),
        "9417": ("gastos_financieros", "Revisar conciliacion 01251 con la magnitud contable de PyG."),
        "9421": ("gastos_financieros", "Revisar conciliacion 01253 con la magnitud contable de PyG."),
        "11712": ("balance", "Revisar signo/importes de inversiones financieras corrientes."),
        "11716": ("balance", "Verificar 00331 contra el desglose contable importado."),
    }
    for err in errors:
        e = dict(err)
        page, casilla = e.get("pagina"), e.get("casilla")
        if page and casilla:
            e["valor_200_local"] = money(get(vals, page, casilla))
        desc = _norm(e.get("descripcion"))
        code = e.get("codigo") or ""
        if code == "FRECH":
            e["categoria"] = "rechazo_global"
            e["modo"] = "no_local"
            e["bloqueante"] = False
            e["accion_propuesta"] = "Resolver los errores bloqueantes; FRECH desaparece como consecuencia."
        elif code in aviso_families or code.startswith("209"):
            categoria, accion = aviso_families.get(
                code,
                ("aviso_coherencia", "Revisar coherencia contable/fiscal antes de firmar; no suele impedir importar."),
            )
            e["categoria"] = categoria
            e["modo"] = "hitl_requerido"
            e["bloqueante"] = False
            e["severidad"] = "aviso"
            e["accion_propuesta"] = accion
        elif code in {"E25400632", "E25400645"}:
            e["categoria"] = "ecpn"
            e["modo"] = "hitl_requerido"
            e["accion_propuesta"] = "Revisar modelo de cuentas/ECPN marcado; podar contenido incompatible o recalcular ECPN."
        elif (
            code in {"E25400599", "E25400611", "E25401586", "E25400621"}
            and "no puede tener contenido" in desc
        ):
            e["categoria"] = "foral"
            e["modo"] = "auto_seguro"
            e["accion_propuesta"] = (
                "En tributacion conjunta Estado/Foral, omitir las casillas de resultado solo-Estado "
                "y completar el resultado/reparto en pagina 26."
            )
        elif "no puede tener contenido" in desc:
            e["categoria"] = "calculada_no_importable"
            e["modo"] = "auto_seguro"
            e["accion_propuesta"] = "Eliminar/dejar a cero la casilla calculada y alimentar sus componentes."
        elif code in {"E25400210", "E25400216", "E25400222", "E25400228", "E25400230", "E25400252"}:
            e["categoria"] = "balance"
            e["modo"] = "hitl_requerido"
            e["accion_propuesta"] = "Recalcular balance desde componentes y revisar modelo de cuentas importado."
        elif code in {
            "22820", "22880", "22890", "22925", "22940", "E25401214", "E25401216",
            "E25401249", "E25401260", "E25402369",
        }:
            e["categoria"] = "gastos_financieros"
            e["modo"] = "hitl_requerido" if code in {"E25401249", "E25402369"} else "auto_seguro"
            e["accion_propuesta"] = "Reemitir bloque de gastos financieros completo y coherente con pagina 7 y ajustes 00363/00364."
        elif code in {"E25400417", "E25400418", "E25400420", "E25400426", "E25400474", "E25400476", "E25400494", "E25400496"}:
            e["categoria"] = "correcciones_liquidacion"
            e["modo"] = "hitl_requerido"
            e["accion_propuesta"] = "Mover importes a casillas de detalle soportadas por el DR y recalcular los totales de correcciones."
        elif code in {
            "E25400600", "E25400612", "E25400619", "E25400622", "E25401587",
            "E25401624", "E25401629", "E25402301", "E25402303", "E25402306",
            "E25402308", "E25402310",
        }:
            e["categoria"] = "foral"
            e["modo"] = "hitl_requerido"
            e["accion_propuesta"] = "Revisar pagina 26, porcentajes/volumenes y reparto Estado-Diputaciones/Navarra."
        elif e.get("calculado_aeat") is not None and _looks_like_x100(e.get("calculado_aeat"), e.get("importado_aeat")):
            e["categoria"] = "unidades_x100"
            e["modo"] = "auto_seguro"
            e["accion_propuesta"] = "Normalizar importes a euros con dos decimales; el valor importado parece venir multiplicado por 100."
        elif code in {
            "E25400552", "E25401330", "E25400562", "E25400582", "E25400592", "E25400599",
            "E25400611", "E25401586", "E25400621",
        }:
            e["categoria"] = "liquidacion"
            e["modo"] = "hitl_requerido"
            e["accion_propuesta"] = "Recalcular la cadena de liquidacion desde sus determinantes DR."
        elif e.get("calculado_aeat") is not None:
            e["categoria"] = "formula_open"
            e["modo"] = "hitl_requerido"
            e["accion_propuesta"] = "Reconciliar formula local; usar el calculado AEAT como evidencia."
        elif code in formal_families:
            categoria, accion = formal_families[code]
            e["categoria"] = categoria
            e["modo"] = "hitl_requerido"
            e["accion_propuesta"] = accion
        elif code in {"DID0060", "EMALEJER1", "EMALEJER9", "DID0090"}:
            e["categoria"] = "did"
            e["modo"] = "auto_seguro" if code != "DID0090" else "hitl_requerido"
            e["accion_propuesta"] = "Reemitir cabecera DID desde identificativos/periodo confirmados."
        elif code in {"EMALR31", "EMALREG", "EMALREGPAG26B"}:
            e["categoria"] = "grupo_obligatorio"
            e["modo"] = "hitl_requerido"
            e["accion_propuesta"] = "Completar o vaciar la fila/grupo parcial indicado por Open."
        elif code == "EMAL500_12":
            e["categoria"] = "contabilidad_liquidacion"
            e["modo"] = "hitl_requerido"
            e["accion_propuesta"] = "Cuadrar el 00500 contable y el de pagina 12."
        elif code in {"EMAL00501", "EMAL501", "EMALP13_2"}:
            e["categoria"] = "liquidacion"
            e["modo"] = "auto_seguro"
            e["accion_propuesta"] = "Recalcular la cadena de liquidacion desde sus determinantes DR."
        else:
            e.setdefault("categoria", "aeat")
            e.setdefault("modo", "hitl_requerido")
            e.setdefault("accion_propuesta", "Revisar contra DR, manual y valores importados.")
        if code != "FRECH":
            e.setdefault("bloqueante", e.get("severidad") != "aviso")
        if e.get("severidad") == "aviso":
            e["bloqueante"] = False
        _apply_phase_policy(e, aeat_evidence=True)
        annotated.append(e)
    return annotated


def cargar_subtotales(ejercicio: str) -> dict[str, list[str]]:
    root = Path(__file__).resolve().parents[2]
    path = root / "Extractor-parseador" / "data" / "campaigns" / str(ejercicio) / "mapeo_pgc_aeat.json"
    if not path.exists():
        return {}
    return json.loads(path.read_text(encoding="utf-8")).get("subtotales") or {}


def cargar_rollups_estados(ejercicio: str) -> dict[str, Any]:
    root = Path(__file__).resolve().parents[2]
    path = root / "Extractor-parseador" / "data" / "campaigns" / str(ejercicio) / "estados_contables_rollups.json"
    if not path.exists():
        return {}
    return json.loads(path.read_text(encoding="utf-8"))


def cargar_perfiles_estados(ejercicio: str) -> dict[str, Any]:
    root = Path(__file__).resolve().parents[2]
    path = root / "Extractor-parseador" / "data" / "campaigns" / str(ejercicio) / "estados_contables_perfiles.json"
    if not path.exists():
        return {}
    return json.loads(path.read_text(encoding="utf-8"))


def _perfil_estado_codigo(codigo: str | None) -> str:
    return {"1": "normal", "2": "abreviado", "3": "pymes"}.get(str(codigo or "").strip(), "")


def filtrar_subtotales_por_perfil(
    subtotales: dict[str, list[str]],
    parsed: dict,
    ejercicio: str,
) -> dict[str, list[str]]:
    """Adapta las reglas de roll-up normal al modelo de estados declarado en DP200001B.

    En abreviado/PYMES hay casillas que en el modelo normal son subtotales de detalle, pero OpenWeb las trata como
    carriers importables del perfil. El detalle normal se pliega en ellas y no se emite; validar `carrier = sum(detalle
    normal)` produce falsos bloqueos locales aunque el fichero importe correctamente. La fuente de verdad de esos
    carriers es el mapa de rollups certificado por importaciones reales.
    """
    if not subtotales:
        return {}
    out = {k: list(v) for k, v in subtotales.items()}
    # OpenWeb confirmó en import real (Lanzarote 2025) que 00208 se recalcula y no admite contenido no cero en
    # el `.200` normal. No debe bloquearse localmente por `00208 != 00209`; debe emitirse 00209 y dejar 00208 a cero.
    out.pop("00208", None)
    rollups = cargar_rollups_estados(ejercicio)
    targets_by_profile = rollups.get("targets") or {}
    familias = {
        "balance": _perfil_estado_codigo(_field_value(parsed, "DP200001B", 14)),
        "pyg": _perfil_estado_codigo(_field_value(parsed, "DP200001B", 16)),
    }
    for familia, perfil in familias.items():
        if perfil not in {"abreviado", "pymes"}:
            continue
        targets = (targets_by_profile.get(perfil) or {}).get(familia) or {}
        for casilla, regla in targets.items():
            out.pop(casilla, None)
            for fuente in regla.get("from", []):
                out.pop(str(fuente).zfill(5), None)
    return out


def analizar(
    doc: str,
    dr: dict,
    ejercicio: str = "2025",
    *,
    subtotales: dict[str, list[str]] | None = None,
    bin_limite_pct: float | Decimal | None = None,
    errores_aeat_text: str | None = None,
    incluir_autocontrol: bool = True,
) -> dict[str, Any]:
    """Devuelve un informe estructurado de importabilidad probable."""
    parsed = mp.parse_text(doc, dr, include_fields=True)
    vals = values_by_page(parsed)
    present_pages = set(parsed.get("summary", {}).get("pages") or [])

    estructura = validar_estructura(doc, dr, parsed=parsed)
    findings: list[dict[str, Any]] = []
    findings.extend(check_formales(parsed, vals, present_pages))
    findings.extend(check_estados_contables_importabilidad(parsed, vals, present_pages, ejercicio))
    findings.extend(check_paginas_obligatorias(present_pages, modelo_balance=_field_value(parsed, "DP200001B", 14)))
    findings.extend(check_liquidacion_comun(vals, dr, present_pages))
    findings.extend(check_b1_totales(parsed))
    findings.extend(check_b2(parsed))
    findings.extend(check_gastos_financieros(vals, present_pages))
    findings.extend(check_foral(vals, present_pages))
    findings.extend(check_did(parsed, vals, ejercicio, present_pages))

    if incluir_autocontrol:
        try:
            import autocontrol_200  # import tardio para evitar ciclos con la fachada de autocontrol_200
            subtotales_base = subtotales if subtotales is not None else cargar_subtotales(ejercicio)
            auto = autocontrol_200.validar(
                doc,
                dr,
                ejercicio,
                subtotales=filtrar_subtotales_por_perfil(subtotales_base, parsed, ejercicio),
                bin_limite_pct=bin_limite_pct,
            )
            findings.extend(_autocontrol_to_findings(auto))
        except Exception as exc:  # noqa: BLE001
            add_finding(
                findings,
                codigo="AUTOCONTROL-ERROR",
                severidad="aviso",
                categoria="autocontrol",
                mensaje=f"No se pudo ejecutar autocontrol_200: {exc}",
                fuente="validacion_importabilidad_200.py",
                modo="no_local",
                bloqueante=False,
            )
    findings = _dedupe_findings(findings)

    errors = annotate_aeat_errors(parsear_errores_aeat(errores_aeat_text), vals)
    errores_bloqueantes = [e for e in errors if e.get("codigo") != "FRECH" and e.get("bloqueante", True)]
    hallazgos_bloqueantes = [h for h in findings if h.get("bloqueante", True)]
    errores_bloquean_importacion = [
        e for e in errors
        if e.get("codigo") != "FRECH" and e.get("bloquea_importacion", e.get("bloqueante", True))
    ]
    hallazgos_bloquean_importacion = [
        h for h in findings
        if h.get("bloquea_importacion", h.get("bloqueante", True))
    ]
    post_import_fiscal = [
        h for h in findings
        if h.get("fase") == "post_import_fiscal"
    ] + [
        e for e in errors
        if e.get("fase") == "post_import_fiscal"
    ]
    hitl = [h for h in findings if h.get("modo") == "hitl_requerido"]

    return {
        "ejercicio": str(ejercicio),
        "resumen": {
            "dr_ok": not estructura,
            "registros": parsed.get("summary", {}).get("records"),
            "registros_cerrados": parsed.get("summary", {}).get("closed_records"),
            "paginas": parsed.get("summary", {}).get("pages"),
            "hallazgos": len(findings),
            "hallazgos_bloqueantes": len(hallazgos_bloqueantes),
            "hallazgos_bloquean_importacion": len(hallazgos_bloquean_importacion),
            "hitl_pendiente": len(hitl),
            "post_import_fiscal_pendiente": len(post_import_fiscal),
            "errores_aeat": len(errors),
            "errores_aeat_bloqueantes": len(errores_bloqueantes),
            "errores_aeat_bloquean_importacion": len(errores_bloquean_importacion),
            "importabilidad_probable": (
                not estructura
                and not hallazgos_bloquean_importacion
                and not errores_bloquean_importacion
            ),
        },
        "estructura": estructura,
        "hallazgos": findings,
        "errores_aeat": errors,
    }


def validar(
    doc: str,
    dr: dict,
    ejercicio: str = "2025",
    *,
    subtotales: dict[str, list[str]] | None = None,
    bin_limite_pct: float | Decimal | None = None,
    errores_aeat_text: str | None = None,
) -> list[dict[str, Any]]:
    """Atajo compatible: devuelve solo los hallazgos locales."""
    return analizar(
        doc,
        dr,
        ejercicio,
        subtotales=subtotales,
        bin_limite_pct=bin_limite_pct,
        errores_aeat_text=errores_aeat_text,
    )["hallazgos"]


def analizar_path(
    file_path: str | os.PathLike[str],
    ejercicio: str = "2025",
    *,
    errores_aeat_path: str | os.PathLike[str] | None = None,
    out_json: str | os.PathLike[str] | None = None,
    out_md: str | os.PathLike[str] | None = None,
) -> dict[str, Any]:
    dr = dr200.cargar_dr(ejercicio=ejercicio)
    doc = Path(file_path).read_bytes().decode("latin1", "replace")
    errores_text = Path(errores_aeat_path).read_text(encoding="utf-8", errors="replace") if errores_aeat_path else None
    report = analizar(doc, dr, ejercicio, errores_aeat_text=errores_text)
    report["archivo"] = str(Path(file_path).resolve())
    if out_json:
        Path(out_json).write_text(json.dumps(report, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    if out_md:
        Path(out_md).write_text(markdown(report), encoding="utf-8")
    return report


def markdown(report: dict[str, Any]) -> str:
    lines = [
        "# Diagnostico de importabilidad Modelo 200",
        "",
        f"- Archivo: `{report.get('archivo', '')}`",
        f"- Ejercicio: `{report.get('ejercicio', '')}`",
        f"- DR OK: `{report['resumen']['dr_ok']}`",
        f"- Importabilidad probable: `{report['resumen']['importabilidad_probable']}`",
        f"- Hallazgos que bloquean importacion: `{report['resumen'].get('hallazgos_bloquean_importacion', report['resumen']['hallazgos_bloqueantes'])}`",
        f"- Pendientes fiscales post-import: `{report['resumen'].get('post_import_fiscal_pendiente', 0)}`",
        f"- HITL pendiente: `{report['resumen']['hitl_pendiente']}`",
        f"- Errores AEAT aportados: `{report['resumen']['errores_aeat']}`",
        "",
    ]
    if report.get("estructura"):
        lines.extend(["## Estructura DR", ""])
        for item in report["estructura"]:
            lines.append(f"- **{item.get('codigo')}** {item.get('pagina', item.get('tag', ''))}: {item.get('mensaje', '')}")
        lines.append("")
    if report.get("hallazgos"):
        lines.extend(["## Hallazgos locales", ""])
        for h in report["hallazgos"]:
            lines.append(
                f"- **{h.get('codigo')}** `{h.get('pagina','')}/{h.get('casilla','')}` "
                f"({h.get('fase', 'pre_import')}, {h.get('modo')}, {h.get('severidad')}): {h.get('mensaje','')} "
                f"Valor `.200` `{h.get('valor_200','')}`; esperado `{h.get('esperado_local','')}`. "
                f"{h.get('accion_propuesta','')}"
            )
        lines.append("")
    if report.get("errores_aeat"):
        lines.extend(["## Errores AEAT/Open cruzados", ""])
        for e in report["errores_aeat"]:
            if e.get("codigo") == "FRECH":
                continue
            lines.append(
                f"- **{e.get('codigo')}** `{e.get('pagina_label','')}/{e.get('casilla','')}` "
                f"({e.get('fase', 'pre_import')}, {e.get('modo')}): local `{e.get('valor_200_local','')}`, "
                f"AEAT calculado `{e.get('calculado_aeat') or ''}`, "
                f"AEAT importado `{e.get('importado_aeat') or ''}`. {e.get('accion_propuesta','')}"
            )
    return "\n".join(lines) + "\n"


def main() -> int:  # pragma: no cover
    ap = argparse.ArgumentParser()
    ap.add_argument("file", help="Ruta del .200")
    ap.add_argument("--ejercicio", default="2025")
    ap.add_argument("--errors", help="Texto pegado de errores/avisos AEAT/Open")
    ap.add_argument("--out-json")
    ap.add_argument("--out-md")
    args = ap.parse_args()

    report = analizar_path(
        args.file,
        ejercicio=args.ejercicio,
        errores_aeat_path=args.errors,
        out_json=args.out_json,
        out_md=args.out_md,
    )
    print(json.dumps(report, ensure_ascii=False, indent=2))
    return 0 if report["resumen"]["importabilidad_probable"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
