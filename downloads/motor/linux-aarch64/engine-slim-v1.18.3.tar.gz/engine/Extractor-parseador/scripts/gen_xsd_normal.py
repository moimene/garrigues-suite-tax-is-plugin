#!/usr/bin/env python3
"""gen_xsd_normal.py — Campos importables del XSD oficial (rama Normal) del Modelo 200.

Transcribe, en ORDEN exacto (xs:sequence), las casillas T##### que el esquema oficial
mod200<ej>.xsd admite en cada página de la rama Normal (Balance 03-06, CuentaPyG 07-08,
CambiosPN 09-11). IMPORTANTE: el XSD NO incluye subtotales/totales/resultados calculados por la AEAT
(p.ej. 00101, 00136, 00180, 00185, 00210, 00228, 00252, 00296, 00324, 00325, 00327, 00500). El builder
debe emitir SOLO estas casillas y en este orden.

Emite:
  - data/xsd_campos_<ej>.json  : {pagina: [casillas en orden], bloques, raiz, rama}
  - data/mod200<ej>_normal.xsd : subesquema válido (rama Normal) para validar con lxml documentos Normal.

Fuente: mod2002024.xsd (AEAT). Para otra campaña, actualizar las listas con su XSD.
"""
import argparse, json
from pathlib import Path

# Orden EXACTO del xs:sequence de cada tipo_PaginaNN (rama Normal) del mod2002024.xsd
PAGINAS = {
 "Pagina03": ["00103","00104","00105","00106","00107","00108","00700","00109","00110","00111","00112",
              "00113","00114","00115","00116","00117","00119","00120","00121","00122","00123","00124",
              "00125","00127","00128","00129","00130","00131","00132","00133","00134","00135","00137",
              "00138","00139","00140","00141","00142","00143","00144","00145","00146","00147","00148","00701"],
 "Pagina04": ["00151","00152","00153","00154","00155","00156","00157","00158","00159","00161","00162",
              "00163","00164","00165","00166","00167","00169","00170","00171","00172","00173","00174",
              "00175","00176","00177","00178","00179"],
 "Pagina05": ["00188","00189","00764","00765","00190","00192","00193","00702","01001","01002","00712",
              "00766","00767","00194","00195","00196","00197","00198","00199","00200","00768","00769",
              "00201","00202","00203","00204","00205","00206","00207","00208","00209","00780","00782",
              "00783","00784","00211","00212","00213","00214","00215","00217","00218","00219","00220",
              "00221","00222","00223","00224","00225","00226","00227"],
 "Pagina06": ["00785","00787","00788","00789","00229","00230","00703","00704","00232","00233","00234",
              "00235","00236","00237","00238","00241","00242","00243","00244","00245","00246","00247",
              "00248","00249","00250","00251"],
 "Pagina07": ["00255","00256","00257","00711","00706","00707","00708","00258","00259","00760","00761",
              "00762","00763","00771","00772","00263","00264","00267","00268","00269","00271","00790",
              "00273","00274","00275","00276","00277","00278","00253","00254","00281","00282","00283",
              "00709","00284","00285","00286","00289","00290","00292","00293","00710","00792","00793",
              "00294","00295"],
 "Pagina08": ["00299","00300","00302","00303","00794","00304","00306","00307","00308","00796","00309",
              "00310","00311","00312","00314","00315","00316","00317","00318","00319","00320","00321",
              "00322","00323","00330","00331","00332","00326","00328"],
 "Pagina09": ["00336","00337","00338","00339","00340","00341","00342","00343","00344","00346","00347",
              "00348","00349","00350","00351","00352","00353"],
 "Pagina10": ["00380","00381","00382","00383","00384","00385","00386","00394","00395","00396","00397",
              "00398","00399","00400","00408","00409","00410","00411","00412","00413","00414","00436",
              "00437","00438","00439","00440","00441","00442","00450","00451","00452","00453","00454",
              "00455","00456","00478","00479","00480","00481","00482","00483","00484","00492","00493",
              "00494","00495","00496","00497","00498","00520","00521","00522","00523","00524","00525",
              "00526","00534","00535","00536","00537","00538","00539","00540","00548","00549","00550",
              "00551","00552","00553","00554","00562","00563","00564","00565","00566","00567","00568",
              "00576","00577","00578","00579","00580","00581","00582","00590","00591","00592","00593",
              "00594","00595","00596","00604","00605","00606","00607","00608","00609","00610","00618",
              "00619","00620","00621","00622","00623","00624","00715","00716","00717","00718","00719",
              "00720","00721","00729","00730","00731","00732","00733","00734","00735"],
 "Pagina11": ["00387","00388","00389","00390","00391","00392","00401","00402","00403","00404","00405",
              "00406","00415","00416","00417","00418","00419","00420","00443","00444","00445","00446",
              "00448","00457","00458","00461","00462","00485","00486","00489","00490","00499","00502",
              "00503","00504","00527","00528","00529","00530","00531","00532","00541","00542","00543",
              "00544","00545","00546","00555","00556","00557","00558","00560","00569","00570","00571",
              "00572","00574","00583","00584","00585","00586","00588","00597","00598","00599","00600",
              "00602","00611","00612","00613","00614","00615","00616","00625","00626","00627","00628",
              "00629","00630","00722","00723","00724","00725","00726","00727","00736","00737","00738",
              "00739","00740","00741"],
}
BLOQUES = {"Balance": ["Pagina03", "Pagina04", "Pagina05", "Pagina06"],
           "CuentaPyG": ["Pagina07", "Pagina08"],
           "CambiosPN": ["Pagina09", "Pagina10", "Pagina11"]}
WRAPPER = {"Balance": "tipo_BalanceNormal", "CuentaPyG": "tipo_CuentaNormal", "CambiosPN": "tipo_CambiosPN"}


def emit_xsd(ejercicio):
    L = ['<?xml version="1.0" encoding="ISO-8859-1"?>',
         '<xs:schema xmlns:xs="http://www.w3.org/2001/XMLSchema" elementFormDefault="qualified" attributeFormDefault="unqualified">',
         '  <xs:simpleType name="tipo_ImpNegativo"><xs:restriction base="xs:decimal">',
         '    <xs:minInclusive value="-9999999999999.99"/><xs:maxInclusive value="9999999999999.99"/>',
         '    <xs:fractionDigits value="2"/></xs:restriction></xs:simpleType>']
    for pag, casillas in PAGINAS.items():
        L.append(f'  <xs:complexType name="tipo_{pag}"><xs:sequence>')
        for c in casillas:
            L.append(f'    <xs:element name="T{c}" type="tipo_ImpNegativo" minOccurs="0"/>')
        L.append('  </xs:sequence></xs:complexType>')
    for bloque, pags in BLOQUES.items():
        L.append(f'  <xs:complexType name="{WRAPPER[bloque]}"><xs:sequence>')
        for p in pags:
            L.append(f'    <xs:element name="{p}" type="tipo_{p}" minOccurs="0"/>')
        L.append('  </xs:sequence></xs:complexType>')
    L += ['  <xs:complexType name="tipo_Normal"><xs:sequence>',
          '    <xs:element name="Balance" type="tipo_BalanceNormal" minOccurs="0"/>',
          '    <xs:element name="CuentaPyG" type="tipo_CuentaNormal" minOccurs="0"/>',
          '    <xs:element name="CambiosPN" type="tipo_CambiosPN" minOccurs="0"/>',
          '  </xs:sequence></xs:complexType>',
          f'  <xs:element name="MOD200{ejercicio}"><xs:complexType><xs:choice>',
          '    <xs:element name="Normal" type="tipo_Normal"/>',
          '  </xs:choice></xs:complexType></xs:element>',
          '</xs:schema>']
    return "\n".join(L) + "\n"


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--ejercicio", default="2024")
    ap.add_argument("--data", default=str(Path(__file__).resolve().parent.parent / "data"))
    a = ap.parse_args()
    data = Path(a.data); data.mkdir(parents=True, exist_ok=True)
    doc = dict(modelo="200", ejercicio=str(a.ejercicio), rama="Normal", raiz=f"MOD200{a.ejercicio}",
               fuente="mod2002024.xsd (AEAT)", bloques=BLOQUES, paginas=PAGINAS,
               total_campos=sum(len(v) for v in PAGINAS.values()))
    (data / f"xsd_campos_{a.ejercicio}.json").write_text(json.dumps(doc, ensure_ascii=False, indent=1), encoding="utf-8")
    (data / f"mod200{a.ejercicio}_normal.xsd").write_bytes(emit_xsd(a.ejercicio).encode("iso-8859-1"))
    print(f"OK · {doc['total_campos']} casillas importables (rama Normal) · "
          f"xsd_campos_{a.ejercicio}.json + mod200{a.ejercicio}_normal.xsd")
    for p, v in PAGINAS.items():
        print(f"  {p}: {len(v)} casillas")


if __name__ == "__main__":
    main()
