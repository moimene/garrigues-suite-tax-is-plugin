"""Generador de `.ses` (sesión de Sociedades WEB / OPEN) — el INVERSO de `ses200_parser`.

FALLBACK resiliente al `.200`: cargar un `.ses` con "Cargar" NO pasa por el recálculo estricto del importador
(a diferencia de "Importar" un `.200`), así que un solo error no tumba la declaración — el abogado recibe la
declaración PRE-RELLENA con lo que genera el harness y completa el residuo (p.ej. la cola de diferencias
temporales de gastos financieros) en la propia herramienta.

Enfoque PLANTILLA (robusto): parte de un `.ses` real (cabecera/secciones/ocurrencias/`sello`) y SUSTITUYE los
valores de las casillas monetarias por los generados; no reconstruye el formato desde cero (que tiene `sello`
y metadatos cuyo significado no está documentado). Las claves van page-keyed `T<NNNNN>_<página>` (p.ej.
`T02369_20`); el valor es decimal con punto y 2 decimales (`3208497.87`). Los flags (`true~…`) no se tocan.

0 PII en este módulo (genérico). La plantilla `.ses` y la salida son LOCALES y gitignored (como `caso_local`).
"""
import re
import zlib

import ses200_parser as ses

_CLAVE_RE = re.compile(r"^T(\d{5})(?:_(\w+))?$")


def _fmt(v):
    """Valor monetario → formato `.ses` (decimal con punto, 2 decimales). No-numérico se deja tal cual."""
    try:
        return f"{float(str(v).replace(',', '.')):.2f}"
    except (ValueError, TypeError):
        return str(v)


def escribir(plantilla_path, casillas_pagina, out_path, fecha_creacion=None):
    """Escribe un `.ses` cargable a partir de la PLANTILLA `plantilla_path`, sustituyendo el valor de cada
    casilla monetaria por el de `casillas_pagina` = {pagina_DR: {casilla: valor}} (page-aware, evita homónimos).
    Devuelve {sustituidas, no_en_plantilla, bytes}. Las casillas que la plantilla no trae NO se añaden (el
    abogado las completa); el `sello`/cabecera se conservan (solo se refresca FechaCreacion si se indica)."""
    txt = ses.descomprimir(plantilla_path)
    by_cp, by_c = {}, {}                                   # {(casilla, sufijo_página): valor} y {casilla: valor}
    for pg, cas in (casillas_pagina or {}).items():
        suf = pg[6:] if pg.startswith("DP200") else ""     # DP200004→'04', DP200020D→'20D'
        for c, v in cas.items():
            by_cp[(c, suf)] = v
            by_c.setdefault(c, v)
    usadas, lineas_out = set(), []
    for linea in txt.split("\n"):
        if "~" not in linea:
            lineas_out.append(linea)
            continue
        partes = linea.split("~", 2)
        if len(partes) != 3:
            lineas_out.append(linea)
            continue
        clave, occ, val = partes
        m = _CLAVE_RE.match(clave.strip())                 # las líneas traen espacios de sangría iniciales
        if not m or ("~" in val) or ("true" in val.lower()):   # no-casilla o flag compuesto: intacto
            lineas_out.append(linea)
            continue
        code, suf = m.group(1), m.group(2)
        nv = by_cp.get((code, suf), by_c.get(code)) if suf else by_c.get(code)
        if nv is None:
            lineas_out.append(linea)
            continue
        usadas.add((code, suf))
        lineas_out.append(f"{clave}~{occ}~{_fmt(nv)}")     # `clave` conserva su sangría original
    nuevo = "\n".join(lineas_out)
    if fecha_creacion:
        nuevo = re.sub(r'FechaCreacion="[^"]*"', f'FechaCreacion="{fecha_creacion}"', nuevo, count=1)
    comp = zlib.compress(nuevo.encode("latin1", "replace"), 9)
    with open(out_path, "wb") as fh:
        fh.write(comp)
    en_plantilla = {c for c, _ in usadas}
    return {"sustituidas": len(usadas), "casillas_distintas": len(en_plantilla),
            "no_en_plantilla": sorted({c for c in by_c} - en_plantilla), "bytes": len(comp)}


def main():   # pragma: no cover
    import sys
    plantilla, out = sys.argv[1], sys.argv[2]
    # casillas desde un .200 (page-aware) si se pasa un 3er arg
    cas = {}
    if len(sys.argv) > 3:
        import os
        sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
        import autocontrol_200
        import dr200
        dr = dr200.cargar_dr(ejercicio=sys.argv[4] if len(sys.argv) > 4 else "2025")
        cas = autocontrol_200.casillas_por_pagina(open(sys.argv[3], encoding="latin1").read(), dr)
    r = escribir(plantilla, cas, out)
    print(f".ses escrito: {out} · {r['bytes']} bytes · {r['sustituidas']} casillas sustituidas "
          f"({r['casillas_distintas']} distintas); {len(r['no_en_plantilla'])} generadas no estaban en la plantilla")


if __name__ == "__main__":
    main()
