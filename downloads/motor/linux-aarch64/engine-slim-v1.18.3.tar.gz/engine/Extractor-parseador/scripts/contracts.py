#!/usr/bin/env python3
"""contracts.py — Contratos tipados y versionados de la tubería EPC (F1, consolidación harness).

Pydantic v2. Contratos IS-specific (PGC / casillas mod200); lo genérico de cobertura/calidad vive en
`parser_core` (decisión híbrida 2026-06-15). Diseñados para ROUND-TRIP con `builder.cargar_canonico`
(CSV ';') SIN cambiar el comportamiento: el número que firma el XML es idéntico.

La PROVENANCE viaja en el OBJETO (campo `fuente` del canónico + `_fuente` por fila), no en el centinela
in-band despojable -> cierra el LÍMITE CONOCIDO a nivel de OBJETO. El cierre server-bound pleno (un cliente
API directo no puede forjar la provenance) es F2, vía el run-model como emisor/verificador. Versionado POR
CONTRATO (`schema_version`).

Endurecido tras revisión adversarial (Codex, 2026-06-15):
  - `_f` NO zerea valores ilegibles (regla dura "nunca inventar cifras"): None->0.0, resto float() que peta.
  - `to_csv` usa csv.writer (entrecomilla ';'/comillas/saltos) -> round-trip seguro contra cargar_canonico.
  - `from_csv` espeja `builder.cargar_canonico` EXACTAMENTE (mismo guard, un solo BOM utf-8-sig).
  - modelo `frozen` + validador que RECHAZA inferido+exportable (fail-closed no evitable por mutación).
  - `_fuente` se guarda como dict (sin pérdida de claves/tipos), no se serializa al CSV.
"""
from __future__ import annotations

import csv
import hashlib
import io
import json
from enum import Enum
from typing import Optional

from pydantic import BaseModel, Field, model_validator

# El centinela in-band se mantiene por compatibilidad con clientes que pasan CSV crudo; los llamadores
# TIPADOS usan `CanonicoContable.fuente`. DEBE coincidir con engines._CENTINELA_CCAA_A3 (lo fija un test
# byte-for-byte). F2/F3 deberían unificar haciendo que engines importe esta constante desde aquí.
CENTINELA_CCAA_A3 = "# PROVENANCE=ccaa_a3_inferido; no_exportable_sin_confirmacion_HITL"
HEADER_CSV = "Cuenta;Descripción;Saldo Final;Debe;Haber;Saldo Inicial"


def _f(x) -> float:
    """float() de un valor PRESENTE. Un ilegible (string no numérica, o `None` presente) LEVANTA: nunca se
    inventa 0.0 (regla dura). El default por AUSENCIA de clave lo pone el llamador con `.get(k, 0.0)`, que
    espeja a `_canonico_csv_desde_filas` (`dict.get(k, 0.0)`): clave ausente -> 0.0; clave presente pero
    ilegible -> el flujo legacy también peta (en el builder). NaN/Inf los admite `float()` igual que el
    legacy (mismo `float()`): NO se filtran aquí para no DIVERGIR, y el gate de cuadre tol=0 los rechaza
    aguas abajo (nan/inf nunca cuadran -> fail-closed)."""
    return float(x)


class FuenteCanonico(str, Enum):
    """Provenance del canónico completo (qué vía lo produjo). Gobierna el gating HITL."""
    sys = "sys"                       # Sumas y Saldos real (CASO A, determinista, exportable)
    mayor = "mayor"                   # libro mayor real (CASO A)
    ccaa_inferido = "ccaa_inferido"   # inferido de CCAA/OCR (CASO B): NO exportable sin confirmación HITL


class FilaCanonica(BaseModel):
    """Fila del canónico 4d en la forma que consume `builder` (cuenta/denom/sf/debe/haber/si) + provenance.
    `fuente_celda` se guarda como dict CRUDO (espejo de tipos.FuenteCelda, TypedDict total=False): no se
    coercionan ni se pierden claves; no se serializa al CSV."""
    model_config = {"populate_by_name": True}

    cuenta: str
    denom: str = ""
    sf: float = 0.0
    debe: float = 0.0
    haber: float = 0.0
    si: float = 0.0
    fuente_celda: Optional[dict] = Field(default=None, alias="_fuente")


class Cuadres(BaseModel):
    """Cuadres del canónico. CAMPO de datos: lo rellena el ÚNICO sitio que los calcula (no se recalcula
    aquí — evitar una N-ésima implementación del cuadre es el objetivo de la consolidación)."""
    suma_debe: float
    suma_haber: float
    cuadra_debe_haber: bool


class CanonicoContable(BaseModel):
    """Contrato del canónico contable (v1). La provenance (`fuente`) viaja AQUÍ, no en el CSV.

    `frozen=True`: value-object inmutable -> el invariante fail-closed (inferido => no exportable) no se
    salta por asignación normal. Las vías que Pydantic NO valida (`model_construct`, `model_copy(update=)`,
    `object.__setattr__`) sí podrían forzar el campo; por eso la DECISIÓN de exportar se toma con
    `puede_exportar()` (derivada), no con el booleano crudo `exportable_a_importador`."""
    model_config = {"frozen": True}

    schema_version: str = "1"
    fuente: FuenteCanonico
    filas: list[FilaCanonica] = Field(default_factory=list)
    cuadres: Optional[Cuadres] = None
    coverage: Optional[dict] = None          # forma estable de parser_core.cobertura_pgc (caller-populated)
    exportable_a_importador: bool = False

    @model_validator(mode="after")
    def _fail_closed_inferido_no_exportable(self) -> "CanonicoContable":
        """Invariante fail-closed: un canónico inferido (CASO B) NO puede ser exportable sin confirmación
        HITL. Se RECHAZA (loud), no se coacciona en silencio: marcar exportable un inferido es un error del
        llamador, y con el modelo frozen no hay coerción válida tras construir."""
        if self.fuente == FuenteCanonico.ccaa_inferido and self.exportable_a_importador:
            raise ValueError("canónico inferido (CASO B) no puede ser exportable_a_importador (HITL obligatorio)")
        return self

    @property
    def es_inferido(self) -> bool:
        """CASO B por el CAMPO TIPADO (no por sniff del centinela): robusto ante despojar el string."""
        return self.fuente == FuenteCanonico.ccaa_inferido

    def puede_exportar(self) -> bool:
        """Decisión de exportabilidad DERIVADA: un inferido NUNCA exporta, pase lo que pase con el campo
        `exportable_a_importador`. Los chokepoints deben usar ESTO, no el booleano crudo. Razón: en Pydantic
        v2 `model_copy(update=...)`, `object.__setattr__` y `model_construct` NO re-ejecutan el validador
        (Codex, ronda 2), así que un patch podría dejar un inferido con `exportable_a_importador=True`;
        recomputar el invariante al LEER lo mantiene fail-closed sin depender de cómo se fijó el campo."""
        return self.exportable_a_importador and not self.es_inferido

    # ----------------------------------------------------------------- entrada
    @classmethod
    def from_a3_filas(cls, filas_a3: list, fuente: FuenteCanonico,
                      exportable: bool = False) -> "CanonicoContable":
        """Filas A3 (descripcion/saldo_final/saldo_inicial, salida de generar_sys) -> contrato tipado.
        Un importe presente pero ilegible NO se zerea (regla dura): `_f` levanta."""
        filas = [FilaCanonica(cuenta=str(f.get("cuenta", "")), denom=str(f.get("descripcion", "")),
                              sf=_f(f.get("saldo_final", 0.0)), debe=_f(f.get("debe", 0.0)),
                              haber=_f(f.get("haber", 0.0)), si=_f(f.get("saldo_inicial", 0.0)),
                              fuente_celda=f.get("_fuente"))
                 for f in (filas_a3 or [])]
        return cls(fuente=fuente, filas=filas, exportable_a_importador=exportable)

    @classmethod
    def from_filas(cls, filas: list, fuente: FuenteCanonico,
                   exportable: bool = False) -> "CanonicoContable":
        """Filas ya en forma builder (cuenta/denom/sf/debe/haber/si [+_fuente]) -> contrato tipado."""
        norm = [FilaCanonica(cuenta=str(f.get("cuenta", "")), denom=str(f.get("denom", "")),
                             sf=_f(f.get("sf", 0.0)), debe=_f(f.get("debe", 0.0)),
                             haber=_f(f.get("haber", 0.0)), si=_f(f.get("si", 0.0)),
                             fuente_celda=f.get("_fuente"))
                for f in (filas or [])]
        return cls(fuente=fuente, filas=norm, exportable_a_importador=exportable)

    @classmethod
    def from_csv(cls, texto: str, fuente: Optional[FuenteCanonico] = None) -> "CanonicoContable":
        """CSV ';' (con/sin centinela) -> contrato. Parseo IDÉNTICO a builder.cargar_canonico: mismo guard
        (`r and r[0].strip().isdigit()`, sin tope de columnas -> una fila numérica corta levanta igual que
        el builder), csv.reader, un solo BOM (utf-8-sig). Si `fuente` no se pasa, se SNIFFEA del centinela
        in-band: ese sniff es DESPOJABLE (documenta el LÍMITE que F2 cierra server-side). Por ser substring,
        un denom que contuviera el literal del centinela daría un falso positivo 'inferido' (dirección
        fail-closed: bloquearía un SyS legítimo, no al revés); lo cierra el marcador estructurado de F2."""
        texto = texto or ""
        if texto.startswith("\ufeff"):          # utf-8-sig quita UN BOM inicial, no varios
            texto = texto[1:]
        if fuente is None:
            fuente = (FuenteCanonico.ccaa_inferido
                      if CENTINELA_CCAA_A3 in texto else FuenteCanonico.sys)
        filas = []
        for r in csv.reader(io.StringIO(texto), delimiter=";"):
            if r and str(r[0]).strip().isdigit():
                filas.append(FilaCanonica(cuenta=r[0].strip(), denom=r[1],
                                          sf=float(r[2]), debe=float(r[3]),
                                          haber=float(r[4]), si=float(r[5])))
        return cls(fuente=fuente, filas=filas)

    # ----------------------------------------------------------------- salida
    def to_filas(self) -> list:
        """Forma que consume `builder.cargar_canonico`/`proyectar`: dicts cuenta/denom/sf/debe/haber/si
        (+ `_fuente` VERBATIM cuando hay provenance por celda; sin coerción ni pérdida de claves)."""
        out = []
        for x in self.filas:
            d = {"cuenta": x.cuenta, "denom": x.denom, "sf": x.sf,
                 "debe": x.debe, "haber": x.haber, "si": x.si}
            if x.fuente_celda is not None:
                d["_fuente"] = x.fuente_celda
            out.append(d)
        return out

    def to_csv(self) -> str:
        """CSV ';' compatible con builder.cargar_canonico. Usa csv.writer para las FILAS (entrecomilla ';',
        comillas y saltos -> round-trip seguro contra cargar_canonico, que también es csv.reader). El
        centinela y la cabecera van LITERALES (byte-for-byte con engines._canonico_csv_desde_filas para
        filas de valores float sin caracteres CSV-especiales). El `_fuente` NO se serializa."""
        cab = [CENTINELA_CCAA_A3, HEADER_CSV] if self.es_inferido else [HEADER_CSV]
        buf = io.StringIO()
        w = csv.writer(buf, delimiter=";", lineterminator="\n")
        for f in self.filas:
            w.writerow([f.cuenta, f.denom, f.sf, f.debe, f.haber, f.si])
        cuerpo = buf.getvalue().rstrip("\n")
        return "\n".join(cab + ([cuerpo] if cuerpo else []))


class CuadreProyeccion(BaseModel):
    """Cuadre del balance AEAT proyectado (salida de builder.proyectar). `dif` = 00180 − 00252 (debe ser 0
    a céntimos para firmar; `reconciliador.exigir_cuadre_proyeccion` es la AUTORIDAD fail-closed)."""
    total_activo: float
    total_pnpasivo: float
    dif: float
    resultado: float                         # R = Σ PyG = casilla 00500
    no_map: list[str] = Field(default_factory=list)
    n_casillas: int = 0


class ProyeccionAeat(BaseModel):
    """Contrato de la PROYECCIÓN AEAT (v1): salida del exportador (`builder.proyectar`) = casillas del mod200
    + cuadre + traza de lineage cuenta->casilla. `frozen` value-object. NO recomputa fiscalidad: envuelve lo
    que el builder YA calculó (el número que firma el XML no cambia)."""
    model_config = {"frozen": True}

    schema_version: str = "1"
    casillas: dict[str, float] = Field(default_factory=dict)
    cuadre: CuadreProyeccion
    lineage: list[dict] = Field(default_factory=list)   # traza cuenta->casilla VERBATIM (lossless, como _fuente)

    @classmethod
    def from_proyectar(cls, casillas: dict, lineage: list, cuadre: dict) -> "ProyeccionAeat":
        """Envuelve la 3-upla relevante de `builder.proyectar` (casillas, lineage, cuadre) en el contrato."""
        return cls(casillas=dict(casillas or {}),
                   cuadre=CuadreProyeccion(**(cuadre or {})),
                   lineage=list(lineage or []))

    @property
    def cuadra(self) -> bool:
        """B3 (lectura DERIVADA, no autoridad): el balance AEAT cuadra si 00180==00252 (dif==0 a céntimos).
        Solo expone el `dif` ya calculado por el builder; el gate fail-closed es `reconciliador`."""
        return round(self.cuadre.dif, 2) == 0.0


class Firma(BaseModel):
    """Contrato de la FIRMA (v1): el NÚMERO firmado por el motor Python (ADR-001) que va al XML y al gating.
    `frozen` value-object. El `hash` (SHA256[:16] sobre las casillas, sort_keys) es el SELLO de integridad:
    `hash_valido()` lo recomputa para detectar manipulación del número entre la firma y su consumo.

    Las casillas se guardan como dict CRUDO (sin coerción de valores int/float): el sello se computa sobre el
    `json.dumps` exacto, así que coercer los valores rompería la verificación (misma lección que `_fuente`).
    NO recomputa fiscalidad: `apto_para_firma` lo decide el orquestador (motor_expediente M4), aquí solo viaja."""
    model_config = {"frozen": True}

    schema_version: str = "1"
    base_imponible: Optional[float] = None
    cuota_integra: Optional[float] = None
    cuota_liquida: Optional[float] = None
    cuota_a_ingresar: Optional[float] = None
    casillas: dict = Field(default_factory=dict)      # crudo (sin coerción de valores) -> hash fiel
    hash: str = ""
    autoridad: str = ""
    apto_para_firma: Optional[bool] = None

    @classmethod
    def from_firma(cls, firma: dict) -> "Firma":
        """Envuelve la salida de `engines.firma_desde_orquestado` (base/cuotas/casillas/hash/autoridad/apto).
        Copia las casillas tal cual (sin tocar valores) para preservar el sello."""
        f = firma or {}
        return cls(base_imponible=f.get("base_imponible"), cuota_integra=f.get("cuota_integra"),
                   cuota_liquida=f.get("cuota_liquida"), cuota_a_ingresar=f.get("cuota_a_ingresar"),
                   casillas=dict(f.get("casillas") or {}), hash=str(f.get("hash") or ""),
                   autoridad=str(f.get("autoridad") or ""), apto_para_firma=f.get("apto_para_firma"))

    def hash_recomputado(self) -> str:
        """Recalcula el sello EXACTAMENTE como engines.firma_desde_orquestado: SHA256 de
        json.dumps(casillas, sort_keys=True, default=str), 16 hex. DEBE coincidir con esa fórmula."""
        return hashlib.sha256(
            json.dumps(self.casillas, sort_keys=True, default=str).encode()
        ).hexdigest()[:16]

    def hash_valido(self) -> bool:
        """Integridad: el `hash` sella las casillas firmadas; recomputa y compara -> detecta manipulación del
        número entre la firma del motor y su consumo (XML/gating). Los chokepoints pueden exigirlo."""
        return bool(self.hash) and self.hash == self.hash_recomputado()


class CoberturaCalidad(BaseModel):
    """Contrato Cobertura/Calidad (v1, decisión híbrida): envuelve la forma GENÉRICA de `parser_core`
    (`cobertura_pgc` + `QualityReport`) para el pipeline IS. `frozen`. Es OBSERVABILIDAD (no el número
    firmado): dicts crudos, sin coerción. Lo genérico vive en parser_core (liftable, sin deps); aquí solo
    el envoltorio tipado/versionado del pipeline."""
    model_config = {"frozen": True}

    schema_version: str = "1"
    cobertura: dict = Field(default_factory=dict)   # parser_core.cobertura_pgc: {cuentas, mapeadas, pct_*, warnings}
    calidad: dict = Field(default_factory=dict)      # parser_core.QualityReport.to_dict(): {confianza_media, n_*, apto_auto}

    @classmethod
    def from_ingesta(cls, cobertura: dict, calidad: dict) -> "CoberturaCalidad":
        """Envuelve la cobertura PGC + el QualityReport (ambos dicts ya calculados) en el contrato."""
        return cls(cobertura=dict(cobertura or {}), calidad=dict(calidad or {}))

    @property
    def apto_auto(self) -> bool:
        """Conveniencia derivada: True si la calidad no exige intervención humana (sin revisión ni bloqueo)."""
        return bool(self.calidad.get("apto_auto"))
