#!/usr/bin/env python3
"""motor_sys.py — Motor de normalización del Sumas y Saldos (EPC-IS, PRD §9A).

Productiza los 2 prompts de Harvey (ver referencias/PROMPTS_Harvey_SyS_a_A3.md):

  Etapa A (validación)  : detección de columnas -> truncado 4d/3d -> match contra maestro PGC
                          -> análisis de naturaleza/signo + reglas guía por descripción
                          -> TABLA DE VALIDACIÓN (solo filas con duda) [human-in-the-loop].
  Etapa B (agrupado)    : agrupa a 4 dígitos (3d -> 4d añadiendo '0'), suma por cuenta,
                          denominación oficial del maestro, FORMATO ESPAÑOL (1.234,56)
                          -> "Sumas y Saldos A3": Cuenta | Descripción | Saldo Final | Debe | Haber | Saldo Inicial.
  Cuadres               : Σ Debe = Σ Haber ; Σ deudor = Σ acreedor ; Σ saldo final.
  Lineage               : por fila original -> c4 -> asignado -> resolución (auditoría).

Diseño schema-first / determinista: no inventa códigos; si un código no está en el maestro,
lo marca para revisión humana (no lo fuerza). La fase de juicio fino (descripción/signo) propone,
no aplica: la confirmación es del profesional (Etapa A se "detiene" para validación).

Lector robusto: usa python-calamine (lee .xls BIFF, .xls de JasperReports, .xlsx) con
fallback a xlrd / openpyxl / csv.

Uso:
  python3 motor_sys.py --input SyS.(xls|xlsx|csv) \
      --maestro ../data/pgc_maestro.csv --outdir ../salidas/GIP [--empresa "GIP" --ejercicio 2025]
"""
from __future__ import annotations
import argparse, csv, os, re
from decimal import Decimal, ROUND_HALF_UP
from pathlib import Path


def _cent(x) -> Decimal:
    """Importe -> céntimos exactos (Decimal ROUND_HALF_UP); cuadre tol=0 sin ruido float (B3)."""
    return Decimal(str(x or 0)).quantize(Decimal("0.01"), rounding=ROUND_HALF_UP)

# --------------------------------------------------------------------------- IO

def leer_filas(path: str) -> list[list]:
    """Devuelve la hoja como lista de filas (listas de celdas). Lector robusto."""
    ext = os.path.splitext(path)[1].lower()
    if ext in (".xls", ".xlsx", ".xlsm"):
        # 1) calamine (cubre BIFF clásico, JasperReports y OOXML)
        try:
            import pandas as pd
            df = pd.read_excel(path, engine="calamine", header=None)
            return df.where(df.notna(), None).values.tolist()
        except Exception:
            pass
        # 2) xlrd para .xls antiguos
        if ext == ".xls":
            try:
                import xlrd
                b = xlrd.open_workbook(path); s = b.sheet_by_index(0)
                return [[s.cell_value(i, j) for j in range(s.ncols)] for i in range(s.nrows)]
            except Exception:
                pass
        # 3) openpyxl para OOXML
        try:
            import openpyxl
            ws = openpyxl.load_workbook(path, data_only=True).worksheets[0]
            return [list(r) for r in ws.iter_rows(values_only=True)]
        except Exception:
            pass
        raise SystemExit(f"No se pudo leer el Excel: {path}")
    # CSV
    with open(path, encoding="utf-8-sig", newline="") as f:
        sample = f.read(2048); f.seek(0)
        delim = ";" if sample.count(";") >= sample.count(",") else ","
        return [r for r in csv.reader(f, delimiter=delim)]


def cargar_maestro(path: str) -> dict[str, str]:
    m = {}
    with open(path, encoding="utf-8-sig", newline="") as f:
        for r in csv.reader(f, delimiter=";"):
            if len(r) >= 2 and r[0].strip().isdigit():
                m[r[0].strip()] = r[1].strip()
    return m

# --------------------------------------------------------------------- helpers

def _norm(s) -> str:
    return str(s if s is not None else "").strip().lower()

def _sin_acentos(s: str) -> str:
    tab = str.maketrans("áéíóúüñ", "aeiouun")
    return s.translate(tab)

def num(s):
    """Parsea importe a float. Acepta formatos con coma o punto; vacío -> None."""
    if s is None or s == "":
        return None
    if isinstance(s, (int, float)):
        return float(s)
    t = str(s).strip().replace("€", "").replace(" ", "").replace("\xa0", "")
    if t in ("", "-", "--"):
        return None
    # Si tiene coma y punto, el último separador es el decimal
    if "," in t and "." in t:
        if t.rfind(",") > t.rfind("."):
            t = t.replace(".", "").replace(",", ".")
        else:
            t = t.replace(",", "")
    elif "," in t:
        t = t.replace(",", ".")
    try:
        return float(t)
    except ValueError:
        return None

def fmt_es(x) -> str:
    """Formato español: punto miles, coma decimal. -32661132.0 -> '-32.661.132,00'."""
    if x is None:
        return ""
    neg = x < 0
    s = f"{abs(x):,.2f}".replace(",", "§").replace(".", ",").replace("§", ".")
    return ("-" if neg else "") + s

def naturaleza(cod: str) -> str:
    """Naturaleza esperada (convención de signo: deudora>0, acreedora<0)."""
    if cod[:2] in ("28", "29"):
        return "acreedora"            # amort. acumulada / deterioro (contra-activo)
    if cod[:2] in ("13",):
        return "mixta/revisar"        # ajustes por cambios de valor / dif. conversión
    if cod[:3] in ("129",):
        return "mixta/revisar"        # resultado del ejercicio
    g = cod[:1]
    if g in ("2", "3", "6"):
        return "deudora"
    if g in ("1", "7"):
        return "acreedora"
    if g in ("4", "5"):
        return "mixta/revisar"        # 4 y 5 tienen cuentas deudoras y acreedoras
    return "mixta/revisar"

# Reglas guía 5.1 (subconjunto del prompt Harvey). Devuelve (codigo_propuesto, motivo) o None.
def regla_descripcion(desc: str, c3: str, c4: str):
    d = _sin_acentos(_norm(desc))
    if "amortizacion acumulada" in d or ("amort" in d and "acum" in d):
        if c3.startswith("28"):
            return None  # ya es amortización acumulada
        if any(k in d for k in ("intangible", "aplicac", "i+d", "investig", "desarrollo")):
            return ("280x", "Amortización acumulada de inmovilizado intangible -> 280x")
        return ("281x", "Amortización acumulada de inmovilizado material -> 281x")
    if "deterioro" in d and c3.startswith("28"):
        return ("29x", "Es deterioro (29x), no amortización acumulada (28x)")
    if "gastos anticipados" in d:
        return ("480", "'Gastos anticipados' -> 480")
    if "ingresos anticipados" in d or "prevision de ingresos" in d:
        return ("485", "'Ingresos anticipados' -> 485")
    if any(k in d for k in ("banco", "caixa", "bankia", "santander", "bbva", "tesoreria", "c/c", "cuenta cte", "cuenta corriente")):
        if any(k in d for k in ("dolar", "dólar", "usd", "divisa", "moneda extranjera", "mep")):
            return ("573", "Tesorería en moneda extranjera -> 573")
        return ("572", "Tesorería en euros -> 572")
    if "impuesto sobre benef" in d or ("impuesto" in d and "benef" in d):
        return ("630", "'Impuesto sobre beneficios' -> 630")
    if "ajustes positivos" in d and "indirecta" in d:
        return ("639", "Ajustes positivos en imposición indirecta -> 639")
    # Holding: ingreso por participaciones/dividendos mal codificado en 70x (ventas)
    if c3.startswith("70") and any(k in d for k in ("particip", "dividend", "de capital")):
        return ("760", "Ingreso por participaciones/dividendos -> 760 (no 70x ventas)")
    return None

# ------------------------------------------------------------------ detección

ROLES = ("cuenta", "descripcion", "saldo_final", "saldo_inicial", "debe", "haber")

# Sinónimos de cabecera ES + EN (exports tipo ERP). EN: Account/Description/Actual Debit/Actual Credit/
# Actual YTD (o Balance). Añadido 2026-06-25 por caso real con TB en inglés. El ES queda intacto
# (no-regresión GIP): las nuevas ramas EN solo disparan con tokens en inglés ausentes en los SyS españoles.
def _h_cuenta(c): return c.startswith(("cuenta", "codig", "códig", "account"))
def _h_desc(c):   return ("descrip" in c) or ("concepto" in c) or ("description" in c)
def _h_sfinal(c): return ("saldo" in c and ("actual" in c or "final" in c)) or ("ytd" in c) or (c.strip() in ("balance", "closing balance"))
def _h_sini(c):   return ("saldo" in c and ("ant" in c or "inicial" in c)) or ("opening" in c) or ("prior" in c)
def _h_debe(c):   return c.startswith("debe") or ("debit" in c)
def _h_haber(c):  return c.startswith("haber") or ("credit" in c)


def detectar(filas):
    for i, row in enumerate(filas):
        cells = [_norm(c) for c in row]
        if any(_h_cuenta(c) for c in cells) and any(_h_desc(c) for c in cells):
            col = {}
            for j, c in enumerate(cells):
                if _h_cuenta(c) and "cuenta" not in col:
                    col["cuenta"] = j
                elif _h_desc(c) and "descripcion" not in col:
                    col["descripcion"] = j
                elif _h_sfinal(c) and "saldo_final" not in col:
                    col["saldo_final"] = j
                elif _h_sini(c) and "saldo_inicial" not in col:
                    col["saldo_inicial"] = j
                elif _h_debe(c):
                    col["debe"] = j if ("actual" in c or "debe" not in col) else col["debe"]
                elif _h_haber(c):
                    col["haber"] = j if ("actual" in c or "haber" not in col) else col["haber"]
            if "saldo_final" not in col:
                for j, c in enumerate(cells):
                    if c.strip() == "saldo" or "importe" in c:
                        col["saldo_final"] = j; break
            return i, col
    raise SystemExit("No se detectó la cabecera (Cuenta / Descripción).")


# Detección de FORMATO «TB internacional» (export ERP de grupo, cabecera en inglés). Marcadores que NO
# existen en un SyS español (GIP/ARIOSO ⇒ no entran ⇒ camino ES intacto, byte-idéntico): «Actual Debit/
# Credit/YTD», «Local addition code», «GL account code». Devuelve True solo si la fila de cabecera trae
# esos rótulos. Particularidades de esta familia (caracterizadas sobre grupos reales, 2026-06-27):
#   - el «Account» es el plan INTERNO del grupo (PGC-like 4d), el saldo final = «Actual YTD» CON SIGNO;
#   - el «Actual Credit» (Haber) viene en NEGATIVO ⇒ Σdebe=+X, Σhaber=−X ⇒ falso descuadre Σdebe≠Σhaber;
#   - el resultado va por partida doble: cuenta 129x (Pérdidas y ganancias) + un PLUG «Not Applicable»
#     que la compensa (129x + plug = 0). El motor ya excluye el plug y deriva el resultado de la P&L (6/7);
#     mantener 129x dejaría Σdeudor≠Σacreedor por el importe del resultado.
# El tratamiento (Haber→abs, 129x excluida como el plug) se aplica SOLO en esta rama; el camino ES no cambia.
def formato_internacional(filas, hidx) -> bool:
    if hidx is None or hidx >= len(filas):
        return False
    cells = [_norm(c) for c in filas[hidx]]
    tiene_actual = any(("actual" in c and ("debit" in c or "credit" in c)) or ("ytd" in c) for c in cells)
    tiene_codigo_grupo = any(("local addition code" in c) or ("gl account code" in c) for c in cells)
    return tiene_actual or tiene_codigo_grupo

# Overrides de cuenta->cuenta SOLO para «TB internacional» (scoped): NO son reglas PGC generales. Se consultan
# ÚNICAMENTE en la rama intl (formato_internacional()==True); el camino ES (GIP/ARIOSO/CCAA) nunca los ve, por
# lo que el maestro PGC y el mapeo_pgc_aeat.json quedan intactos para ES. Cada entrada reasigna el código 4d de
# AGREGACIÓN a otro código 4d que SÍ tiene casilla en el mapeo (la casilla la sigue resolviendo builder por su
# regla de prefijo: aquí NO se inventa ninguna casilla). Caracterizado sobre grupos reales y confirmado por el
# abogado 2026-06-28.
#   4370: el TB internacional de esta familia describe la cuenta 4370 como «Anticipos de clientes» (PGC 438 ->
#         casilla 00248). En el PGC el 437 es «Envases y embalajes a devolver por clientes» (!= anticipos), así
#         que es una COLISIÓN SEMÁNTICA: prevalece la descripción contable de la fuente. Se reasigna 4370 -> 4380
#         SOLO en intl para que builder lo lleve a 00248 (regla 438). NO se extiende como regla PGC general
#         (437 = envases; los anticipos son 438 = 00248). Trazado en la tabla de validación.
OVERRIDES_INTL = {
    "4370": {"a": "4380", "denom": "Anticipos de clientes (TB internacional; PGC 438)",
             "nota": ("4370->00248 solo para TB internacional de grupo por prevalencia de la descripcion contable "
                      "fuente \"Anticipos de clientes\" sobre el maestro PGC 437; no extender como regla PGC "
                      "general (437=envases; anticipos=438=00248)")},
}

# ----------------------------------------------------------------------- core

def procesar(filas, maestro):
    hidx, col = detectar(filas)
    intl = formato_internacional(filas, hidx)   # rama «TB internacional» (aditiva, no toca el camino ES)
    def cell(row, key):
        j = col.get(key)
        return row[j] if (j is not None and j < len(row)) else None

    grupos = {}          # c4 -> agregados
    revision = []        # filas para la tabla de validación (Etapa A)
    lineage = []         # auditoría por fila
    n_filas = 0

    # Mapeo por DESCRIPCIÓN + INFERENCIA (plan no-PGC, p. ej. de grupo internacional). Dos estructuras sobre
    # el maestro (solo cuentas significativas >=3 díg.): (a) índice EXACTO {denominación normalizada -> código},
    # excluyendo colisiones; (b) nombres/tokens normalizados para la INFERENCIA fuzzy. Añadido 2026-06-25.
    from difflib import SequenceMatcher
    _desc_idx, _desc_col, _nn, _nt = {}, set(), {}, {}
    for _code, _den in maestro.items():
        if len(re.sub(r"\D", "", str(_code))) < 3:
            continue
        _k = _norm(re.sub(r"\([^)]*\)", " ", _den))   # ignora coletillas «(euros)», «(pesetas)»…
        if not _k:
            continue
        if _k in _desc_idx and _desc_idx[_k] != _code:
            _desc_col.add(_k)
        else:
            _desc_idx[_k] = _code
        _nn[_code] = _k
        _nt[_code] = frozenset(t for t in _k.split() if len(t) >= 2)
    for _k in _desc_col:
        _desc_idx.pop(_k, None)

    def _inferir(_d):
        """INFERENCIA fuzzy (seq 50% + solape de tokens 50%) -> (código, score) si score>=0.5; si no (None,score).
        Carga asistida + Cowork: se APLICA para que el contable proyecte y se importe, marcada «inferida» para que
        el abogado la revise TRAS importar. Nunca toca cuentas que ya casan por código (GIP byte-idéntico)."""
        _dn = _norm(re.sub(r"\([^)]*\)", " ", _d or ""))
        if not _dn:
            return None, 0.0
        _dtok = frozenset(t for t in _dn.split() if len(t) >= 2)
        _best, _sc = None, 0.0
        for _c, _nm in _nn.items():
            _seq = SequenceMatcher(None, _dn, _nm).ratio()
            _tk = _nt.get(_c, frozenset())
            _tok = (len(_dtok & _tk) / len(_dtok | _tk)) if (_dtok or _tk) else 0.0
            _s = 0.5 * _seq + 0.5 * _tok
            if _s > _sc:
                _best, _sc = _c, _s
        return (_best, round(_sc, 3)) if _sc >= 0.5 else (None, round(_sc, 3))

    for row in filas[hidx + 1:]:
        cv = cell(row, "cuenta")
        desc = str(cell(row, "descripcion") or "").strip()
        if cv in (None, "") and not desc:
            continue
        sf = num(cell(row, "saldo_final"))
        si = num(cell(row, "saldo_inicial"))
        debe = num(cell(row, "debe")) or 0.0
        haber = num(cell(row, "haber")) or 0.0
        # [TB internacional] El «Actual Credit» (Haber) viene en NEGATIVO en estos exports de grupo. Se
        # NORMALIZA a positivo (convención SyS: Haber>0) para que Σdebe=Σhaber cuadre (hoy Σhaber=−X daba un
        # descuadre espurio que bloqueaba la emisión). El saldo final = «Actual YTD» CON SIGNO no se toca (la
        # naturaleza/cuadre deudor=acreedor se calcula sobre el saldo, no sobre debe/haber). Solo en esta rama.
        if intl and haber < 0:
            haber = -haber
        # [TB internacional] Simétrico al Haber: algún «Actual Debit» (Debe) viene en NEGATIVO (ajuste con signo
        # en la columna del Debe, p.ej. 6380 «Ajustes en la imposición» con Debe=−X / Haber=+X). Se NORMALIZA a
        # positivo (convención SyS: Debe>0) para que Σdebe=Σhaber cuadre (sin esto, un Debe=−X daba Σdebe−Σhaber=
        # −2X y bloqueaba la emisión por la identidad de mayor SI+debe−haber≠SF, pese a cuadrar el balance por
        # saldos). El saldo final (Actual YTD, con signo) no se toca. Solo en la rama internacional. (2026-06-28)
        if intl and debe < 0:
            debe = -debe
        cod = re.sub(r"\D", "", str(cv))
        # Cuentas-PLUG del ERP (descripción «Not Applicable»/«N/A»/«sin asignar»): NO son cuentas PGC y se
        # EXCLUYEN del balance. Suele ser el RESULTADO DEL EJERCICIO embebido, que el motor ya deriva de la
        # cuenta de P&L (no se mete a mano). Confirmado por el equipo fiscal (caso RRE, 2026-06-25). Se traza.
        if _norm(desc) in ("not applicable", "no aplica", "n a", "na", "sin asignar"):
            # Cuenta-PLUG del ERP («Not Applicable»/«N/A»/«sin asignar»): NO es cuenta PGC -> se EXCLUYE del
            # balance. Si tiene saldo suele ser el RESULTADO DEL EJERCICIO embebido; el resultado del balance lo
            # deriva el motor de la P&L (resultado_casillas), no de esta cuenta. Confirmado equipo fiscal RRE 2026-06-25.
            if sf or debe or haber:
                revision.append(dict(orig=str(cv), desc=desc, sf=sf, nat="—", signo="—", prop="", denom="",
                                     tipo="excluida (plug ERP = resultado del ejercicio)",
                                     motivo="Cuenta-plug del ERP con saldo (resultado del ejercicio embebido); excluida del balance. El resultado del balance lo deriva el motor de la P&L (resultado_casillas) — confirmar con el cliente.",
                                     alt="", notas=""))
            continue
        # [TB internacional] Cuenta 129x «Pérdidas y ganancias» con saldo = el RESULTADO del ejercicio. En estos
        # TB de grupo el resultado va por partida doble (129x + el plug «Not Applicable», que suman 0); el plug
        # se acaba de excluir arriba. Mantener 129x dejaría Σdeudor≠Σacreedor por el importe del resultado, y el
        # motor YA deriva el resultado de la P&L (cuentas 6/7 → resultado_casillas → 00199), así que 129x es
        # redundante para el balance. Se EXCLUYE (igual que el plug y que el camino ES, donde 129x va cerrada a
        # 0). Solo en la rama internacional: el camino ES no llega aquí (en GIP 129x trae saldo final 0).
        _cod_intl = re.sub(r"\D", "", str(cv))
        if intl and _cod_intl.startswith("129"):
            if sf or debe or haber:
                revision.append(dict(orig=str(cv), desc=desc, sf=sf, nat="—", signo="—", prop="", denom="",
                                     tipo="excluida (resultado del ejercicio = cuenta 129x)",
                                     motivo="Cuenta 129x (Pérdidas y ganancias) con el resultado del ejercicio embebido (TB internacional, partida doble con el plug). Excluida del balance: el resultado lo deriva el motor de la P&L (6/7 → 00199). Revisar tras importar.",
                                     alt="", notas=""))
            continue
        # totales/subtotales sin código que arrastran importe -> ruido, fuera
        if not cod:
            if sf or debe or haber:
                revision.append(dict(orig=str(cv), desc=desc, sf=sf, nat="—", signo="—",
                                     prop="", denom="", tipo="sin código / no numérico",
                                     motivo="Fila sin código numérico (posible subtotal/total)",
                                     alt="", notas="Revisar si es cuenta o agregación"))
            continue
        n_filas += 1
        c3, c4 = cod[:3], cod[:4].ljust(4, "0")
        # match contra maestro (4d -> 3d) -> fallback por DESCRIPCIÓN (plan no-PGC) -> no identificada
        if c4 in maestro:
            asignado, tipo, _den = c4, "4d directo", maestro[c4]
        elif c3 in maestro:
            asignado, tipo, _den = c4, "3d directo", maestro[c3]   # se agrupa a 4d aunque el PGC tenga 3d
        else:
            _pgc = _desc_idx.get(_norm(re.sub(r"\([^)]*\)", " ", desc))) if desc else None  # ¿la descripción casa EXACTA?
            if _pgc:
                asignado, tipo, _den = _pgc.ljust(4, "0"), "por descripción", maestro[_pgc]
            else:
                _inf, _isc = _inferir(desc)                  # si no, INFERIR (fuzzy) y aplicar; revisa el abogado tras importar
                if _inf:
                    asignado, tipo, _den = _inf.ljust(4, "0"), "inferida", maestro[_inf]
                else:
                    asignado, tipo, _den = c4, "no identificada", None
        denom = _den or maestro.get(c4) or maestro.get(c3) or desc
        # [TB internacional] Override de cuenta scoped (solo intl): reasigna el código 4d de agregación a otro 4d
        # con casilla en el mapeo, por COLISIÓN SEMÁNTICA descripción-fuente vs maestro PGC (p.ej. 4370 «Anticipos
        # de clientes» -> 4380 -> 00248, no 437=envases). NO es regla PGC general; el camino ES no entra aquí. Se
        # traza en la tabla de validación para que el abogado lo revise tras importar. Confirmado abogado 2026-06-28.
        if intl and asignado in OVERRIDES_INTL:
            _ov = OVERRIDES_INTL[asignado]
            revision.append(dict(orig=str(cv), desc=desc, sf=sf, nat="—", signo="—",
                                 prop=_ov["a"], denom=_ov["denom"],
                                 tipo="override TB internacional (cuenta scoped, no regla PGC general)",
                                 motivo=_ov["nota"], alt="", notas=""))
            asignado, denom, tipo = _ov["a"], _ov["denom"], "override intl"
        nat = naturaleza(asignado)
        signo = "+" if (sf or 0) > 0 else ("-" if (sf or 0) < 0 else "0")

        # --- Etapa A: detección de casos de revisión (proponen, no aplican) ---
        motivos = []
        prop = regla_descripcion(desc, c3, c4)
        if tipo == "no identificada":
            motivos.append(("no identificada", f"{c4} (ni {c3}) existe en el maestro PGC", prop[0] if prop else ""))
        if tipo == "por descripción":
            motivos.append(("mapeada por descripción",
                            f"el código {cod} no es PGC; asignada {asignado} por su descripción (confirmar)",
                            asignado))
        if tipo == "inferida":
            motivos.append(("inferida (revisar tras importar)",
                            f"el código {cod} no es PGC y la descripción no casa exacta; INFERIDA a {asignado} — confírmala",
                            asignado))
        if len(cod) < 3:
            motivos.append(("código < 3 dígitos", "Código demasiado corto: revisar", ""))
        if sf is not None and ((nat == "deudora" and sf < 0) or (nat == "acreedora" and sf > 0)):
            motivos.append(("posible signo equivocado",
                            f"Naturaleza {nat} pero saldo {signo}", ""))
        if prop and tipo != "no identificada":
            # propuesta por descripción distinta de la familia detectada
            fam_prop = prop[0][:3].replace("x", "")
            if not c3.startswith(fam_prop[:2]):
                motivos.append(("inconsistencia código-descripción", prop[1], prop[0]))

        if motivos:
            tipo_res = "; ".join(m[0] for m in motivos)
            motivo_txt = "; ".join(m[1] for m in motivos)
            propuesta = next((m[2] for m in motivos if m[2]), (prop[0] if prop else ""))
            revision.append(dict(orig=str(cv), desc=desc, sf=sf, nat=nat, signo=signo,
                                 prop=propuesta, denom=maestro.get(propuesta, ""),
                                 tipo=tipo_res, motivo=motivo_txt,
                                 alt=(prop[0] if prop else ""), notas=""))

        # --- Etapa B: agregación a 4 dígitos (sobre la asignación determinista) ---
        g = grupos.setdefault(asignado, dict(sf=0.0, debe=0.0, haber=0.0, si=0.0,
                                             denom=denom, tipo=tipo))
        g["sf"] += sf or 0.0; g["debe"] += debe; g["haber"] += haber; g["si"] += si or 0.0
        lineage.append(dict(orig=str(cv), desc=desc, c4=c4, asignado=asignado,
                            tipo=tipo, nat=nat, signo=signo, sf=sf))

    return hidx, col, grupos, revision, lineage, n_filas

# --------------------------------------------------------------------- salidas

def escribir(outdir, empresa, ejercicio, src, hidx, col, grupos, revision, lineage, n_filas):
    out = Path(outdir); out.mkdir(parents=True, exist_ok=True)
    cols_line = ("Columnas detectadas: "
                 f"Código = col{col.get('cuenta')}, Descripción = col{col.get('descripcion')}, "
                 f"Saldo Final = col{col.get('saldo_final')}, Debe = col{col.get('debe','no detectada')}, "
                 f"Haber = col{col.get('haber','no detectada')}, Saldo Inicial = col{col.get('saldo_inicial','no detectada')}")

    # cuadres
    td = sum(v["debe"] for v in grupos.values())
    th = sum(v["haber"] for v in grupos.values())
    sd = sum(v["sf"] for v in grupos.values() if v["sf"] > 0)
    sa = sum(-v["sf"] for v in grupos.values() if v["sf"] < 0)
    sf_tot = sum(v["sf"] for v in grupos.values())
    no_id = [c for c, v in grupos.items() if v["tipo"] == "no identificada"]

    # 1) agrupado CSV (formato A3) — números crudos para reimportar
    with open(out / "agrupado_4d.csv", "w", encoding="utf-8-sig", newline="") as f:
        w = csv.writer(f, delimiter=";")
        w.writerow(["Cuenta", "Descripción", "Saldo Final", "Debe", "Haber", "Saldo Inicial"])
        for c in sorted(grupos):
            g = grupos[c]
            w.writerow([c, g["denom"], round(g["sf"], 2), round(g["debe"], 2),
                        round(g["haber"], 2), round(g["si"], 2)])

    # 2) agrupado MD (formato español, legible)
    md = [f"# Sumas y Saldos A3 — agrupado 4 dígitos · {empresa} {ejercicio}", "",
          f"Fuente: `{os.path.basename(src)}`  ·  Filas de cuenta procesadas: {n_filas}  ·  "
          f"Cuentas agrupadas (4d): {len(grupos)}", "", cols_line, "",
          "| Cuenta | Descripción | Saldo Final | Debe | Haber | Saldo Inicial |",
          "|---|---|---:|---:|---:|---:|"]
    for c in sorted(grupos):
        g = grupos[c]
        md.append(f"| {c} | {g['denom']} | {fmt_es(round(g['sf'],2))} | {fmt_es(round(g['debe'],2))} "
                  f"| {fmt_es(round(g['haber'],2))} | {fmt_es(round(g['si'],2))} |")
    (out / "agrupado_4d.md").write_text("\n".join(md) + "\n", encoding="utf-8")

    # 3) tabla de validación (Etapa A) — 14 columnas del prompt Harvey
    v = [f"# Tabla de validación (Etapa A) · {empresa} {ejercicio}", "", cols_line, "",
         f"Filas que requieren revisión humana: **{len(revision)}** de {n_filas}.", "",
         "| Código original | Descripción | Importe/Saldo | Naturaleza esperada | Signo | "
         "Cuenta PGC propuesta | Denominación PGC propuesta | Tipo de resolución | Motivo | "
         "Alternativas | Notas | ✅ Validar | ✏️ Corregir (código cuenta = ) |",
         "|---|---|---:|---|:--:|:--:|---|---|---|---|---|:--:|---|"]
    for r in revision:
        v.append(f"| {r['orig']} | {r['desc']} | {fmt_es(r['sf'])} | {r['nat']} | {r['signo']} | "
                 f"{r['prop']} | {r['denom']} | {r['tipo']} | {r['motivo']} | {r['alt']} | {r['notas']} |  |  |")
    (out / "validacion.md").write_text("\n".join(v) + "\n", encoding="utf-8")

    # 4) lineage CSV (auditoría)
    with open(out / "lineage.csv", "w", encoding="utf-8-sig", newline="") as f:
        w = csv.writer(f, delimiter=";")
        w.writerow(["codigo_original", "descripcion", "c4", "codigo_asignado", "tipo_resolucion",
                    "naturaleza", "signo", "saldo_final"])
        for l in lineage:
            w.writerow([l["orig"], l["desc"], l["c4"], l["asignado"], l["tipo"], l["nat"],
                        l["signo"], round(l["sf"], 2) if l["sf"] is not None else ""])

    # 5) resumen de cuadres
    eq = lambda a, b: "✅ cuadra" if abs(a - b) < 0.01 else f"🔴 descuadre {fmt_es(a-b)}"
    r = [f"# Resumen de cuadres · {empresa} {ejercicio}", "",
         f"- Filas de cuenta procesadas: **{n_filas}**",
         f"- Cuentas agrupadas a 4 dígitos: **{len(grupos)}**",
         f"- Filas a revisión (Etapa A): **{len(revision)}**",
         f"- Cuentas no identificadas en el maestro PGC: **{len(no_id)}**"
         + (f" → {', '.join(sorted(no_id))}" if no_id else ""),
         "",
         "## Cuadres contables",
         f"- Σ Debe = **{fmt_es(round(td,2))}**  ·  Σ Haber = **{fmt_es(round(th,2))}**  →  {eq(td,th)}",
         f"- Σ Saldo deudor = **{fmt_es(round(sd,2))}**  ·  Σ Saldo acreedor = **{fmt_es(round(sa,2))}**  →  {eq(sd,sa)}",
         f"- Σ Saldo Final (con signo, debe ser 0) = **{fmt_es(round(sf_tot,2))}**  →  "
         + ("✅ cuadra" if abs(sf_tot) < 0.01 else f"🔴 {fmt_es(sf_tot)}"),
         "",
         "> Nota: el agrupado se calcula sobre la asignación determinista (4d/3d). Las propuestas de "
         "reasignación por descripción/signo (tabla de validación) NO se aplican hasta validación humana.",
         ]
    (out / "resumen_cuadres.md").write_text("\n".join(r) + "\n", encoding="utf-8")

    return dict(td=td, th=th, sd=sd, sa=sa, sf_tot=sf_tot, n=n_filas,
                grupos=len(grupos), rev=len(revision), no_id=no_id)


# --------------------------------------------------------- A3 import (xlsx)
HEADERS_A3 = ["Cuenta", "Descripción", "Saldo Final", "Debe", "Haber", "Saldo Inicial"]
TOL_A3 = 0.01


def escribir_a3_xlsx(outdir, empresa, ejercicio, grupos, nif=""):
    """Emite `agrupado_4d.xlsx` = fichero de IMPORTACIÓN de A3 (Sumas y Saldos).

    Layout del template real de A3 (spec Wolters Kluwer; mismo que
    suite-is/scripts/generar_sys_a3.py::build_xlsx_template_a3):
      fila 1 `Nif Sociedad` | fila 2 `Nombre Sociedad` | fila 3 cabeceras EXACTAS | datos.
    Reglas A3: cuenta a 4d como TEXTO; saldos acreedores en negativo; cuentas 129x
    SIN saldo final (A3 reconstruye el resultado); cuadres Σdebe=Σhaber y
    Σdeudor=Σacreedor obligatorios. Fail-closed: si descuadra tras la regla 129x,
    NO se escribe el fichero (se devuelve ok=False con motivo) — nunca un xlsx
    que A3 vaya a rechazar.
    """
    import openpyxl

    avisos = []
    filas = []
    for c in sorted(grupos):
        g = grupos[c]
        sf = round(g["sf"], 2)
        if c.startswith("129"):
            if abs(sf) > 0:
                avisos.append(f"Cuenta {c} (PyG) traía saldo final {sf}; va VACÍO en el "
                              "fichero A3 (balance antes del cierre).")
            sf = None
        filas.append([c, g["denom"], sf, round(g["debe"], 2), round(g["haber"], 2),
                      round(g["si"], 2)])

    # Cuadre por CÉNTIMOS EXACTOS (B3, tol=0): un descuadre de 0,01 NO emite el A3 (era allowlist con TOL_A3).
    td = sum((_cent(f[3]) for f in filas), Decimal("0"))
    th = sum((_cent(f[4]) for f in filas), Decimal("0"))
    sd = sum((_cent(f[2]) for f in filas if f[2] is not None and f[2] > 0), Decimal("0"))
    sa = sum((-_cent(f[2]) for f in filas if f[2] is not None and f[2] < 0), Decimal("0"))
    ctrl = dict(n_cuentas=len(filas), total_debe=float(td), total_haber=float(th),
                saldo_deudor=float(sd), saldo_acreedor=float(sa),
                cuadra_debe_haber=td == th, cuadra_deudor_acreedor=sd == sa)
    if not (ctrl["cuadra_debe_haber"] and ctrl["cuadra_deudor_acreedor"]):
        return dict(ok=False, control=ctrl, avisos=avisos,
                    motivo="descuadre tras regla 129x: A3 rechazaría el fichero; "
                           "no se emite agrupado_4d.xlsx")

    wb = openpyxl.Workbook()
    ws = wb.active
    ws.title = "Sumas y Saldos"
    ws.append(["Nif Sociedad", nif or ""])
    ws.append(["Nombre Sociedad", empresa or ""])
    ws.append(HEADERS_A3)
    for f in filas:
        ws.append(f)
    for colu, w in {"A": 12, "B": 44, "C": 16, "D": 16, "E": 16, "F": 16}.items():
        ws.column_dimensions[colu].width = w
    for r in range(4, ws.max_row + 1):
        ws[f"A{r}"].number_format = "@"
        for colu in ("C", "D", "E", "F"):
            cell = ws[f"{colu}{r}"]
            if isinstance(cell.value, (int, float)):
                cell.number_format = "#,##0.00"
    path = Path(outdir) / "agrupado_4d.xlsx"
    wb.save(path)
    return dict(ok=True, fichero=str(path), control=ctrl, avisos=avisos)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--input", required=True)
    ap.add_argument("--maestro", default=str(Path(__file__).resolve().parent.parent / "data" / "pgc_maestro.csv"))
    ap.add_argument("--outdir", required=True)
    ap.add_argument("--empresa", default="")
    ap.add_argument("--ejercicio", default="")
    a = ap.parse_args()

    filas = leer_filas(a.input)
    maestro = cargar_maestro(a.maestro)
    hidx, col, grupos, revision, lineage, n = procesar(filas, maestro)
    s = escribir(a.outdir, a.empresa, a.ejercicio, a.input, hidx, col, grupos, revision, lineage, n)

    print(f"OK · filas={s['n']} · cuentas4d={s['grupos']} · revisión={s['rev']} · no_id={len(s['no_id'])}")
    print(f"Σ Debe={fmt_es(round(s['td'],2))}  Σ Haber={fmt_es(round(s['th'],2))}  "
          f"dif={fmt_es(round(s['td']-s['th'],2))}")
    print(f"Σ deudor={fmt_es(round(s['sd'],2))}  Σ acreedor={fmt_es(round(s['sa'],2))}  "
          f"dif={fmt_es(round(s['sd']-s['sa'],2))}")
    print(f"Σ saldo final (con signo) = {fmt_es(round(s['sf_tot'],2))}")
    if s["no_id"]:
        print("No identificadas:", ", ".join(sorted(s["no_id"])))


if __name__ == "__main__":
    main()
