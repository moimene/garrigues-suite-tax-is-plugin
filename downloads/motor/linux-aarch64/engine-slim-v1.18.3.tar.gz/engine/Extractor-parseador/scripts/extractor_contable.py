#!/usr/bin/env python3
"""Extractor contable layout-aware con PROVENANCE (EPIC B / D12, Stage 1).

Lee un fichero (SyS/mayor: .xls/.xlsx/.csv) REUSANDO el lector robusto, la detección de cabecera y el
parser numérico del motor EPC (`motor_sys`), y extrae las cuentas EN BRUTO con su celda de origen
(fila), para alimentar el normalizador PGC. No agrupa ni mapea: extrae fielmente con trazabilidad.
"""
import os
import sys

_HERE = os.path.dirname(os.path.abspath(__file__))
if _HERE not in sys.path:
    sys.path.insert(0, _HERE)
import motor_sys  # noqa: E402  (lector robusto + detectar + num, reusados)


def extraer_cuentas(path: str) -> dict:
    """Fichero contable -> cuentas en bruto [{cuenta, denom, debe, haber, saldo, _fuente}] + metadatos."""
    try:
        filas = motor_sys.leer_filas(path)        # lectura: puede fallar (bytes no-UTF8, xlsx falso, NUL...)
        hidx, col = motor_sys.detectar(filas)      # detección de cabecera: SystemExit si no la halla
    except (SystemExit, Exception) as e:           # noqa: BLE001  fichero ilegible/corrupto -> error controlado, NUNCA 500
        return {"error": str(e) or type(e).__name__, "cuentas": [], "n": 0}

    def cell(row, key):
        i = col.get(key)
        return row[i] if i is not None and i < len(row) else None

    def numero(v):
        try:
            return motor_sys.num(v if v is not None else 0)
        except Exception:  # noqa: BLE001
            return 0.0

    cuentas = []
    for ridx, row in enumerate(filas[hidx + 1:], start=hidx + 2):
        cod = cell(row, "cuenta")
        if cod is None or not str(cod).strip():
            continue
        cod = str(cod).strip()
        # Una CUENTA real es dígitos + separadores (. - / espacio), sin letras. Se saltan: filas sin dígitos
        # (texto) y filas de SUBTOTAL/footer cuya celda 'cuenta' es una etiqueta con dígitos incidentales
        # ("Total cuenta 4300", "AJUSTE 43000000"): su código extraído chocaría con una cuenta real y
        # enmascararía un descuadre en la reconciliación inter-fichero (adversarial B5).
        if not any(ch.isdigit() for ch in cod) or any(ch.isalpha() for ch in cod):
            continue
        cuentas.append({
            "cuenta": cod,
            "denom": str(cell(row, "descripcion") or "").strip(),
            "debe": numero(cell(row, "debe")),
            "haber": numero(cell(row, "haber")),
            "saldo": numero(cell(row, "saldo_final")),
            # Saldo INICIAL (B5/EPIC B): necesario para la identidad del mayor SI+debe−haber=SF. Solo si la
            # columna existe (un SyS-resumen puede no traerla); ausente => no se fuerza la identidad.
            "si": numero(cell(row, "saldo_inicial")) if col.get("saldo_inicial") is not None else None,
            # Provenance por CELDA (B1/EPIC B): fichero + fila + columna por campo (de la cabecera detectada).
            "_fuente": {"fichero": os.path.basename(path), "fila": ridx,
                        "col": {k: col.get(k) for k in
                                ("cuenta", "descripcion", "debe", "haber", "saldo_final", "saldo_inicial")}},
        })
    return {
        "cuentas": cuentas,
        "n": len(cuentas),
        "cabecera_fila": hidx + 1,
        "columnas": {k: col.get(k) for k in
                     ("cuenta", "descripcion", "debe", "haber", "saldo_final", "saldo_inicial")},
    }


if __name__ == "__main__":
    import json
    if len(sys.argv) > 1:
        out = extraer_cuentas(sys.argv[1])
        print(json.dumps({k: v for k, v in out.items() if k != "cuentas"}, ensure_ascii=False, indent=1))
        print("primeras:", json.dumps(out["cuentas"][:3], ensure_ascii=False))
    else:
        print("Uso: python3 extractor_contable.py <fichero.xls|.xlsx|.csv>")
