#!/usr/bin/env python3
"""Extract AEAT record-design workbooks to a documented JSON structure.

This is intentionally richer than normalizar_dr200.py:
- keeps fixed-width fields and variable wrapper fields;
- preserves row-level Excel formulas for auditability;
- keeps post-total notes separately from actual fields;
- detects bracketed casilla codes, note references and simple content rules.

Usage:
    python3 extraer_dr_json.py <DR200.xls|xlsx> <salida.json>
"""
from __future__ import annotations

import json
import os
import re
import shutil
import subprocess
import sys
import tempfile
from datetime import datetime
from pathlib import Path
from typing import Any

from openpyxl import load_workbook
from openpyxl.utils import get_column_letter


HEADER_ALIASES = {
    "num_campo": ("nº", "n°", "num", "n."),
    "posicion": ("posic", "posicion", "posición"),
    "longitud": ("lon", "long"),
    "tipo": ("tipo",),
    "com": ("com",),
    "descripcion": ("descrip",),
    "validacion": ("valida",),
    "contenido": ("conten",),
}
CANONICAL_COLUMNS = [
    "num_campo",
    "posicion",
    "longitud",
    "tipo",
    "com",
    "descripcion",
    "validacion",
    "contenido",
]

CASILLA_BRACKET_RE = re.compile(r"\[(\d{5})\]")
FIVE_DIGIT_RE = re.compile(r"(?<!\d)(\d{5})(?!\d)")
NOTE_REF_RE = re.compile(r"\bNota\s*\d+\b", re.IGNORECASE)
FORMAT_RE = re.compile(r"(\d+)\s*enteros?.*?(\d+)\s*decimales?", re.IGNORECASE | re.DOTALL)
QUOTED_RE = re.compile(r'"([^"]*)"')
CONST_QUOTED_RE = re.compile(r'Constante[^"]*"([^"]*)"', re.IGNORECASE)
CONST_UNQUOTED_RE = re.compile(r"Constante\.?\s+([^\s].*)", re.IGNORECASE)
RAW_TAG_RE = re.compile(r"</?T[0-9A-Z]+>|<T|>", re.IGNORECASE)


def _clean(v: Any) -> str:
    if v is None:
        return ""
    if isinstance(v, float) and v.is_integer():
        return str(int(v))
    return str(v).replace("\r\n", "\n").replace("\r", "\n").strip()


def _as_int_or_text(v: Any) -> int | str | None:
    s = _clean(v)
    if not s:
        return None
    try:
        f = float(s)
    except ValueError:
        return s
    if f.is_integer():
        return int(f)
    return s


def _is_int_like(v: Any) -> bool:
    return isinstance(_as_int_or_text(v), int)


def _is_total(v: Any) -> bool:
    return _clean(v).lower().startswith("total")


def _norm_header(v: Any) -> str:
    return _clean(v).lower().replace(".", "")


def _map_header(row_values: list[Any]) -> dict[str, int] | None:
    found: dict[str, int] = {}
    for idx, value in enumerate(row_values):
        label = _norm_header(value)
        if not label:
            continue
        for canonical, aliases in HEADER_ALIASES.items():
            if canonical in found:
                continue
            if any(label == a or label.startswith(a) for a in aliases):
                found[canonical] = idx
                break
    if not {"posicion", "longitud", "tipo"} <= set(found):
        return None
    if "num_campo" not in found and found["posicion"] >= 1:
        found["num_campo"] = found["posicion"] - 1
    return found


def _sheet_used_bounds(ws_values, ws_formulas) -> tuple[int, int]:
    max_row = 0
    max_col = 0
    for ws in (ws_values, ws_formulas):
        for row in ws.iter_rows():
            for cell in row:
                if cell.value is not None and _clean(cell.value) != "":
                    max_row = max(max_row, cell.row)
                    max_col = max(max_col, cell.column)
    return max_row, max_col


def _cell(ws, row: int, col0: int) -> Any:
    return ws.cell(row=row, column=col0 + 1).value


def _cell_addr(row: int, col0: int) -> str:
    return f"{get_column_letter(col0 + 1)}{row}"


def _row_payload(ws_values, ws_formulas, row: int, max_col0: int) -> dict[str, Any]:
    values: dict[str, str] = {}
    formulas: dict[str, str] = {}
    for col0 in range(max_col0 + 1):
        val = _clean(_cell(ws_values, row, col0))
        frm = _cell(ws_formulas, row, col0)
        formula = _clean(frm) if isinstance(frm, str) and frm.startswith("=") else ""
        if val:
            values[get_column_letter(col0 + 1)] = val
        if formula:
            formulas[get_column_letter(col0 + 1)] = formula
    out: dict[str, Any] = {"fila_excel": row, "valores": values}
    if formulas:
        out["formulas"] = formulas
    return out


def _detect_constant(description: str, content: str) -> str | None:
    text = content.strip()
    if not text:
        return None
    m = CONST_QUOTED_RE.search(text)
    if m:
        return m.group(1)
    if "constante" in description.lower():
        quoted = QUOTED_RE.fullmatch(text)
        if quoted:
            return quoted.group(1)
    m = CONST_UNQUOTED_RE.search(text)
    if m:
        return m.group(1).strip().strip('"')
    if RAW_TAG_RE.fullmatch(text):
        return text
    return None


def _logic(description: str, validation: str, content: str) -> dict[str, Any]:
    joined = "\n".join(x for x in (description, validation, content) if x)
    constant = _detect_constant(description, content)
    quoted = QUOTED_RE.findall(content or "")
    values = []
    if constant is None and quoted:
        # Deduplicate while preserving order. A single quoted value can still be meaningful
        # when the content says "Blanco ... o 'C'".
        seen = set()
        for value in quoted:
            if value not in seen:
                seen.add(value)
                values.append(value)
    fmt = FORMAT_RE.search(content or "")
    rules: dict[str, Any] = {
        "validacion": validation,
        "contenido": content,
        "obligatorio": "obligatorio" in (validation or "").lower(),
        "constante": constant,
        "valores_permitidos": values,
        "blanco_permitido_o_relleno": bool(re.search(r"\bblanc[oa]s?\b|en blanco", content or "", re.IGNORECASE)),
        "relleno_ceros": bool(re.search(r"\bceros?\b", content or "", re.IGNORECASE)),
        "formato_numerico": None,
        "referencias_nota": sorted(set(m.group(0).replace(" ", " ") for m in NOTE_REF_RE.finditer(joined))),
        "referencias_codigos_5_digitos": sorted(set(FIVE_DIGIT_RE.findall(joined))),
    }
    if fmt:
        rules["formato_numerico"] = {
            "enteros": int(fmt.group(1)),
            "decimales": int(fmt.group(2)),
        }
    return rules


def _extract_page_code(fields: list[dict[str, Any]]) -> str | None:
    for field in fields:
        desc = (field.get("descripcion") or "").lower()
        if desc.startswith("página") or desc.startswith("pagina"):
            return field.get("logica", {}).get("constante")
    return None


def _convert_xls_to_xlsx(path: Path) -> Path:
    soffice = shutil.which("soffice") or shutil.which("libreoffice")
    if not soffice:
        raise RuntimeError("No se puede leer .xls: falta xlrd y no se encuentra soffice/libreoffice para convertir.")
    tmpdir = Path(tempfile.mkdtemp(prefix="dr_json_"))
    subprocess.run(
        [soffice, "--headless", "--convert-to", "xlsx", "--outdir", str(tmpdir), str(path)],
        check=True,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        text=True,
    )
    candidates = sorted(tmpdir.glob("*.xlsx"))
    if not candidates:
        raise RuntimeError(f"soffice no genero xlsx en {tmpdir}")
    return candidates[0]


def _open_workbooks(path: Path):
    parsed_path = path
    conversion = None
    if path.suffix.lower() == ".xls":
        parsed_path = _convert_xls_to_xlsx(path)
        conversion = {
            "metodo": "soffice --headless --convert-to xlsx",
            "formato_intermedio": "xlsx",
            "nota": "Conversion temporal solo para lectura; la fuente canonica es el archivo original.",
        }
    wb_values = load_workbook(parsed_path, read_only=False, data_only=True)
    wb_formulas = load_workbook(parsed_path, read_only=False, data_only=False)
    return parsed_path, conversion, wb_values, wb_formulas


def extract_json(source: str) -> dict[str, Any]:
    source_path = Path(source).expanduser().resolve()
    parsed_path, conversion, wb_values, wb_formulas = _open_workbooks(source_path)

    sheets = []
    all_casillas: set[str] = set()
    field_count = 0
    fixed_field_count = 0
    note_count = 0

    for sheet_index, original_name in enumerate(wb_values.sheetnames, start=1):
        ws_values = wb_values[original_name]
        ws_formulas = wb_formulas[original_name]
        max_row, max_col = _sheet_used_bounds(ws_values, ws_formulas)
        header_row = None
        header_map = None
        for row in range(1, min(max_row, 30) + 1):
            candidate = [_cell(ws_values, row, col0) for col0 in range(max_col)]
            mapped = _map_header(candidate)
            if mapped:
                header_row = row
                header_map = mapped
                break
        if header_row is None or header_map is None:
            sheets.append({
                "indice": sheet_index,
                "nombre_hoja": original_name.strip(),
                "nombre_hoja_original": original_name,
                "cabecera_detectada": None,
                "campos": [],
                "notas": [],
            })
            continue

        header_values = {
            canonical: _clean(_cell(ws_values, header_row, col0))
            for canonical, col0 in sorted(header_map.items(), key=lambda item: item[1])
        }
        preamble = [
            _row_payload(ws_values, ws_formulas, row, min(max_col - 1, 7))
            for row in range(1, header_row)
            if any(_clean(_cell(ws_values, row, col0)) for col0 in range(min(max_col, 8)))
        ]

        fields: list[dict[str, Any]] = []
        total_row_payload = None
        post_total_start = max_row + 1

        for row in range(header_row + 1, max_row + 1):
            first = _cell(ws_values, row, header_map["num_campo"])
            if _is_total(first):
                total_row_payload = _row_payload(ws_values, ws_formulas, row, min(max_col - 1, 7))
                post_total_start = row + 1
                break
            if not _is_int_like(first):
                continue

            values_by_col: dict[str, Any] = {}
            formulas_by_col: dict[str, str] = {}
            cells_by_col: dict[str, str] = {}
            for canonical in CANONICAL_COLUMNS:
                if canonical not in header_map:
                    continue
                col0 = header_map[canonical]
                values_by_col[canonical] = _cell(ws_values, row, col0)
                raw_formula = _cell(ws_formulas, row, col0)
                if isinstance(raw_formula, str) and raw_formula.startswith("="):
                    formulas_by_col[canonical] = raw_formula
                cells_by_col[canonical] = _cell_addr(row, col0)

            description = _clean(values_by_col.get("descripcion"))
            validation = _clean(values_by_col.get("validacion"))
            content = _clean(values_by_col.get("contenido"))
            position = _as_int_or_text(values_by_col.get("posicion"))
            length = _as_int_or_text(values_by_col.get("longitud"))
            is_fixed = isinstance(position, int) and isinstance(length, int)
            casillas = sorted(set(CASILLA_BRACKET_RE.findall("\n".join([description, validation, content]))))
            all_casillas.update(casillas)

            field = {
                "num_campo": _as_int_or_text(values_by_col.get("num_campo")),
                "fila_excel": row,
                "posicion": position,
                "longitud": length,
                "posicion_fin": position + length - 1 if is_fixed else None,
                "tipo": _clean(values_by_col.get("tipo")),
                "com": _clean(values_by_col.get("com")) if "com" in header_map else None,
                "descripcion": description,
                "logica": _logic(description, validation, content),
                "casillas": casillas,
                "es_campo_ancho_fijo": is_fixed,
                "celdas_origen": cells_by_col,
                "formulas_excel": formulas_by_col,
            }
            fields.append(field)

        notes = []
        for row in range(post_total_start, max_row + 1):
            payload = _row_payload(ws_values, ws_formulas, row, min(max_col - 1, 7))
            if payload["valores"] or payload.get("formulas"):
                payload["texto"] = " ".join(payload["valores"].values()).strip()
                notes.append(payload)

        field_count += len(fields)
        fixed_field_count += sum(1 for f in fields if f["es_campo_ancho_fijo"])
        note_count += len(notes)

        sheets.append({
            "indice": sheet_index,
            "nombre_hoja": original_name.strip(),
            "nombre_hoja_original": original_name,
            "codigo_pagina": _extract_page_code(fields),
            "cabecera_detectada": {
                "fila_excel": header_row,
                "columnas": header_values,
            },
            "encabezado": preamble,
            "total": total_row_payload,
            "resumen": {
                "campos": len(fields),
                "campos_ancho_fijo": sum(1 for f in fields if f["es_campo_ancho_fijo"]),
                "campos_variables_o_no_posicionales": sum(1 for f in fields if not f["es_campo_ancho_fijo"]),
                "notas": len(notes),
            },
            "notas": notes,
            "campos": fields,
        })

    result = {
        "version_esquema": "1.0",
        "generado_en": datetime.now().astimezone().isoformat(timespec="seconds"),
        "fuente": {
            "archivo": str(source_path),
            "archivo_parseado": str(parsed_path) if parsed_path == source_path else None,
            "conversion": conversion,
        },
        "resumen": {
            "hojas": len(sheets),
            "campos": field_count,
            "campos_ancho_fijo": fixed_field_count,
            "campos_variables_o_no_posicionales": field_count - fixed_field_count,
            "notas": note_count,
            "casillas_unicas_en_corchetes": len(all_casillas),
        },
        "casillas_unicas_en_corchetes": sorted(all_casillas),
        "hojas": sheets,
    }

    wb_values.close()
    wb_formulas.close()
    return result


def main(argv: list[str]) -> int:
    if len(argv) != 3:
        print(__doc__, file=sys.stderr)
        return 2
    data = extract_json(argv[1])
    output = Path(argv[2]).expanduser().resolve()
    output.parent.mkdir(parents=True, exist_ok=True)
    with output.open("w", encoding="utf-8") as fh:
        json.dump(data, fh, ensure_ascii=False, indent=2)
        fh.write("\n")
    print(
        f"{os.path.basename(argv[1])}: {data['resumen']['hojas']} hojas · "
        f"{data['resumen']['campos']} campos · "
        f"{data['resumen']['casillas_unicas_en_corchetes']} casillas -> {output}"
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main(sys.argv))
