"""Gate ARITMÉTICO de la proyección normal->abreviado/PYMES (complementa el topológico de reconciliar_abreviado).

El validador topológico solo comprueba que cada hoja tenga DESTINO; no que el destino conserve el IMPORTE. Un
carrier mal clasificado (p.ej. op=propio_o_suma en un carrier de hermanas, o autorreferencia en el `from` con
op=suma) pasa la reconciliación topológica e incluso importa LIMPIO en Open (los estados se cargan aunque el PN
quede corto), pero el balance NO CUADRA. Este gate lo caza:

  por entidad × sección, la suma de las HOJAS EMITIDAS (carriers + casillas importables sin descendiente emitido)
  debe igualar el TOTAL ORIGINAL calculado de esa sección (balance: 00180 Activo / 00252 PN+Pasivo).

Si la proyección es sin pérdida, recomputado == original al céntimo. Determinista, 0 PII (solo códigos, el booleano
y el delta). Detectó (2026-06-30) el bug del carrier de reservas 00193 (perdía 00192) con Δ exacto.
"""
from __future__ import annotations

import sys
from decimal import Decimal
from pathlib import Path

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
from extraer_perfiles_cap04 import parse_cap04  # noqa: E402
import transformar_xml_abreviado as ab  # noqa: E402
from transformar_200_abreviado import Declaracion200  # noqa: E402
import dr200  # noqa: E402

# Totales calculados (originales) por sección y las páginas DR cuyas hojas deben sumarlos.
SECCIONES = {
    "balance": [
        ("ACTIVO (00180)", "00180", ["DP200003", "DP200004"]),
        ("PN+PASIVO (00252)", "00252", ["DP200005", "DP200006"]),
    ],
}


def _arbol():
    arbol = {}
    for _sec, ents in parse_cap04().items():
        for e in ents:
            if e["formula"]:
                arbol.setdefault(e["casilla"], set()).update(e["formula"])
    return arbol


def _descendientes(c, arbol, vis=None):
    vis = vis if vis is not None else set()
    for h in arbol.get(c, ()):
        if h not in vis:
            vis.add(h)
            _descendientes(h, arbol, vis)
    return vis


def gate(entidad_path, perfil="abreviado", familias=("balance",)):
    """Devuelve [(etiqueta, original, recomputado, ok)] por sección. ok=True si recomputado==original."""
    arbol = _arbol()
    cas2pag = ab._casilla_pagina(dr200.cargar_dr(ejercicio="2025"))
    d = Declaracion200(entidad_path)
    fam_pags = {"balance": ["DP200003", "DP200004", "DP200005", "DP200006"],
                "pyg": ["DP200007", "DP200008"], "ecpn": ["DP200009", "DP200010", "DP200011"]}
    orig = {}
    for fam in familias:
        for p in fam_pags[fam]:
            if d._page_span(p):
                for c in d.presentes(p):
                    v = d.leer_importe(p, c)
                    if v is not None:
                        orig[c] = Decimal(str(v))
    out, _, _ = ab.proyectar_dict({k: v for k, v in orig.items()}, perfil=perfil,
                                  familias=familias, ejercicio="2025")
    emit = {c: Decimal(str(v)) for c, v in out.items()}
    emset = set(emit)
    hojas = [c for c in emset if not (_descendientes(c, arbol) & emset)]  # sin descendiente emitido
    res = []
    for fam in familias:
        for etiqueta, total_cas, pags in SECCIONES.get(fam, []):
            original = orig.get(total_cas)
            if original is None:
                continue
            recomputado = sum(emit[c] for c in hojas if cas2pag.get(c) in pags)
            res.append((etiqueta, original, recomputado, recomputado == original))
    return res


if __name__ == "__main__":
    import argparse  # noqa: E401
    ap = argparse.ArgumentParser()
    ap.add_argument("paths", nargs="+")
    ap.add_argument("--familias", default="balance")
    ap.add_argument("--perfil", default="abreviado", choices=["abreviado", "pymes"])
    a = ap.parse_args()
    fams = tuple(x.strip() for x in a.familias.split(",") if x.strip())
    fallo = False
    for p in a.paths:
        nombre = Path(p).stem
        for etiqueta, orig, recomp, ok in gate(p, perfil=a.perfil, familias=fams):
            estado = "OK" if ok else f"MISMATCH Δ={recomp - orig}"
            if not ok:
                fallo = True
            print(f"{nombre}: {etiqueta} orig={orig} recomputado={recomp} -> {estado}")
    sys.exit(1 if fallo else 0)
