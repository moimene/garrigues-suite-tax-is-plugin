#!/usr/bin/env python3
"""extractor_ccaa.py — Motor de INFERENCIA: cuentas anuales (PDF) -> borrador de partidas.

Para documentos no estructurados (CCAA en PDF) la estrategia es inferencia con revisión humana:
  1. Convierte el PDF a texto/tablas (pdfplumber -> pdfminer -> aviso si necesita OCR).
  2. Localiza líneas 'etiqueta ... importe' candidatas (heurística determinista).
  3. Hook LLM opcional (mapear_llm) para asignar casilla AEAT; si no hay clave de API, devuelve None y
     el borrador queda 'requiere revisión'. NUNCA inventa: marca baja confianza.

Premisa persona_tax: el extractor NO es la fuente de verdad; entrega un borrador. Para la vía
principal y cuadrada, usar el Sumas y Saldos (motor_sys). Las CCAA sirven de contraste/relleno.

Uso: python3 extractor_ccaa.py --pdf <ccaa.pdf> [--out ccaa_borrador.csv] [--max-paginas 30]
"""
from __future__ import annotations
import argparse, csv, os, re
from pathlib import Path

NUM = re.compile(r"-?\(?\d{1,3}(?:[.\s]\d{3})*(?:,\d{2})?\)?-?$")

def extraer_texto(pdf_path, max_pag=40):
    # 1) pdfplumber
    try:
        import pdfplumber
        out = []
        with pdfplumber.open(pdf_path) as pdf:
            for i, pg in enumerate(pdf.pages[:max_pag]):
                out.append(pg.extract_text() or "")
        return "\n".join(out), "pdfplumber"
    except Exception:
        pass
    # 2) pdfminer
    try:
        from pdfminer.high_level import extract_text
        return extract_text(pdf_path, maxpages=max_pag) or "", "pdfminer"
    except Exception:
        pass
    return "", "no-extractor"

def to_float(s):
    s = s.strip().replace(" ", "")
    neg = s.startswith("(") and s.endswith(")") or s.endswith("-")
    s = s.strip("()").rstrip("-")
    s = s.replace(".", "").replace(",", ".")
    try:
        v = float(s); return -v if neg else v
    except ValueError:
        return None

def candidatos(texto):
    cands = []
    for ln in texto.splitlines():
        ln = ln.strip()
        if len(ln) < 6:
            continue
        m = re.search(r"(.+?)\s+(-?\(?\d[\d.\s]*,\d{2}\)?-?)\s*$", ln)
        if not m:
            continue
        etiqueta = re.sub(r"[.\s]+$", "", m.group(1)).strip()
        val = to_float(m.group(2))
        if val is None or not re.search(r"[A-Za-zÁÉÍÓÚáéíóúÑñ]", etiqueta):
            continue
        cands.append((etiqueta[:70], val))
    return cands

def mapear_llm(candidatos, catalogo_path=None):
    """Hook LLM: asignar casilla por etiqueta. Devuelve None si no hay clave de API configurada."""
    if not (os.getenv("ANTHROPIC_API_KEY") or os.getenv("OPENAI_API_KEY")):
        return None
    # Implementación real: enviar candidatos + etiquetas del catálogo a un LLM con prompt estricto
    # (solo casillas existentes). Se deja como punto de integración (model policy por coste).
    return None

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--pdf", required=True)
    ap.add_argument("--out", default=None)
    ap.add_argument("--max-paginas", type=int, default=40)
    a = ap.parse_args()
    texto, motor = extraer_texto(a.pdf, a.max_paginas)
    cands = candidatos(texto)
    asign = mapear_llm(cands)
    print(f"OK · extractor={motor} · caracteres={len(texto)} · candidatos={len(cands)} · "
          f"mapeo_llm={'sí' if asign else 'no (sin API key -> requiere revisión)'}")
    if a.out:
        with open(a.out, "w", encoding="utf-8-sig", newline="") as f:
            w = csv.writer(f, delimiter=";")
            w.writerow(["etiqueta_detectada", "importe", "casilla_propuesta", "confianza", "nota"])
            for et, val in cands:
                w.writerow([et, round(val, 2), "", "baja", "requiere revisión humana o usar SyS"])
    if motor == "no-extractor":
        print("  🟡 No hay extractor de PDF disponible (instala pdfplumber/pdfminer.six) o el PDF necesita OCR.")

if __name__ == "__main__":
    main()
