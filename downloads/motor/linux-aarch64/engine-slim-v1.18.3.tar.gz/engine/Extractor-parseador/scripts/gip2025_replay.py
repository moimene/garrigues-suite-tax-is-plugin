"""Replay GIP 2025: genera el `.200` del ejercicio 2025 desde los workbooks fuente (no desde el `.ses`, que
es el objetivo y es page-ambiguo). Cadena:

    SyS 31/12/2025 (contable) ─┐
    Estimación GIS 2025 (liq.) ─┼─> engines.exportar_aeat(ejercicio=2025) ─> .200 importable
    datos formales 2024 (arrastre) ┘                                          (contable + liquidación + formales)

Valida las anclas del oráculo GIP 2025 y, si hay `.ses`, reporta la cobertura. Hay DOS oráculos (selección
automática según los facts del abogado): PROVISIONAL (sin `gf_limite_30`) BI 6.695.228,99 / cuota 1.673.807,25,
y ESTRICTO (criterio art.16.5, con `gf_limite_30` = 30%·B.O. real negativo) BI 8.368.841,36 / cuota 2.092.210,34
— este último aún NO firme para la importación hasta reconciliar 01250 con 00296 (compuerta humana). (El viejo
3.208.497,87 / 802.124,47 era INCORRECTO: le faltaba el ajuste del art.16.) Las rutas son LOCALES y gitignored
(`caso_local.json` → `paths_2025`/`facts_2025`); sin ellas el script avisa y no hace nada. Salida en
`_local_out/gip2025_replay/` (gitignored). 0 PII en este fichero.

Uso:  python3 Extractor-parseador/scripts/gip2025_replay.py
"""
import base64
import os
import sys

ROOT = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
sys.path.insert(0, ROOT)
sys.path.insert(0, os.path.join(ROOT, "Extractor-parseador", "scripts"))

import caso_local                                 # noqa: E402
import dr200                                      # noqa: E402
import ecpn_sys                                   # noqa: E402
import gip2024_liquidacion_parser as liquidacion  # noqa: E402
import modelo200_golden as golden                 # noqa: E402
import ses200_parser as ses                       # noqa: E402
from engine_service import engines                # noqa: E402

# Oráculo GIP 2025 CORREGIDO (2026-06-19): incluye el ajuste positivo obligatorio del art.16 LIS (00363 =
# 6.973.462,24 de GF no deducible este año, que se arrastra), confirmado por el abogado contra el Manual de
# Sociedades 2025. El oráculo anterior (BI 3.208.497,87 / cuota 802.124,47) era INCORRECTO: la Estimación no
# traía el ajuste. BI previa 13.390.457,98 → compensación BINs 50% = 6.695.228,99 → BI 6.695.228,99 → cuota 25%.
ANCLAS = {"00552": "6695228.99", "00562": "1673807.25", "00621": "1673807.25"}   # oráculo GIP 2025 PROVISIONAL
# Oráculo ESTRICTO (criterio art.16.5 confirmado por el abogado 2026-06-19): con el 30%·B.O. real negativo
# (gf_limite_30=-2.707.290,08) todo el GF de adquisición es no deducible → BI 8.368.841,36 / cuota 2.092.210,34.
# Aún NO firme para la importación: requiere reconciliar 01250/01251/02368 con 00296 (compuerta humana).
ANCLAS_ESTRICTO = {"00552": "8368841.36", "00562": "2092210.34", "00621": "2092210.34"}


def replay(out_dir=None):
    sys_path = caso_local.path_2025("sys")
    est_path = caso_local.path_2025("estimacion")
    df_path = caso_local.path_2025("datos_formales") or caso_local.path("datos_formales")
    if not (sys_path and os.path.exists(sys_path)):
        print("paths_2025.sys no configurado (caso_local.json) — nada que hacer.")
        return None
    out_dir = out_dir or os.path.join(ROOT, "engine_service", "_local_out", "gip2025_replay")
    os.makedirs(out_dir, exist_ok=True)

    # Datos de HECHO fiscales confirmados por el abogado (Paso 1: sustituyen los hardcodes). Vacío → defaults
    # provisionales y el autocontrol marca fail-closed lo no confirmado (regla dura 5). Vive en caso_local.json.
    # Codex finding 4: NORMALIZAR los facts (un "0,50" / "70.000.000,00" del JSON reventaría float()/comparaciones).
    _facts_raw = caso_local.facts_2025()
    facts = dict(_facts_raw)
    for _k in ("gf_limite_30", "gf_01250_real", "gf_adq", "gf_ord", "gf_adicion_01255", "bin_limite_pct",
               "incn_12m", "dias_periodo"):
        if facts.get(_k) is not None:
            facts[_k] = liquidacion._num(facts[_k])
    # INCN de los 12 meses previos (tramo BIN art.26 + ámbito art.30bis). DETERMINACIÓN del ejercicio (≠ INCN
    # contable 00255 ni el flag del .200 anterior). GIP 2025: 20-60M (confirmado por el despacho).
    incn = facts["incn_12m"] if facts.get("incn_12m") is not None else 30_000_000
    # Codex finding 1: UNA sola fuente de bin_pct (tramo art.26) para parse Y autocontrol — si solo viene
    # incn_12m, derivar de él (no usar 0.50 fijo); si viene bin_limite_pct, usarlo. Evita parse/autocontrol divergentes.
    bin_pct = facts.get("bin_limite_pct")
    if bin_pct is None:
        bin_pct = 0.70 if incn < 20_000_000 else (0.50 if incn < 60_000_000 else 0.25)
    # Liquidación 2025 (hoja 'GIS 2025' de la Estimación; mismas etiquetas de B.I./cuota que 2024).
    # `gf_limite_30` (30%·B.O. REAL, art.16.1) o `gf_01250_real` (resultado de explotación conciliado con 00296)
    # los aporta el abogado: si el B.O. es negativo (ETVE), el límite del 16.5 es 0 y el GF de adquisición es 100%
    # no deducible (criterio estricto, decisión 2026-06-19) → cuota 2.092.210,34. Sin ellos, provisional 1.673.807,25.
    def _parse_liq(r_01250=None):
        return liquidacion.parse(est_path, sheet_liq="GIS 2025", sheet_gf="GF",
                                 gf_pendientes=liquidacion.GF_PENDIENTES_2025, gf_pend_min_row=0,
                                 bin_casillas=liquidacion.BIN_CASILLAS_2025, bin_aplicado_ceil=False,
                                 gf_aeat_calcula=False, bin_limite_pct=bin_pct, regimen="etve",
                                 gf_limite_30=facts.get("gf_limite_30"),
                                 gf_01250_real=(r_01250 if r_01250 is not None else facts.get("gf_01250_real")),
                                 gf_adq=facts.get("gf_adq"), gf_ord=facts.get("gf_ord"),
                                 gf_adicion_01255=facts.get("gf_adicion_01255", 0.0),
                                 dias_periodo=facts.get("dias_periodo", 365)).get("casillas") or {}
    liq = _parse_liq() if (est_path and os.path.exists(est_path)) else {}
    # Datos formales (se arrastran del 2024).
    formales = engines.datos_formales(df_path)["formales"] if df_path and os.path.exists(df_path) else None
    # Caracteres de la declaración (config estable: ETVE/grupo/matriz…) arrastrados del .200 del año anterior.
    prior_200 = caso_local.path("real_200")
    tiene_prior = bool(prior_200 and os.path.exists(prior_200))
    caracteres = engines.caracteres_declaracion(prior_200, "2024") if tiene_prior else None
    # ECPN (DP200009/010/011) proyectado del propio SyS: Balance normal lo OBLIGA (error EMALP311). El PN de
    # cierre cuadra con el del balance (00185) por construcción; el año anterior es solo fallback.
    ecpn_pag, ecpn_avisos, _ = ecpn_sys.proyectar(sys_path)
    # DP200001B (modelo de estados de cuentas + matriz última): se arrastra del .200 anterior. Sin ella el
    # importador rechaza las páginas 3-11 (segunda forma del EMALP311: "debe haber cumplimentado algún estado
    # de cuentas"). Config estable (capa 1); el personal asalariado va como provisional del año anterior.
    pagina01b = engines.pagina01b_declaracion(prior_200, "2024") if tiene_prior else None

    def _export(liq_):
        _res = engines.exportar_aeat(sys_path, ejercicio="2025", nif=caso_local.nif(),
                                     razon_social=caso_local.razon_social(), liquidacion=liq_, formales=formales,
                                     caracteres=caracteres, incn=incn, ecpn=ecpn_pag, pagina01b=pagina01b)
        _decl = (_res.get("ficheros") or {}).get("declaracion_dr")
        _doc = base64.b64decode(_decl["base64"]).decode("iso-8859-1") if _decl else None
        return _res, _doc

    res, doc = _export(liq)
    if doc is None:
        print(f"No se generó la declaración (estado={res.get('estado')}, motivo={res.get('motivo')}).")
        return None
    dr = dr200.cargar_dr(ejercicio="2025")
    import autocontrol_200
    # AUTO-RECONCILIACIÓN 01250↔00296 (2ª pasada, gated por `conciliar_01250_con_00296`): el criterio estricto
    # exige que el resultado de explotación del art.16 (01250) concilie con el del PyG (00296). Si el abogado lo
    # pide y no aportó ya el dato, se LEE el 00296 real del propio .200 y se re-parsea fijando 01250=00296 → el
    # límite GF cae al suelo de 1M (B.O. real negativo) y el .200 queda import-limpio con la cuota estricta.
    recon_warn = None
    if (facts.get("conciliar_01250_con_00296") and facts.get("gf_01250_real") is None
            and facts.get("gf_limite_30") is None and est_path and os.path.exists(est_path)):
        _00296 = (autocontrol_200.casillas_por_pagina(doc, dr).get("DP200007") or {}).get("00296")
        if _00296:
            liq = _parse_liq(r_01250=_00296)
            res, doc = _export(liq)
            if doc is None:
                print("No se generó la declaración tras la reconciliación 01250↔00296.")
                return None
            facts = {**facts, "gf_01250_real": _00296}          # activa el modo estricto para las anclas
        else:
            # Codex finding C: fail-loud — el flag pidió conciliar pero no hay 00296 (DP200007 ausente o 0);
            # la reconciliación NO pudo ejecutarse y el .200 sigue provisional (INT-GF-RE bloqueará).
            recon_warn = ("conciliar_01250_con_00296 solicitado pero NO se encontró 00296 (DP200007) en el .200 "
                          "— la reconciliación NO se aplicó; el .200 queda provisional/fail-closed.")
    decl = (res.get("ficheros") or {}).get("declaracion_dr")     # de la pasada FINAL (tras reconciliación si la hubo)
    out_200 = os.path.join(out_dir, "declaracion_mod200_2025.200")
    with open(out_200, "w", encoding="iso-8859-1") as fh:
        fh.write(doc)

    # Validación: anclas del oráculo dentro del .200 + cobertura vs el .ses (si lo hay).
    # AUTOCONTROL pre-importación: comprueba las reglas de consistencia del importador AEAT ya descubiertas
    # (roll-up contable, desglose BINs, web de gastos financieros, reserva, matriz última, DID) SIN gastar una
    # importación. Un incumplimiento aquí = el importador rechazará el fichero -> corregir antes de subirlo.
    import json as _json
    _sub = _json.load(open(os.path.join(ROOT, "Extractor-parseador", "data", "campaigns", "2025",
                                         "mapeo_pgc_aeat.json"), encoding="utf-8")).get("subtotales")
    # Tramo art.26: MISMA fuente que la pasada a parse() (Codex finding 1) — coherencia parse↔autocontrol.
    autocontrol = autocontrol_200.validar(doc, dr, "2025", subtotales=_sub, bin_limite_pct=bin_pct)
    gen_cas = {f["casilla"] for f in golden.present_fields(out_200, dr) if f.get("casilla")}
    # Anclas según el MODO (Codex finding 5): estricto si el abogado aportó el 30%·B.O. real o el 01250 conciliado
    # (= 00296); si no, provisional.
    modo_estricto = facts.get("gf_limite_30") is not None or facts.get("gf_01250_real") is not None
    anclas_ref = ANCLAS_ESTRICTO if modo_estricto else ANCLAS
    anclas_ok = all(str(liq.get(c)) == v for c, v in anclas_ref.items())
    ses_path = caso_local.path_2025("ses")
    cobertura = None
    if ses_path and os.path.exists(ses_path):
        sescas = set(ses.parse(ses_path)["casillas"])
        cobertura = {"generadas": len(gen_cas), "en_ses": len(sescas),
                     "comunes": len(gen_cas & sescas), "faltan_del_ses": len(sescas - gen_cas)}
    avisos = list(res.get("avisos") or [])
    if recon_warn:
        avisos.append(recon_warn)
    # 00619 (cuota líquida mínima, art. 30bis) = 15% de la BI: el parser de liquidación la calcula siempre,
    # pero su INCLUSIÓN depende de una REGLA (INCN>=20M o grupo). El builder de replay la poda si INCN<20M;
    # la vía exportar_aeat NO. Para GIP es correcta (cualifica, como en 2024); para una entidad general la
    # inclusión la decide el motor de reglas. Se avisa para revisión (regla dura 5), no se emite en silencio.
    if "00619" in (liq or {}):
        avisos.append("00619 (cuota mínima art.30bis = 15% BI) emitida por el parser; correcta para GIP "
                      "(cualifica), pero su inclusión es una REGLA (INCN>=20M/grupo) — revisar para otra entidad.")
    if pagina01b:
        avisos.append("DP200001B arrastrada del .200 anterior (modelo de estados de cuentas + matriz última). "
                      "El personal asalariado (00041/00042) es la cifra del AÑO ANTERIOR (provisional) — revisar.")
    for x in autocontrol:
        avisos.append(f"AUTOCONTROL [{x['error_aeat']}] {x['regla']}: {x['detalle']}")
    return {"fichero": out_200, "bytes": len(doc), "casillas": len(gen_cas),
            "contiene_formales": decl.get("contiene_formales"), "contiene_liquidacion": decl.get("contiene_liquidacion"),
            "contiene_pagina01b": decl.get("contiene_pagina01b"),
            "anclas_oraculo_ok": anclas_ok, "casilla_00619": (liq or {}).get("00619"), "cobertura": cobertura,
            "autocontrol_ok": not autocontrol, "autocontrol_incumplimientos": autocontrol, "warnings": avisos}


def main():   # pragma: no cover
    r = replay()
    if not r:
        return
    print(f"{r['fichero']} · {r['bytes']} bytes · {r['casillas']} casillas")
    print(f"  contable+liquidación+formales: liq={r['contiene_liquidacion']} formales={r['contiene_formales']}")
    print(f"  anclas oráculo GIP 2025 (BI/cuota/ingresar) correctas: {r['anclas_oraculo_ok']}")
    print(f"  AUTOCONTROL pre-importación: {'✓ sin incumplimientos conocidos' if r['autocontrol_ok'] else str(len(r['autocontrol_incumplimientos']))+' INCUMPLIMIENTOS'}")
    for x in r["autocontrol_incumplimientos"]:
        print(f"    [{x['error_aeat']}] {x['regla']}: {x['detalle']}")
    if r["cobertura"]:
        print(f"  cobertura vs .ses: {r['cobertura']}")


if __name__ == "__main__":
    main()
