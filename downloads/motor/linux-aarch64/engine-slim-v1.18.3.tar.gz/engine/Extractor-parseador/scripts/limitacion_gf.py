#!/usr/bin/env python3
"""Límite de gastos financieros (art. 16 LIS) por CRITERIO — fuente ÚNICA de la matemática.

Extrae la aritmética del art. 16 que vive acoplada al Excel en
`gip2024_liquidacion_parser._gastos_financieros` a una función PURA que toma FIGURAS (no un path de
Excel), para exponer el criterio (leniente / estricto) como una decisión del cuestionario de la lanzadera.

El criterio se materializa como el IMPORTE del ajuste permanente **00363** (= 01260 = c2 art.16.5 + l2
art.16.1), que entra como `diferencias_permanentes` (signo +) en `liquidar_orquestado` (el motor firma la
cuota, ADR-001). NO toca `dr200`/`builder`/`motor_expediente`/`limite_bins` (GIP 2024 byte-idéntico).

Consistencia con el parser GIP-validado: garantizada por test gated (`test_gf_criterio` / GIP local) que
exige `limitacion_gf(...)["00363"] == _gastos_financieros(...)["01260"]` para ambos criterios. Helpers
`_round2`/`_limite_gf_161` self-contained (idénticos a los del parser; el número del art.16 es lo que se
mantiene de fuente única).
"""
from __future__ import annotations

from decimal import Decimal, ROUND_HALF_UP

_Q = Decimal("0.01")


def _round2(x) -> float:
    """Redondeo a 2 decimales HALF_UP (idéntico al `_round2` del parser)."""
    if x is None:
        return 0.0
    return float(Decimal(str(x)).quantize(_Q, rounding=ROUND_HALF_UP))


def _limite_gf_161(limite_30, adicion=0.0, suelo=1_000_000.0, dias_periodo=365, dias_anio=365) -> float:
    """Límite art. 16.1 (casilla 02369) = max(30%·B.O.[clampado a ≥0] + adición 01255; suelo 1M prorrateado).

    Réplica EXACTA de `gip2024_liquidacion_parser._limite_gf_161` (ingeniería inversa del importador AEAT
    2026-06-19: 02369 = max(suelo; max(0, 01249) + 01255); el 30%·B.O. negativo se clampa a 0 antes de sumar)."""
    base = max(0.0, (float(limite_30) if limite_30 is not None else 0.0)) + (float(adicion) if adicion else 0.0)
    suelo = max(0.0, float(suelo))
    dias_anio = dias_anio if dias_anio and dias_anio > 0 else 365
    dias = min(max(1, int(dias_periodo)), dias_anio)
    suelo_efectivo = suelo if dias >= dias_anio else round(suelo * dias / dias_anio, 2)
    return _round2(max(base, suelo_efectivo))


def limitacion_gf(neto, *, criterio="leniente", regimen="etve", limite_30_hoja=None,
                  resultado_explotacion_01250=None, resultado_pyg_00296=None, limite_30_real=None,
                  gf_adq=None, gf_ord=None, adicion_01255=0.0, suelo=1_000_000.0, dias_periodo=365) -> dict:
    """Límite de GF del art. 16 por criterio. Devuelve casillas de GF, incl. **00363 = 01260**.

    - `neto`: gasto financiero neto del período (casilla 01256 de la hoja GF).
    - `criterio="leniente"`: resultado de explotación de la hoja (01250) tal cual → 01249 = `limite_30_hoja`.
    - `criterio="estricto"`: reconcilia 01250↔00296 (art.16.1, suelo 1M) → `limite_30` =
      `limite_30_real`, o `limite_30_hoja − 0,30·(01250 − 00296)`; con B.O. real ≤ 0, 02369 cae al suelo y el
      GF de adquisición (art.16.5, sin suelo) queda no deducible → 00363 mayor.
    - `regimen="etve"`: GF de adquisición por art.16.5 (bloque 1, 01240-01243) + filtro art.16.1 (bloque 2);
      `general`: GF ordinarios solo por art.16.1.
    """
    regimen = str(regimen or "general").strip().lower()   # ETVE/Etve/etve -> etve (Codex GF1: el resto del motor acepta mayúsculas)
    if criterio == "estricto":
        if limite_30_real is not None:
            limite_30 = _round2(limite_30_real)
        elif None not in (limite_30_hoja, resultado_explotacion_01250, resultado_pyg_00296):
            limite_30 = _round2(limite_30_hoja - 0.30 * (resultado_explotacion_01250 - resultado_pyg_00296))
        else:
            limite_30 = limite_30_hoja
    else:
        limite_30 = limite_30_hoja
    base_30 = _round2(limite_30) if limite_30 is not None else None
    o2369 = _limite_gf_161(base_30, adicion=adicion_01255, suelo=suelo, dias_periodo=dias_periodo)
    out = {"01249": base_30, "02369": o2369}
    if regimen == "etve":
        limite_165 = max(0.0, _round2((base_30 or 0.0) + (adicion_01255 or 0.0)))
        gf_adq_v = max(0.0, _round2(gf_adq) if gf_adq is not None else _round2(neto))
        gf_ord_v = max(0.0, _round2(gf_ord) if gf_ord is not None else 0.0)
        c1 = _round2(min(gf_adq_v, limite_165))
        out["01243"] = _round2(gf_adq_v - c1)            # c2) NO deducible por el 16.5 (se arrastra)
        base_b2 = _round2(c1 + gf_ord_v)
        out["01248"] = base_b2
        out["01256"] = _round2(min(base_b2, o2369))      # l1) deducible por el 16.1
        out["01257"] = _round2(max(0.0, base_b2 - o2369))  # l2) NO deducible por el 16.1 (exceso sobre 02369)
    else:
        neto_pos = max(0.0, _round2(neto))
        out["01243"] = 0.0
        out["01248"] = neto_pos
        out["01256"] = _round2(min(neto_pos, o2369))
        out["01257"] = _round2(max(0.0, neto_pos - out["01256"]))
    out["01260"] = _round2((out.get("01243") or 0.0) + out["01257"])
    out["00363"] = out["01260"]                          # ajuste permanente positivo (art.16) que mueve la BI
    return out


def gf_criterio(payload: dict) -> dict:
    """Calcula el GF por AMBOS criterios (leniente/estricto) + delta del 00363, para el cuestionario.

    NO firma cuota: el 00363 elegido entra como `diferencias_permanentes` (+) en `liquidar_orquestado`.
    `payload` (todas las figuras opcionales salvo `neto`): neto, regimen, limite_30_hoja,
    resultado_explotacion_01250, resultado_pyg_00296, limite_30_real, gf_adq, gf_ord, adicion_01255,
    suelo, dias_periodo.
    """
    p = dict(payload or {})
    neto = p.pop("neto", 0.0) or 0.0
    p.pop("criterio", None)
    leniente = limitacion_gf(neto, criterio="leniente", **p)
    estricto = limitacion_gf(neto, criterio="estricto", **p)
    return {
        "leniente": leniente,
        "estricto": estricto,
        "delta_00363": _round2(float(estricto["00363"]) - float(leniente["00363"])),
    }
