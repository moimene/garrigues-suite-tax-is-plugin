#!/usr/bin/env python3
"""Ciclo de declaraciones: genera N borradores `.200` del Modelo 200 desde los workbooks de cada cliente y
produce un INFORME DE TRIAJE (qué cuadra, qué debe revisar/corregir el abogado).

Filosofía: GENERAR YA (borrador best-effort) → el abogado corrige en Sociedades WEB; el autocontrol ADELANTA
CRITERIO (marca antes de importar lo que el importador rechazaría o lo que es decisión fiscal).

Config: `Extractor-parseador/declaraciones.json` (gitignored, con los workbooks REALES) o, si no existe, el
ejemplo sintético `declaraciones.example.json`. Cada entrada = una declaración (ver el esquema en el ejemplo).
El motor RAMIFICA por `regimen` (general=GF art.16.1 bloque 2; etve=GF art.16.5 bloque 1) y por `incn` (tramo
BIN art.26 + cuota mínima art.30bis). Las entradas con paths vacíos se marcan 'pendiente' (faltan workbooks).

0 PII en este módulo. Las salidas (`.200` y el informe) van a `_local_out/` (gitignored). El resumen por
pantalla enmascara el NIF.

Uso:  python3 Extractor-parseador/scripts/ciclo_declaraciones.py [ruta_config.json]
"""
import base64
import json
import os
import sys

ROOT = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
sys.path.insert(0, ROOT)
sys.path.insert(0, os.path.join(ROOT, "Extractor-parseador", "scripts"))

import autocontrol_200                                # noqa: E402
import dr200                                          # noqa: E402
import ecpn_sys                                       # noqa: E402
import gip2024_liquidacion_parser as liquidacion      # noqa: E402
import validacion_importabilidad_200 as importabilidad  # noqa: E402
from engine_service import engines                    # noqa: E402

_DIR = os.path.join(ROOT, "Extractor-parseador")
_OUT = os.path.join(ROOT, "engine_service", "_local_out", "ciclo")


def _tramo_bin(incn):
    """% de compensación de BINs por tramo de INCN (art. 26 LIS)."""
    incn = float(incn or 0)
    return 0.70 if incn < 20_000_000 else (0.50 if incn < 60_000_000 else 0.25)


def _mask(nif):
    return (nif[:1] + "***" + nif[-2:]) if nif and len(nif) >= 3 else "***"


def generar_declaracion(cfg, out_dir):
    """Genera el `.200` borrador de UNA declaración y devuelve su entrada de triaje. cfg = dict del config."""
    paths = cfg.get("paths") or {}
    sys_path = paths.get("sys")
    est_path = paths.get("estimacion")
    df_path = paths.get("datos_formales")
    prior_200 = paths.get("prior_200")
    ident = cfg.get("id") or _mask(cfg.get("nif"))
    base = {"id": ident, "nif": _mask(cfg.get("nif")), "regimen": cfg.get("regimen", "general"),
            "ejercicio": str(cfg.get("ejercicio", "2025"))}
    if not (sys_path and os.path.exists(sys_path)):
        return {**base, "estado": "pendiente", "motivo": "falta el SyS contable (paths.sys)"}

    ej = str(cfg.get("ejercicio", "2025"))
    regimen = cfg.get("regimen", "general")
    incn = cfg.get("incn") or 0
    bin_pct = _tramo_bin(incn)
    sheets = cfg.get("sheets") or {}

    # 1) LIQUIDACIÓN (Estimación): el motor ramifica por régimen + tramo BIN.
    liq = {}
    if est_path and os.path.exists(est_path):
        liq = liquidacion.parse(est_path, sheet_liq=sheets.get("liq"), sheet_gf=sheets.get("gf"),
                                gf_pendientes=liquidacion.GF_PENDIENTES_2025, gf_pend_min_row=0,
                                bin_casillas=liquidacion.BIN_CASILLAS_2025, bin_aplicado_ceil=False,
                                gf_aeat_calcula=(ej == "2024"), bin_limite_pct=bin_pct,
                                regimen=regimen).get("casillas") or {}
    # 2) Datos formales + caracteres + estados de cuentas (se arrastran del .200 anterior si lo hay).
    formales = engines.datos_formales(df_path)["formales"] if df_path and os.path.exists(df_path) else None
    tiene_prior = bool(prior_200 and os.path.exists(prior_200))
    ej_prior = str(int(ej) - 1)
    caracteres = engines.caracteres_declaracion(prior_200, ej_prior) if tiene_prior else None
    pagina01b = engines.pagina01b_declaracion(prior_200, ej_prior) if tiene_prior else None
    # 3) ECPN proyectado del propio SyS (Balance normal lo obliga).
    try:
        ecpn_pag, _, _ = ecpn_sys.proyectar(sys_path)
    except Exception as e:   # noqa: BLE001
        ecpn_pag, ecpn_err = None, str(e)
    else:
        ecpn_err = None

    # 4) EXPORTAR: SyS contable → .200 (fail-closed si descuadra).
    res = engines.exportar_aeat(sys_path, ejercicio=ej, nif=cfg.get("nif", ""),
                                razon_social=cfg.get("razon_social", ""), liquidacion=liq, formales=formales,
                                caracteres=caracteres, incn=(float(incn) if incn else None), ecpn=ecpn_pag,
                                pagina01b=pagina01b)
    decl = (res.get("ficheros") or {}).get("declaracion_dr")
    if not decl:
        return {**base, "estado": "fail-closed",
                "motivo": res.get("motivo") or f"no se generó (estado={res.get('estado')})"}
    doc = base64.b64decode(decl["base64"]).decode("iso-8859-1")
    os.makedirs(out_dir, exist_ok=True)
    out_200 = os.path.join(out_dir, f"declaracion_{ident}.200")
    with open(out_200, "w", encoding="iso-8859-1") as fh:
        fh.write(doc)

    # 5) IMPORTABILIDAD (adelanta criterio): DR + autocontrol + reglas Open/HITL antes de importar.
    dr = dr200.cargar_dr(ejercicio=ej)
    _sub_path = os.path.join(_DIR, "data", "campaigns", ej, "mapeo_pgc_aeat.json")
    _sub = json.load(open(_sub_path, encoding="utf-8")).get("subtotales") if os.path.exists(_sub_path) else None
    informe_import = importabilidad.analizar(doc, dr, ej, subtotales=_sub, bin_limite_pct=bin_pct)
    incumpl = [h for h in informe_import["hallazgos"] if h.get("bloqueante", True)]
    # Avisos de criterio (decisiones del abogado que el motor no resuelve solo):
    revisar = [
        f"[{x['codigo']}] {x.get('pagina','')}/{x.get('casilla','')}: {x.get('mensaje','')}"
        for x in informe_import["hallazgos"]
    ]
    if ecpn_err:
        revisar.append(f"ECPN no proyectado: {ecpn_err}")
    if liq.get("00619"):
        revisar.append("00619 (cuota mínima art.30bis = 15% BI): inclusión condicionada a INCN>=20M/grupo — confirmar.")
    if not tiene_prior:
        revisar.append("Sin .200 del año anterior: faltan caracteres (ETVE/grupo/matriz) y estados de cuentas (DP200001B) — el importador exigirá páginas 3-11.")
    # Avisos de DATO DE CLIENTE (el harness no los deriva; el abogado los completa en Sociedades WEB):
    revisar.append("Datos de cliente a verificar/completar en el formulario: CNAE-2025 actividad principal (196); "
                   "NIF de la sociedad dominante del grupo si consolida (21200); signos de existencias/deudores "
                   "del activo corriente y de las correcciones al PyG (11711/11717).")
    revisar.extend(res.get("avisos") or [])

    anclas = cfg.get("anclas") or {}
    anclas_ok = all(str(liq.get(c)) == v for c, v in anclas.items()) if anclas else None
    return {**base, "estado": "generado", "fichero": out_200, "bytes": len(doc),
            "bi_00552": liq.get("00552"), "cuota_00562": liq.get("00562"),
            "autocontrol_ok": not incumpl,
            "importabilidad_probable": informe_import["resumen"]["importabilidad_probable"],
            "importabilidad": informe_import["resumen"],
            "n_revisar": len(revisar), "revisar": revisar,
            "anclas_ok": anclas_ok}


def ciclo(config_path=None):
    """Procesa todas las declaraciones del config y devuelve la lista de triaje."""
    config_path = config_path or os.path.join(_DIR, "declaraciones.json")
    if not os.path.exists(config_path):
        config_path = os.path.join(_DIR, "declaraciones.example.json")
    cfg = json.load(open(config_path, encoding="utf-8"))
    decls = cfg.get("declaraciones") or []
    out_dir = _OUT
    resultados = [generar_declaracion(d, out_dir) for d in decls]
    _escribir_informe(resultados, out_dir, config_path)
    return resultados


def _escribir_informe(resultados, out_dir, config_path):
    os.makedirs(out_dir, exist_ok=True)
    gen = [r for r in resultados if r["estado"] == "generado"]
    L = ["# Informe de triaje — ciclo de declaraciones Modelo 200", "",
         f"Config: `{os.path.relpath(config_path, ROOT)}` · {len(resultados)} declaración(es) "
         f"· {len(gen)} generada(s) · {sum(1 for r in gen if r.get('importabilidad_probable'))} importable(s) probable(s).", "",
         "| ID | Régimen | Estado | BI (00552) | Cuota (00562) | Importabilidad | A revisar |",
         "|---|---|---|---|---|---|---|"]
    for r in resultados:
        ac = ("✓" if r.get("importabilidad_probable") else f"⚠️ {r.get('n_revisar', '')}") if r["estado"] == "generado" else "—"
        L.append(f"| {r['id']} | {r['regimen']} | {r['estado']} | {r.get('bi_00552', '—')} | "
                 f"{r.get('cuota_00562', '—')} | {ac} | {r.get('n_revisar', 0) if r['estado']=='generado' else r.get('motivo','')} |")
    L.append("")
    for r in gen:
        if r.get("revisar"):
            L.append(f"## {r['id']} — {len(r['revisar'])} punto(s) a revisar por el abogado")
            L.extend(f"- {x}" for x in r["revisar"])
            L.append("")
    path = os.path.join(out_dir, "informe_triaje.md")
    open(path, "w", encoding="utf-8").write("\n".join(L))
    return path


def main():   # pragma: no cover
    cfg_arg = sys.argv[1] if len(sys.argv) > 1 else None
    resultados = ciclo(cfg_arg)
    gen = [r for r in resultados if r["estado"] == "generado"]
    print(f"CICLO: {len(resultados)} declaración(es) · {len(gen)} generada(s) · "
          f"{sum(1 for r in gen if r.get('importabilidad_probable'))} importable(s) probable(s).")
    for r in resultados:
        if r["estado"] == "generado":
            print(f"  [{r['id']:24}] {r['regimen']:7} · BI {r.get('bi_00552')} · cuota {r.get('cuota_00562')} "
                  f"· importabilidad {'✓' if r.get('importabilidad_probable') else '⚠️ '+str(r['n_revisar'])} "
                  f"· revisar {r['n_revisar']}")
        else:
            print(f"  [{r['id']:24}] {r['estado']}: {r.get('motivo','')}")
    print(f"Informe: {os.path.relpath(os.path.join(_OUT, 'informe_triaje.md'), ROOT)}")


if __name__ == "__main__":
    main()
