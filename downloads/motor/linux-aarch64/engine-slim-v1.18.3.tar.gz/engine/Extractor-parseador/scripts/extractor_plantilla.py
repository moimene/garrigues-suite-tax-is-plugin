"""Extractor declarativo por plantilla — el 'seam' determinista para generalizar a sociedades nuevas.

En vez de un parser a medida por sociedad (hoy `gip2024_*_parser.py`), una PLANTILLA declarativa mapea cada
casilla a una celda del workbook. Una sociedad nueva = una plantilla (CONFIG), no código. La salida es un
FRAGMENTO DE CONTRATO (`source`/`casillas`/`campos_pos`/`warnings`) idéntico al que producen los parsers,
así que entra sin cambios en `gip2024_replay_contract.merge_sources` y de ahí al builder.

El mismo contrato lo podrá producir mañana un extractor por LLM (vía gateway, sin keys locales): este módulo
fija la frontera para que esa pieza sea enchufable sin tocar el builder.

Localización de celda en la plantilla, por casilla:
- `{"hoja": H, "celda": "C15"}`                                  -> referencia A1 directa
- `{"hoja": H, "etiqueta": "Base imponible", "desplazamiento": [0, 1]}`  -> ancla por etiqueta + offset
  (robusto a filas que se desplazan; por defecto la celda a la derecha de la etiqueta).
Opcional `"tipo": "texto"` para no coercer a número; por defecto se intenta número (formato europeo).

NO contiene PII: las plantillas reales de cada sociedad viven fuera de git (junto a `caso_local.json`); la
forma versionada y sintética es `extractor_plantilla.example.json`.
"""
from __future__ import annotations

import json
import re

_CELDA_RE = re.compile(r"([A-Za-z]+)(\d+)")


def col_a_indice(col: str) -> int:
    """Letra(s) de columna Excel -> índice 0-based. 'A'->0, 'C'->2, 'AA'->26."""
    idx = 0
    for ch in str(col).upper():
        if not ("A" <= ch <= "Z"):
            raise ValueError(f"columna inválida: {col!r}")
        idx = idx * 26 + (ord(ch) - 64)
    return idx - 1


def celda_a_rc(celda: str):
    """Referencia A1 ('C15') -> (fila, columna) 0-based: (14, 2)."""
    m = _CELDA_RE.fullmatch(str(celda).strip())
    if not m:
        raise ValueError(f"celda inválida: {celda!r}")
    return int(m.group(2)) - 1, col_a_indice(m.group(1))


def _valor_celda(grid, r, c):
    if 0 <= r < len(grid) and 0 <= c < len(grid[r]):
        return grid[r][c]
    return None


def _buscar_etiqueta(grid, etiqueta):
    """TODAS las celdas cuyo texto coincide (sin distinguir mayúsculas/espacios) con `etiqueta` -> [(fila,col)].
    Devuelve la lista completa para que el llamante detecte ambigüedad (no elige a ciegas)."""
    objetivo = str(etiqueta).strip().lower()
    return [(r, c) for r, fila in enumerate(grid) for c, val in enumerate(fila)
            if val is not None and str(val).strip().lower() == objetivo]


def _resolver(grid, spec):
    """(valor, error) de una celda según la spec (celda directa o ancla por etiqueta)."""
    if "celda" in spec:
        try:
            r, c = celda_a_rc(spec["celda"])
        except ValueError as e:
            return None, str(e)
        return _valor_celda(grid, r, c), None
    if "etiqueta" in spec:
        pos = _buscar_etiqueta(grid, spec["etiqueta"])
        if not pos:
            return None, f"etiqueta no encontrada: {spec['etiqueta']!r}"
        if len(pos) > 1:                       # ambigua: no se elige a ciegas (regla dura 5)
            return None, f"etiqueta ambigua, {len(pos)} coincidencias: {spec['etiqueta']!r}"
        dr, dc = spec.get("desplazamiento", [0, 1])
        return _valor_celda(grid, pos[0][0] + dr, pos[0][1] + dc), None
    return None, "spec sin 'celda' ni 'etiqueta'"


_MILES_RE = re.compile(r"\d{1,3}(\.\d{3})+")        # '1.234.567' (solo puntos en grupos de 3 = miles)


def _a_float(v):
    """Número desde celda Excel (int/float ya parseado por pandas) o string. Convención española: la coma
    es el decimal y el punto el separador de miles. Para evitar números MAL interpretados en silencio:
    - con coma -> los puntos son miles ('2.486.355,42' -> 2486355.42; '11068602,43' -> 11068602.43);
    - solo puntos en grupos de 3 -> miles ('1.234.567' -> 1234567; '1.000' -> 1000);
    - punto suelto no-agrupado -> decimal a la anglosajona ('1234.56' -> 1234.56)."""
    if isinstance(v, bool):
        raise ValueError("booleano no es importe")
    if isinstance(v, (int, float)):
        return float(v)
    s = str(v).strip()
    if "," in s:                              # coma = decimal; puntos = miles
        s = s.replace(".", "").replace(",", ".")
    elif _MILES_RE.fullmatch(s):              # solo puntos en grupos de 3 = miles europeos
        s = s.replace(".", "")
    return float(s)


def _coerce(val, tipo):
    """Coerción del valor de celda según `tipo` ('texto' -> str; por defecto número)."""
    if tipo == "texto":
        return str(val).strip()
    return _a_float(val)


def extraer_por_plantilla(cuadricula: dict, plantilla: dict) -> dict:
    """`cuadricula` = {hoja: grid (lista de filas)}; `plantilla` = {meta, casillas:{cas: spec}}.
    Devuelve un fragmento de contrato: {source, priority, casillas, campos_pos, warnings, provenance}.
    Fail-loud (regla dura 5): celda vacía/ausente/ilegible -> warning, NO se inventa el valor."""
    meta = plantilla.get("meta") or {}
    casillas, warnings, provenance = {}, [], {}
    for cas, spec in (plantilla.get("casillas") or {}).items():
        cas = str(cas).strip()
        hoja = spec.get("hoja")
        grid = cuadricula.get(hoja)
        if grid is None:
            warnings.append(f"casilla {cas}: hoja {hoja!r} no está en el workbook")
            continue
        val, err = _resolver(grid, spec)
        if err:
            warnings.append(f"casilla {cas}: {err}")
            continue
        if val is None or (isinstance(val, str) and not val.strip()):
            warnings.append(f"casilla {cas}: celda vacía ({spec.get('celda') or spec.get('etiqueta')})")
            continue
        try:
            casillas[cas] = _coerce(val, spec.get("tipo"))
        except (ValueError, TypeError):
            warnings.append(f"casilla {cas}: valor no numérico {val!r} (¿tipo: texto?)")
            continue
        provenance[cas] = {k: spec[k] for k in ("hoja", "celda", "etiqueta") if k in spec}
    frag = {"source": meta.get("source", "plantilla"),
            "casillas": casillas, "campos_pos": {}, "warnings": warnings, "provenance": provenance}
    if meta.get("priority") is not None:        # 'priority: None' rompería _priority (int(None)) en el merge
        frag["priority"] = meta["priority"]
    return frag


def cargar_cuadricula(path, hojas=None) -> dict:
    """Lee un workbook (.xlsx/.xls) a {hoja: grid} con pandas (header=None, dtype=object; NaN -> None).
    Aislado del extractor puro para que la lógica sea testeable sin ficheros Excel."""
    import pandas as pd
    xls = pd.ExcelFile(path)
    out = {}
    for h in (hojas or xls.sheet_names):
        df = pd.read_excel(xls, sheet_name=h, header=None, dtype=object)
        out[h] = df.where(pd.notnull(df), None).values.tolist()
    return out


def extraer(path, plantilla) -> dict:
    """Conveniencia: carga el workbook (solo las hojas que usa la plantilla) y aplica la plantilla."""
    if isinstance(plantilla, str):
        with open(plantilla, encoding="utf-8") as fh:
            plantilla = json.load(fh)
    hojas = sorted({s.get("hoja") for s in (plantilla.get("casillas") or {}).values() if s.get("hoja")})
    return extraer_por_plantilla(cargar_cuadricula(path, hojas), plantilla)


if __name__ == "__main__":   # pragma: no cover
    import sys
    frag = extraer(sys.argv[1], sys.argv[2])
    print(f"source={frag['source']} casillas={len(frag['casillas'])} warnings={len(frag['warnings'])}")
