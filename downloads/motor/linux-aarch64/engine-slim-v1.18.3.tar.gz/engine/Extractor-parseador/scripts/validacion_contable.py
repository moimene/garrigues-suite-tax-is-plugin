#!/usr/bin/env python3
"""validacion_contable.py — Validación PRE-IMPORT de la Fase A (importador de datos contables) [Epic 3].

Antes de emitir/validar el XML contra el XSD, comprueba que los datos contables son **aptos para
importar** en Sociedades WEB (Fase A, D13 — SOLO balance/PyG/ECPN, sin liquidación):

  BLOQUEANTES (🔴):
    - balance_cuadra      : identidad contable TOTAL ACTIVO (00180) = TOTAL PN+PASIVO (00252).
    - resultado_presente  : el resultado del ejercicio (00500) existe y es numérico.
  AVISOS (🟡):
    - cuentas_mapeadas    : todas las cuentas mapean al PGC→casilla (las no mapeadas no impiden cuadre).
    - perfil_entidad      : el tipo de entidad selecciona la rama del XSD; en 2024 sólo "normal" validado.
    - formato_*           : formato DR200 (tipo/constante/longitud) de las casillas presentes.

Es el PASO PREVIO al XSD (que valida estructura). Las identidades inter-casilla completas de la AEAT
(más allá del balance) son un documento aparte (pendiente) — aquí se valida lo verificable y NO se
inventan reglas. Determinista, sin dependencias.
"""
from __future__ import annotations

from typing import List, Optional

PERFILES = {"normal", "abreviado", "pymes"}


def _num(v) -> Optional[float]:
    try:
        return float(v)
    except (TypeError, ValueError):
        return None


def _validar_formato(casillas: dict, vf: dict) -> List[dict]:
    """Formato DR200 (validaciones_formato.json) sobre las casillas PRESENTES. Solo avisos (🟡)."""
    issues: List[dict] = []
    for c, val in casillas.items():
        if val is None:
            continue
        spec = vf.get(c)
        if not spec:
            continue
        if spec.get("tipo") == "N" and _num(val) is None:
            issues.append({"regla": f"formato_tipo_{c}", "ok": False,
                           "detalle": f"{c}: se esperaba numérico, llegó {val!r}", "casilla": c})
        cont = spec.get("contenido")
        if cont not in (None, "") and str(val).strip() != str(cont).strip():
            issues.append({"regla": f"formato_constante_{c}", "ok": False,
                           "detalle": f"{c}: contenido fijo esperado {cont!r}, llegó {val!r}", "casilla": c})
        lon = spec.get("longitud")
        n = _num(val)
        if lon and n is not None and len(str(int(round(abs(n) * 100)))) > int(lon):
            issues.append({"regla": f"formato_longitud_{c}", "ok": False,
                           "detalle": f"{c}: excede longitud {lon} (en céntimos)", "casilla": c})
    return issues


def validar(casillas: dict, cuadre: dict, *, tipo_entidad="normal",
            validaciones_formato=None, ejercicio="2024") -> dict:
    """casillas contables + cuadre (builder) -> informe 'apto para importar' (Fase A)."""
    casillas = casillas or {}
    cuadre = cuadre or {}
    checks: List[dict] = []

    def add(regla, ok, criticidad, detalle, casilla=None):
        checks.append({"regla": regla, "ok": bool(ok), "criticidad": criticidad,
                       "detalle": detalle, "casilla": casilla})

    # 🔴 1) Identidad de balance: 00180 == 00252.
    # `builder.proyectar` devuelve `dif` pero NO siempre la clave `cuadra` (solo `build` la añade);
    # derivamos el cuadre de `dif` cuando falta, o de 00180/00252 si tampoco hay `dif`.
    ta, tp, dif = cuadre.get("total_activo"), cuadre.get("total_pnpasivo"), cuadre.get("dif")
    cuadra = cuadre.get("cuadra")
    if cuadra is None:
        d = _num(dif)
        if d is None and _num(ta) is not None and _num(tp) is not None:
            d = _num(ta) - _num(tp)
        cuadra = (d is not None) and abs(d) < 0.01
    add("balance_cuadra", bool(cuadra), "🔴",
        f"TOTAL ACTIVO (00180)={ta} vs TOTAL PN+PASIVO (00252)={tp}; diferencia={dif}")

    # 🔴 2) Resultado del ejercicio presente
    res = cuadre.get("resultado", casillas.get("00500"))
    add("resultado_presente", _num(res) is not None, "🔴",
        f"Resultado del ejercicio (00500)={res}")

    # 🟡 3) Cuentas sin mapear (no impiden cuadre, pero conviene revisar)
    no_map = cuadre.get("no_map") or []
    add("cuentas_mapeadas", len(no_map) == 0, "🟡",
        f"{len(no_map)} cuenta(s) sin mapear" + (": " + ", ".join(map(str, no_map[:10])) if no_map else ""))

    # 🟡 4) Perfil de entidad / rama del XSD
    perfil = str(tipo_entidad or "normal").lower()
    perfil_ok = perfil == "normal"
    add("perfil_entidad", perfil_ok, "🟡",
        f"Perfil Normal (validado en {ejercicio})." if perfil_ok else
        (f"Perfil '{perfil}' aún no cargado (sólo Normal validado en {ejercicio}); revisar manualmente."
         if perfil in PERFILES else f"Perfil '{perfil}' desconocido."))

    # 🟡 5) Formato DR200 sobre casillas presentes
    if validaciones_formato:
        for f in _validar_formato(casillas, validaciones_formato):
            add(f["regla"], f["ok"], "🟡", f["detalle"], f.get("casilla"))

    n_rojo = sum(1 for c in checks if c["criticidad"] == "🔴" and not c["ok"])
    n_amar = sum(1 for c in checks if c["criticidad"] == "🟡" and not c["ok"])
    apto = n_rojo == 0
    return {
        "apto": apto,
        "tipo_entidad": perfil,
        "ejercicio": str(ejercicio),
        "semaforo": "🟢" if (n_rojo == 0 and n_amar == 0) else ("🟡" if n_rojo == 0 else "🔴"),
        "n_rojo": n_rojo,
        "n_amarillo": n_amar,
        "checks": checks,
        "motivos": [c["detalle"] for c in checks if not c["ok"]],
        "nota": "Fase A (D13): identidades contables (bloqueantes) + formato/perfil (avisos). "
                "El XML solo-contable se valida además contra el XSD.",
    }
