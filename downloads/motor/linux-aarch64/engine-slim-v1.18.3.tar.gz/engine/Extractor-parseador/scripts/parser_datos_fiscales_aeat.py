"""Parser determinista de la «Consulta de Datos Fiscales — Impuesto Sociedades» de la AEAT (PDF digital).

Es la fuente OPCIONAL del Nivel C (ver docs/memoria/2026-06-20-proceso-extraccion-parseo-validacion-fiscal.md):
un documento de PLANTILLA FIJA que AUTOETIQUETA sus casillas M200, por lo que su ingesta es DETERMINISTA
(no requiere modelo potente). Aporta, ya mapeado a casilla:
  - Capa 1: identificativos (NIF/nombre), CNAE 2025, caracteres (00027/00039/00081…), estados de cuentas
    (00050-00055/00075-00077 → perfil Normal/Abreviado/PYMES).
  - Capa 2: administradores, socios (B.2), titular real.
  - Inputs de liquidación: INCN (00255), retenciones (M190 y de cuentas bancarias → 01785/01786), BINs
    pendientes de compensar (→ 00547) y, por extender, deducciones (DT37.1 → 02702).

ROBUSTEZ (hallazgo 2026-06-20): solo aplica a la **«Consulta de Datos Fiscales» DIGITAL** de la AEAT (texto
nativo). Algunos despachos aportan un ESCANEO (PDF imagen, sin texto) → este parser devuelve `necesita_ocr=True`
y la ruta correcta es OCR (servicio persona_tax/Docling) + este mismo parser sobre el texto OCR, con HITL.
Validado 5/5 sobre la muestra ARIOSO 2025 (12/12 campos en ARIOSO 5). Sin dependencias del proyecto. 0 PII.

Uso:  python3 parser_datos_fiscales_aeat.py <fichero.pdf>
"""
from __future__ import annotations
import re
import os
import shutil
import subprocess
import tempfile

_MIN_TEXTO = 200   # nº mínimo de caracteres extraídos; por debajo, PDF escaneado → OCR


def _num(s):
    """Importe español ('4.134.670,60') → float; None si no parsea."""
    try:
        return float(str(s).strip().replace(".", "").replace(",", "."))
    except (ValueError, AttributeError):
        return None


def _leer_texto(path: str) -> str:
    """Texto del PDF (todas las páginas) o de una extracción `.txt`/`.md`.

    El `.txt` es la vía HITL cuando la Consulta AEAT viene como PDF imagen: el humano/OCR externo deja el texto
    en la carpeta y se reusa el mismo parser determinista.
    """
    if os.path.splitext(path)[1].lower() in {".txt", ".md"}:
        with open(path, encoding="utf-8", errors="ignore") as fh:
            return fh.read()
    import pdfplumber
    with pdfplumber.open(path) as pdf:
        return "\n".join((pg.extract_text() or "") for pg in pdf.pages)


def _ocr_texto_local(path: str) -> str:
    """OCR local best-effort para PDFs imagen. No introduce dependencia dura: si faltan binarios, devuelve ''."""
    if not (shutil.which("pdftoppm") and shutil.which("tesseract")):
        return ""
    with tempfile.TemporaryDirectory() as td:
        prefix = os.path.join(td, "page")
        try:
            subprocess.run(["pdftoppm", "-r", "200", "-png", path, prefix],
                           check=True, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        except (OSError, subprocess.CalledProcessError):
            return ""
        out: list[str] = []
        for img in sorted(p for p in os.listdir(td) if p.startswith("page-") and p.endswith(".png")):
            ipath = os.path.join(td, img)
            for lang in ("spa+eng", "eng"):
                try:
                    r = subprocess.run(["tesseract", ipath, "stdout", "-l", lang, "--psm", "6"],
                                       check=True, capture_output=True, text=True)
                    out.append(r.stdout)
                    break
                except (OSError, subprocess.CalledProcessError):
                    continue
        return "\n".join(out)


def parse_texto(text: str, ejercicio: str = "") -> dict:
    """Parsea el TEXTO (nativo u OCR) de la Consulta de Datos Fiscales → contrato de salida."""
    out = {
        "necesita_ocr": False, "fuente": "datos_fiscales_aeat", "ejercicio": ejercicio,
        "casillas": {}, "capa1": {}, "capa2": {}, "liquidacion": {},
    }
    L = [l.rstrip() for l in text.split("\n")]

    # --- Capa 1: identificativos ---
    for i, l in enumerate(L):
        if l.startswith("DATOS IDENTIFICATIVOS") and i + 2 < len(L):
            m = re.match(r"([A-Z]\d{7,8}|\d{8}[A-Z])\s+(.+?)\s+(Definitivo|Provisional)", L[i + 2])
            if m:
                out["capa1"]["nif"] = m.group(1)
                out["capa1"]["nombre"] = m.group(2).strip()
    if not out["capa1"].get("nif"):
        m = re.search(r"NIF:\s*([A-Z]\d{7,8}|\d{8}[A-Z]).*?Nombre:\s*(.+?)\s*Tipo\s+NIF", text, re.S | re.I)
        if m:
            out["capa1"]["nif"] = m.group(1)
            out["capa1"]["nombre"] = " ".join(m.group(2).split())
    # CNAE 2025 + epígrafe IAE
    m = re.search(r"AE\d+\s+\S+\s+.+?\s+([\d.]+)\s+(\d{4})\s*$", text, re.M)
    if m:
        out["capa1"]["cnae_2025"] = m.group(2)
        out["capa1"]["iae"] = m.group(1)
    elif m := re.search(r"CNAE\s*\(2025\)\s*Actividad Principal\s+(\d{4})", text, re.I):
        out["capa1"]["cnae_2025"] = m.group(1)
    # Caracteres de la declaración (MD2xxxx  000XX  descripción)
    for m in re.finditer(r"MD2\d{4}\s+(\d{5})\s+(.+)", text):
        out["casillas"][m.group(1)] = "X"
        out["capa1"].setdefault("caracteres", []).append((m.group(1), m.group(2).strip()))
    # Estados de cuentas (MD7xxxx  000XX  Balance/PyG/ECPN: Mod ...) → perfil
    for m in re.finditer(r"MD7\d{4}\s+(\d{5})\s+(.+)", text):
        out["casillas"][m.group(1)] = "X"
        out["capa1"].setdefault("estados_cuentas", []).append((m.group(1), m.group(2).strip()))
    cas = out["casillas"]
    out["capa1"]["perfil_estados_cuentas"] = (
        "abreviado" if "00051" in cas or "00054" in cas else
        "pymes" if "00052" in cas or "00055" in cas else
        "normal" if "00050" in cas or "00053" in cas else None)

    # --- Inputs de liquidación ---
    m = re.search(r"VOLUMEN DE OPERACIONES A EFECTOS IVA.*?TRT\d+\s+([\d.]+,\d\d)", text, re.S)
    if m:
        out["liquidacion"]["00255_INCN"] = _num(m.group(1))
    m = re.search(r"M190.*?TOTAL\s+([\d.]+,\d\d)\s+([\d.]+,\d\d)", text, re.S)
    if m:
        out["liquidacion"]["ret_M190"] = _num(m.group(2))
    if re.search(r"Casilla M200\s+00297\s+01785", text):
        mb = re.search(r"Cuenta corriente\s+\d+\s+([\d.]+,\d\d)\s+([\d.]+,\d\d)", text)
        if mb:
            out["liquidacion"]["ret_cuentas_01785"] = _num(mb.group(2))
    m = (re.search(r"CALCULO DE BASES IMPONIBLES NEGATIVAS.*?TOTAL\s+([\d.]+,\d\d)", text, re.S | re.I)
         or re.search(r"Bases Imponibles Negativas.*?TOTAL\s+([\d.]+,\d\d)", text, re.S | re.I))
    if m:
        out["liquidacion"]["BIN_pendiente_total"] = _num(m.group(1))

    # --- Capa 2 ---
    for m in re.finditer(r"MD4\d{4}\s+(\S+)\s+(F[ií]sica|Jur[ií]dica)\s+(.+?)\s+(No|S[ií])\s", text):
        out["capa2"].setdefault("administradores", []).append(
            {"nif": m.group(1), "nombre": m.group(3).strip()})
    for m in re.finditer(r"MD6\d{4}\s+(\S+)\s+(F[ií]sica|Jur[ií]dica)\s+\S+\s+(.+?)\s+\S+\s+([\d.]+,\d\d)\s+([\d.,]+)\s*%", text):
        out["capa2"].setdefault("socios", []).append(
            {"nif": m.group(1), "nombre": m.group(3).strip(), "pct": m.group(5)})
    for m in re.finditer(r"MD0\d{4}\s+(\S+)\s+(.+?)\s+([A-Z]{2})\s*$", text, re.M):
        pais = m.group(3).strip()
        out["capa2"].setdefault("titulares_reales", []).append(
            {"nif": m.group(1), "nombre": m.group(2).strip(), "extra": [pais, pais]})
    nif_pat = r"(?:[A-Z]\d{7,8}[A-Z]?|\d{8}[A-Z])"
    for m in re.finditer(rf"MD8(\d{{4}})\s+({nif_pat})\s+(.+?)\s+(Secretario(?: del Consejo)?|Representante Legal)\s*$",
                         text, re.M | re.I):
        item = {"nif": m.group(2), "nombre": m.group(3).strip()}
        funcion = m.group(4).lower()
        if "secretario" in funcion:
            out["capa2"].setdefault("secretario", []).append(item)
        else:
            out["capa2"].setdefault("representantes", []).append(item)
    # Algunas extracciones de navegador rompen la tabla MD800 en dos líneas:
    # "Función Código NIF Y7727002M" + "MD80002 NOMBRE Representante Legal".
    if "MD800" in text and not out["capa2"].get("representantes") and not out["capa2"].get("secretario"):
        bloque = re.search(
            r"SECRETARIO DEL CONSEJO.*?(?=IDENTIFICACI[ÓO]N DEL TITULAR REAL|PAGOS FRACCIONADOS|$)",
            text,
            re.S | re.I,
        )
        if bloque:
            sec = bloque.group(0)
            nifs = re.findall(r"\b([A-Z]\d{7,8}[A-Z]?|\d{8}[A-Z])\b", sec)
            filas = re.findall(r"MD8(\d{4})\s+(.+?)\s+(Secretario(?: del Consejo)?|Representante Legal)", sec, re.S | re.I)
            for idx, (codigo, nombre, funcion) in enumerate(filas):
                nif = nifs[idx] if idx < len(nifs) else ""
                item = {"nif": nif, "nombre": " ".join(nombre.split())}
                if "secretario" in funcion.lower():
                    out["capa2"].setdefault("secretario", []).append(item)
                else:
                    out["capa2"].setdefault("representantes", []).append(item)
    # En la Consulta AEAT el bloque se titula conjuntamente "Secretario ... y representantes".
    # Caso SUN 2025: la tabla solo trae una fila MD80002 como "Representante Legal", pero OpenWeb exige
    # 152/153 (secretario) si se informa el bloque G. Si no hay secretario explícito, se copia la primera
    # persona MD800 como secretario fallback confirmado por HITL, manteniendo también el representante.
    if (not out["capa2"].get("secretario")
            and out["capa2"].get("representantes")
            and re.search(r"SECRETARIO DEL CONSEJO.*REPRESENTANTES", text, re.I | re.S)):
        sec = dict(out["capa2"]["representantes"][0])
        sec["origen"] = "datos_fiscales_md800_fallback"
        out["capa2"]["secretario"] = [sec]
    return out


def parse(path: str, ejercicio: str = "") -> dict:
    """Lee el PDF y lo parsea. Si no hay texto extraíble (escaneado), devuelve `necesita_ocr=True`."""
    text = _leer_texto(path)
    ocr_local = False
    if len(text.strip()) < _MIN_TEXTO:
        text = _ocr_texto_local(path)
        ocr_local = bool(text.strip())
    if len(text.strip()) < _MIN_TEXTO:
        return {"necesita_ocr": True, "fuente": "datos_fiscales_aeat", "ejercicio": ejercicio,
                "nota": "PDF sin texto (escaneado): enrutar a OCR y reparsear con parse_texto()."}
    out = parse_texto(text, ejercicio=ejercicio)
    if ocr_local:
        out["ocr_local"] = True
    return out


def a_params_motor(parsed: dict) -> dict | None:
    """Mapea la salida de `parse()` a los PARÁMETROS del motor (`dr200.construir_fichero` / `exportar_aeat`):
    `caracteres` {casilla:'1'}, `formales` {administradores/socios/titulares_reales/secretario/representantes}
    e `identificativos`. Probado end-to-end: emite un `.200` con DP200001 (caracteres) + DP200002/002B
    (formales) precargados. Devuelve None si el PDF necesita OCR. Los inputs de liquidación se devuelven aparte
    (no se autofirman: van a confirmación profesional — estado «carga asistida»)."""
    if parsed.get("necesita_ocr"):
        return None
    c1 = parsed.get("capa1", {})
    c2 = parsed.get("capa2", {})

    def _pct(v):
        # El % de participación se lee del PDF como PORCENTAJE ("56,20" = 56,20 %) pero `_socios_campos`
        # (formal200, contrato compartido con el golden) espera FRACCIÓN (0,5620 -> 5620 centésimas, ×10000).
        # Sin el /100 el % se escribe ×100 y la AEAT lo rechaza ("% no puede ser mayor que 100", EMALR3C73x).
        try:
            return float(str(v).replace(".", "").replace(",", ".")) / 100.0
        except (ValueError, AttributeError):
            return None

    caracteres = {cas: "1" for cas, _ in c1.get("caracteres", [])}
    socios = [{"nif": s.get("nif"), "nombre": s.get("nombre"), "porcentaje": _pct(s.get("pct"))}
              for s in c2.get("socios", [])]
    formales = {
        "administradores": c2.get("administradores", []),
        "socios": socios,
        "titulares_reales": [{"nif": t.get("nif"), "nombre": t.get("nombre"), "extra": t.get("extra") or []}
                              for t in c2.get("titulares_reales", [])],
        "secretario": c2.get("secretario", []),
        "representantes": c2.get("representantes", []),
    }
    return {
        "caracteres": caracteres,
        "formales": formales,
        "identificativos": {"nif": c1.get("nif"), "razon_social": c1.get("nombre"),
                            "ejercicio": parsed.get("ejercicio", "")},
        "liquidacion_inputs": parsed.get("liquidacion", {}),   # NO autofirmados: confirmación profesional
    }


if __name__ == "__main__":
    import sys
    import json
    print(json.dumps(parse(sys.argv[1]), ensure_ascii=False, indent=1))
