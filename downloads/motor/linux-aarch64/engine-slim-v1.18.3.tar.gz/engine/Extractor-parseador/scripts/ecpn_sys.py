"""Proyección del ECPN (Estado de Cambios en el Patrimonio Neto, páginas DP200009/010/011 del Modelo 200)
desde el Sumas y Saldos del ejercicio.

El SyS trae el saldo de APERTURA ("Saldo Ant.") y el de CIERRE de cada cuenta, así que el ECPN se proyecta
del PROPIO ejercicio (el año anterior es solo fallback): apertura = saldo de las cuentas de PN al inicio
(= cierre del año previo), cierre = saldo al final. El PN de cierre del ECPN CUADRA con el del balance
(`00185`) por construcción (mismas cuentas de PN, misma convención de signo). NO inventa: si una cuenta de
PN no encaja en ningún componente, AVISA (regla dura 5). Mapeo de casillas idéntico al parser contable 2024.

0 PII: opera sobre códigos PGC y saldos.
"""
import re

import pandas as pd

# Componentes del patrimonio neto por cuenta PGC (3 primeros dígitos del código de 4).
_COMP = {
    "capital": ("100", "101", "102", "103"),
    "prima": ("110",),
    "reservas": ("111", "112", "113", "114", "115", "116", "117", "118", "119", "120", "121"),
    "resultado_prev": ("129",),                       # Resultado del ejercicio (apertura = resultado anterior)
    "ajustes": ("130", "131", "132", "133", "134", "135", "136", "137", "138"),  # ajustes valor + subvenciones
}


def _num(v):
    return float(v) if isinstance(v, (int, float)) else 0.0


def _r2(x):
    return round(float(x), 2)


def componentes(sys_path, sheet="Sumas y Saldos"):
    """{componente: (apertura, cierre)} del PN desde el SyS + lista de cuentas de PN SIN clasificar (aviso)."""
    df = pd.read_excel(sys_path, sheet_name=sheet, header=None, dtype=object)
    op = {k: 0.0 for k in _COMP}
    ci = {k: 0.0 for k in _COMP}
    sin_clasificar = []
    for _, r in df.iterrows():
        c4 = str(r[1]).split(".")[0].strip() if pd.notna(r[1]) else ""
        if not re.match(r"^1\d{3}$", c4):             # cuentas del grupo 1 (PN), código de 4 dígitos
            continue
        c3 = c4[:3]
        ap = -_num(r[3])                              # apertura: 'Saldo Ant.' (crédito negativo -> PN positivo)
        cl = _num(r[7]) - _num(r[6])                  # cierre: 'Haber Actual' - 'Debe Actual'
        for k, prefs in _COMP.items():
            if c3 in prefs:
                op[k] += ap
                ci[k] += cl
                break
        else:
            if re.match(r"^1[0-3]\d$", c3):           # es PN (10x-13x) pero no clasificada -> avisar
                sin_clasificar.append(c4)
    return {k: (_r2(op[k]), _r2(ci[k])) for k in _COMP}, sin_clasificar


def resultado_ejercicio(sys_path, sheet="Sumas y Saldos"):
    """Resultado contable del ejercicio (00500) desde el SyS = Σ(saldo cierre de las cuentas de los grupos 6
    y 7). Ingreso (7xx) = crédito (+); gasto (6xx) = débito (−); su suma (Haber−Debe) es el resultado neto
    (incluye el gasto por IS, cuenta 630)."""
    df = pd.read_excel(sys_path, sheet_name=sheet, header=None, dtype=object)
    total = 0.0
    for _, r in df.iterrows():
        c = str(r[1]).split(".")[0].strip() if pd.notna(r[1]) else ""
        if re.match(r"^[67]\d{3}$", c):
            total += _num(r[7]) - _num(r[6])          # Haber Actual − Debe Actual
    return _r2(total)


# ----- variante DESDE EL CANÓNICO 4d (la lanzadera no tiene el SyS en export-base; el canónico SÍ trae
# Saldo Inicial + Saldo Final por cuenta PGC). Misma convención de signo que el SyS: apertura = −SaldoInicial,
# cierre = −SaldoFinal (PN en crédito → saldo negativo → PN positivo). Mismo mapeo de componentes/casillas.
def componentes_desde_canonico(filas):
    """{componente: (apertura, cierre)} del PN desde el canónico (filas de builder.cargar_canonico:
    {cuenta, sf, si, ...}) + cuentas de PN sin clasificar (aviso)."""
    op = {k: 0.0 for k in _COMP}
    ci = {k: 0.0 for k in _COMP}
    sin_clasificar = []
    for f in filas or []:
        c4 = str(f.get("cuenta") or "").split(".")[0].strip()
        if not re.match(r"^1\d{3}$", c4):
            continue
        c3 = c4[:3]
        ap = -_num(f.get("si"))                         # apertura = −Saldo Inicial
        cl = -_num(f.get("sf"))                         # cierre   = −Saldo Final
        for k, prefs in _COMP.items():
            if c3 in prefs:
                op[k] += ap
                ci[k] += cl
                break
        else:
            if re.match(r"^1[0-3]\d$", c3):
                sin_clasificar.append(c4)
    return {k: (_r2(op[k]), _r2(ci[k])) for k in _COMP}, sin_clasificar


def resultado_ejercicio_canonico(filas):
    """Resultado contable (00500) desde el canónico = Σ(−Saldo Final) de las cuentas de los grupos 6 y 7."""
    total = 0.0
    for f in filas or []:
        c = str(f.get("cuenta") or "").split(".")[0].strip()
        if re.match(r"^[67]\d{3}$", c):
            total += -_num(f.get("sf"))
    return _r2(total)


def proyectar_desde_canonico(filas, resultado=None):
    """Igual que `proyectar` pero desde las filas del canónico 4d (no el SyS). `resultado` = 00500 (si None,
    se deriva de los grupos 6/7 del propio canónico)."""
    comp, sin_clasificar = componentes_desde_canonico(filas)
    resultado = resultado if resultado is not None else resultado_ejercicio_canonico(filas)
    return _construir_paginas(comp, sin_clasificar, resultado)


def proyectar_desde_balance(comp_apertura, comp_cierre, resultado):
    """Proyecta el ECPN desde los COMPONENTES de PN del balance (no de cuentas PGC en crudo). Es la ruta para
    TB que NO traen saldo de apertura en el propio SyS (p.ej. exports YTD): la APERTURA se toma de la columna
    N-1 del Balance de la CCAA y el CIERRE de la columna N (o del balance ya clasificado por el motor).

    `comp_apertura` / `comp_cierre`: dict {componente: importe} con los 5 componentes de `_COMP`
    (capital, prima, reservas, resultado_prev, ajustes) en convención PN-positiva (capital +, ajustes con su
    signo). El «dividendo a cuenta» y los «resultados de ejercicios anteriores» se PLIEGAN en `reservas` (el
    total de PN cuadra; lo que la AEAT valida con dureza es saldo_final = balance y la consistencia interna).
    `resultado` = resultado del ejercicio (00500, columna N). Reusa `_construir_paginas` (misma matriz que ya
    importa limpia en TB PGC), por lo que NO altera GIP/ARIOSO (rutas distintas). 0 PII."""
    comp = {k: (_r2(comp_apertura.get(k, 0.0)), _r2(comp_cierre.get(k, 0.0))) for k in _COMP}
    return _construir_paginas(comp, [], _r2(resultado))


# ---- Paso del motor: APERTURA del ECPN desde el Balance de la CCAA (columnas N y N-1) ----------------------
# Cuando el SyS NO trae saldo de apertura (export YTD: si=0 en todas las cuentas), el ECPN no se puede proyectar
# del canónico (apertura=0 → la AEAT recalcula y rechaza la hoja). La APERTURA está en la columna N-1 del Balance
# de la CCAA. Este parser lee ese bloque (texto de la CCAA) → componentes de PN por año, plegando dividendo a
# cuenta / resultados de ejercicios anteriores / acciones propias en `reservas` (el TOTAL de PN cuadra, que es
# lo que la AEAT valida con dureza). 0 PII (opera sobre etiquetas e importes en memoria).
# Líneas de DETALLE (subniveles) que NO se suman porque ya están en su subtotal del bloque de PN.
_CCAA_DETALLE = re.compile(r"escriturado|no exigido|cooperativ|legal y estatutarias|otras reservas\b|"
                           r"derivados de cobertura|de capitalizaci", re.I)
# Subtotales del bloque de PN del Balance → componente ECPN (se pliegan dividendo/resultados-anteriores/
# acciones-propias/otras-aportaciones en `reservas`; subvenciones en `ajustes`). Una coincidencia por línea.
_CCAA_PN_LABELS = [
    ("resultado_prev", r"resultado del ejercicio"),                      # antes que 'capital'/'reservas' (excluyente)
    ("capital",        r"^\s*capital\b"),
    ("prima",          r"prima de emisi"),
    ("reservas",       r"^\s*reservas\b|resultados (?:negativos )?(?:de )?ejercicios anteriores|"
                       r"acciones y participaciones en patrimonio propias|(?:otras )?aportaci[oó]n(?:es)? de socios|"
                       r"dividendo a cuenta"),
    ("ajustes",        r"ajustes por cambios de valor|subvenciones, donaciones"),
]


def _ccaa_num(tok):
    t = str(tok).strip()
    if t in ("-", "", "—"):
        return 0.0
    neg = t.startswith("(") and t.endswith(")")
    t = t.strip("()").replace(".", "").replace(",", ".")
    try:
        v = float(t)
    except ValueError:
        return None
    return -v if neg else v


def _ccaa_two_nums(line):
    """Las DOS últimas magnitudes de la línea = columnas (N, N-1) del balance."""
    toks = re.findall(r"\(?-?\d[\d.,]*\)?|—|-(?=\s|$)", line)
    vals = [v for v in (_ccaa_num(t) for t in toks) if v is not None]
    return (vals[-2], vals[-1]) if len(vals) >= 2 else None


def componentes_desde_ccaa_texto(texto):
    """Texto del Balance de la CCAA (con columnas N y N-1) → (comp_apertura, comp_cierre, control). Cada comp es
    {capital,prima,reservas,resultado_prev,ajustes}. `control` trae los TOTALES de PN declarados (para cuadre).
    Devuelve None si no localiza el bloque de PN. NO usa cuentas PGC en crudo (sirve para TB no estándar)."""
    lineas = str(texto or "").splitlines()
    # 1) ACOTAR al bloque de PN del Balance: desde "PATRIMONIO NETO" (no "...Y PASIVO") hasta "PASIVO NO CORRIENTE"
    #    / "TOTAL PATRIMONIO NETO Y PASIVO". Así "Resultado del ejercicio", "Capital"… son inequívocos (1 vez).
    ini = fin = None
    pn_total = (None, None)
    for i, ln in enumerate(lineas):
        low = ln.lower()
        if ini is None and re.search(r"^\s*(?:[a-z]\)\s*)?patrimonio neto\b", low) and "y pasivo" not in low:
            ini = i
            v = _ccaa_two_nums(ln)
            if v:
                pn_total = v
            continue
        if ini is not None and re.search(r"pasivo no corriente|total patrimonio neto y pasivo|total pasivo", low):
            fin = i
            break
    if ini is None:
        return None
    bloque = lineas[ini + 1: fin if fin is not None else ini + 40]
    # 2) Sumar SUBTOTALES del bloque (saltando las líneas de detalle ya incluidas en su subtotal).
    ci = {k: 0.0 for k in _COMP}
    ap = {k: 0.0 for k in _COMP}
    hits = 0
    for ln in bloque:
        if not ln.strip() or _CCAA_DETALLE.search(ln):
            continue
        low = ln.lower()
        for comp, pat in _CCAA_PN_LABELS:
            if re.search(pat, low):
                v = _ccaa_two_nums(ln)
                if v is not None:
                    ci[comp] += v[0]
                    ap[comp] += v[1]
                    hits += 1
                break
    if not hits:
        return None
    return ap, ci, {"pn_total_n": pn_total[0], "pn_total_n1": pn_total[1]}


def proyectar(sys_path, resultado=None, sheet="Sumas y Saldos"):
    """Casillas del ECPN por página {DP200009/010/011: {casilla: valor}} + avisos + control (PN cierre, que
    debe cuadrar con `00185` del balance). `resultado` = resultado del ejercicio (00500); si es None se
    deriva del propio SyS (grupos 6/7)."""
    comp, sin_clasificar = componentes(sys_path, sheet)
    resultado = resultado if resultado is not None else resultado_ejercicio(sys_path, sheet)
    return _construir_paginas(comp, sin_clasificar, resultado)


def _construir_paginas(comp, sin_clasificar, resultado):
    """Páginas DP200009/010/011 del ECPN desde los componentes (apertura, cierre) + el resultado del ejercicio.
    Compartido por `proyectar` (SyS) y `proyectar_desde_canonico` (canónico): la matemática es idéntica."""
    resultado = _r2(resultado)
    capital, capital_prev = comp["capital"][1], comp["capital"][0]
    prima, prima_prev = comp["prima"][1], comp["prima"][0]
    reservas, reservas_prev = comp["reservas"][1], comp["reservas"][0]
    resultado_prev = comp["resultado_prev"][0]        # resultado del ejercicio ANTERIOR (apertura de 129)
    ajustes, ajustes_prev = comp["ajustes"][1], comp["ajustes"][0]
    variacion_ajustes = _r2(ajustes - ajustes_prev)
    patrimonio_prev = _r2(capital_prev + prima_prev + reservas_prev + resultado_prev + ajustes_prev)
    patrimonio = _r2(capital + prima + reservas + resultado + ajustes)
    # Dividendo = resultado anterior NO retenido en reservas (lo demás se distribuye).
    dividendo = _r2(resultado_prev - (reservas - reservas_prev))
    delta_capital = _r2(capital - capital_prev)
    delta_prima = _r2(prima - prima_prev)
    operaciones_socios_total = _r2(-dividendo + delta_capital + delta_prima)

    def neg(x):
        return _r2(-x) if x else x

    paginas = {
        "DP200009": {"00343": variacion_ajustes, "00345": variacion_ajustes,
                     "00355": _r2(resultado + variacion_ajustes)},
        "DP200010": {"00380": capital_prev, "00382": prima_prev, "00383": reservas_prev,
                     "00422": capital_prev, "00424": prima_prev, "00425": reservas_prev,
                     "00506": delta_capital, "00508": delta_prima,
                     "00520": delta_capital if delta_capital > 0 else 0.0,
                     "00522": delta_prima if delta_prima > 0 else 0.0,
                     "00534": delta_capital if delta_capital < 0 else 0.0,
                     "00536": delta_prima if delta_prima < 0 else 0.0,
                     "00509": neg(dividendo), "00565": neg(dividendo),
                     "00621": resultado_prev, "00732": resultado_prev,
                     "00632": capital, "00634": prima, "00635": reservas},
        "DP200011": {"00387": resultado_prev, "00390": ajustes_prev, "00393": patrimonio_prev,
                     "00429": resultado_prev, "00432": ajustes_prev, "00435": patrimonio_prev,
                     "00443": resultado, "00446": variacion_ajustes, "00449": _r2(resultado + variacion_ajustes),
                     "00519": operaciones_socios_total,
                     "00533": _r2(max(delta_capital, 0.0) + max(delta_prima, 0.0)),
                     "00547": _r2(min(delta_capital, 0.0) + min(delta_prima, 0.0)),
                     "00575": neg(dividendo),
                     "00625": neg(resultado_prev), "00736": neg(resultado_prev),
                     "00639": resultado, "00642": ajustes, "00645": patrimonio},
    }
    paginas = {pg: {c: v for c, v in cas.items() if v not in (None, "", 0, 0.0)} for pg, cas in paginas.items()}
    avisos = []
    if sin_clasificar:
        avisos.append(f"ECPN: cuentas de PN sin clasificar (revisar signo/componente): {sin_clasificar}")
    return paginas, avisos, {"patrimonio_cierre": patrimonio, "patrimonio_apertura": patrimonio_prev,
                             "dividendo": dividendo}


def main():   # pragma: no cover
    import sys
    paginas, avisos, ctrl = proyectar(sys.argv[1], float(sys.argv[2]) if len(sys.argv) > 2 else 0.0)
    print("PN cierre:", ctrl["patrimonio_cierre"], "· dividendo:", ctrl["dividendo"])
    for pg, cas in paginas.items():
        print(f"  {pg}: {len(cas)} casillas")
    for a in avisos:
        print("  aviso:", a)


if __name__ == "__main__":
    main()
