"""Parser del formato de sesión de Sociedades WEB / programa OPEN de la AEAT (`.ses`).

El `.ses` que descarga el contribuyente ("guardar sesión") es un fichero **zlib-comprimido** cuyo contenido
es texto PERSISTENCIAV2: una cabecera `<?xml … CodModelo CodModelo EjModelo …?><PERSISTENCIAV2>` seguida de
secciones `[NOMBRE]` y líneas `CLAVE~OCURRENCIA~VALOR`. Las casillas van como claves `T<NNNNN>` (y variantes
`T<NNNNN>_<col>` / con sufijo de letra para campos multi-columna); los identificativos como `T0_NIFCERTIFICADO`,
`T1_NIF`, etc.

Sirve para usar una declaración REAL (2024 o 2025) como oráculo del harness sin disponer del `.200`: se
extrae {casilla: valor} y se compara contra lo que genera el builder. NO contiene PII en este módulo (es
genérico); el `.ses` real del cliente queda fuera de git (igual que `caso_local.json`).
"""
from __future__ import annotations

import re
import zlib

# Clave de casilla: T + 5 dígitos, con sufijo opcional de columna (_<n>) y/o letra (T/B/…) para campos
# multi-columna del DR. Captura la casilla y, si lo hay, el índice de columna.
_CAS_RE = re.compile(r"^T(\d{5})(?:_(\d+))?[A-Z]?$")
# Atributos de la cabecera <?xml … ?> (sello, VersionReglas, CodModelo, EjModelo, …).
_ATTR_RE = re.compile(r'(\w+)="([^"]*)"')


def descomprimir(path) -> str:
    """Lee el `.ses`, lo descomprime (zlib; con fallback a raw-deflate) y lo decodifica en latin1."""
    with open(path, "rb") as fh:
        raw = fh.read()
    try:
        data = zlib.decompress(raw)
    except zlib.error:
        data = zlib.decompress(raw, -zlib.MAX_WBITS)     # raw deflate (sin cabecera); si tb. falla, lanza
    return data.decode("latin1")


def _num(x):
    """Clave de ordenación numérica tolerante (None -> -1, no-numérico -> grande) para ocurrencia/columna."""
    if x is None:
        return -1
    s = str(x)
    return int(s) if s.isdigit() else 10 ** 9


def parse_texto(txt: str) -> dict:
    """Parsea el texto PERSISTENCIAV2 ya descomprimido. Devuelve:
        {
          "meta": {sello, VersionReglas, CodModelo, EjModelo, …},   # cabecera <?xml …?>
          "secciones": ["[DECLARACIONES]", …],
          "casillas": {"00500": [{"occ": "1", "col": None, "valor": "…"}, …], …},  # ocurrencia y columna
          "identificativos": {"T1_NIF": "…", …},                    # claves no-casilla relevantes        # SEPARADAS, sin conflación
          "claves": {clave: {ocurrencia: valor}},                   # crudo, todas las claves
        }

    Ocurrencia (3er campo del triple, registro repetido) y columna (sufijo `_<n>` de la clave, campo
    multi-columna del DR) se guardan por SEPARADO: `T00123_10~1~x` (col 10, occ 1) y `T00123~10~x`
    (occ 10, sin col) ya no colisionan.
    """
    meta = {}
    cab = txt.split("<PERSISTENCIAV2>", 1)
    if cab[0]:
        meta = dict(_ATTR_RE.findall(cab[0]))
    body = cab[1] if len(cab) > 1 else txt

    secciones, claves, casillas, ident = [], {}, {}, {}
    seccion = ""                             # sección PERSISTENCIAV2 vigente ([SOC200], [LIQUIDACION2…], …)
    for linea in body.replace("\r", "").split("\n"):
        s = linea.strip()
        if not s:
            continue
        if re.fullmatch(r"\[.+\]", s):
            secciones.append(s)
            seccion = s.strip("[]")
            continue
        if "~" not in s:
            continue
        partes = s.split("~", 2)
        if len(partes) != 3:
            continue
        clave, occ, valor = partes
        claves.setdefault(clave, {})[occ] = valor
        m = _CAS_RE.match(clave)
        if m:
            cas = m.group(1)
            col = m.group(2)                 # columna del campo multi-columna (None si la clave no la trae)
            casillas.setdefault(cas, []).append({"occ": occ, "col": col, "valor": valor, "seccion": seccion})
        elif clave.startswith("T") and ("NIF" in clave or "VERSION" in clave or "NOMBRE" in clave):
            ident[clave] = valor
    return {"meta": meta, "secciones": secciones, "casillas": casillas,
            "identificativos": ident, "claves": claves}


def parse(path) -> dict:
    """Descomprime y parsea un `.ses`."""
    return parse_texto(descomprimir(path))


def casillas_planas(parsed: dict) -> dict:
    """{casilla: valor} tomando el primer registro (menor ocurrencia, menor columna) de cada casilla — vista
    simple para oráculo. Para casillas multi-columna/multi-ocurrencia usar `parsed['casillas'][cas]` (lista
    de {occ, col, valor})."""
    out = {}
    for cas, recs in parsed.get("casillas", {}).items():
        r = sorted(recs, key=lambda x: (_num(x["occ"]), _num(x["col"])))[0]
        out[cas] = r["valor"]
    return out


def ejercicio(parsed: dict) -> str:
    """Ejercicio del modelo (cabecera EjModelo)."""
    return str(parsed.get("meta", {}).get("EjModelo", "")).strip()


if __name__ == "__main__":   # pragma: no cover
    import sys
    p = parse(sys.argv[1])
    print(f"modelo={p['meta'].get('CodModelo')} ejercicio={ejercicio(p)} "
          f"casillas={len(p['casillas'])} secciones={len(p['secciones'])}")
