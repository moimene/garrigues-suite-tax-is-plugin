#!/usr/bin/env python3
"""Guardrail DR200 Modelo Registro v2 — equivalencia RUNTIME (`dr200.cargar_dr`) ↔ JSON canónico.

Cierra el lazo contra la ESTRUCTURA QUE CONSUME EL MOTOR (`dr200.cargar_dr`), no contra el CSV crudo:
es lo que usan `emitir_registro`, `modelo200_parser` y `validacion_importabilidad_200`.

READ-ONLY: compara y reporta; NO corrige, NO regenera, NO muta ficheros.

Riesgo de nivel superior reconocido (no lo cubre este guardrail): JSON y CSV/runtime pueden coincidir
entre sí y AUN ASÍ compartir una pérdida frente al XLS oficial AEAT (gap documentado 6824 vs 6810/6808).
Se emite como `known_scope_note` (deuda explícita), no como fallo.

Spec v2 (2026-06-28). Uso:
    python3 check_dr200_model_guardrail.py [--ejercicio 2025] [--json <ruta>] [--out-json <ruta>]
    exit 0 si status==ok (p0==0); exit 1 si fail.
"""
from __future__ import annotations

import argparse
import csv
import hashlib
import json
import re
import sys
from pathlib import Path
from typing import Any, Callable

# Constantes críticas de registro: solo `contenido` que afecta a la ESTRUCTURA FÍSICA del .200 (tags/cierres
# y envoltorio DP200000). El resto de `contenido`/`descripcion`/`validacion` es P1 (texto).
CRIT_RE = re.compile(r"</?T200|</?AUX>|DP200000", re.IGNORECASE)
JSON_BY_EJERCICIO = {"2025": "DR200e25_modelo_registro.json"}
# Recuento histórico de la extracción DIRECTA del DR XLS oficial (docs/MODELO200_2025_REGLAS_CAMPOS_IMPORTACION.md;
# NO re-extraído aquí). Sirve para dejar EXPLÍCITA la deuda JSON/CSV ↔ XLS, no para fallar.
XLS_DIRECT_FIELDS_DOCUMENTED = {"2025": 6824}


def _is_num(x: Any) -> bool:
    try:
        int(str(x).strip())
        return True
    except (TypeError, ValueError):
        return False


def _norm(s: Any) -> str:
    return re.sub(r"\s+", " ", str(s or "").strip())


def _sha256(path: str | None) -> str | None:
    try:
        return hashlib.sha256(Path(path).read_bytes()).hexdigest()
    except (OSError, TypeError):
        return None


def _casillas_json(campo: dict) -> list[str]:
    v = campo.get("casillas")
    if isinstance(v, list):
        return sorted({str(x).strip() for x in v if str(x).strip()})
    return sorted({t for t in re.split(r"[;,/\s]+", str(v or "")) if t})


def _casillas_runtime(s: Any) -> list[str]:
    return sorted({t for t in re.split(r"[;,/\s]+", str(s or "")) if t})


def _crit(contenido: Any) -> str:
    c = _norm(contenido)
    return c if CRIT_RE.search(c) else ""


def _docs_dir() -> Path | None:
    """Localiza `docs/info soporte` en el repo (dev) o en el plugin EMPAQUETADO (bajo `engine/`)."""
    here = Path(__file__).resolve()
    for parent in here.parents:
        for rel in (("docs", "info soporte"), ("engine", "docs", "info soporte")):
            cand = parent.joinpath(*rel)
            if cand.is_dir():
                return cand
    return None


def _campo_logica(campo: dict, key: str) -> Any:
    lg = campo.get("logica")
    if isinstance(lg, dict) and key in lg:
        return lg.get(key)
    return campo.get(key)


def _model_from_json(json_path: str) -> tuple[dict, int, list, list]:
    """JSON canónico → {(hoja,num): campo_norm}, total_campos, P1[], P0_estructura[]."""
    data = json.load(open(json_path, encoding="utf-8"))
    hojas = data.get("hojas") or []
    fixed: dict[tuple, dict] = {}
    p1: list[dict] = []
    p0: list[dict] = []
    seen: set[tuple] = set()
    total = 0
    for h in hojas:
        pag = h.get("nombre_hoja") or h.get("pagina") or h.get("nombre")
        for c in (h.get("campos") or []):
            total += 1
            es_fijo = bool(c.get("es_campo_ancho_fijo"))
            num_ok = _is_num(c.get("posicion")) and _is_num(c.get("longitud"))
            if es_fijo and not num_ok:
                p0.append({"severity": "P0", "page": pag, "key": str(c.get("num_campo")),
                           "field": "posicion/longitud",
                           "message": "es_campo_ancho_fijo=true con posicion/longitud no numerica"})
                continue
            if not num_ok:
                continue  # variable / no posicional → fuera de alcance de comparación
            if not es_fijo:
                p1.append({"severity": "P1", "page": pag, "key": str(c.get("num_campo")),
                           "field": "es_campo_ancho_fijo",
                           "message": "posicion/longitud numericos pero es_campo_ancho_fijo=false"})
            key = (pag, str(c.get("num_campo")))
            if key in seen:
                p0.append({"severity": "P0", "page": pag, "key": key[1], "field": "num_campo",
                           "message": "clave (pagina_hoja, num_campo) duplicada en JSON"})
            seen.add(key)
            fixed[key] = {"pos": int(c["posicion"]), "len": int(c["longitud"]),
                          "tipo": _norm(c.get("tipo")), "cas": _casillas_json(c),
                          "crit": _crit(_campo_logica(c, "contenido")),
                          "desc": _norm(c.get("descripcion")), "val": _norm(_campo_logica(c, "validacion"))}
    return fixed, total, p1, p0


def _model_from_runtime(loader: Callable, ejercicio: str) -> tuple[dict, list]:
    """Salida REAL de `cargar_dr` → {(hoja,num): campo_norm}, P0_estructura[]."""
    paginas = loader(ejercicio=ejercicio)
    fixed: dict[tuple, dict] = {}
    p0: list[dict] = []
    seen: set[tuple] = set()
    for pag, campos in paginas.items():
        for c in campos:
            if not (_is_num(c.get("posicion")) and _is_num(c.get("longitud"))):
                continue
            key = (pag, str(c.get("num")))
            if key in seen:
                p0.append({"severity": "P0", "page": pag, "key": key[1], "field": "num_campo",
                           "message": "clave (pagina_hoja, num_campo) duplicada en runtime"})
            seen.add(key)
            fixed[key] = {"pos": int(c["posicion"]), "len": int(c["longitud"]),
                          "tipo": _norm(c.get("tipo")), "cas": _casillas_runtime(c.get("casilla")),
                          "crit": _crit(c.get("contenido")),
                          "desc": _norm(c.get("descripcion")), "val": _norm(c.get("validacion"))}
    return fixed, p0


def analizar(ejercicio: str = "2025", json_path: str | None = None,
             loader: Callable | None = None) -> dict:
    import dr200
    loader = loader or dr200.cargar_dr
    docs = _docs_dir()
    if json_path is None:
        name = JSON_BY_EJERCICIO.get(ejercicio, JSON_BY_EJERCICIO["2025"])
        json_path = str((docs / name)) if docs else name
    csv_path = None
    try:
        csv_path = dr200.path_dr(ejercicio=ejercicio)
    except Exception:   # noqa: BLE001
        csv_path = None

    jfix, jtotal, p1, jp0 = _model_from_json(json_path)
    rfix, rp0 = _model_from_runtime(loader, ejercicio)

    diffs: list[dict] = list(jp0) + list(rp0) + list(p1)
    jk, rk = set(jfix), set(rfix)
    pages_json = {k[0] for k in jk}
    pages_rt = {k[0] for k in rk}
    for pg in sorted(pages_rt - pages_json):
        diffs.append({"severity": "P0", "page": pg, "key": "*", "field": "page",
                      "message": "pagina runtime ausente en JSON"})
    for pg in sorted(pages_json - pages_rt):
        diffs.append({"severity": "P0", "page": pg, "key": "*", "field": "page",
                      "message": "pagina JSON ausente en runtime"})
    for key in sorted(rk - jk):
        diffs.append({"severity": "P0", "page": key[0], "key": key[1], "field": "campo",
                      "message": "campo de ancho fijo runtime ausente en JSON"})
    for key in sorted(jk - rk):
        diffs.append({"severity": "P0", "page": key[0], "key": key[1], "field": "campo",
                      "message": "campo de ancho fijo JSON ausente en runtime"})
    for key in sorted(jk & rk):
        j, r = jfix[key], rfix[key]
        for f, label in (("pos", "posicion"), ("len", "longitud"), ("tipo", "tipo"),
                         ("cas", "casilla"), ("crit", "constante critica")):
            if j[f] != r[f]:
                diffs.append({"severity": "P0", "page": key[0], "key": key[1], "field": label,
                              "json_value": j[f], "runtime_value": r[f],
                              "message": f"{label} distinto runtime vs JSON"})
        for f, label in (("desc", "descripcion"), ("val", "validacion")):
            if j[f] != r[f]:
                diffs.append({"severity": "P1", "page": key[0], "key": key[1], "field": label,
                              "message": f"{label} difiere (texto, no afecta parseo/emision)"})

    p0 = sum(1 for d in diffs if d["severity"] == "P0")
    p1c = sum(1 for d in diffs if d["severity"] == "P1")
    xls_doc = XLS_DIRECT_FIELDS_DOCUMENTED.get(ejercicio)
    return {
        "guardrail": "dr200_modelo_registro_runtime_equivalence",
        "status": "ok" if p0 == 0 else "fail",
        "exercise": ejercicio,
        "sources": {
            "json_model": {"path": json_path, "sha256": _sha256(json_path)},
            "runtime_loader": {"function": "dr200.cargar_dr", "csv_path": csv_path,
                               "csv_sha256": _sha256(csv_path)},
        },
        "counts": {
            "json_fields_total": jtotal,
            "json_fixed_width_fields": len(jfix),
            "runtime_fixed_width_fields": len(rfix),
            "pages_json": len(pages_json),
            "pages_runtime": len(pages_rt),
        },
        "known_scope_note": {
            "xls_direct_fields_documented": xls_doc,            # 6824 total (docs/MODELO200_2025_REGLAS_CAMPOS_IMPORTACION.md; no re-extraído)
            "json_fields_total": jtotal,                        # 6810
            "json_fixed_width_fields": len(jfix),               # 6808
            "gap_total_xls_vs_json": (xls_doc - jtotal) if xls_doc else None,  # ~14, SIN clasificar por ancho-fijo
            "status": "must_be_explained_or_escalated",
            "note": ("Este guardrail demuestra JSON aceptado <-> runtime cargar_dr(); NO demuestra JSON <-> XLS "
                     "oficial AEAT. El gap XLS(6824) <-> JSON no está clasificado por ancho-fijo (≈14-16 campos); "
                     "reconciliar o escalar a un guardrail superior XLS<->JSON."),
        },
        "summary": {"p0": p0, "p1": p1c, "runtime_equivalent_to_json": p0 == 0},
        "diffs": diffs,
    }


def main() -> int:   # pragma: no cover
    ap = argparse.ArgumentParser(description="Guardrail DR200 Modelo Registro v2 (runtime cargar_dr <-> JSON canónico)")
    ap.add_argument("--ejercicio", default="2025")
    ap.add_argument("--json", default=None, help="Ruta del JSON canónico (por defecto, el de la campaña).")
    ap.add_argument("--out-json", default=None)
    args = ap.parse_args()
    report = analizar(ejercicio=args.ejercicio, json_path=args.json)
    txt = json.dumps(report, ensure_ascii=False, indent=2)
    if args.out_json:
        Path(args.out_json).write_text(txt, encoding="utf-8")
    print(txt)
    return 0 if report["summary"]["runtime_equivalent_to_json"] else 1


if __name__ == "__main__":   # pragma: no cover
    raise SystemExit(main())
