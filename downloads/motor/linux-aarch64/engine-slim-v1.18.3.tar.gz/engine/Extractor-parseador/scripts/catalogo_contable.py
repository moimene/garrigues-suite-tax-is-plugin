#!/usr/bin/env python3
"""catalogo_contable.py — Extrae el catálogo de campos contables del Modelo 200 (schema-first).

Fuente oficial: diseño de registro DR200e25.xls (AEAT), páginas contables DP200003-DP200011:
  Balance (págs. 3-6) · Cuenta de PyG (7-8) · Estado de cambios en el PN (9-11).

Cada campo de dato lleva su CASILLA embebida en la descripción como [NNNNN]. El nodo XML del
esquema mod200<ejercicio>.xsd es T+casilla (p.ej. casilla 00103 -> <T00103>), correspondencia
confirmada con la documentación del XSD (T00103=Desarrollo, T00700=Propiedad intelectual).

Salida: data/catalogo_contable_<ejercicio>.json con, por página: bloque, constante de página y la
lista ordenada de campos {casilla, tcode, orden, posicion, longitud, tipo, etiqueta, descripcion}.

Uso: python3 catalogo_contable.py --dr200 <DR200e25.xls> --ejercicio 2025 --out ../data/catalogo_contable_2025.json
"""
from __future__ import annotations
import argparse, json, re
from pathlib import Path

PAGINAS = [f"DP2000{n:02d}" for n in range(3, 12)]  # DP200003..DP200011
BLOQUE = {**{f"Pagina{n:02d}": "Balance" for n in (3, 4, 5, 6)},
          **{f"Pagina{n:02d}": "CuentaPyG" for n in (7, 8)},
          **{f"Pagina{n:02d}": "CambiosPN" for n in (9, 10, 11)}}

CASILLA_RE = re.compile(r"\[(\d{3,5})\]")

def limpiar_etiqueta(desc: str) -> str:
    """'Balance: Activo (I) - Activo - Desarrollo  [00103]' -> 'Desarrollo'."""
    d = CASILLA_RE.sub("", desc).strip()
    if " - " in d:
        d = d.split(" - ")[-1].strip()
    return re.sub(r"\s+", " ", d)

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--dr200", required=True)
    ap.add_argument("--ejercicio", default="2025")
    ap.add_argument("--out", required=True)
    a = ap.parse_args()

    import xlrd
    wb = xlrd.open_workbook(a.dr200)
    paginas, por_casilla = {}, {}
    total_campos = 0

    for nm in PAGINAS:
        if nm not in wb.sheet_names() and nm.strip() not in [s.strip() for s in wb.sheet_names()]:
            continue
        # algunas hojas vienen con espacios en el nombre
        real = next(s for s in wb.sheet_names() if s.strip() == nm)
        s = wb.sheet_by_name(real)
        pag_key = f"Pagina{int(nm[5:]):02d}"
        constante = None
        campos = []
        for r in range(5, s.nrows):
            n = str(s.cell_value(r, 0)).strip()
            tipo = str(s.cell_value(r, 3)).strip()
            desc = str(s.cell_value(r, 4)).strip()
            cont = str(s.cell_value(r, 6)).strip() if s.ncols > 6 else ""
            if "Página" in desc and "0" in cont:
                m = re.search(r"(\d{5})", cont)
                if m:
                    constante = m.group(1)
            m = CASILLA_RE.search(desc)
            if not m:
                continue
            casilla = m.group(1).zfill(5)
            try:
                pos = int(float(s.cell_value(r, 1)))
                lon = int(float(s.cell_value(r, 2)))
            except (ValueError, TypeError):
                pos, lon = None, None
            campo = dict(casilla=casilla, tcode="T" + casilla,
                         orden=int(float(n)) if n.replace(".", "").isdigit() else None,
                         posicion=pos, longitud=lon, tipo=tipo or "N",
                         etiqueta=limpiar_etiqueta(desc), descripcion=re.sub(r"\s+", " ", desc))
            campos.append(campo)
            por_casilla[casilla] = dict(pagina=pag_key, bloque=BLOQUE.get(pag_key), **campo)
        paginas[pag_key] = dict(bloque=BLOQUE.get(pag_key), hoja=real,
                                constante=constante or f"{int(nm[5:]):02d}000", campos=campos)
        total_campos += len(campos)

    catalogo = dict(modelo="200", ejercicio=str(a.ejercicio),
                    fuente=Path(a.dr200).name, total_campos=total_campos,
                    bloques={"Balance": ["Pagina03", "Pagina04", "Pagina05", "Pagina06"],
                             "CuentaPyG": ["Pagina07", "Pagina08"],
                             "CambiosPN": ["Pagina09", "Pagina10", "Pagina11"]},
                    paginas=paginas, por_casilla=por_casilla)
    Path(a.out).parent.mkdir(parents=True, exist_ok=True)
    Path(a.out).write_text(json.dumps(catalogo, ensure_ascii=False, indent=1), encoding="utf-8")
    print(f"OK · {total_campos} campos en {len(paginas)} páginas -> {a.out}")
    for p, v in paginas.items():
        print(f"  {p} [{v['bloque']}] const={v['constante']} · {len(v['campos'])} campos")

if __name__ == "__main__":
    main()
