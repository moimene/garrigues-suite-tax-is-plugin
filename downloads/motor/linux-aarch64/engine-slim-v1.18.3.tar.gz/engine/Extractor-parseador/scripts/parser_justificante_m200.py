"""Parser determinista del JUSTIFICANTE de presentación del Modelo 200 (PDF AEAT) — Nivel B.

Es la fuente del **Nivel B** (ver docs/memoria/2026-06-20-proceso-extraccion-parseo-validacion-fiscal.md):
la declaración del año anterior siempre disponible como justificante PDF. Plantilla fija de Sociedades WEB
(formato formulario). Complementa al Nivel C (datos fiscales digital): aporta lo que el datos-fiscales no
trae, en particular la **fecha de poder y notaría de los representantes** (error de import 153).

Cobertura ROBUSTA (validada en 11 justificantes ARIOSO/HOSPITALITY/RIV-IV): identificativos, grupo/matriz
última, perfil de estados de cuentas, administradores, secretario y representantes (con fecha de poder).
GAP CONOCIDO (best-effort): **titular real (F)**, **socios B.2** y **caracteres** — viven en rejilla de
formulario que se interleava mal en el texto lineal del PDF; para los tres la fuente FIABLE es el
datos-fiscales DIGITAL (Nivel C), que sí los extrae. Si el justificante es la única fuente y se necesitan esos
campos → extracción por TABLA (pdfplumber.extract_tables) o HITL. Si no hay texto (escaneado) → `necesita_ocr=True`.
Sin deps de proyecto. 0 PII.

Uso:  python3 parser_justificante_m200.py <justificante.pdf>
"""
from __future__ import annotations
import re

_MIN_TEXTO = 200
_NIF = r"(?=[A-Z0-9.\-]*\d)[A-Z0-9][A-Z0-9.\-]{6,14}"   # exige ≥1 dígito (evita capturar palabras como 'MARTINEZ')


def _paginas_texto(path):
    import pdfplumber
    with pdfplumber.open(path) as pdf:
        return [(pg.extract_text() or "") for pg in pdf.pages]


def _na(s):
    """Normaliza para comparar: sin acentos ni espacios (robusto a OCR)."""
    return s.translate(str.maketrans("áéíóúÁÉÍÓÚ", "aeiouAEIOU")).replace(" ", "")


def _pagina(paginas, marca):
    """Texto de la primera página cuyo encabezado contiene `marca` (p.ej. 'Página 1 bis')."""
    marca_n = _na(marca)
    for t in paginas:
        if marca_n in _na("\n".join(t.split("\n")[:2])):
            return t
    return ""


def parse(path: str, ejercicio: str = "") -> dict:
    return parse_paginas(_paginas_texto(path), ejercicio=ejercicio)


def parse_paginas(paginas, ejercicio: str = "") -> dict:
    """Núcleo testeable: parsea una lista de textos de página (nativo u OCR)."""
    text = "\n".join(paginas)
    if len(text.strip()) < _MIN_TEXTO:
        return {"necesita_ocr": True, "fuente": "justificante_m200",
                "nota": "Justificante sin texto (escaneado): enrutar a OCR."}
    out = {"necesita_ocr": False, "fuente": "justificante_m200", "ejercicio": ejercicio,
           "capa1": {}, "capa2": {}, "casillas": {}}

    # --- Identificativos (Página 1) ---
    p1 = _pagina(paginas, "Página 1")
    m = re.search(rf"({_NIF})\s+(.+?S\.?L\.?U?\.?|.+?S\.?A\.?U?\.?)\b", p1)
    if m:
        out["capa1"]["nif"] = m.group(1)
        out["capa1"]["nombre"] = m.group(2).strip()
    m = re.search(r"CNAE\s*\(2009\)[^\d]*(\d{4})", p1)
    if m:
        out["capa1"]["cnae"] = m.group(1)
    m = re.search(r"Ejercicio\s*\.*\s*(\d{4})", p1)
    if m:
        out["capa1"]["ejercicio"] = m.group(1)

    # --- Grupo / matriz última + estados de cuentas (Página 1 bis) ---
    p1b = _pagina(paginas, "Página 1 bis")
    m = re.search(r"sociedad matriz última.*?\n\s*NIF\s+Razón social\s*\n\s*(\S+)\s+([^\n]+)", p1b, re.S)
    if m:
        out["capa1"]["matriz_ultima"] = {"nif": m.group(1).strip(), "razon": m.group(2).strip()}
        mp = re.search(r"País de residencia.*?\n\s*([A-ZÁÉÍÓÚÑ ]+?)\s+(\S+)\s*$", p1b, re.M)
        if mp:
            out["capa1"]["matriz_ultima"]["pais"] = mp.group(1).strip()
    # estados de cuentas: marcas X junto a 0005x (balance/PyG) / 0007x (ECPN)
    for cas in re.findall(r"X\s*(0005[0-9]|0007[0-9])", p1b):
        out["casillas"][cas] = "X"
    cas = out["casillas"]
    out["capa1"]["perfil_estados_cuentas"] = (
        "abreviado" if "00051" in cas or "00054" in cas else
        "pymes" if "00052" in cas or "00055" in cas else
        "normal" if "00050" in cas or "00053" in cas else None)

    # --- Capa 2 ---
    p2 = _pagina(paginas, "Página 2")
    p2b = _pagina(paginas, "Página 2 bis")
    # A. Administradores: líneas "NIF F/J Nombre" tras "Relación de administradores"
    if "Relación de administradores" in p2:
        bloque = p2.split("Relación de administradores", 1)[1].split("Participaciones", 1)[0]
        for m in re.finditer(rf"^\s*({_NIF})\s+([FJ])\s+(.+?)\s*$", bloque, re.M):
            out["capa2"].setdefault("administradores", []).append(
                {"nif": m.group(1), "fj": m.group(2), "nombre": m.group(3).strip()})
    # B.2 Socios: línea "NIF J/F/Otra Nombre ... pais nominal %"
    mB2 = re.search(r"B\.2\..*?Apellidos y nombre / Razón social.*?\n(.+?)(?:Suma de porcentajes|\Z)", p2, re.S)
    if mB2:
        for m in re.finditer(rf"^\s*({_NIF})\s+([JFO])\s+(.+?)\s+([A-Z]{{2}})\s+([\d.]+,\d\d)\s+([\d.,]+)\s*$",
                             mB2.group(1), re.M):
            out["capa2"].setdefault("socios", []).append(
                {"nif": m.group(1), "nombre": m.group(3).strip(), "pais": m.group(4),
                 "nominal": m.group(5), "pct": m.group(6)})
    # F. Titular real (Página 2 bis): "1 <NIF> <Nombre> ... <fecha> <pais> <nac>"
    for blk in (p2b, *(t for t in paginas if "titular real" in t.lower())):
        for m in re.finditer(rf"\b1\s+({_NIF})\s+([A-ZÁÉÍÓÚÑ ,\.]+?)\s+(\d{{2}}/\d{{2}}/\d{{4}})\s+([A-ZÁÉÍÓÚÑ ]+?)\s+([A-Z]{{2}})\b", blk):
            t = {"nif": m.group(1), "nombre": m.group(2).strip(), "fecha_nac": m.group(3), "nacionalidad": m.group(5)}
            if t not in out["capa2"].setdefault("titulares_reales", []):
                out["capa2"]["titulares_reales"].append(t)
    # G. Secretario + representantes (con fecha de poder + notaría)
    for blk in (p2b, *(t for t in paginas if "representantes legales" in t.lower())):
        msec = re.search(rf"Secretario del Consejo.*?\n\s*([A-ZÁÉÍÓÚÑ ,\.]+?)\s+({_NIF})\b", blk, re.S)
        if msec and "secretario" not in out["capa2"]:
            out["capa2"]["secretario"] = [{"nombre": msec.group(1).strip(), "nif": msec.group(2)}]
        for m in re.finditer(rf"^\s*([A-ZÁÉÍÓÚÑ ,\.]+?)\s+({_NIF})\s+(\d{{2}}/\d{{2}}/\d{{4}})\s+(.+?)\s*$", blk, re.M):
            rep = {"nombre": m.group(1).strip(), "nif": m.group(2), "fecha_poder": m.group(3), "notario": m.group(4).strip()}
            if rep not in out["capa2"].setdefault("representantes", []):
                out["capa2"]["representantes"].append(rep)
    return out


if __name__ == "__main__":
    import sys
    import json
    print(json.dumps(parse(sys.argv[1]), ensure_ascii=False, indent=1))
