"""Parser row-aware del Cap.04 (estados contables Modelo 200, régimen general páginas 3-11).

Extrae, por casilla: el marcador de modelo {N,A,P} y la fórmula normal embebida (parent=children).
Régimen general SOLO: excluye páginas 27-33 (entidades de crédito, Banco de España) — fuera de alcance (spec §1.3).

Salida: dict por sección (balance_activo / balance_pn_pasivo / pyg / ecpn) con entradas:
  {casilla, label, modelos:set, formula:[hijos], es_resto:bool, linea}

NO escribe artefactos: este módulo solo PARSEA. La derivación de catálogo+rollups la hace el generador.
Determinista, 0 PII (la fuente es el Manual oficial).
"""
from __future__ import annotations

import re
from pathlib import Path

CAP04 = Path(__file__).resolve().parents[2] / "suite-is/Manual_Sociedades_2025_md/04_Cap04_Estados_contables_modelo_200.md"

# Anclas de sección (substrings que aparecen al inicio de cada bloque, en orden de aparición).
SECCIONES = [
    ("balance_activo", "Balance: activo"),
    ("balance_pn_pasivo", "Balance: patrimonio neto y pasivo"),
    ("pyg", "Cuenta de pérdidas y ganancias (páginas 7 y 8)"),
    ("ecpn", "Estado de cambios en el patrimonio neto (páginas 9 a 11)"),
]
# Fin del régimen general: a partir de aquí viene el bloque de entidades de crédito (Banco de España).
FIN_REGIMEN_GENERAL = "Estados contables de las entidades sometidas a las"

CLAVE_RE = re.compile(r"\[(\d{3,5})\]")
# Token de modelo: letra N/A/P AISLADA (bordeada por no-alfanumérico). En estas tablas las mayúsculas N/A/P
# sueltas son SIEMPRE marcadores (los PGC son dígitos; las etiquetas son palabras → 'NECA','NO','ACTIVO' quedan
# descartadas por el lookaround). Tolera marcadores partidos por la clave o por saltos de línea: «(N, [00106]… A, P)».
MARK_TOKEN_RE = re.compile(r"(?<![A-Za-zÁÉÍÓÚÑ0-9])([NAP])(?![A-Za-zÁÉÍÓÚÑ0-9])")

# Líneas de ruido a descartar como continuación (cabeceras, footers, separadores).
RUIDO_SUBSTR = (
    "Manual práctico de Sociedades",
    "Capítulo 4. Estados contables",
    "Régimen general (páginas 3 a 11)",
    "PGC Y PGC PYMES",
    "Equivalencias cuentas",
    "Equivalencia cuentas",
    "Estado de cambios en el",
    "Estado de ingresos y",
    "Estado total de",
    "Cuenta de pérdidas y",
)


def _norm_clave(c: str) -> str:
    return c.zfill(5)


def _es_separador(linea: str) -> bool:
    s = linea.strip().strip("|").strip()
    return bool(s) and set(s) <= set("- :|")


def _es_ruido(linea: str) -> bool:
    if _es_separador(linea):
        return True
    return any(sub in linea for sub in RUIDO_SUBSTR)


def _cargar_lineas() -> list[str]:
    return CAP04.read_text(encoding="utf-8").splitlines()


def _rango_secciones(lineas: list[str]) -> dict[str, tuple[int, int]]:
    # localizar índice de inicio de cada sección y el fin del régimen general
    idx = {}
    for nombre, ancla in SECCIONES:
        for i, ln in enumerate(lineas):
            if ln.strip().startswith(ancla):
                idx[nombre] = i
                break
    fin = next((i for i, ln in enumerate(lineas) if FIN_REGIMEN_GENERAL in ln), len(lineas))
    # construir rangos [inicio, siguiente_inicio)
    orden = [n for n, _ in SECCIONES if n in idx]
    rangos = {}
    for k, nombre in enumerate(orden):
        ini = idx[nombre]
        sig = idx[orden[k + 1]] if k + 1 < len(orden) else fin
        rangos[nombre] = (ini, min(sig, fin))
    return rangos


def _es_continuacion_formula(raw: str) -> bool:
    """True si una línea con clave es CONTINUACIÓN de fórmula/equivalencias (no inicia partida).
    Señales: (a) el texto antes de la 1ª clave termina en '+', ',' o '=' (operando ligado);
    (b) la línea no tiene etiqueta alfabética real (solo claves/operadores/PGC)."""
    m = CLAVE_RE.search(raw)
    if not m:
        return False
    # mirar SOLO la celda inmediatamente anterior a la clave (tras el último '|'): si termina en operador
    # (+ , =) la clave es un operando ligado. NO cruzar el '|' (una etiqueta puede acabar en coma:
    # «Patentes, licencias, | [00105]» NO es continuación de fórmula).
    antes_celda = raw[:m.start()].split("|")[-1].strip()
    if antes_celda.endswith(("+", "=")):   # operador real; NO ',' (aparece en etiquetas y marcadores partidos)
        return True
    # ¿hay etiqueta alfabética (≥3 letras seguidas, ignorando NECA/PGC)? si no, es continuación de fórmula
    sin_neca = re.sub(r"NECA", "", raw)
    if not re.search(r"[A-Za-zÁÉÍÓÚÑáéíóúñ]{3,}", sin_neca):
        return True
    return False


def _modelos_de(texto: str) -> set:
    """Conjunto {N,A,P} por escaneo tolerante de letras-modelo aisladas (soporta marcadores partidos)."""
    sin_claves = CLAVE_RE.sub(" ", texto)  # quitar [NNN] para no confundir
    return {t for t in MARK_TOKEN_RE.findall(sin_claves)}


def _reconstruir_entradas(lineas: list[str], ini: int, fin: int, columnar: bool = False) -> list[dict]:
    """Reconstruye filas lógicas: cada clave-de-registro (1ª clave bare de su línea) + sus continuaciones.
    columnar=True (ECPN págs 10-11, matriz fila×columna): TODAS las claves de la fila son casillas-registro
    y heredan el marcador de la fila (no son operandos de fórmula)."""
    bloque = lineas[ini:fin]
    grupos: list[tuple[int, list[str]]] = []  # (linea_abs, [textos])
    actual: tuple[int, list[str]] | None = None
    for off, raw in enumerate(bloque):
        abs_ln = ini + off
        es_primaria = bool(CLAVE_RE.search(raw)) and not _es_continuacion_formula(raw)
        if es_primaria:
            if actual:
                grupos.append(actual)
            actual = (abs_ln, [raw])
        elif actual and not _es_ruido(raw) and raw.strip():
            actual[1].append(raw)

    if actual:
        grupos.append(actual)

    entradas: list[dict] = []
    for abs_ln, textos in grupos:
        joined = " ".join(textos)
        claves = CLAVE_RE.findall(textos[0])
        if not claves:
            continue
        record = _norm_clave(claves[0])
        todas = [_norm_clave(c) for c in CLAVE_RE.findall(joined)]
        operandos = todas[1:]
        tiene_formula = bool(re.search(r"\[\d{3,5}\]\s*[=+]\s*\[\d{3,5}\]", joined)) or (
            "+" in joined and len(operandos) >= 1 and re.search(r"\]\s*\+\s*\[", joined)
        )
        formula = operandos if tiene_formula else []
        etiqueta = re.sub(r"\[\d{3,5}\]", "", textos[0])
        etiqueta = re.sub(r"[|]", " ", etiqueta)
        etiqueta = re.sub(r"\s+", " ", etiqueta).strip(" -")
        es_resto = bool(re.match(r"^\(?resto", etiqueta.lower()))
        modelos = _modelos_de(joined)
        if columnar:
            # cada clave de la fila es una casilla-registro con el marcador de la fila
            for c in todas:
                entradas.append({"casilla": c, "label": etiqueta[:80], "modelos": set(modelos),
                                 "formula": [], "es_resto": es_resto, "linea": abs_ln + 1})
        else:
            entradas.append({
                "casilla": record,
                "label": etiqueta[:80],
                "modelos": modelos,
                "formula": formula,
                "es_resto": es_resto,
                "linea": abs_ln + 1,
            })
    return entradas


def parse_cap04() -> dict[str, list[dict]]:
    lineas = _cargar_lineas()
    rangos = _rango_secciones(lineas)
    out: dict[str, list[dict]] = {}
    for nombre, (ini, fin) in rangos.items():
        out[nombre] = _reconstruir_entradas(lineas, ini, fin, columnar=(nombre == "ecpn"))
    return out


if __name__ == "__main__":
    import json
    import sys

    data = parse_cap04()
    if "--resumen" in sys.argv:
        for sec, ents in data.items():
            n_only = [e["casilla"] for e in ents if e["modelos"] == {"N"}]
            con_a = [e["casilla"] for e in ents if "A" in e["modelos"]]
            restos = [e["casilla"] for e in ents if e["es_resto"]]
            sin_marca = [e["casilla"] for e in ents if not e["modelos"]]
            print(f"\n=== {sec}: {len(ents)} casillas ===")
            print(f"  N-only ({len(n_only)}): {n_only}")
            print(f"  con A ({len(con_a)}): {con_a}")
            print(f"  RESTO ({len(restos)}): {restos}")
            print(f"  SIN marcador ({len(sin_marca)}): {sin_marca}")
    else:
        ser = {sec: [{**e, "modelos": sorted(e["modelos"])} for e in ents] for sec, ents in data.items()}
        print(json.dumps(ser, ensure_ascii=False, indent=1))
