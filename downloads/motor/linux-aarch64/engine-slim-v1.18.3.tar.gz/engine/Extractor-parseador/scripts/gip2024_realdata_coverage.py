#!/usr/bin/env python3
"""Cobertura de datos reales GIP 2024 contra el .200 presentado.

Este harness no calcula impuesto ni inventa casillas. Hace tres cosas:
1) parsea el .200 real con el DR2024,
2) parsea el .200 generado por Suite IS,
3) busca evidencias de los campos reales en los documentos fuente del expediente.

La salida es un informe local para decidir que fuentes alimentan cada bloque que falta.
"""
import argparse
import csv
import json
import re
import subprocess
import tempfile
from collections import Counter, defaultdict
from pathlib import Path

import pandas as pd

import dr200

NUM_RE = re.compile(r"[-+]?\d{1,3}(?:[.\s]\d{3})*(?:,\d+)?|[-+]?\d+(?:[.,]\d+)?")


def _float_from_any(v):
    if isinstance(v, (int, float)) and not pd.isna(v):
        return float(v)
    s = str(v).strip()
    if not s:
        return None
    s = s.replace("\u00a0", " ").replace(" ", "")
    if "," in s and "." in s:
        s = s.replace(".", "").replace(",", ".")
    elif "," in s:
        s = s.replace(",", ".")
    try:
        return float(s)
    except ValueError:
        return None


def _numeric_candidates(v):
    out = []
    direct = _float_from_any(v)
    if direct is not None:
        out.append(direct)
    for m in NUM_RE.finditer(str(v)):
        x = _float_from_any(m.group(0))
        if x is not None:
            out.append(x)
    # stable, rounded de-dup
    seen = set()
    dedup = []
    for x in out:
        k = round(x, 2)
        if k not in seen:
            seen.add(k)
            dedup.append(x)
    return dedup


def _text_pdf(path: Path) -> str:
    with tempfile.TemporaryDirectory() as td:
        out = Path(td) / "out.txt"
        try:
            subprocess.run(["pdftotext", "-layout", str(path), str(out)],
                           check=True, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
            if out.exists():
                return out.read_text(encoding="utf-8", errors="replace")
        except Exception:
            return ""
    return ""


def build_source_index(sources):
    cells = []
    source_stats = []
    for category, raw_path in sources:
        path = Path(raw_path)
        if path.suffix.lower() in (".xls", ".xlsx"):
            xl = pd.ExcelFile(path)
            nonempty = 0
            for sheet in xl.sheet_names:
                df = pd.read_excel(path, sheet_name=sheet, header=None, dtype=object)
                for r_idx, row in enumerate(df.itertuples(index=False), start=1):
                    for c_idx, val in enumerate(row, start=1):
                        if pd.isna(val):
                            continue
                        nonempty += 1
                        cells.append({
                            "category": category,
                            "file": path.name,
                            "sheet": sheet,
                            "row": r_idx,
                            "col": c_idx,
                            "text": str(val),
                            "nums": _numeric_candidates(val),
                        })
            source_stats.append({"category": category, "file": path.name, "kind": path.suffix.lower(),
                                 "units": nonempty})
        elif path.suffix.lower() == ".pdf":
            text = _text_pdf(path)
            lines = [ln for ln in text.splitlines() if ln.strip()]
            for i, line in enumerate(lines, start=1):
                cells.append({
                    "category": category,
                    "file": path.name,
                    "sheet": "pdf_text",
                    "row": i,
                    "col": 1,
                    "text": line,
                    "nums": _numeric_candidates(line),
                })
            source_stats.append({"category": category, "file": path.name, "kind": ".pdf",
                                 "units": len(lines), "extractable_text": bool(lines)})
        elif path.suffix.lower() in (".txt", ".md"):
            text = path.read_text(encoding="utf-8", errors="replace")
            lines = [ln for ln in text.splitlines() if ln.strip()]
            for i, line in enumerate(lines, start=1):
                cells.append({
                    "category": category,
                    "file": path.name,
                    "sheet": "text",
                    "row": i,
                    "col": 1,
                    "text": line,
                    "nums": _numeric_candidates(line),
                })
            source_stats.append({"category": category, "file": path.name, "kind": path.suffix.lower(),
                                 "units": len(lines), "extractable_text": bool(lines)})
    return cells, source_stats


def records(path: Path, dr):
    tag_to_page = {}
    for page, campos in dr.items():
        line = dr200.emitir_registro(campos)
        m = re.match(r"<(T200[^>]+)>", line)
        if m:
            tag_to_page[m.group(1)] = page
    s = path.read_bytes().decode("latin1", "replace")
    starts = [m.start() for m in re.finditer(r"<T200[^>]+>", s)]
    tag_counts = Counter()
    out = []
    for st in starts[1:]:
        tag = re.match(r"<(T200[^>]+)>", s[st:]).group(1)
        close = s.find(f"</{tag}>", st)
        if close < 0:
            continue
        tag_counts[tag] += 1
        out.append({
            "tag": tag,
            "occ": tag_counts[tag],
            "page": tag_to_page.get(tag),
            "record": s[st:close + len(f"</{tag}>")],
        })
    return out


def _raw(campo, rec):
    pos = campo["posicion"] - 1
    return rec[pos:pos + campo["longitud"]]


def _present(campo, raw):
    if not campo.get("casilla"):
        return False
    tipo = (campo.get("tipo") or "").lower()
    if tipo == "n" or (tipo.startswith("num") and campo["longitud"] == 17):
        return raw and raw != "0" * len(raw)
    if tipo.startswith("num"):
        return raw and raw != "0" * len(raw)
    return bool(raw.strip())


def decode_candidates(campo, raw):
    tipo = (campo.get("tipo") or "").lower()
    length = campo["longitud"]
    out = []
    clean = raw.strip()
    if not clean:
        return out
    if tipo == "n" or (tipo.startswith("num") and length == 17):
        sign = -1 if clean.startswith("N") else 1
        digits = re.sub(r"\D", "", clean)
        if digits:
            out.append(sign * int(digits) / 100.0)
    elif tipo.startswith("num"):
        digits = re.sub(r"\D", "", clean)
        if digits:
            out.append(float(int(digits)))
            if length == 4:
                out.append(float(int(digits)) / 100.0)
    else:
        x = _float_from_any(clean)
        if x is not None:
            out.append(x)
    seen = set()
    dedup = []
    for x in out:
        k = round(x, 2)
        if k not in seen:
            seen.add(k)
            dedup.append(x)
    return dedup


def present_fields(path: Path, dr):
    fields = []
    for rec in records(path, dr):
        page = rec["page"]
        if not page:
            continue
        for campo in dr.get(page, []):
            raw = _raw(campo, rec["record"])
            if _present(campo, raw):
                fields.append({
                    "tag": rec["tag"],
                    "occ": rec["occ"],
                    "page": page,
                    "casilla": campo["casilla"],
                    "posicion": campo["posicion"],
                    "longitud": campo["longitud"],
                    "tipo": campo["tipo"],
                    "raw": raw,
                    "values": decode_candidates(campo, raw),
                    "descripcion": campo["descripcion"],
                })
    return fields


def key(field):
    return (field["tag"], field["occ"], field["casilla"], field["posicion"])


def find_hits(field, cells, max_hits=6):
    hits = []
    values = [v for v in field["values"] if abs(v) >= 10 or field["casilla"] == "00558"]
    text = field["raw"].strip()
    for cell in cells:
        matched = False
        for v in values:
            if any(abs(v - n) <= 0.01 for n in cell["nums"]):
                matched = True
                break
        if not matched and len(text) >= 4 and text in cell["text"]:
            matched = True
        if matched:
            hits.append({k: cell[k] for k in ("category", "file", "sheet", "row", "col")})
        if len(hits) >= max_hits:
            break
    return hits


def write_csv(path, rows, fieldnames):
    with open(path, "w", encoding="utf-8", newline="") as fh:
        w = csv.DictWriter(fh, fieldnames=fieldnames)
        w.writeheader()
        w.writerows(rows)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--real-200", required=True)
    ap.add_argument("--generated-200", required=True)
    ap.add_argument("--out", required=True)
    ap.add_argument("--source", action="append", default=[],
                    help="categoria=/ruta/fichero")
    args = ap.parse_args()

    out = Path(args.out)
    out.mkdir(parents=True, exist_ok=True)
    sources = []
    for item in args.source:
        category, path = item.split("=", 1)
        sources.append((category, path))

    dr = dr200.cargar_dr(ejercicio="2024")
    cells, source_stats = build_source_index(sources)
    real = present_fields(Path(args.real_200), dr)
    gen = present_fields(Path(args.generated_200), dr)
    gen_map = {key(f): f for f in gen}
    real_keys = {key(f) for f in real}

    rows = []
    missing_rows = []
    by_tag = defaultdict(lambda: Counter())
    by_source = Counter()
    for f in real:
        k = key(f)
        hits = find_hits(f, cells)
        cats = sorted({h["category"] for h in hits})
        row = {
            "tag": f["tag"],
            "occ": f["occ"],
            "page": f["page"],
            "casilla": f["casilla"],
            "posicion": f["posicion"],
            "tipo": f["tipo"],
            "generado": "si" if k in gen_map else "no",
            "fuentes": "|".join(cats),
            "num_hits": len(hits),
            "descripcion": f["descripcion"],
            "valor_candidatos": "|".join(str(round(v, 2)) for v in f["values"][:3]),
        }
        rows.append(row)
        by_tag[f["tag"]]["real"] += 1
        if k in gen_map:
            by_tag[f["tag"]]["generado"] += 1
        else:
            by_tag[f["tag"]]["faltante"] += 1
            missing_rows.append(row)
        if cats:
            by_tag[f["tag"]]["con_fuente"] += 1
            for c in cats:
                by_source[c] += 1

    extra = [f for f in gen if key(f) not in real_keys]
    summary = {
        "source_stats": source_stats,
        "real_present_fields": len(real),
        "generated_present_fields": len(gen),
        "missing_from_generated": len(missing_rows),
        "extra_in_generated": len(extra),
        "real_fields_with_source_hit": sum(1 for r in rows if r["num_hits"]),
        "source_hit_counts": dict(by_source),
        "by_tag": {tag: dict(counts) for tag, counts in sorted(by_tag.items())},
    }

    (out / "coverage_summary.json").write_text(json.dumps(summary, ensure_ascii=False, indent=2), encoding="utf-8")
    write_csv(out / "real_present_fields.csv", rows,
              ["tag", "occ", "page", "casilla", "posicion", "tipo", "generado", "fuentes",
               "num_hits", "valor_candidatos", "descripcion"])
    write_csv(out / "missing_from_generated.csv", missing_rows,
              ["tag", "occ", "page", "casilla", "posicion", "tipo", "generado", "fuentes",
               "num_hits", "valor_candidatos", "descripcion"])

    md = [
        "# Cobertura datos reales GIP 2024",
        "",
        "## Resumen",
        "",
        f"- Campos con valor en .200 real: {summary['real_present_fields']}",
        f"- Campos con valor en .200 generado: {summary['generated_present_fields']}",
        f"- Campos del real aun no generados: {summary['missing_from_generated']}",
        f"- Campos reales con evidencia numerica/textual en fuentes: {summary['real_fields_with_source_hit']}",
        "",
        "## Fuentes",
        "",
        "| Categoria | Fichero | Tipo | Unidades leidas | Texto extraible |",
        "|---|---:|---:|---:|---:|",
    ]
    for s in source_stats:
        md.append(f"| {s['category']} | {s['file']} | {s['kind']} | {s['units']} | {s.get('extractable_text', '')} |")
    md += ["", "## Cobertura por registro", "", "| Registro | Real | Generado | Faltante | Con fuente |",
           "|---|---:|---:|---:|---:|"]
    for tag, c in sorted(by_tag.items()):
        md.append(f"| {tag} | {c['real']} | {c['generado']} | {c['faltante']} | {c['con_fuente']} |")
    md += ["", "## Hits por fuente", "", "| Fuente | Campos reales con hit |", "|---|---:|"]
    for src, n in by_source.most_common():
        md.append(f"| {src} | {n} |")
    md += [
        "",
        "## Lectura tecnica",
        "",
        "- `liquidacion` es la fuente principal para liquidacion, deducciones, BINs y limite de gastos financieros.",
        "- `balance_pyg` y `sumas_saldos` explican la mayor parte de balance, PyG y parte del ECPN.",
        "- `datos_fiscales` aporta evidencias fiscales externas, especialmente retenciones/datos AEAT.",
        "- `ccaa_pdf` no tiene capa de texto; `ccaa_ocr` es una fuente derivada por OCR local y requiere tolerancia.",
        "- Los campos sin hit suelen ser flags/formales, opciones de regimen o magnitudes derivadas no impresas como numero exacto.",
        "",
        "## Backlog de cierre",
        "",
        "1. Parser de datos formales: entidad, grupo mercantil, ETVE, empleados, administradores y participaciones.",
        "2. Parser contable ampliado: balance/PyG/ECPN desde `BALANCE Y CPYG` con fallback SyS y OCR CCAA.",
        "3. Parser de liquidacion ampliado: BINs, limite gastos financieros, deducciones DDI, cuota minima y paginas 15/16/20.",
        "4. Parser de datos fiscales AEAT: retenciones, pagos, informacion censal y contraste de modelos origen.",
        "5. Generador .200 completo: emitir paginas vacias/forzadas requeridas por el real y poblar por origen controlado.",
        "6. Validador golden: comparar contra el .200 real por pagina/casilla y bloquear diferencias no justificadas.",
        "",
        "Detalle: `real_present_fields.csv` y `missing_from_generated.csv`.",
    ]
    (out / "COBERTURA_DATOS_REALES_GIP2024.md").write_text("\n".join(md) + "\n", encoding="utf-8")
    print(json.dumps(summary, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
