#!/usr/bin/env python3
"""Reconciliador contable (EPIC B / B3) — cuadres con tolerancia 0 + reconciliación inter-documento.

Identidades que TODO canónico que vaya a firmar el XML debe cumplir (fail-closed aguas arriba):
  - Σdebe = Σhaber                      (cuadre de movimientos)
  - Σsaldos deudores = Σsaldos acreedores  (A = PN + PASIVO a nivel SyS)
  - SI + debe − haber = SF  por línea   (identidad de la cuenta; solo si hay saldo inicial)
  - inter-documento: Σ(Mayor) ≡ Σ(SyS) por familia de cuenta (agrupación simétrica por prefijo, tol 0)

Sin dependencias nuevas. Tolera ambos shapes de fila (builder: sf/si; normalizador: saldo).
"""
from __future__ import annotations

from decimal import Decimal, ROUND_HALF_UP


class CanonicoDescuadradoError(Exception):
    """El canónico no cumple las identidades de cuadre (Σdebe=Σhaber ∧ Σdeudor=Σacreedor, céntimos exactos):
    NO debe firmar el XML mod200 ni emitir los xlsx AEAT. Definida aquí (chokepoint del cuadre) para que
    TODOS los emisores (builder.build, emitir_mod200, pipeline.run) compartan el mismo bloqueo."""

# tol=0 REAL (EPIC B): se comparan CÉNTIMOS exactos (Decimal por valor) -> nada de ruido float ni
# allowlist de 1 céntimo. Un descuadre de ±0,01 bloquea (Codex B3).


def _f(x) -> float:
    try:
        return float(x or 0)
    except (TypeError, ValueError):
        return 0.0


def _c(x) -> Decimal:
    """Importe -> céntimos exactos (Decimal ROUND_HALF_UP a 2 decimales). La suma de Decimals es exacta:
    permite igualdad estricta (tol=0) sin el ruido de acumular floats."""
    return Decimal(str(_f(x))).quantize(Decimal("0.01"), rounding=ROUND_HALF_UP)


def _saldo_final(f: dict) -> Decimal:
    for k in ("sf", "saldo_final", "saldo"):
        if k in f:
            return _c(f.get(k))
    return Decimal("0.00")


def cuadre_debe_haber(canonico) -> dict:
    sd = sum((_c(f.get("debe")) for f in canonico or []), Decimal("0"))
    sh = sum((_c(f.get("haber")) for f in canonico or []), Decimal("0"))
    return {"ok": sd == sh, "suma_debe": float(sd), "suma_haber": float(sh), "delta": float(sd - sh)}


def cuadre_deudor_acreedor(canonico) -> dict:
    sd = sum((sf for sf in (_saldo_final(f) for f in (canonico or [])) if sf > 0), Decimal("0"))
    sa = sum((-sf for sf in (_saldo_final(f) for f in (canonico or [])) if sf < 0), Decimal("0"))
    return {"ok": sd == sa, "saldo_deudor": float(sd), "saldo_acreedor": float(sa), "delta": float(sd - sa)}


def cuadre_saldo_por_linea(canonico) -> dict:
    """SI + debe − haber = SF por cuenta (céntimos exactos). Solo verifica filas que TRAEN saldo inicial
    (si/saldo_inicial): sin SI no se puede comprobar la identidad y NO se marca descuadre (no se inventa)."""
    malas = []
    for f in canonico or []:
        si_val = f.get("si", f.get("saldo_inicial"))
        if si_val is None:        # sin saldo inicial REAL no se comprueba la identidad (None ≠ 0; no se inventa)
            continue
        esperado = _c(si_val) + _c(f.get("debe")) - _c(f.get("haber"))
        sf = _saldo_final(f)
        if esperado != sf:
            malas.append({"cuenta": f.get("cuenta") or f.get("codigo_canonico"),
                          "esperado": float(esperado), "sf": float(sf), "delta": float(esperado - sf)})
    return {"ok": not malas, "descuadradas": malas}


def reconciliar(canonico) -> dict:
    """Agrega los cuadres intrínsecos del canónico (céntimos exactos, tol=0). `ok=False` => NO debe firmar
    el XML (fail-closed).

    El GATE usa las identidades ROBUSTAS de un balance de Sumas y Saldos: Σdebe=Σhaber ∧ Σdeudor=Σacreedor
    (las que un SyS-resumen real cumple — p.ej. GIP). La identidad por línea SI+debe−haber=SF es de MAYOR
    (un SyS-resumen exportado a menudo NO la cumple), así que se REPORTA como aviso informativo, NO bloquea
    (en B5 se aplica como gate específico a los mayores, donde sí debe cumplirse)."""
    dh = cuadre_debe_haber(canonico)
    da = cuadre_deudor_acreedor(canonico)
    sl = cuadre_saldo_por_linea(canonico)
    errores, avisos = [], []
    if not dh["ok"]:
        errores.append(f"Σdebe {dh['suma_debe']} ≠ Σhaber {dh['suma_haber']} (delta {dh['delta']})")
    if not da["ok"]:
        errores.append(f"Σdeudor {da['saldo_deudor']} ≠ Σacreedor {da['saldo_acreedor']} (delta {da['delta']})")
    if not sl["ok"]:
        avisos.append(f"{len(sl['descuadradas'])} cuenta(s) con SI+debe−haber≠SF (identidad de mayor; "
                      "no bloquea un SyS-resumen, sí en B5 sobre mayores)")
    return {"ok": not errores, "errores": errores, "avisos": avisos,
            "debe_haber": dh, "deudor_acreedor": da, "saldo_linea": sl}


def exigir_cuadre(canonico) -> dict:
    """Gate fail-closed: reconcilia y, si NO cuadra, levanta CanonicoDescuadradoError ANTES de cualquier
    emisión (XML/xlsx). Lo usan builder.build y emitir_mod200 como chokepoint único."""
    rec = reconciliar(canonico)
    if not rec["ok"]:
        raise CanonicoDescuadradoError("Canónico descuadrado (no firma): " + "; ".join(rec["errores"]))
    return rec


def cuadre_proyeccion(cuadre) -> tuple:
    """Cuadre de la PROYECCIÓN AEAT (dict de builder.proyectar): un canónico raw-cuadrado puede proyectar
    un BALANCE descuadrado (00180≠00252) -> el número AEAT NO es firmable. El GATE es la identidad del
    balance: `dif=0` al céntimo. `no_map` NO bloquea por sí solo (un SyS real -p.ej. GIP- tiene cuentas
    informativas sin mapear que no rompen el balance; si rompiesen el balance, `dif≠0` ya lo capta) ->
    se devuelve como aviso. Devuelve (ok, errores)."""
    errores = []
    dif = (cuadre or {}).get("dif")
    if dif is not None and _c(dif) != Decimal("0.00"):
        no_map = (cuadre or {}).get("no_map") or []
        msg = f"Balance AEAT descuadrado: 00180−00252 = {dif}"
        if no_map:
            msg += f" ({len(no_map)} cuenta(s) sin mapear: {list(no_map)[:5]})"
        errores.append(msg)
    return (not errores, errores)


def exigir_cuadre_proyeccion(cuadre) -> None:
    """Gate fail-closed POST-proyección: levanta si el balance AEAT proyectado descuadra o hay no_map."""
    ok, errores = cuadre_proyeccion(cuadre)
    if not ok:
        raise CanonicoDescuadradoError("Proyección AEAT no firmable: " + "; ".join(errores))


def _digitos_cuenta(f) -> str:
    """Dígitos de la CUENTA REAL (granularidad nativa del documento); cae a codigo_canonico solo si no hay
    cuenta (p.ej. borrador CCAA sin código)."""
    cod = str(f.get("cuenta") or f.get("codigo_canonico") or "").strip()
    return "".join(ch for ch in cod if ch.isdigit())


def _hojas(rows):
    """Descarta SUBTOTALES/encabezados de UN documento: una fila cuyo código es prefijo ESTRICTO de otra
    fila del MISMO documento es un total de grupo (no una hoja). Contarla doble-contaría su detalle y, si
    vive en el otro lado, actuaría de 'imán' que colapsa cuentas hermanas y enmascararía un mal reparto.
    (Un código de grupo cuyo detalle está SOLO en el otro documento NO tiene hijos aquí → se conserva, y la
    reconciliación compara al nivel común más fino.)"""
    cods = [c for c, _ in rows]
    return [(c, s) for c, s in rows if not any(o != c and o.startswith(c) for o in cods)]


def reconciliar_inter_documento(sys_canonico, mayor_canonico, n_digitos=4) -> dict:
    """Reconcilia el Mayor contra el SyS con AGRUPACIÓN SIMÉTRICA por familia de cuenta (tol=0, cent-exact):

    - Se toma el UNIVERSO de códigos de AMBOS documentos. Cada fila (de cualquier lado) se agrupa por el
      código MÁS CORTO del universo que es su prefijo (su "familia"). Una familia solo se colapsa si un código
      más grueso EXISTE en los datos: así SyS 5700/5701 NO se funden a 570 (no hay 570) y un mal reparto entre
      hermanas se detecta; pero SyS 8d ↔ Mayor 4d (o 3d ↔ 8d) sí reconcilian (la dirección de detalle da igual).
    - Compara Σsaldo(SyS) vs Σsaldo(Mayor) por familia; delta si difieren al céntimo.

    `n_digitos` se mantiene por compatibilidad de firma (la agrupación es por familia real, no por truncado).
    NOTA: el SyS debe ser de HOJA; una fila de subtotal/grupo con código que prefija a su propio detalle
    (p.ej. 570 + 5700 en el mismo documento) se doble-contaría y daría delta (entrada malformada)."""
    sys_rows = _hojas([(c, _saldo_final(f)) for f in (sys_canonico or []) if (c := _digitos_cuenta(f))])
    may_rows = _hojas([(c, _saldo_final(f)) for f in (mayor_canonico or []) if (c := _digitos_cuenta(f))])
    universo = sorted({c for c, _ in sys_rows} | {c for c, _ in may_rows}, key=len)  # asc: el más corto 1º

    def familia(code):
        return next((c for c in universo if code.startswith(c)), code)   # código más corto que lo prefija

    sys_acc, may_acc = {}, {}
    for c, s in sys_rows:
        b = familia(c); sys_acc[b] = sys_acc.get(b, Decimal("0")) + s
    for c, s in may_rows:
        b = familia(c); may_acc[b] = may_acc.get(b, Decimal("0")) + s
    deltas = []
    for cod in sorted(set(sys_acc) | set(may_acc)):
        sy, my = sys_acc.get(cod, Decimal("0")), may_acc.get(cod, Decimal("0"))
        if my != sy:
            deltas.append({"cuenta": cod, "sys": float(sy), "mayor": float(my), "delta": float(my - sy)})
    return {"ok": not deltas, "deltas": deltas}
