#!/usr/bin/env python3
"""Parser estructural del fichero `.200` del Modelo 200.

El `.200` es un stream ISO-8859-1 sin separadores: envoltorio DP200000 + registros de pagina
`<T200xxxxx>... </T200xxxxx>`, cada uno con campos de ancho fijo segun el DR oficial. Este modulo lee el
stream contra `dr200.cargar_dr(...)` y devuelve una estructura PAGE-AWARE. La clave es no aplanar por
casilla: el Modelo 200 reutiliza codigos entre paginas y conceptos distintos.

No contiene reglas fiscales ni intenta "corregir" importes. Solo decodifica el formato fisico.
"""
from __future__ import annotations

import argparse
import json
import re
from collections import Counter
from decimal import Decimal
from pathlib import Path

import dr200

_OPEN_TAG_RE = re.compile(r"<(T200[0-9A-Z]+)>")
_WRAPPER_RE = re.compile(r"^<T200(?P<discriminante>.)(?P<ejercicio>\d{4})(?P<periodo>.{2})(?P<tipo>.{4})>")


def tag_to_page(dr: dict) -> dict:
    """Mapa `{T200xxxxx: DP200xxx}` derivado del propio DR normalizado."""
    out = {}
    for page, campos in dr.items():
        if page == "DP200000":
            continue
        rec = dr200.emitir_registro(campos)
        m = re.match(r"<(T200[^>]+)>", rec)
        if m:
            out[m.group(1)] = page
    return out


def parse_meta(texto: str) -> dict:
    """Metadatos del envoltorio exterior DP200000."""
    m = _WRAPPER_RE.match(texto)
    if not m:
        return {}
    meta = m.groupdict()
    meta["tag"] = m.group(0)[1:-1]
    aux = re.search(r"<AUX>(.*?)</AUX>", texto, flags=re.DOTALL)
    if aux:
        meta["aux_len"] = len(aux.group(1))
        # No se interpreta el AUX aqui: contiene campos EEDD/reservados y puede incluir datos de proveedor.
        meta["has_aux"] = True
    else:
        meta["has_aux"] = False
    return meta


def _is_monetario(campo: dict) -> bool:
    tipo = (campo.get("tipo") or "").strip().lower()
    return tipo == "n" or (tipo.startswith("num") and campo.get("longitud") == 17)


def _is_numeric(campo: dict) -> bool:
    return (campo.get("tipo") or "").strip().lower().startswith("num")


def decode_value(campo: dict, raw: str):
    """Valor legible sin perder el `raw`.

    Monetarios del DR: centimos implicitos y negativo como `N` + digitos. Numericos no monetarios se dejan
    como entero textual; algunos campos de tipo/porcentaje llevan reglas especificas fuera de este parser.
    """
    if _is_monetario(campo):
        digits = re.sub(r"\D", "", raw or "")
        if not digits:
            return "0.00"
        sign = -1 if (raw or "")[:1] in ("N", "-") else 1
        val = (Decimal(sign * int(digits)) / Decimal("100")).quantize(Decimal("0.01"))
        return f"{val:.2f}"
    if _is_numeric(campo):
        digits = re.sub(r"\D", "", raw or "")
        return str(int(digits)) if digits else ""
    return (raw or "").rstrip()


def field_kind(campo: dict) -> str:
    """Clasifica el campo dentro del registro."""
    if dr200.constante(campo) is not None:
        return "constante"
    if campo.get("casilla"):
        return "casilla"
    return "campo_pos"


def has_significant_casilla_value(campo: dict, raw: str) -> bool:
    """Misma semantica que el golden diff: casillas numericas a cero no cuentan como rellenadas."""
    if not campo.get("casilla"):
        return False
    if _is_monetario(campo) or _is_numeric(campo):
        digits = re.sub(r"\D", "", raw or "")
        return bool(digits) and int(digits) != 0
    return bool((raw or "").strip())


def parse_record_fields(record: str, page: str, campos: list[dict]) -> list[dict]:
    """Campos de un registro de pagina, con raw y valor decodificado."""
    out = []
    for campo in campos:
        pos, ln = campo.get("posicion"), campo.get("longitud")
        if not pos or not ln:
            continue
        raw = record[pos - 1:pos - 1 + ln]
        out.append({
            "num": campo.get("num"),
            "posicion": pos,
            "longitud": ln,
            "tipo": campo.get("tipo"),
            "kind": field_kind(campo),
            "casilla": campo.get("casilla") or "",
            "descripcion": campo.get("descripcion") or "",
            "raw": raw,
            "valor": decode_value(campo, raw),
            "raw_not_blank": bool(raw.strip()),
            "significant": has_significant_casilla_value(campo, raw),
            "page": page,
        })
    return out


def records_from_text(texto: str, dr: dict, include_fields: bool = True) -> list[dict]:
    """Registros internos del `.200`, excluyendo el envoltorio DP200000."""
    page_by_tag = tag_to_page(dr)
    counts = Counter()
    out = []
    for m in _OPEN_TAG_RE.finditer(texto):
        tag, start = m.group(1), m.start()
        if tag not in page_by_tag:
            continue
        close = texto.find(f"</{tag}>", start)
        closed = close >= 0
        record = texto[start:close + len(f"</{tag}>")] if closed else texto[start:]
        counts[tag] += 1
        page = page_by_tag[tag]
        entry = {
            "tag": tag,
            "page": page,
            "occ": counts[tag],
            "closed": closed,
            "record_len": len(record),
        }
        if include_fields:
            entry["fields"] = parse_record_fields(record, page, dr.get(page, []))
        out.append(entry)
    return out


def parse_text(texto: str, dr: dict, include_fields: bool = True) -> dict:
    """Parsea texto `.200` ya decodificado."""
    records = records_from_text(texto, dr, include_fields=include_fields)
    return {
        "meta": parse_meta(texto),
        "records": records,
        "summary": {
            "records": len(records),
            "closed_records": sum(1 for r in records if r.get("closed")),
            "pages": sorted({r["page"] for r in records if r.get("page")}),
        },
    }


def parse(path: str | Path, dr: dict | None = None, ejercicio: str | int | None = None,
          include_fields: bool = True) -> dict:
    """Lee un `.200` desde disco y lo parsea contra el DR del ejercicio indicado."""
    path = Path(path)
    texto = path.read_bytes().decode("latin1", "replace")
    if dr is None:
        inferred = parse_meta(texto).get("ejercicio")
        dr = dr200.cargar_dr(ejercicio=str(ejercicio or inferred or "2025"))
    parsed = parse_text(texto, dr, include_fields=include_fields)
    parsed["path"] = str(path)
    return parsed


def casillas_por_pagina(parsed: dict, significant_only: bool = True) -> dict:
    """`{pagina: {casilla: [entradas]}}`, sin conflar homonimos entre paginas."""
    out = {}
    for rec in parsed.get("records", []):
        page, occ = rec.get("page"), rec.get("occ")
        for f in rec.get("fields", []):
            if f.get("kind") != "casilla":
                continue
            if significant_only and not f.get("significant"):
                continue
            out.setdefault(page, {}).setdefault(f["casilla"], []).append({
                "occ": occ,
                "raw": f["raw"],
                "valor": f["valor"],
                "descripcion": f["descripcion"],
                "posicion": f["posicion"],
            })
    return out


def campos_pos_por_pagina(parsed: dict, include_numeric_zero: bool = False) -> dict:
    """Campos no-casilla por numero de campo.

    Por defecto evita inundar con numericos emitidos como ceros por el DR. Para una reemision byte-compatible,
    usar los `fields` crudos de `parsed["records"]`.
    """
    out = {}
    for rec in parsed.get("records", []):
        page = rec.get("page")
        for f in rec.get("fields", []):
            if f.get("kind") != "campo_pos":
                continue
            raw = f.get("raw") or ""
            if not raw.strip():
                continue
            if _is_numeric(f) and not include_numeric_zero and re.sub(r"\D", "", raw) and int(re.sub(r"\D", "", raw)) == 0:
                continue
            out.setdefault(page, {})[str(f["num"])] = {
                "raw": raw,
                "valor": f["valor"],
                "descripcion": f["descripcion"],
            }
    return out


def source_from_200(parsed: dict) -> dict:
    """Salida compatible con el contrato de replay, manteniendo ademas la vista page-aware."""
    cpp = casillas_por_pagina(parsed, significant_only=True)
    flat = {}
    conflicts = []
    for page, casillas in cpp.items():
        for casilla, entries in casillas.items():
            valor = entries[0]["valor"] if entries else ""
            if casilla in flat and flat[casilla] != valor:
                conflicts.append({"casilla": casilla, "kept": flat[casilla], "candidate": valor, "page": page})
                continue
            flat[casilla] = valor
    return {
        "source": "declaracion_previa_200",
        "casillas": flat,
        "casillas_por_pagina": cpp,
        "campos_pos": campos_pos_por_pagina(parsed),
        "meta": {
            "modelo200": parsed.get("meta") or {},
            "records": parsed.get("summary", {}).get("records"),
            "conflicts": conflicts,
        },
    }


def compact_summary(parsed: dict) -> dict:
    """Resumen sin valores de cliente."""
    by_page = {}
    for page, casillas in casillas_por_pagina(parsed).items():
        by_page[page] = sum(len(v) for v in casillas.values())
    return {
        "meta": parsed.get("meta"),
        "records": parsed.get("summary", {}).get("records"),
        "closed_records": parsed.get("summary", {}).get("closed_records"),
        "present_casilla_fields": sum(by_page.values()),
        "present_by_page": dict(sorted(by_page.items())),
    }


def main():  # pragma: no cover
    ap = argparse.ArgumentParser(description="Parsea un fichero .200 del Modelo 200 contra el DR oficial")
    ap.add_argument("path")
    ap.add_argument("--ejercicio")
    ap.add_argument("--out")
    ap.add_argument("--full", action="store_true", help="incluye todos los campos raw del DR en la salida")
    ap.add_argument("--source", action="store_true",
                    help="emite el contrato declaracion_previa_200 con casillas page-aware")
    args = ap.parse_args()
    parsed = parse(args.path, ejercicio=args.ejercicio, include_fields=True)
    if args.source:
        payload = source_from_200(parsed)
    elif args.full:
        payload = parsed
    else:
        payload = compact_summary(parsed)
    text = json.dumps(payload, ensure_ascii=False, indent=2)
    if args.out:
        Path(args.out).write_text(text, encoding="utf-8")
    print(text)


if __name__ == "__main__":
    main()
