"""Resolver de plan de cuentas de GRUPO → PGC (carga asistida) + adaptador de TB a la CSV del motor.

PROBLEMA (limitaciones L1/L2a/L2b, ver docs/memoria/2026-06-20-limitaciones-ingesta-casos-reales-2025.md):
los trial balance de ERP de grupo traen cabeceras en inglés (`Account/Description/Actual YTD` o `Balance`) y
un **plan de cuentas a 4 dígitos propio** que no casa con el PGC por prefijo → el balance no cuadra y el motor
va fail-closed. Este módulo lo resuelve en modo **CARGA ASISTIDA** (interpretación propia autorizada; el
profesional revisa): mapea cada cuenta a PGC por **código → descripción (maestro 904) → fallback por grupo**,
con una **confianza** por cuenta; las de baja confianza se marcan para revisión humana (HITL).

Tres reglas que hacen cuadrar el balance (00180=00252) desde un TB de ERP:
  1. **Resolución a PGC**: código que ya mapea (prefijo cubierto por `mapeo_pgc_aeat.json`) se mantiene; si no,
     match por descripción contra las denominaciones del maestro 904 (exacta → contiene → fuzzy); si no,
     fallback por grupo (1er dígito) con confianza baja.
  2. **Excluir la cuenta de resultado** (129x / «pérdidas y ganancias»): el motor DERIVA el resultado de la
     PyG (grupos 6/7) y lo suma al PN (00199); incluir además 129x lo DUPLICA. Se omite del balance.
  3. **Emitir solo el Saldo Final** (la columna YTD/Balance ya lleva el signo): Debe/Haber vacíos → el cuadre
     Σdebe=Σhaber pasa trivialmente y Σdeudor=Σacreedor sale del saldo con signo.

Validado: **18/18** entidades de la muestra (13 Redevco-ERP + 5 ARIOSO) emiten XML mod200 válido contra XSD.
El resolver es **PRE-MOTOR** (no toca dr200/builder/engines): GIP 2024 intacto. Sin deps de proyecto salvo
python-calamine. 0 PII.

Uso:  python3 resolver_contable_grupo.py <TB.xls[x]> <salida.csv> [ejercicio]
"""
from __future__ import annotations
import csv
import difflib
import json
import re
import unicodedata
from pathlib import Path

_ROOT = Path(__file__).resolve().parents[2]
_MAESTRO_904 = _ROOT / "suite-is" / "rules" / "pgc" / "maestro_pgc.csv"


def _norm(s) -> str:
    s = unicodedata.normalize("NFKD", str(s or "")).encode("ascii", "ignore").decode().lower()
    return re.sub(r"[^a-z0-9 ]", " ", s).strip()


def _num(v):
    if v in (None, ""):
        return None
    if isinstance(v, (int, float)):
        return float(v)
    s = str(v).strip().replace(" ", "").replace("\xa0", "")
    if "," in s and "." in s:
        s = s.replace(".", "").replace(",", ".") if s.rfind(",") > s.rfind(".") else s.replace(",", "")
    elif "," in s:
        s = s.replace(",", ".")
    try:
        return float(s)
    except ValueError:
        return None


def _mapeo_path(ejercicio: str) -> Path:
    return _ROOT / "Extractor-parseador" / "data" / "campaigns" / str(ejercicio) / "mapeo_pgc_aeat.json"


def cargar(ejercicio: str = "2025"):
    """Devuelve (maestro {cod:denom}, prefijos cubiertos por el mapeo, denoms mapeables, fn cubre)."""
    maestro = {}
    with open(_MAESTRO_904, encoding="utf-8-sig") as fh:
        for r in csv.reader(fh, delimiter=";"):
            if len(r) >= 2 and r[0].strip().isdigit():
                maestro[r[0].strip()] = r[1].strip()
    mapeo = json.load(open(_mapeo_path(ejercicio)))
    prefijos = sorted({str(x["prefijo"]) for x in mapeo["reglas"]}, key=len, reverse=True)
    cubre = lambda cod: any(cod.startswith(p) for p in prefijos)
    denoms = [(cod, _norm(den)) for cod, den in maestro.items() if cubre(cod)]
    return maestro, prefijos, denoms, cubre


def resolver(codigo, descripcion, ctx):
    """(codigo_pgc, metodo, confianza) para una cuenta. `ctx` = salida de cargar()."""
    maestro, prefijos, denoms, cubre = ctx
    cod = re.sub(r"\D", "", str(codigo))
    if not cod:
        return None, "sin_codigo", 0.0
    c4 = cod[:4]
    if cubre(c4):                                            # 1) ya mapea por prefijo
        return c4, "codigo", 1.0
    d = _norm(descripcion)
    if d:                                                    # 2) por descripción contra el 904 mapeable
        exact = [c for c, dn in denoms if dn == d]
        if exact:
            return exact[0], "desc_exacta", 0.97
        cont = sorted([(c, dn) for c, dn in denoms if dn and (dn in d or d in dn)],
                      key=lambda x: -len(x[1]))
        if cont:
            return cont[0][0], "desc_contiene", 0.9
        best, bs = None, 0.0
        for c, dn in denoms:
            r = difflib.SequenceMatcher(None, d, dn).ratio()
            if r > bs:
                bs, best = r, c
        if bs >= 0.72:
            return best, "desc_fuzzy", round(bs, 2)
    g = next((c for c, dn in denoms if c.startswith(cod[:1])), None)   # 3) fallback por grupo
    if g:
        return g, "fallback_grupo", 0.3
    return c4, "sin_resolver", 0.0


def adaptar(xlsx_path: str, csv_out: str, ejercicio: str = "2025", lineage_out: str | None = None) -> list:
    """TB de ERP de grupo → CSV que el motor ingesta. Devuelve el lineage (con confianza por cuenta)."""
    from python_calamine import CalamineWorkbook
    ctx = cargar(ejercicio)
    maestro = ctx[0]
    rows = CalamineWorkbook.from_path(xlsx_path).get_sheet_by_index(0).to_python()
    hidx, cmap = None, {}
    for i, row in enumerate(rows[:25]):
        low = [str(c).strip().lower() for c in row]
        if any(c == "account" or c.startswith("cuenta") for c in low) and any("descrip" in c or "description" in c for c in low):
            hidx = i
            for j, c in enumerate(low):
                if (c == "account" or c.startswith("cuenta")) and "cuenta" not in cmap:
                    cmap["cuenta"] = j
                elif ("description" in c or "descrip" in c) and "desc" not in cmap:
                    cmap["desc"] = j
                elif "ytd" in c and "sf" not in cmap:
                    cmap["sf"] = j
                elif c == "balance" and "sf" not in cmap:
                    cmap["sf"] = j
            break
    if hidx is None:
        raise SystemExit("No se detectó la cabecera Account/Description del TB.")
    out, lineage = [], []
    for row in rows[hidx + 1:]:
        def g(k):
            j = cmap.get(k)
            return row[j] if (j is not None and j < len(row)) else None
        raw = str(g("cuenta") or "").strip()
        acc = re.sub(r"\D", "", raw)
        desc = str(g("desc") or "").strip()
        if not acc or raw.lower().startswith("total") or acc == "9999":
            continue
        # Regla 2: la cuenta de resultado NO va al balance (el motor la deriva de la PyG)
        if acc.startswith("129") or re.search(r"perdidas y ganancias|resultado del ejercicio", _norm(desc)):
            continue
        sf = _num(g("sf"))
        cod, met, conf = resolver(acc, desc, ctx)
        # Regla 3: solo Saldo Final (Debe/Haber vacíos)
        out.append([cod, maestro.get(cod, desc), sf if sf is not None else "", "", "", ""])
        lineage.append({"orig": acc, "desc": desc, "pgc": cod, "metodo": met, "confianza": conf})
    with open(csv_out, "w", encoding="utf-8-sig", newline="") as f:
        w = csv.writer(f, delimiter=";")
        w.writerow(["Cuenta", "Descripción", "Saldo Final", "Debe", "Haber", "Saldo Inicial"])
        for r in out:
            w.writerow(r)
    if lineage_out:
        with open(lineage_out, "w", encoding="utf-8-sig", newline="") as f:
            w = csv.writer(f, delimiter=";")
            w.writerow(["cuenta_origen", "descripcion", "pgc_resuelto", "metodo", "confianza", "revisar_HITL"])
            for x in lineage:
                w.writerow([x["orig"], x["desc"], x["pgc"], x["metodo"], x["confianza"],
                            "SÍ" if x["confianza"] < 0.7 else ""])
    return lineage


if __name__ == "__main__":
    import sys
    ej = sys.argv[3] if len(sys.argv) > 3 else "2025"
    lin = adaptar(sys.argv[1], sys.argv[2], ejercicio=ej)
    from collections import Counter
    print("métodos:", dict(Counter(x["metodo"] for x in lin)))
    hitl = [x for x in lin if x["confianza"] < 0.7]
    print(f"cuentas a revisar (HITL, confianza<0.7): {len(hitl)}")
    for x in hitl[:15]:
        print(f"   {x['orig']} '{x['desc'][:30]}' -> {x['pgc']} ({x['metodo']},{x['confianza']})")
