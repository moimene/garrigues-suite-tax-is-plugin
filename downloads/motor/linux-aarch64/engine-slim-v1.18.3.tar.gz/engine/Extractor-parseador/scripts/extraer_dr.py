#!/usr/bin/env python3
"""extraer_dr.py — extractor genérico de Diseños de Registro (DR) oficiales de la AEAT a CSV.

Cada DR de la AEAT (Modelos 200/202/210/216/220/222/232/242/FOV…) es un libro Excel con una hoja por
página del modelo. Cada hoja contiene una tabla campo-a-campo cuya cabecera incluye 'Posic.'/'Lon'/'Tipo'
(la FILA de esa cabecera varía por modelo y por hoja). Este módulo:

  1. abre el libro (.xlsx vía openpyxl, .xls legacy vía xlrd),
  2. detecta la fila de cabecera de CADA hoja,
  3. vuelca todos los campos a un CSV uniforme:
       hoja,num,posicion,longitud,tipo,descripcion,validacion,contenido

NUNCA inventa: copia literalmente lo que dice el DR oficial; las columnas ausentes en un modelo concreto
salen en blanco. Reutiliza el mismo formato que las extracciones ya en repo (p.ej. A202e25_extraccion.csv),
de modo que el resto del ecosistema de modelos quede legible con el mismo esquema.

Uso:
    python3 extraer_dr.py <libro.xlsx|.xls> [salida.csv]
    python3 extraer_dr.py --resumen <libro.xlsx>      # solo cuenta hojas/campos, no escribe
"""
import csv
import os
import sys

# Etiquetas de cabecera del DR -> columna canónica del CSV (match por prefijo en minúsculas).
_COLS = [
    ("num", ("nº", "n°", "num", "n.")),
    ("posicion", ("posic", "posición", "posicion")),
    ("longitud", ("lon", "long")),
    ("tipo", ("tipo",)),
    ("descripcion", ("descrip",)),
    ("validacion", ("valida",)),
    ("contenido", ("conten",)),
]
SALIDA_COLS = ["hoja", "num", "posicion", "longitud", "tipo", "descripcion", "validacion", "contenido"]


def _norm(v) -> str:
    return ("" if v is None else str(v)).replace("\n", " ").strip()


def _filas_xlsx(path):
    import openpyxl
    import warnings
    warnings.filterwarnings("ignore")
    wb = openpyxl.load_workbook(path, read_only=True, data_only=True)
    for hoja in wb.sheetnames:
        ws = wb[hoja]
        filas = [[c for c in row] for row in ws.iter_rows(values_only=True)]
        yield hoja, filas
    wb.close()


def _filas_xls(path):
    import xlrd
    wb = xlrd.open_workbook(path)
    for sh in wb.sheets():
        filas = [[sh.cell_value(r, c) for c in range(sh.ncols)] for r in range(sh.nrows)]
        yield sh.name, filas


def _mapa_cabecera(fila):
    """Dada una fila, devuelve {col_canónica: índice} si parece la cabecera del DR (tiene posic+lon+tipo)."""
    idx = {}
    for j, cel in enumerate(fila):
        et = _norm(cel).lower()
        if not et:
            continue
        for col, prefijos in _COLS:
            if col in idx:
                continue
            if any(et == p or et.startswith(p) for p in prefijos):
                idx[col] = j
                break
    # cabecera válida solo si están las tres columnas estructurales
    if not {"posicion", "longitud", "tipo"} <= set(idx):
        return None
    # Algunas hojas no rotulan 'Nº' (p.ej. DR220 T220000000 trae 'Versión 1.1' donde iría 'Nº'), pero el Nº
    # SÍ está en los datos, en la columna inmediatamente anterior a 'Posic.'. Si no se detectó, se infiere de
    # ahí; _es_dato luego valida que esa columna lleve enteros (si no, la hoja se reporta vacía, no se pierde).
    if "num" not in idx and idx["posicion"] >= 1:
        idx["num"] = idx["posicion"] - 1
    return idx


def _es_dato(fila, idx):
    """Una fila de datos lleva un Nº entero en la columna 'num'."""
    if "num" not in idx or idx["num"] >= len(fila):
        return False
    v = _norm(fila[idx["num"]])
    try:
        int(float(v))
        return True
    except ValueError:
        return False


def _celda(fila, idx, col):
    j = idx.get(col)
    if j is None or j >= len(fila):
        return ""
    v = _norm(fila[col if False else j])
    # los números (num/posicion/longitud) vienen a veces como float "1.0"
    if col in ("num", "posicion", "longitud") and v:
        try:
            return str(int(float(v)))
        except ValueError:
            return v
    return v


def extraer(path, diagnostico=None):
    """Lee el DR y devuelve la lista de filas-dict (una por campo) en orden de hoja y posición.

    Si `diagnostico` es una lista, se le añade el nombre de toda hoja en la que SÍ se detectó cabecera
    (posic/lon/tipo) pero NO se emitió ningún campo: eso delata una pérdida silenciosa de datos (cabecera con
    forma rara) y no debe pasar desapercibida — un CSV incompleto no se presenta como completo (regla dura 5)."""
    ext = os.path.splitext(path)[1].lower()
    gen = _filas_xls(path) if ext == ".xls" else _filas_xlsx(path)
    out = []
    for hoja, filas in gen:
        idx = None
        n_antes = len(out)
        for fila in filas:
            if idx is None:
                idx = _mapa_cabecera(fila)
                continue
            if _es_dato(fila, idx):
                reg = {"hoja": hoja}
                for col in SALIDA_COLS[1:]:
                    reg[col] = _celda(fila, idx, col)
                out.append(reg)
        if idx is not None and len(out) == n_antes and diagnostico is not None:
            diagnostico.append(hoja)   # cabecera detectada pero 0 campos -> sospechoso
    return out


def escribir_csv(registros, salida):
    with open(salida, "w", encoding="utf-8", newline="") as fh:
        w = csv.DictWriter(fh, fieldnames=SALIDA_COLS)
        w.writeheader()
        w.writerows(registros)


def _resumen(registros):
    hojas = {}
    for r in registros:
        hojas[r["hoja"]] = hojas.get(r["hoja"], 0) + 1
    return hojas


if __name__ == "__main__":
    args = [a for a in sys.argv[1:] if not a.startswith("--")]
    solo_resumen = "--resumen" in sys.argv
    if not args:
        print(__doc__)
        sys.exit(2)
    src = args[0]
    sospechosas = []
    regs = extraer(src, diagnostico=sospechosas)
    hojas = _resumen(regs)
    print(f"{os.path.basename(src)}: {len(hojas)} hojas · {len(regs)} campos")
    if sospechosas:
        print(f"  AVISO: {len(sospechosas)} hoja(s) con cabecera pero 0 campos (posible pérdida): {sospechosas}")
    if solo_resumen:
        for h, n in hojas.items():
            print(f"  {h}: {n}")
        sys.exit(0)
    dst = args[1] if len(args) > 1 else os.path.splitext(src)[0] + "_extraccion.csv"
    escribir_csv(regs, dst)
    print(f"  -> {dst}")
