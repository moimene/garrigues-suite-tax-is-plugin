#!/usr/bin/env python3
"""Construye un .200 de replay GIP 2024 desde parsers locales.

No sustituye al endpoint general /exportar-aeat. Es un harness golden para cerrar el caso real GIP 2024.
"""
from __future__ import annotations

import argparse
import datetime
import json
import os
import re
import sys
from decimal import Decimal, InvalidOperation, ROUND_HALF_UP
from pathlib import Path

import caso_local
import dr200
import gip2024_contable_parser as contable_parser
import gip2024_datos_formales_parser as datos_formales
import gip2024_liquidacion_parser as liquidacion_parser
import gip2024_replay_contract as contract
import modelo200_golden
from formal200 import (  # capa COMPARTIDA de datos formales (misma lógica que usa el motor en dr200)
    _a_float, _fecha_aaaammdd, _fj, _grupo21_campos, _iso2_pais, _nombre,  # noqa: F401  (reexport tests/otros)
    _representantes_campos, _socios_campos, _titular_campos,  # noqa: F401
    formal_page_entries as _formal_page_entries,
)


ROOT = Path(__file__).resolve().parents[2]
DEFAULT_REAL = caso_local.path("real_200")
DEFAULT_BASE = ROOT / "engine_service" / "_local_out" / "gip2024_replay" / "declaracion_mod200_2024.200"

PAGINAS_CONTABLE = ["DP200003", "DP200004", "DP200005", "DP200006", "DP200007", "DP200008",
                    "DP200009", "DP200010", "DP200011"]
PAGINAS_LIQUIDACION = ["DP200012", "DP200013", "DP200014", "DP200014B", "DP200015", "DP200015B",
                       "DP200016", "DP200020", "DP200020B", "DP200020D", "DP200026E",
                       "DP200026F", "DP200026G", "DP200DID"]

LIQUIDACION_KEYS = {
    "DP200012": ["00500", "00301", "00501"],
    "DP200013": ["00340", "00386", "00417", "00418"],
    "DP200014": ["00550", "00547", "00552", "01330", "00558", "00562", "00571", "00582"],
    "DP200014B": ["00619", "00592", "00599", "00611", "01586", "00621"],
    "DP200015": ["01045", "01046", "01047", "01519", "01521", "01592", "01594", "01825",
                 "01827", "02193", "02195", "00194", "00196", "00151", "00164", "00009",
                 "00020", "00670", "00547", "00671"],
    "DP200020": ["01245", "01246", "01247", "01248", "01249", "01250", "01251", "02368",
                 "01255", "02369", "01256", "02438", "01214", "01982", "01983", "02258",
                 "02260", "02404", "02406", "01103", "01105", "01398", "01400", "00538",
                 "00539", "00546"],
    "DP200020B": ["02301", "02302", "00417", "00418"],
    "DP200020D": ["00650", "00653", "00654", "01522", "00666"],
    "DP200026E": ["03051"],
    "DP200026F": ["03226"],
    "DP200026G": ["02301", "02302"],
    "DP200DID": ["00552", "00562", "01586", "00621"],
}


def _tag(ejercicio="2024"):
    return f"2000{ejercicio}0A0000"


def _aux(marca="", version="", nif_eedd=""):
    """Bloque `<AUX>` del DP200000 (contenido = 300 chars). Posiciones tomadas de los `.200` reales para
    importación byte-compatible: `marca` (p. ej. 'E') en offset 30; `version` (p. ej. 'F 1.05') alineada al
    FINAL del campo 4 (termina en offset 73; 'F 1.05' empieza en 68 a caballo del reservado); `nif_eedd`
    (NIF Empresa Desarrollo) en el campo 6 (offset 78). Por defecto (todo vacío) va en blanco."""
    c = list(" " * 300)
    for i, ch in enumerate(str(marca)[:40]):
        c[30 + i] = ch
    v = str(version)[:14]
    inicio = max(0, 74 - len(v))                         # versión pegada al final del campo 4 (offset 73)
    for i, ch in enumerate(v):
        c[inicio + i] = ch
    for i, ch in enumerate(str(nif_eedd)[:9]):
        c[78 + i] = ch
    return "<AUX>" + "".join(c) + "</AUX>"


def _wrapper(content, ejercicio="2024", aux_cfg=None):
    tag = _tag(ejercicio)
    a = aux_cfg or {}
    aux = _aux(a.get("marca", ""), a.get("version", ""), a.get("nif_eedd", ""))
    return f"<T{tag}>" + aux + content + f"</T{tag}>"


def _casillas_from_existing_200(path, pages, ejercicio="2024"):
    if not path or not Path(path).exists():
        return {}
    dr = dr200.cargar_dr(ejercicio=ejercicio)
    out = {}
    for field in modelo200_golden.present_fields(path, dr):
        if field["page"] in pages and field["values"]:
            out[field["casilla"]] = field["values"][0]
    return out


def _page_has_casilla(dr, page, casillas):
    wanted = set(casillas)
    return any(c.get("casilla") in wanted for c in dr.get(page, []))


def _only(casillas, keys):
    return {k: casillas[k] for k in keys if k in casillas and casillas[k] not in (None, "")}


def _ident_campos(nif, razon, ejercicio="2024", cuota_00621=None, incn=None):
    campos = {
        7: nif,
        8: razon,
        9: ejercicio,
        11: ejercicio,
        12: "01",
        13: "01",
        14: ejercicio,
        15: "12",
        16: "31",
        17: "1",
    }
    # Campo 6 (pos 13) = Tipo de declaración. En blanco invalida el IBAN del DID (error EMALID32).
    cuota = _a_float(cuota_00621)
    campos[6] = "I" if cuota > 0 else ("D" if cuota < 0 else "N")
    # Tramo de INCN (campos 102/103/104, pos 241/242/243): habilita la cuota líquida mínima 00619
    # (art. 30 bis LIS). Sin marcarlo, la AEAT rechaza 00619 (error E25400619). ≥60M -> 104.
    inc = _a_float(incn)
    if inc >= 60_000_000:
        campos[104] = "1"
    elif inc >= 20_000_000:
        campos[103] = "1"
    return campos


def _did_campos(nif, razon, formales, cuota_00621, ejercicio="2024"):
    bank = (formales.get("cuenta_bancaria") or {})
    iban = str(bank.get("iban", ""))
    cuota = _a_float(cuota_00621)                    # robusto a string europeo / None
    campos = {
        6: "0",                                      # Cuenta corriente tributaria = no (en blanco = inválido)
        7: ejercicio,
        8: "1",
        9: "0A",
        10: "01",
        11: "01",
        12: ejercicio[-2:],
        13: "31",
        14: "12",
        15: ejercicio[-2:],
        16: nif,
        17: razon,
    }
    if cuota > 0:                                    # A INGRESAR -> modalidad/importe/IBAN de INGRESO (33/34/35)
        campos[33] = "I"
        campos[34] = cuota                            # float parseado -> emitir_registro lo codifica a céntimos
        campos[35] = iban
    elif cuota < 0:                                  # A DEVOLVER -> bloque de DEVOLUCIÓN (26/27/29)
        campos[26] = "1" if iban.startswith("ES") else "0"
        campos[27] = iban
        campos[29] = bank.get("banco", "")
    return campos


# _grupo21_campos: movido a formal200 (fuente única, importado arriba) — el replay lo usa sin cambiar su salida.


def _campo_de_casilla(dr, page, casilla):
    """Devuelve el campo del DR para (pagina, casilla), o None si esa casilla no existe en esa página."""
    for c in dr.get(page, []):
        if c.get("casilla") == casilla:
            return c
    return None


def _valor_emitible(campo, valor):
    """(ok, motivo) — comprueba que `valor` se puede emitir en `campo` SIN corromper. Monetario:
    numérico y que quepa en la longitud (céntimos + signo 'N'). Numérico corto: dígitos. An: cualquiera."""
    tipo = (campo.get("tipo") or "").strip().lower()
    longitud = campo.get("longitud") or 0
    if tipo == "n" or (tipo.startswith("num") and longitud == 17):
        try:
            cents = int((Decimal(str(valor)) * 100).to_integral_value(rounding=ROUND_HALF_UP))
        except (InvalidOperation, ValueError, TypeError):
            return False, "valor no numerico"
        max_dig = longitud - 1 if cents < 0 else longitud      # negativo: 'N' + (L-1) dígitos
        if len(str(abs(cents))) > max_dig:
            return False, "valor excede la longitud del campo"
        return True, None
    if tipo.startswith("num"):
        if not (isinstance(valor, (int, float)) or str(valor).strip().isdigit()):
            return False, "valor no numerico"
        return True, None
    return True, None


def aplicar_overrides(dr, overrides):
    """Clasifica datos manuales/proyectados aportados por el abogado (regla: 'inferir, no inventar').

    Cada override = {pagina, casilla, valor, estado, fuente?, regla?} con estado en
    auto/revisar/manual_requerido/bloqueado. Se EMITE solo si: la (pagina, casilla) existe en el DR, tiene
    valor emitible (no corrompe el campo) y NO está 'bloqueado'. Lo demás queda 'pendiente' con su motivo.
    `listo` = no quedan pendientes. Un override "aplicado" garantiza que SÍ se materializará en el `.200`.
    """
    por_pagina, aplicados, pendientes = {}, [], []
    for o in (overrides or []):
        if not isinstance(o, dict):
            pendientes.append({"motivo": "entrada de override no es un objeto", "raw": str(o)[:60]})
            continue
        page = str(o.get("pagina") or "").strip()
        casilla = str(o.get("casilla") or "").strip()
        valor = o.get("valor")
        estado = (o.get("estado") or "manual_requerido").strip()
        info = {"pagina": page, "casilla": casilla, "estado": estado,
                "fuente": o.get("fuente"), "regla": o.get("regla")}
        if estado == "bloqueado":
            pendientes.append({**info, "motivo": "bloqueado"})
            continue
        if valor in (None, ""):
            pendientes.append({**info, "motivo": "sin valor"})
            continue
        if not (page and casilla and dr.get(page)):
            pendientes.append({**info, "motivo": "pagina no valida en el DR"})
            continue
        campo = _campo_de_casilla(dr, page, casilla)
        if campo is None:
            pendientes.append({**info, "motivo": "casilla no existe en la pagina"})
            continue
        ok, motivo = _valor_emitible(campo, valor)
        if not ok:
            pendientes.append({**info, "motivo": motivo})
            continue
        existente = por_pagina.get(page, {}).get(casilla)
        if existente is not None and existente != valor:
            pendientes.append({**info, "motivo": "conflicto: override duplicado con valor distinto"})
            continue
        por_pagina.setdefault(page, {})[casilla] = valor
        if existente is None:
            aplicados.append({**info, "valor": valor})
    return {"por_pagina": por_pagina, "aplicados": aplicados, "pendientes": pendientes,
            "listo": not pendientes}


def _fusionar_overrides(plan, por_pagina):
    """Funde los overrides en el plan de emisión [(pagina, casillas, campos_pos)]: si la página ya está,
    mezcla las casillas (el override gana); si no, añade un registro nuevo para esa página."""
    plan = [list(t) for t in plan]
    paginas = {e[0] for e in plan}
    for page, casillas in por_pagina.items():
        if not casillas:
            continue
        if page in paginas:
            for e in plan:
                if e[0] == page:
                    e[1] = {**(e[1] or {}), **casillas}
                    break
        else:
            plan.append([page, dict(casillas), None])
    return [tuple(e) for e in plan]


def build(nif=None, razon_social=None,
          ejercicio="2024", base_generated=DEFAULT_BASE,
          datos_formales_path=None,
          liquidacion_path=None,
          contable_path=None,
          overrides=None,
          usar_caso_local=True):
    # En campaña (usar_caso_local=False) NO se cae a la config singular de caso_local: cada caso aporta SUS
    # rutas/identidad. Así un caso al que le falte una ruta falla (y se captura) en vez de usar las del GIP
    # singular silenciosamente (state bleed entre casos).
    if usar_caso_local:
        nif = nif or caso_local.nif()
        razon_social = razon_social or caso_local.razon_social()
        # Resolver en tiempo de llamada (no en import) para no arrastrar rutas vacías si caso_local.json
        # se configura después de importar el módulo.
        datos_formales_path = datos_formales_path or caso_local.path("datos_formales")
        liquidacion_path = liquidacion_path or caso_local.path("liquidacion")
        contable_path = contable_path or caso_local.path("balance")
        overrides = overrides if overrides is not None else caso_local.overrides()
    else:
        nif = nif or "B12345678"
        razon_social = razon_social or "EMPRESA DEMO SL"
        datos_formales_path = datos_formales_path or ""
        liquidacion_path = liquidacion_path or ""
        contable_path = contable_path or ""
        overrides = overrides or []
    dr = dr200.cargar_dr(ejercicio=ejercicio)
    formales = datos_formales.parse(datos_formales_path)
    liq = liquidacion_parser.parse(liquidacion_path)
    contable_parsed = contable_parser.parse(contable_path)
    contable_by_page = contable_parser.to_casillas_by_page(contable_parsed)
    contable = contable_parsed.get("casillas") or _casillas_from_existing_200(base_generated, PAGINAS_CONTABLE, ejercicio)
    merged = contract.merge_sources([
        {"source": "contable_base", "priority": 55, "casillas": contable},
        formales,
        liq,
    ])
    cas = merged["casillas"]

    # Overrides ANTES del plan: el bloque de pago del DID depende de 00621, que un override puede cambiar.
    resumen_overrides = aplicar_overrides(dr, overrides)
    ov_casillas = {}
    for _pg, _d in resumen_overrides["por_pagina"].items():
        ov_casillas.update(_d)
    cuota_efectiva = ov_casillas.get("00621", cas.get("00621"))
    # INCN para el tramo (cuota líquida mínima art.30bis): cifra de grupo 00987 (si la hay) o INCN propio
    # 00255. Determina qué tramo (102/103/104) marcar en DP200001 y habilita 00619.
    incn_efectivo = ov_casillas.get("00987") or cas.get("00987") or cas.get("00255")
    # La cuota líquida mínima 00619 solo aplica con INCN >=20M (o grupo). Por debajo, NO debe emitirse
    # (si no, la AEAT la rechaza, error E25400619, al no marcarse tramo INCN).
    if _a_float(incn_efectivo) < 20_000_000:
        cas.pop("00619", None)
    # Aviso si una participada extranjera tiene país sin mapeo ISO2 (saldría país en blanco en DP200021).
    avisos_meta = ((merged.get("meta") or {}).setdefault("warnings", []))
    for _p in (formales.get("participadas") or []):
        _pais = str(_p.get("pais") or "").strip().upper()
        if _p.get("nif") and _pais and _pais not in ("ESPAÑA", "ESPANA") and not _iso2_pais(_pais):
            avisos_meta.append({"source": "datos_formales",
                                "warning": f"participada con país '{_pais}' sin mapeo ISO2; país en blanco en DP200021 (revisar)"})
    # Titular real sin fecha de nacimiento AAAAMMDD válida: _titular_campos omite c149 y el emisor lo
    # rellena a '00000000' (fecha inválida). Avisar en vez de pasarlo en silencio.
    for _t in (formales.get("titulares_reales") or []):
        _ex = _t.get("extra") or []
        _fec = _fecha_aaaammdd(_ex[2]) if len(_ex) >= 3 else ""
        if str(_t.get("nif") or "").strip() and not _fec:
            avisos_meta.append({"source": "datos_formales",
                                "warning": "titular real sin fecha de nacimiento AAAAMMDD válida; "
                                           "el .200 emite '00000000' (revisar)"})
    # Representante sin fecha de poder válida o notario: el importador marca 'representante incompleto'
    # (error 153). DP200002B sólo tiene 3 slots de representante.
    _reps = [r for r in (formales.get("representantes") or []) if str(r.get("nif") or "").strip()]
    if len(_reps) > 3:
        avisos_meta.append({"source": "datos_formales",
                            "warning": f"{len(_reps)} representantes pero DP200002B sólo emite 3 — revisar"})
    for _r in _reps[:3]:
        _rex = _r.get("extra") or []
        _rfec = _fecha_aaaammdd(_rex[0]) if len(_rex) >= 1 else ""
        if not _rfec or len(_rex) < 2 or not str(_rex[1]).strip():
            avisos_meta.append({"source": "datos_formales",
                                "warning": "representante sin fecha de poder AAAAMMDD y/o notario; "
                                           "el importador puede marcarlo incompleto (error 153) — revisar"})

    formal_cas = formales.get("casillas") or {}

    # Plan de emisión: lista ordenada de (pagina, casillas, campos_pos). Mismo orden y contenido que la
    # versión previa cuando NO hay overrides (el golden compara por (tag, occ, casilla, posicion), no por
    # orden de registro), de modo que el replay GIP no se altera.
    plan = [
        ("DP200001", formal_cas, _ident_campos(nif, razon_social, ejercicio, cuota_efectiva, incn_efectivo)),
        ("DP200001B", formal_cas,
         {int(k): v for k, v in formales.get("campos_pos", {}).get("DP200001B", {}).items()}),
    ]
    for entry in _formal_page_entries(formales):
        plan.append((entry["page"], entry.get("casillas") or {}, entry.get("campos_pos")))

    for page in PAGINAS_CONTABLE:
        page_casillas = contable_by_page.get(page) or {}
        if _page_has_casilla(dr, page, page_casillas):
            plan.append((page, page_casillas, None))

    for page in PAGINAS_LIQUIDACION:
        if page == "DP200DID":
            plan.append((page, _only(cas, LIQUIDACION_KEYS[page]),
                         _did_campos(nif, razon_social, formales, cuota_efectiva, ejercicio)))
        elif page == "DP200015B":
            plan.append((page, {}, {45: "25.0000", 101: "25.0000", 162: "25.0000"}))
        elif page == "DP200016":
            plan.append((page, _only(cas, ["02324", "02325", "02326", "02327", "00131", "00132", "00571"]),
                         {61: "25.0000"}))
        else:
            page_casillas = _only(cas, LIQUIDACION_KEYS.get(page, []))
            if _page_has_casilla(dr, page, page_casillas):
                plan.append((page, page_casillas, None))

    plan = _fusionar_overrides(plan, resumen_overrides["por_pagina"])

    # Entidades del grupo en DP200021 (NIF/país de las participadas): la regla las exige si 00987 tiene
    # valor (error EMALP21_4). DP200021 hoy llega por override de casilla (campos_pos=None); le añadimos
    # los campos_pos del grupo.
    g21 = _grupo21_campos(formales)
    if g21:
        for idx, e in enumerate(plan):
            if e[0] == "DP200021":
                plan[idx] = (e[0], e[1], {**(e[2] or {}), **g21})
                break

    # El importador (Sociedades WEB) EXIGE el orden canónico de páginas del DR (error EMALORD si no). Los
    # overrides pueden añadir páginas fuera de orden (p. ej. DP200021); ordenamos por el orden del DR.
    orden_dr = {p: i for i, p in enumerate(dr)}
    plan.sort(key=lambda e: orden_dr.get(e[0], 10 ** 6))

    records = [dr200.emitir_registro(dr[page], casillas=casillas, campos_pos=campos_pos)
               for page, casillas, campos_pos in plan if dr.get(page)]
    doc = _wrapper("".join(records), ejercicio=ejercicio, aux_cfg=caso_local.aux())
    return {
        "doc": doc,
        "merged": merged,
        "overrides": resumen_overrides,
        "inputs": {"datos_formales": formales, "liquidacion": liq, "contable": contable_parsed},
    }


def informe_cierre(res, cmp=None):
    """Estado de cierre para el abogado. NO afirma 'importable' (eso lo confirma el import real en
    Sociedades WEB): informa de cobertura, overrides pendientes y avisos, y si requiere revisión.
    Robusto a `res`/`cmp` parciales o malformados (entradas no-dict se ignoran)."""
    ov = res.get("overrides") or {}
    avisos = [f"[{a.get('source')}] {a.get('warning')}"
              for a in (((res.get("merged") or {}).get("meta") or {}).get("warnings") or [])
              if isinstance(a, dict) and a.get("warning")]
    pendientes = [p for p in (ov.get("pendientes") or []) if isinstance(p, dict)]
    bloqueos = [p for p in pendientes if p.get("motivo") == "bloqueado"]
    correct = cmp.get("correct_fields") if cmp else None
    real = cmp.get("real_present_fields") if cmp else None
    # cobertura incompleta = el generado NO reproduce todas las casillas del real (faltantes O distintas):
    # ambas reducen correct_fields, así que basta comparar correct con real (no solo `different`).
    cobertura_incompleta = bool(cmp) and correct != real
    return {
        "cobertura": (f"{correct}/{real}" if cmp else None),
        "casillas_distintas": (cmp.get("different_common_fields") if cmp else None),
        "overrides_aplicados": len(ov.get("aplicados") or []),
        "overrides_pendientes": len(pendientes),
        "bloqueos": len(bloqueos),
        "avisos": len(avisos),
        "requiere_revision": bool(pendientes or avisos or cobertura_incompleta),
        "detalle": {"pendientes": pendientes, "avisos": avisos,
                    "errores_golden": (modelo200_golden.errores(cmp) if cmp else [])},
    }


def informe_md(inf):
    """Renderiza el informe de cierre en Markdown para el abogado."""
    L = ["# Informe de cierre — replay Modelo 200", ""]
    if inf.get("cobertura"):
        L.append(f"- Cobertura casilla-a-casilla vs `.200` real: **{inf['cobertura']}** "
                 f"(distintas: {inf['casillas_distintas']})")
    L.append(f"- Overrides: {inf['overrides_aplicados']} aplicados · {inf['overrides_pendientes']} "
             f"pendientes ({inf['bloqueos']} bloqueados)")
    L.append(f"- Avisos de extracción: {inf['avisos']}")
    L.append("")
    if inf["requiere_revision"]:
        L.append("> **ACCIÓN: revisión requerida** antes de importar (ver detalle abajo).")
    else:
        L.append("> El harness no detecta pendientes ni avisos. Queda la **compuerta humana**: "
                 "import real en Sociedades WEB (validez definitiva).")
    det = inf["detalle"]
    if det["pendientes"]:
        L += ["", "## Pendientes (datos manuales/proyectados)"]
        L += [f"- {p.get('pagina')}.{p.get('casilla')} — {p.get('motivo')} "
              f"({p.get('estado')}; {p.get('regla') or ''})" for p in det["pendientes"]]
    if det["avisos"]:
        L += ["", "## Avisos de extracción"] + [f"- {a}" for a in det["avisos"]]
    if det["errores_golden"]:
        L += ["", "## Casillas que NO cuadran con el `.200` real"] + [f"- {e}" for e in det["errores_golden"]]
    return "\n".join(L) + "\n"


def _slug_caso(cid, i):
    """ID de caso saneado para usar como nombre de carpeta: sin separadores ni traversal."""
    s = re.sub(r"[^A-Za-z0-9_.-]", "_", str(cid or "")).strip("._")
    return s or f"caso{i}"


def _ejercicio_de_200(path):
    """Lee el ejercicio del envoltorio `<T200 d EJ ...>` de un `.200` real, o None."""
    try:
        head = Path(path).read_bytes()[:16].decode("latin1", "replace")
    except OSError:
        return None
    m = re.match(r"<T200.(\d{4})", head)
    return m.group(1) if m else None


def correr_campana(casos, out_dir):
    """Corre la CAMPAÑA: por cada caso genera su `.200` + `INFORME_CIERRE.md` (y golden si hay `real_200`),
    en `out_dir/<id>/`. Un caso que falle (o su escritura/golden) NO aborta la campaña: se registra su
    error y se sigue. Cada caso aporta SUS rutas (sin caer a la config singular). Devuelve el resumen."""
    out_dir = Path(out_dir).resolve()
    resultados, vistos = [], {}
    for i, caso in enumerate(casos):
        cid = _slug_caso(caso.get("id") if isinstance(caso, dict) else None, i)
        vistos[cid] = vistos.get(cid, -1) + 1
        if vistos[cid]:
            cid = f"{cid}_{vistos[cid]}"          # dedup: ids repetidos no se pisan
        ej = str((caso.get("ejercicio") if isinstance(caso, dict) else None) or "2024")
        try:
            if not isinstance(caso, dict):
                raise ValueError("caso no es un objeto")
            paths = caso.get("paths") or {}
            res = build(nif=caso.get("nif"), razon_social=caso.get("razon_social"), ejercicio=ej,
                        datos_formales_path=(paths.get("datos_formales") or None),
                        liquidacion_path=(paths.get("liquidacion") or None),
                        contable_path=(paths.get("balance") or None),
                        overrides=caso.get("overrides"), usar_caso_local=False)
            cdir = out_dir / cid
            cdir.mkdir(parents=True, exist_ok=True)
            doc_path = cdir / "declaracion.200"
            doc_path.write_bytes(res["doc"].encode("iso-8859-1", "replace"))
            cmp, nota = None, None
            real = paths.get("real_200")
            if real and os.path.exists(real):
                ej_real = _ejercicio_de_200(real)
                if ej_real and ej_real != ej:
                    nota = f"golden omitido: el .200 real es del ejercicio {ej_real}, no {ej}"
                else:
                    cmp = modelo200_golden.compare(real, doc_path, ejercicio=ej)
            inf = informe_cierre(res, cmp)
            (cdir / "INFORME_CIERRE.md").write_text(informe_md(inf), encoding="utf-8")
            fila = {"id": cid, "ejercicio": ej, "cobertura": inf["cobertura"],
                    "requiere_revision": inf["requiere_revision"],
                    "pendientes": inf["overrides_pendientes"], "avisos": inf["avisos"]}
            if nota:
                fila["nota"] = nota
            resultados.append(fila)
        except Exception as e:  # noqa: BLE001 — un caso roto no debe tumbar la campaña
            resultados.append({"id": cid, "ejercicio": ej, "error": f"{type(e).__name__}: {e}"})
    return resultados


def resumen_campana_md(resultados):
    """Resumen de la campaña en Markdown: una fila por caso (cobertura, pendientes, avisos, revisión)."""
    L = ["# Campaña Modelo 200 — resumen", "",
         "| Caso | Ej. | Cobertura | Pendientes | Avisos | Revisión |",
         "|---|---|---|---:|---:|---|"]
    for r in resultados:
        cid, ej = r.get("id", "?"), r.get("ejercicio", "?")
        if r.get("error"):
            L.append(f"| {cid} | {ej} | ERROR | — | — | {r['error']} |")
        else:
            rev = "sí" if r.get("requiere_revision") else "no"
            if r.get("nota"):
                rev += f" ({r['nota']})"
            L.append(f"| {cid} | {ej} | {r.get('cobertura') or '—'} | "
                     f"{r.get('pendientes', '—')} | {r.get('avisos', '—')} | {rev} |")
    return "\n".join(L) + "\n"


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--out", default=str(ROOT / "engine_service" / "_local_out" / "gip2024_replay" / "declaracion_mod200_2024_replay.200"))
    ap.add_argument("--meta-out", default=str(ROOT / "engine_service" / "_local_out" / "gip2024_replay" / "replay_meta.json"))
    ap.add_argument("--base-generated", default=str(DEFAULT_BASE))
    ap.add_argument("--real", default=DEFAULT_REAL)
    ap.add_argument("--ejercicio", default="2024", help="ejercicio de la campaña (2024/2025)")
    ap.add_argument("--campana", action="store_true",
                    help="corre TODOS los casos de caso_local.json (campaña multi-entidad) en vez de uno")
    ap.add_argument("--campana-out", default=str(ROOT / "engine_service" / "_local_out" / "campana"),
                    help="carpeta de salida de la campaña (por defecto bajo _local_out, gitignored)")
    args = ap.parse_args()
    if args.campana:
        camp_dir = Path(args.campana_out)
        resultados = correr_campana(caso_local.casos(), camp_dir)
        camp_dir.mkdir(parents=True, exist_ok=True)
        md = resumen_campana_md(resultados)
        (camp_dir / "CAMPANA.md").write_text(md, encoding="utf-8")
        print(md)
        return
    res = build(ejercicio=args.ejercicio, base_generated=args.base_generated)
    out = Path(args.out)
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_bytes(res["doc"].encode("iso-8859-1", "replace"))
    meta = {k: v for k, v in res.items() if k != "doc"}
    Path(args.meta_out).write_text(json.dumps(meta, ensure_ascii=False, indent=2, default=str), encoding="utf-8")
    cmp = None
    if args.real and os.path.exists(args.real):
        cmp = modelo200_golden.compare(args.real, out, ejercicio=args.ejercicio)
        out.with_suffix(".golden.json").write_text(
            json.dumps(cmp, ensure_ascii=False, indent=2, default=str), encoding="utf-8")
    inf = informe_cierre(res, cmp)
    (out.parent / "INFORME_CIERRE.md").write_text(informe_md(inf), encoding="utf-8")
    print(f"{out}")
    print(f"informe: cobertura={inf['cobertura']} · overrides_pendientes={inf['overrides_pendientes']} "
          f"· avisos={inf['avisos']} · requiere_revision={inf['requiere_revision']}")


if __name__ == "__main__":
    main()
