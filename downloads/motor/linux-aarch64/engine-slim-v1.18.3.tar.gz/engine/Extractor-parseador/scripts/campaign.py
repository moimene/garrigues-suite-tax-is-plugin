#!/usr/bin/env python3
"""campaign.py — Versionado por campaña (ejercicio) del Modelo 200.

La AEAT publica el diseño/esquema CADA EJERCICIO y puede cambiar casillas. Por eso TODO artefacto
dependiente del año vive en data/campaigns/<ejercicio>/ y se resuelve por ejercicio:

  data/campaigns/2024/
    mod2002024.xsd              (XSD oficial AEAT, opcional pero recomendado)
    mod2002024_normal.xsd       (subesquema rama Normal, para validar)
    xsd_campos.json             (casillas importables por página, en orden xs:sequence)
    catalogo_contable.json      (etiquetas del DR200 de ese año; cosmético)
    mapeo_pgc_aeat.json         (PGC -> casilla, específico del año)
    campaign.json               (manifest: fuentes, provisional, fecha, hash XSD)
  data/pgc_maestro.csv          (PGC RD 1514/2007; compartido, salvo override por campaña)

Comandos:
  campaign.py list
  campaign.py resolve   --ejercicio 2024
  campaign.py diff      --a 2024 --b 2025
  campaign.py onboard   --ejercicio 2025 --xsd mod2002025.xsd [--base 2024] [--dr200 DR200e25.xls]

`onboard` parsea el XSD OFICIAL real (lxml) -> xsd_campos + subesquema Normal; copia el mapeo de la
campaña base y emite un informe de diferencias (casillas nuevas sin mapear / casillas que desaparecen
y dejan reglas huérfanas). Así dar de alta un ejercicio nuevo = soltar su XSD y revisar el informe.
"""
from __future__ import annotations
import argparse, hashlib, json, re, shutil
from datetime import date
from pathlib import Path

DATA = Path(__file__).resolve().parent.parent / "data"
CAMPAIGNS = DATA / "campaigns"
BLOQUES_NORMAL = ("Balance", "CuentaPyG", "CambiosPN")

# ----------------------------------------------------------------- parse XSD oficial
def parse_official_xsd(xsd_path: str, rama: str = "Normal") -> dict:
    """Extrae de un mod200<ej>.xsd oficial las casillas por página de una rama (orden xs:sequence)."""
    from lxml import etree
    XS = "{http://www.w3.org/2001/XMLSchema}"
    root = etree.parse(str(xsd_path)).getroot()

    # mapa: nombre de complexType -> [(elem_name, elem_type)] en orden
    ctypes = {}
    for ct in root.findall(f"{XS}complexType"):
        name = ct.get("name")
        if not name:
            continue
        seq = ct.find(f"{XS}sequence")
        elems = []
        if seq is not None:
            for el in seq.findall(f"{XS}element"):
                elems.append((el.get("name"), el.get("type")))
        ctypes[name] = elems

    # raíz MOD200xxxx -> choice -> elemento de la rama -> su tipo
    raiz_el = next((e for e in root.findall(f"{XS}element") if e.get("name", "").startswith("MOD200")), None)
    if raiz_el is None:
        raise SystemExit("No se encontró el elemento raíz MOD200xxxx en el XSD.")
    raiz = raiz_el.get("name")
    choice = raiz_el.find(f"{XS}complexType/{XS}choice")
    rama_type = None
    for el in choice.findall(f"{XS}element"):
        if el.get("name") == rama:
            rama_type = el.get("type")
    if not rama_type:
        raise SystemExit(f"La rama {rama} no existe en el XSD.")

    # tipo_Normal -> Balance/CuentaPyG/CambiosPN -> wrapper type -> PaginaNN -> tipo_PaginaNN
    bloques, paginas = {}, {}
    for bloque_name, wrapper_type in ctypes.get(rama_type, []):
        pages = []
        for pag_name, pag_type in ctypes.get(wrapper_type, []):
            casillas = [n[1:] for (n, _t) in ctypes.get(pag_type, []) if n and re.fullmatch(r"T\d{5}", n)]
            paginas[pag_name] = casillas
            pages.append(pag_name)
        bloques[bloque_name] = pages

    ej = re.sub(r"\D", "", raiz)
    return dict(modelo="200", ejercicio=ej, rama=rama, raiz=raiz,
                fuente=Path(xsd_path).name, bloques=bloques, paginas=paginas,
                total_campos=sum(len(v) for v in paginas.values()))

# ----------------------------------------------------------------- resolver
def resolve(ejercicio, data_dir: Path = DATA) -> dict:
    base = data_dir / "campaigns" / str(ejercicio)
    if not base.exists():
        raise SystemExit(f"Campaña {ejercicio} no existe. Da de alta: "
                         f"python3 campaign.py onboard --ejercicio {ejercicio} --xsd mod200{ejercicio}.xsd --base 2024")
    prov = {}
    def need(name):
        p = base / name
        if not p.exists():
            raise SystemExit(f"Campaña {ejercicio}: falta {name} (re-onboard).")
        return str(p)
    xsd_campos = need("xsd_campos.json")
    mapeo = need("mapeo_pgc_aeat.json")
    # subesquema para validar
    xsd = None
    for cand in (f"mod200{ejercicio}_normal.xsd", f"mod200{ejercicio}.xsd"):
        if (base / cand).exists():
            xsd = str(base / cand); break
    # catálogo (etiquetas): del año o, si falta, el más cercano disponible (cosmético)
    cat = base / "catalogo_contable.json"
    if cat.exists():
        catalogo = str(cat)
    else:
        otros = sorted(data_dir.glob("campaigns/*/catalogo_contable.json"))
        catalogo = str(otros[-1]) if otros else None
        if catalogo:
            prov["catalogo"] = f"etiquetas de {Path(catalogo).parent.name} (no hay del {ejercicio})"
    maestro = base / "pgc_maestro.csv"
    maestro = str(maestro) if maestro.exists() else str(data_dir / "pgc_maestro.csv")
    man = json.load(open(base / "campaign.json", encoding="utf-8")) if (base / "campaign.json").exists() else {}
    prov.update(man.get("provisional", {}))
    return dict(ejercicio=str(ejercicio), dir=str(base), xsd_campos=xsd_campos, mapeo=mapeo,
                xsd=xsd, catalogo=catalogo, maestro=maestro, provisional=prov, manifest=man)

# ----------------------------------------------------------------- listar
def listar(data_dir: Path = DATA) -> list:
    """Campañas dadas de alta (lee cada campaign.json), ordenadas por ejercicio."""
    out = []
    for p in sorted((data_dir / "campaigns").glob("*/campaign.json")):
        try:
            m = json.load(open(p, encoding="utf-8"))
        except Exception:  # noqa: BLE001  campaign.json ilegible en disco -> marcar, NO tumbar el listado
            out.append({"ejercicio": p.parent.name, "total_campos": None, "xsd_fuente": None,
                        "base": None, "fecha": None, "provisional": True, "error": "campaign.json ilegible"})
            continue
        out.append({
            "ejercicio": str(m.get("ejercicio", p.parent.name)),
            "total_campos": m.get("total_campos"),
            "xsd_fuente": m.get("xsd_fuente"),
            "base": m.get("base"),
            "fecha": m.get("fecha"),
            "provisional": bool(m.get("provisional")),   # dict no vacío => provisional (XSD no oficial)
        })
    return out


# ----------------------------------------------------------------- diff
def diff(ej_a, ej_b, data_dir: Path = DATA) -> dict:
    a = json.load(open(resolve(ej_a, data_dir)["xsd_campos"], encoding="utf-8"))["paginas"]
    b = json.load(open(resolve(ej_b, data_dir)["xsd_campos"], encoding="utf-8"))["paginas"]
    out = {}
    for pag in sorted(set(a) | set(b)):
        sa, sb = set(a.get(pag, [])), set(b.get(pag, []))
        if sa != sb:
            out[pag] = dict(nuevas=sorted(sb - sa), eliminadas=sorted(sa - sb))
    return out

# ----------------------------------------------------------------- onboard
def onboard(ejercicio, xsd_path, base=None, dr200=None, data_dir: Path = DATA) -> dict:
    # 0) Validar TODO lo que puede fallar ANTES de tocar el disco (escritura transaccional = no dejar el dir
    #    de la campaña a medias, MED adversarial): parsear el XSD del origen y resolver el mapeo del `base`.
    campos = parse_official_xsd(str(xsd_path))
    bmap = resolve(base, data_dir)["mapeo"] if base else None   # SystemExit si la base no existe -> antes de mkdir
    dst = data_dir / "campaigns" / str(ejercicio)
    dst.mkdir(parents=True, exist_ok=True)
    # 1) XSD oficial -> guardar + campos + subesquema
    shutil.copyfile(xsd_path, dst / f"mod200{ejercicio}.xsd")
    (dst / "xsd_campos.json").write_text(json.dumps(campos, ensure_ascii=False, indent=1), encoding="utf-8")
    _emit_subesquema(campos, dst / f"mod200{ejercicio}_normal.xsd")
    # 2) mapeo: copiar del base (punto de partida) + informe de diferencias
    informe = []
    if base:
        shutil.copyfile(bmap, dst / "mapeo_pgc_aeat.json")
        d = diff(base, ejercicio, data_dir)
        allowed = set(c for v in campos["paginas"].values() for c in v)
        reglas = json.load(open(dst / "mapeo_pgc_aeat.json", encoding="utf-8"))["reglas"]
        huerfanas = sorted({r["casilla"] for r in reglas if r["casilla"] not in allowed})
        informe = [f"# Onboarding campaña {ejercicio} (base {base})", "",
                   f"Casillas importables {ejercicio}: {campos['total_campos']}", ""]
        for pag, ch in d.items():
            if ch["nuevas"]:
                informe.append(f"- {pag}: NUEVAS casillas (revisar si mapear): {', '.join(ch['nuevas'])}")
            if ch["eliminadas"]:
                informe.append(f"- {pag}: ELIMINADas: {', '.join(ch['eliminadas'])}")
        if huerfanas:
            informe += ["", f"⚠️ Reglas del mapeo que apuntan a casillas ya NO importables en {ejercicio}: "
                        + ", ".join(huerfanas), "Remapéalas en mapeo_pgc_aeat.json."]
        else:
            informe += ["", "✅ Todas las reglas del mapeo siguen apuntando a casillas válidas."]
    (dst / "ONBOARDING.md").write_text("\n".join(informe) + "\n" if informe else
                                       f"# Campaña {ejercicio}\nSin base: define mapeo_pgc_aeat.json.\n",
                                       encoding="utf-8")
    if dr200:
        shutil.copyfile(dr200, dst / Path(dr200).name)   # referencia
    # 3) manifest
    h = hashlib.sha256((dst / f"mod200{ejercicio}.xsd").read_bytes()).hexdigest()[:16]
    man = dict(ejercicio=str(ejercicio), fecha=date.today().isoformat(),
               xsd_fuente=Path(xsd_path).name, xsd_sha256_16=h, base=base,
               total_campos=campos["total_campos"], provisional={})
    (dst / "campaign.json").write_text(json.dumps(man, ensure_ascii=False, indent=1), encoding="utf-8")
    return dict(dir=str(dst), campos=campos["total_campos"], informe="\n".join(informe))

def _emit_subesquema(campos, out_path):
    L = ['<?xml version="1.0" encoding="ISO-8859-1"?>',
         '<xs:schema xmlns:xs="http://www.w3.org/2001/XMLSchema" elementFormDefault="qualified" attributeFormDefault="unqualified">',
         '  <xs:simpleType name="tipo_ImpNegativo"><xs:restriction base="xs:decimal">',
         '    <xs:minInclusive value="-9999999999999.99"/><xs:maxInclusive value="9999999999999.99"/>',
         '    <xs:fractionDigits value="2"/></xs:restriction></xs:simpleType>']
    for pag, casillas in campos["paginas"].items():
        L.append(f'  <xs:complexType name="tipo_{pag}"><xs:sequence>')
        L += [f'    <xs:element name="T{c}" type="tipo_ImpNegativo" minOccurs="0"/>' for c in casillas]
        L.append('  </xs:sequence></xs:complexType>')
    wrapper = {"Balance": "tipo_BalanceNormal", "CuentaPyG": "tipo_CuentaNormal", "CambiosPN": "tipo_CambiosPN"}
    for bloque, pags in campos["bloques"].items():
        L.append(f'  <xs:complexType name="{wrapper.get(bloque, "tipo_" + bloque)}"><xs:sequence>')
        L += [f'    <xs:element name="{p}" type="tipo_{p}" minOccurs="0"/>' for p in pags]
        L.append('  </xs:sequence></xs:complexType>')
    L.append('  <xs:complexType name="tipo_Normal"><xs:sequence>')
    for bloque in campos["bloques"]:
        L.append(f'    <xs:element name="{bloque}" type="{wrapper.get(bloque, "tipo_" + bloque)}" minOccurs="0"/>')
    L += ['  </xs:sequence></xs:complexType>',
          f'  <xs:element name="{campos["raiz"]}"><xs:complexType><xs:choice>',
          '    <xs:element name="Normal" type="tipo_Normal"/>',
          '  </xs:choice></xs:complexType></xs:element>', '</xs:schema>']
    Path(out_path).write_bytes(("\n".join(L) + "\n").encode("iso-8859-1"))

# ----------------------------------------------------------------- CLI
def main():
    ap = argparse.ArgumentParser()
    sub = ap.add_subparsers(dest="cmd", required=True)
    sub.add_parser("list")
    r = sub.add_parser("resolve"); r.add_argument("--ejercicio", required=True)
    d = sub.add_parser("diff"); d.add_argument("--a", required=True); d.add_argument("--b", required=True)
    o = sub.add_parser("onboard"); o.add_argument("--ejercicio", required=True); o.add_argument("--xsd", required=True)
    o.add_argument("--base", default=None); o.add_argument("--dr200", default=None)
    a = ap.parse_args()
    if a.cmd == "list":
        for p in sorted(CAMPAIGNS.glob("*/campaign.json")):
            m = json.load(open(p, encoding="utf-8"))
            print(f"  {m['ejercicio']}: {m.get('total_campos','?')} casillas · XSD {m.get('xsd_fuente','?')} · base {m.get('base')}")
    elif a.cmd == "resolve":
        print(json.dumps(resolve(a.ejercicio), ensure_ascii=False, indent=1))
    elif a.cmd == "diff":
        dd = diff(a.a, a.b)
        if not dd:
            print(f"Sin diferencias de casillas entre {a.a} y {a.b}.")
        for pag, ch in dd.items():
            print(f"{pag}: +{len(ch['nuevas'])} nuevas {ch['nuevas']} · -{len(ch['eliminadas'])} eliminadas {ch['eliminadas']}")
    elif a.cmd == "onboard":
        res = onboard(a.ejercicio, a.xsd, a.base, a.dr200)
        print(f"OK · campaña {a.ejercicio} · {res['campos']} casillas -> {res['dir']}")
        print(res["informe"][:1500])

if __name__ == "__main__":
    main()
