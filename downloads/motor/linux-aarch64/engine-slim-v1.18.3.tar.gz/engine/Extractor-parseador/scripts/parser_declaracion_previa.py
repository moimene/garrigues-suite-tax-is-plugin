#!/usr/bin/env python3
"""parser_declaracion_previa.py — Motor DETERMINISTA: lee la declaración del ejercicio anterior.

Tres lectores, según el documento N-1:
  · XML de datos contables mod200 -> `parse_xml`: extrae las casillas (T#####) de Balance/CuentaPyG/
    CambiosPN. Sirve para arrastre y comparativa contable con el ejercicio actual.
  · `.200` posicional (registro DR de ancho fijo, la declaración COMPLETA N-1) -> `parse_200` (M1): extrae el
    bloque IDENTIFICATIVO (DP200001) + el MERCANTIL (DP200002 administradores + B.1/B.2 participaciones,
    incluidas complementarias; DP200002B titular real + secretario + representantes, incluidas complementarias)
    por POSICIÓN/LONGITUD del catálogo DR oficial, devolviendo el dict `precarga` normalizado de la capa de PRECARGA N-1
    (`docs/memoria/2026-06-26-spec-capa-precarga-n1.md`).
  · PDF del 200 N-1 (borrador/justificante) -> `parse_pdf` (M2, FALLBACK cuando no hay `.200`): extrae el
    MISMO dict `precarga` por ANCLAS DE ETIQUETA + REGEX sobre `pdftotext -layout`. Best-effort + HITL: lo que
    no salga con confianza se omite (nunca se inventa); PDF imagen (sin texto) -> dict vacío con
    `requiere_vision=True` (la visión real — persona_tax OCR HTTP / Claude — la aporta el llamador, no esta capa).

Los tres lectores son deterministas, 0 red y 0 PII en logs (devuelven el dict; no imprimen NIF/nombres). NO
calculan nada fiscal (cubo 3 fuera de alcance, ADR-001) y NO fabrican titular real: arrastran lo que el N-1
traiga, marcando lo ausente para HITL. El catálogo de posiciones del `.200` lo carga `dr200.cargar_dr` (mismo
origen que el emisor `formal200`/`dr200`, evita drift).

Uso:
  python3 parser_declaracion_previa.py --xml <previo.xml> [--actual casillas.csv] [--out casillas_previo.csv]
  python3 parser_declaracion_previa.py --doscientos <previo.200> [--ejercicio 2024]   # M1: `precarga` N-1
  python3 parser_declaracion_previa.py --pdf <previo.pdf> [--ejercicio 2024]          # M2: `precarga` N-1 (PDF)
"""
from __future__ import annotations
import argparse, csv, re
import xml.etree.ElementTree as ET
from pathlib import Path

def parse_xml(path) -> dict:
    raw = Path(path).read_bytes()
    try:
        txt = raw.decode("iso-8859-1")
    except Exception:
        txt = raw.decode("utf-8", "replace")
    root = ET.fromstring(txt)
    ejercicio = root.tag.replace("MOD200", "")
    casillas = {}
    for rama in root:
        for bloque in rama:
            for pagina in bloque:
                for campo in pagina:
                    m = re.fullmatch(r"T(\d{5})", campo.tag)
                    if m and campo.text:
                        try:
                            casillas[m.group(1)] = float(campo.text.strip())
                        except ValueError:
                            pass
    return dict(ejercicio=ejercicio, rama=(list(root)[0].tag if list(root) else None), casillas=casillas)

# --------------------------------------------------------------------- M1: extractor `.200` N-1 posicional
# La declaración N-1 COMPLETA (no solo el XML contable) viene en un `.200` de ancho fijo. Aquí se extrae el
# bloque IDENTIFICATIVO + MERCANTIL por posición del catálogo DR oficial (el mismo que usa el emisor), para
# la capa de PRECARGA N-1. NO se toca `parse_xml` (contable): este lector es aditivo y vive en paralelo.
_NIF_JURIDICA = set("ABCDEFGHJNPQRSUVW")


def _cargar_dr_pos(ejercicio):
    """{pagina: {num_campo: (posicion, longitud, tipo, descripcion)}} del catálogo DR para leer por posición.
    Reusa dr200.cargar_dr (fuente única de las posiciones; mismo origen que el emisor). Import perezoso para
    no acoplar el módulo (parse_xml sigue sin dependencias)."""
    import dr200
    dr = dr200.cargar_dr(ejercicio=str(ejercicio))
    out = {}
    for pag, campos in dr.items():
        by = {}
        for c in campos:
            num, pos, ln = c.get("num"), c.get("posicion"), c.get("longitud")
            if num and pos and ln:
                by[num] = (pos, ln, (c.get("tipo") or "").strip(), (c.get("descripcion") or "").strip())
        out[pag] = by
    return out


def _pendientes_bin_n1(doc, ejercicio):
    """BINs PENDIENTES de aplicar en períodos futuros (art. 26 LIS) del N-1 -> {total_euros, n_anios}. SURFACE,
    no decide (ADR-001): se arrastra para que el abogado lo confirme (ahorra picado de la tabla de compensación).

    Determinista: las casillas son las de la página DP200015 «Detalle compensación BIN ... Pendiente aplicación en
    períodos futuros» DERIVADAS del DR (no hardcodeadas, no inventadas) -> filtra el reuso de número entre marcos.
    Lee por posición del registro `<T20015000>`. Devuelve None si no hay página DP200015 o no hay pendientes."""
    import dr200
    dr = dr200.cargar_dr(ejercicio=str(ejercicio))
    campos = dr.get("DP200015", [])
    bin_nums = [c["num"] for c in campos
                if "pendiente aplicaci" in (c.get("descripcion") or "").lower()
                and "per" in (c.get("descripcion") or "").lower() and "futuro" in (c.get("descripcion") or "").lower()]
    if not bin_nums:
        return None
    by = _cargar_dr_pos(ejercicio).get("DP200015", {})
    leer = _leer_registro(doc, "T20015000")
    if not leer:
        return None
    total, anios = 0.0, 0
    for num in bin_nums:
        v = _centimos_a_euros(leer(by, num))
        if v:
            total += v
            anios += 1
    if not anios:
        return None
    return {"total_euros": round(total, 2), "n_anios": anios}


def _leer_registro(doc, tag):
    """Devuelve un lector `_c(num)` para el registro de ancho fijo `<tag>…</tag>` del `.200`, o None si la
    página no está presente. El lector recibe un mapa {num: (pos, len, ...)} y corta por posición/longitud."""
    m = re.search("<" + tag + ">(.*?)</" + tag + ">", doc, re.S)
    if not m:
        return None
    rec = "<" + tag + ">" + m.group(1)

    def _c(by, num):
        meta = by.get(num)
        if not meta:
            return ""
        pos, ln = meta[0], meta[1]
        return rec[pos - 1:pos - 1 + ln] if len(rec) >= pos - 1 + ln else ""
    return _c


def _leer_registros(doc, tag):
    """Como `_leer_registro`, pero devuelve todos los registros repetidos del mismo tag.

    DP200002/DP200002B usan registros complementarios (`campo 5 = C`) para listas largas; leer solo el primer
    tag pierde administradores/socios/participadas/titulares que el N-1 sí traía.
    """
    out = []
    for m in re.finditer("<" + tag + ">(.*?)</" + tag + ">", doc, re.S):
        rec = "<" + tag + ">" + m.group(1)

        def _c(by, num, _rec=rec):
            meta = by.get(num)
            if not meta:
                return ""
            pos, ln = meta[0], meta[1]
            return _rec[pos - 1:pos - 1 + ln] if len(_rec) >= pos - 1 + ln else ""
        out.append(_c)
    return out


def _centimos_a_euros(s):
    """Importe DR (céntimos, signo 'N' al frente para negativos) -> euros float, o None si vacío."""
    s = (s or "").strip()
    dig = re.sub(r"\D", "", s)
    if not dig:
        return None
    val = int(dig) / 100.0
    return -val if "N" in s.upper() else val


def _fj(nif):
    """F (persona física) / J (jurídica) por la letra inicial del NIF (heurística del campo tipo-persona)."""
    return "J" if str(nif)[:1].upper() in _NIF_JURIDICA else "F"


def _num_es(s):
    """Número del PDF en formato español ('12.264,00' / '100,00') -> float, o None si no hay dígitos.
    El punto es separador de millares y la coma decimal (M2: importes/% del PDF del 200)."""
    s = (s or "").strip()
    if not re.search(r"\d", s):
        return None
    s = s.replace(".", "").replace(",", ".")
    try:
        return float(s)
    except ValueError:
        return None


def _fecha_dr(s):
    """Campo Num de fecha del DR (AAAAMMDD, justificado a ceros) -> 'AAAAMMDD' o '' si es todo ceros/vacío.
    Evita devolver '00000000' (una fecha vacía codificada como ceros) como si fuera un dato."""
    dig = re.sub(r"\D", "", s or "")
    return dig if (dig and dig.strip("0")) else ""


def parse_200(path, ejercicio="2024") -> dict:
    """`.200` N-1 (registro DR de ancho fijo) -> dict `precarga` NORMALIZADO de la capa de PRECARGA N-1.

    Forma de salida (campos ausentes se omiten; nunca se inventan):
      {
        "identificativos": {nif, razon_social, cnae, periodo:{inicio,fin}, tipo_ejercicio},
        "administradores":  [{nif, nombre, fj}...],          # DP200002 apartado A (5 slots)
        "representantes":   [{nif, nombre, extra:[fecha_poder_AAAAMMDD, notaria]}...],  # DP200002B G
        "secretario":       [{nif, nombre}...],              # DP200002B G (1)
        "participaciones_b2":[{nif, nombre, pct(fracción), nominal(€), fj, pais}...],   # DP200002 B.2
        "titulares_reales": [{nif, nombre, extra:[nacionalidad, residencia, fecha_nac]}...],  # DP200002B F
        "caracteres":       {"00144": "1"}?,                 # flag F titular real (exención art.4.2) SI venía
        "fuente": "previo_200",
      }

    Determinista; lee por posición del catálogo DR (no por etiqueta de casilla, que el bloque mercantil no
    tiene). 0 PII en logs. ADR-001: NO calcula cubo 3 (fiscal). D23: el flag 144 se ARRASTRA tal cual del N-1
    (no se infiere); el inyector/HITL decide qué hacer si falta (no es esta capa)."""
    raw = Path(path).read_bytes()
    try:
        doc = raw.decode("iso-8859-1")
    except Exception:
        doc = raw.decode("utf-8", "replace")
    pos = _cargar_dr_pos(ejercicio)
    out = {"fuente": "previo_200", "identificativos": {}, "administradores": [], "representantes": [],
           "secretario": [], "participaciones_b2": [], "participaciones_b1": [], "titulares_reales": [],
           "caracteres": {}}

    # --- DP200001B: grupo fiscal + modelo de estados de cuentas.
    #     El grupo fiscal NO vive en DP200001: el nº de grupo (00040) y el NIF representante/dominante están en
    #     los campos 6/7 de página 1B. Si no se arrastran desde el `.200` N-1, Open rechaza a los miembros por
    #     10031/00040 aunque el N-1 estuviera completo.
    _m1b = re.search(r"<T20001B00>(.*?)</T20001B00>", doc, re.S)
    if _m1b:
        _r1b_full = "<T20001B00>" + _m1b.group(1)
        _by1b = pos.get("DP200001B", {})
        _c1b = _leer_registro(doc, "T20001B00")
        if _c1b:
            _ng = _c1b(_by1b, 6).strip()
            _nd = _c1b(_by1b, 7).strip()
            _id_dom_depend = _c1b(_by1b, 8).strip()
            if _ng and _ng.strip("0"):
                out["caracteres"]["00040"] = _ng
            if _nd:
                out["caracteres"]["nif_dominante"] = _nd
            if _id_dom_depend:
                out["caracteres"]["id_dominante_dependientes"] = _id_dom_depend

        # Modelo de estados de cuentas (campos 14/15/16, pos 156/157/158 = Balance/ECPN/PyG; valores 1 normal /
        # 2 abreviado / 3 PYMES). La continuidad año a año es la norma: se arrastra como propuesta.
        _me200 = {}
        for _fam, _p in (("balance", 156), ("ecpn", 157), ("pyg", 158)):
            _me200[_fam] = {"1": "normal", "2": "abreviado", "3": "pymes"}.get(
                _r1b_full[_p - 1:_p] if len(_r1b_full) >= _p else "")
        _me200 = {k: v for k, v in _me200.items() if v}
        if _me200:
            out["modelo_estados"] = _me200

    # --- BINs pendientes de aplicar (art. 26 LIS) del N-1: SURFACE para la FICHA (ahorra picado). No decide.
    _bin = _pendientes_bin_n1(doc, ejercicio)
    if _bin:
        out["pendientes_arrastre"] = {"bins": _bin}

    # --- DP200001: identificativos (NIF pos 14, razón social pos 23, CNAE campo 18, período, tipo ejercicio).
    by1 = pos.get("DP200001", {})
    c1 = _leer_registro(doc, "T20001000")
    if c1:
        ident = {}
        # localizar num_campo por descripción (estable entre años); reusa el catálogo ya cargado
        def _num(*kw, excl=()):
            for num, meta in by1.items():
                d = (meta[3] or "").lower()
                if all(k in d for k in kw) and not any(e in d for e in excl):
                    return num
            return None
        n_nif = _num("identificación", "nif")
        if n_nif and c1(by1, n_nif).strip():
            ident["nif"] = c1(by1, n_nif).strip()
        n_rs = _num("identificación", "apellidos")          # "Apellidos y nombre o Razón Social"
        if n_rs and c1(by1, n_rs).strip():
            ident["razon_social"] = c1(by1, n_rs).strip()
        # CNAE: la descripción del DR varía por ejercicio ("C.N.A.E." 2024 / "CNAE-2025" 2025). Se normaliza
        # (sin puntos/guiones) para casar ambas, como hace dr200.mapear_identificativos._find_cnae.
        n_cnae = None
        for num, meta in by1.items():
            d = re.sub(r"[^a-z0-9]", "", (meta[3] or "").lower())
            if "cnae" in d and "actividadprincipal" in d:
                n_cnae = num
                break
        if n_cnae:
            cn = re.sub(r"\D", "", c1(by1, n_cnae))[:4]
            if cn and cn != "0000":
                ident["cnae"] = cn
        n_ai, n_mi, n_di = _num("año", "inicio"), _num("mes", "inicio"), _num("día", "inicio")
        n_af, n_mf, n_df = _num("año", "final"), _num("mes", "final"), _num("día", "final")
        ini = "".join(re.sub(r"\D", "", c1(by1, n)) for n in (n_ai, n_mi, n_di) if n)
        fin = "".join(re.sub(r"\D", "", c1(by1, n)) for n in (n_af, n_mf, n_df) if n)
        per = {}
        if len(ini) == 8 and ini != "00000000":
            per["inicio"] = ini
        if len(fin) == 8 and fin != "00000000":
            per["fin"] = fin
        if per:
            ident["periodo"] = per
        n_te = _num("tipo de ejercicio")
        if n_te:
            te = c1(by1, n_te).strip()
            if te in ("1", "2", "3"):
                ident["tipo_ejercicio"] = te
        out["identificativos"] = ident
        # caracteres de configuración pág 1 (régimen/tipo entidad): casillas len-1 (flags 0/1) marcadas a "1".
        # Se leen por posición y se KEYEAN por su CASILLA (00011, 00023, …), igual que el path PDF («X NNNNN»).
        # Excluye selectores no-carácter (tipo ejercicio/declaración, indicadores de página/identificador).
        import dr200 as _drmod
        _EXCL_CAR = ("tipo de ejercicio", "tipo de declaraci", "indicador de p", "fin de identificador",
                     "complementaria")
        _consum = {n for n in (n_te,) if n}
        for _c in _drmod.cargar_dr(ejercicio=str(ejercicio)).get("DP200001", []):
            _cas = (_c.get("casilla") or "").strip()
            if _c.get("longitud") == 1 and _cas and _c.get("num") not in _consum:
                if any(e in (_c.get("descripcion") or "").lower() for e in _EXCL_CAR):
                    continue
                if c1(by1, _c["num"]).strip().lower() in _drmod._CARACTER_TRUE:
                    out["caracteres"][_cas] = "1"

    # --- DP200002: apartado A administradores (base) + B.1/B.2 participaciones (base + complementarias C).
    by2 = pos.get("DP200002", {})
    for c2 in _leer_registros(doc, "T20002000"):
        es_cont = c2(by2, 5).strip().upper() == "C"
        if not es_cont:
            for k in range(5):
                base = 6 + 6 * k                                  # campos 6,12,18,24,30
                nif = c2(by2, base).strip()
                if not nif:
                    continue
                out["administradores"].append({"nif": nif, "nombre": c2(by2, base + 3).strip(),
                                               "fj": c2(by2, base + 1).strip() or _fj(nif)})
        # B.1 participaciones de la declarante en otras entidades (DP200002 campos 36-89, 18/participada; 3 por
        # registro; las complementarias C añaden las siguientes). Layout DR verificado: 36 NIF · 37 nombre ·
        # 38 país · 39 % (fracción×10000) · 40 nominal · 41 valor en libros · 42 dividendos.
        for k in range(3):
            base = 36 + 18 * k                               # campos 36, 54, 72
            nif = c2(by2, base).strip()
            if not nif:
                continue
            pct_raw = re.sub(r"\D", "", c2(by2, base + 3))   # 5 díg., fracción × 10000
            out["participaciones_b1"].append({
                "nif": nif, "nombre": c2(by2, base + 1).strip(), "pais": c2(by2, base + 2).strip() or None,
                "pct": (int(pct_raw) / 10000.0) if pct_raw else None,
                "nominal": _centimos_a_euros(c2(by2, base + 4)),
                "valor_libros": _centimos_a_euros(c2(by2, base + 5)),
                "dividendos": _centimos_a_euros(c2(by2, base + 6)),
            })
        for k in range(6):
            base = 100 + 7 * k                                # campos 100,107,114,121,128,135
            nif = c2(by2, base).strip()
            if not nif:
                continue
            pct_raw = re.sub(r"\D", "", c2(by2, base + 6))    # 5 díg., % × 100 (3 ent + 2 dec)
            out["participaciones_b2"].append({
                "nif": nif, "fj": c2(by2, base + 2).strip() or None, "nombre": c2(by2, base + 3).strip(),
                "pais": c2(by2, base + 4).strip() or None, "nominal": _centimos_a_euros(c2(by2, base + 5)),
                "pct": (int(pct_raw) / 10000.0) if pct_raw else None,        # FRACCIÓN (0,60 = 60%)
            })

    # --- DP200002B: F titular real (base + complementarias C) + G secretario/representantes (base).
    by2b = pos.get("DP200002B", {})
    for c2b in _leer_registros(doc, "T20002B00"):
        es_cont = c2b(by2b, 5).strip().upper() == "C"
        flag144 = c2b(by2b, 144).strip()                     # F: "Entidad SIN obligación de identificar titular real"
        if flag144 == "1":
            out["caracteres"]["00144"] = "1"                 # D23: se ARRASTRA tal cual (no se infiere)
        nif_tr = c2b(by2b, 146).strip()
        if nif_tr:
            out["titulares_reales"].append({"nif": nif_tr, "nombre": c2b(by2b, 147).strip(),
                                            "extra": [c2b(by2b, 151).strip(), c2b(by2b, 150).strip(),
                                                      _fecha_dr(c2b(by2b, 149))]})  # [nacionalidad, residencia, fecha_nac]
        nif_sec = c2b(by2b, 153).strip()
        if nif_sec and not es_cont:
            out["secretario"].append({"nif": nif_sec, "nombre": c2b(by2b, 152).strip()})
        if not es_cont:
            for k in range(3):
                base = 154 + 4 * k                                # campos 154,158,162
                nif = c2b(by2b, base + 1).strip()
                if not nif:
                    continue
                out["representantes"].append({"nif": nif, "nombre": c2b(by2b, base).strip(),
                                              "extra": [_fecha_dr(c2b(by2b, base + 2)),
                                                        c2b(by2b, base + 3).strip()]})  # [fecha_poder, notaria]
    return out


# --------------------------------------------------------------------- M2: extractor PDF N-1 (fallback texto)
# Cuando NO hay `.200` N-1 (solo el PDF del 200 del año anterior: borrador o justificante de presentación), se
# extrae el MISMO dict `precarga` que `parse_200` por ANCLAS DE ETIQUETA + REGEX sobre el texto del PDF. Los PDF
# del MODELO 200 (borrador/justificante) llevan capa de texto extraíble (verificado: razón social, CNAE, NIF,
# administrador, representante, secretario, titular real y participaciones B.2 aparecen como texto). BEST-EFFORT
# + HITL: lo que no se extraiga con confianza se OMITE; NO se inventa. Si el PDF no tiene capa de texto (PDF
# imagen) -> dict vacío con `requiere_vision=True` (la visión real — persona_tax OCR HTTP o Claude — es input del
# llamador/HITL; aquí NO se hace red ni OCR, solo se deja el flag y el punto de extensión). Aditivo: `parse_200`
# (`.200`) y `parse_xml` (contable) siguen intactos.
# NIF/CIF/NIE/IDs extranjeros del 200 (9 caracteres): NIF persona (8 díg + control), CIF/entidad y código de
# no residente (letra inicial — A-Z, p.ej. 'N' de no residente — + 7 díg + control letra/díg), NIE (X/Y/Z + 7
# díg + control). El orden importa: NIF (todo dígitos) primero para que no lo capture la forma de letra inicial.
_NIF_RE = r"(?:\d{8}[A-Z]|[A-Z]\d{7}[A-Z0-9])"
_FECHA_RE = r"\d{2}/\d{2}/\d{4}"                           # fechas del PDF (DD/MM/AAAA)


def _pdf_a_texto(path):
    """(texto_layout, tiene_capa_texto). Usa `pdftotext -layout` (poppler, preserva columnas — lo que necesitan
    las anclas); si no está disponible, cae a `pdfplumber`. Determinista, 0 red. `tiene_capa_texto=False` cuando
    el PDF es imagen (sin texto extraíble) -> el llamador debe enrutar a visión."""
    import shutil
    import subprocess
    txt = ""
    if shutil.which("pdftotext"):
        try:
            r = subprocess.run(["pdftotext", "-layout", "-enc", "UTF-8", str(path), "-"],
                               capture_output=True, timeout=60)
            txt = (r.stdout or b"").decode("utf-8", "replace")
        except Exception:
            txt = ""
    if not txt.strip():
        try:
            import pdfplumber
            with pdfplumber.open(str(path)) as pdf:
                txt = "\n".join((pg.extract_text(layout=True) or "") for pg in pdf.pages)
        except Exception:
            txt = ""
    return txt, bool(txt.strip())


def _fecha_pdf_a_dr(s):
    """'DD/MM/AAAA' (PDF) -> 'AAAAMMDD' (forma DR/contrato precarga), o '' si no casa."""
    m = re.match(r"(\d{2})/(\d{2})/(\d{4})", (s or "").strip())
    return (m.group(3) + m.group(2) + m.group(1)) if m else ""


def _bloque(lineas, ancla_re, fin_res, max_lineas=40):
    """Devuelve las líneas entre la primera que casa `ancla_re` (excluida) y la primera posterior que casa
    cualquier patrón de `fin_res` (o `max_lineas`). Acota cada apartado mercantil para regexear solo su zona."""
    fin_res = [re.compile(p, re.I) for p in fin_res]
    out, dentro, n = [], False, 0
    anc = re.compile(ancla_re, re.I)
    for ln in lineas:
        if not dentro:
            if anc.search(ln):
                dentro = True
            continue
        if any(p.search(ln) for p in fin_res) or n >= max_lineas:
            break
        out.append(ln)
        n += 1
    return out


def _b1_columnar(path):
    """B.1 (participaciones de la declarante) desde el PDF N-1 por POSICIONES (pdfplumber): la tabla B.1 del
    Modelo 200 es COLUMNAR (Entidad 1ª/2ª/3ª) y `pdftotext -layout` la linealiza mal (la provincia/país y los
    importes se pierden o se mezclan). Aquí se agrupan palabras en filas (tolerancia y) y, por cada fila de dato
    (ancla de etiqueta ES), se toman los 3 primeros valores por orden de x = Entidad 1/2/3. Robusto a importes
    right-aligned. El NOMBRE no se extrae (el texto largo se solapa entre columnas → se deja al abogado/AEAT por
    NIF). Devuelve [] si no hay página B.1 o pdfplumber no está. Sin esto, B.1 desde PDF sale incompleta y la
    AEAT rechaza la participada (FRECH «Código de provincia/país»)."""
    import re as _re, unicodedata as _ud
    def _nm(s): return _ud.normalize("NFKD", s or "").encode("ascii", "ignore").decode().lower()
    _M = _re.compile(r"^-?\d{1,3}(?:\.\d{3})*,\d{2}$")
    def _mo(t): return float(t.replace(".", "").replace(",", ".")) if _M.match(t) else None
    try:
        import pdfplumber
        with pdfplumber.open(str(path)) as pdf:
            page = next((pg for pg in pdf.pages
                         if "Datos de la participada" in (pg.extract_text() or "")
                         and "provincia" in _nm(pg.extract_text() or "")), None)
            if not page:
                return []
            W = page.extract_words(keep_blank_chars=False)
    except Exception:
        return []
    rows = []
    for w in W:
        for r in rows:
            if abs(r["y"] - w["top"]) <= 3.5:
                r["w"].append(w); break
        else:
            rows.append({"y": w["top"], "w": [w]})
    def lab(r): return _nm(" ".join(w["text"] for w in sorted(r["w"], key=lambda z: z["x0"]) if w["x0"] < 256))
    def rtoks(r): return [w for w in sorted(r["w"], key=lambda z: z["x0"]) if w["x0"] >= 256]
    def first3(r, pred): return [w["text"] for w in rtoks(r) if pred(w["text"])][:3]
    P = [{} for _ in range(3)]
    def setc(vals, key, conv=lambda x: x):
        for i, v in enumerate(vals):
            if i < 3 and v not in ("", None):
                P[i][key] = conv(v)
    for r in sorted(rows, key=lambda r: r["y"]):
        L = lab(r)
        nifs = first3(r, lambda t: _re.match(r"^[A-Z]\d{8}$", t))
        if nifs and not L:
            setc(nifs, "nif"); continue
        if "codigo provincia" in L:
            setc(first3(r, lambda t: _re.match(r"^\d{1,2}$", t)), "pais"); continue
        if "porcentaje de participacion" in L:
            setc(first3(r, lambda t: _M.match(t)), "pct", lambda v: _mo(v) / 100.0); continue
        if "valor nominal total" in L:
            setc(first3(r, lambda t: _M.match(t)), "nominal", _mo); continue
        if "valor en libros" in L:
            setc(first3(r, lambda t: _M.match(t)), "valor_libros", _mo); continue
        if "ingresos por dividendos" in L:
            setc(first3(r, lambda t: _M.match(t)), "dividendos", _mo); continue
    return [p for p in P if p.get("nif") and p.get("pais")]


def parse_pdf(path, ejercicio="2024") -> dict:
    """PDF del 200 N-1 (borrador/justificante) -> dict `precarga` (MISMO contrato que `parse_200`, para que el
    inyector M3 lo consuma igual). Extracción por anclas de etiqueta + regex sobre `pdftotext -layout`.

    Forma de salida (idéntica a `parse_200`, + flags de fallback):
      { identificativos, administradores, representantes, secretario, participaciones_b2, titulares_reales,
        caracteres, fuente:"previo_pdf",
        requiere_revision: True,            # SIEMPRE (PDF N-1 = best-effort, revisión del abogado obligatoria)
        requiere_vision: bool }             # True si el PDF no tiene capa de texto (imagen) -> enrutar a visión
    Campos no extraíbles con confianza se OMITEN (no se inventan). 0 PII en logs (devuelve el dict, no imprime).
    ADR-001: NO calcula cubo 3 (fiscal). D23: el flag 144 se ARRASTRA si el PDF lo trae marcado; nunca default."""
    out = {"fuente": "previo_pdf", "identificativos": {}, "administradores": [], "representantes": [],
           "secretario": [], "participaciones_b2": [], "participaciones_b1": [], "titulares_reales": [],
           "caracteres": {}, "requiere_revision": True, "requiere_vision": False}
    texto, tiene_texto = _pdf_a_texto(path)
    if not tiene_texto:
        # PDF imagen (sin texto): no se inventa nada. La visión (persona_tax OCR / Claude) la aporta el llamador.
        out["requiere_vision"] = True
        return out
    lineas = texto.splitlines()

    # --- Identificativos (cubo 1): NIF + razón social (en la PRIMERA fila tras la cabecera "NIF ... razón
    #     social ... Tipo ejercicio" — separada por varias líneas en blanco en el layout), CNAE, tipo ejercicio.
    ident = {}
    for i, ln in enumerate(lineas):
        if re.search(r"\bNIF\b.*Apellidos y nombre o raz.n social.*Tipo ejercicio", ln, re.I):
            te = re.search(r"Tipo ejercicio[^\d]*(\d)\s*$", ln)   # "Tipo ejercicio ......... 1" (puntos de relleno)
            if te:
                ident["tipo_ejercicio"] = te.group(1)
            for sig in lineas[i + 1:i + 12]:                      # la fila de datos cae unas líneas más abajo
                m = re.match(r"\s*(" + _NIF_RE + r")\s{2,}(.+?)(?:\s{2,}|$)", sig)
                if m:
                    ident["nif"] = m.group(1).strip()
                    rs = re.sub(r"\s+C.digo CNAE.*$", "", m.group(2), flags=re.I).strip()
                    if rs:
                        ident["razon_social"] = rs
                    break
            break
    mc = re.search(r"C.digo CNAE[^\d]*\(20\d\d\)[^\d]*actividad principal[^\d]*(\d{4})", texto, re.I)
    if not mc:
        mc = re.search(r"C\.?N\.?A\.?E[^\d]{0,40}(\d{4})", texto, re.I)
    if mc and mc.group(1) != "0000":
        ident["cnae"] = mc.group(1)
    out["identificativos"] = ident

    # --- Caracteres de la declaración (configuración de página 1): marcas "X NNNNN" del bloque (tipo de entidad,
    #     regímenes, otros caracteres, grupo fiscal). Se ARRASTRAN del N-1 como punto de partida (el abogado las
    #     confirma en Sociedades WEB, cubo 3); sin marca NO se inventan. Se acota el bloque ANTES del selector de
    #     "Modelo de cuentas" (Mod. normal/abreviado/pymes, casillas 00050/00053/00075…) que es de página 1B y lo
    #     fija el motor por defecto a NORMAL — no son caracteres de entidad. (REDEVCO 2024: 00011 ETVE, 00023 gran
    #     empresa, 00039 grupo mercantil, 00081 filial grupo multinacional, que la precarga perdía → pág 1 en blanco.)
    car_block = _bloque(lineas, r"Caracteres de la declaraci",
                        [r"Mod\.\s*normal", r"Modelo de cuentas", r"Estados de cuentas",
                         r"Relaci.n de administradores", r"^\s*A\.\s"], 90)
    for ln in car_block:
        for mcar in re.finditer(r"(?:^|\s)X\s+(0\d{4})\b", ln):
            out["caracteres"][mcar.group(1)] = "1"
    # Nº de grupo fiscal (casilla 00040, página 1B): es un VALOR "NNNN/AA" (no un flag), impreso junto a las
    # claves 00009/00010 ("Número de grupo fiscal 0483/18 00040"). Se arrastra del N-1 por `caracteres["00040"]`
    # (canal str JSON-safe que llega al motor); el motor lo coloca en DP200001B si la entidad es de grupo fiscal.
    mgf = re.search(r"N.?mero de grupo fiscal\s+(\d{3,4}\s*/\s*\d{2})", texto, re.I)
    if mgf:
        out["caracteres"]["00040"] = re.sub(r"\s+", "", mgf.group(1))
    # NIF de la sociedad/entidad representante/dominante (DP200001B campo 7). En el N-1 de un DEPENDIENTE (00010)
    # es el NIF de la DOMINANTE (no el suyo), impreso tras "representante/dominante ... (incluida en el grupo
    # fiscal) ...... NIF". Se arrastra por `caracteres["nif_dominante"]` (canal str JSON-safe); el motor lo coloca
    # en el campo 7 si la entidad es dependiente. (En la dominante el motor usa el NIF del declarante.)
    mnd = re.search(r"representante/dominante.*?incluida en el grupo fiscal[\s.)]*?(" + _NIF_RE + r")", texto, re.I | re.S)
    if mnd:
        out["caracteres"]["nif_dominante"] = mnd.group(1).strip()

    # --- Modelo de estados de cuentas (página 1B): Balance / ECPN / PyG = normal / abreviado / PYMES. La marca
    #     "X" del N-1 FIJA el modelo del ejercicio: la continuidad año a año es la norma (cambiar de modelo es
    #     excepcional), así que el intake lo PROPONE al abogado (que confirma). Casillas: Balance 00050/00051/00052
    #     · ECPN 00075/00076/00077 · PyG 00053/00054/00055 (normal/abreviado/PYMES). El motor lo usa para la
    #     coherencia del .200 (DP200001B 14/15/16). Best-effort (PDF): si no hay capa de texto del bloque, se omite.
    _MODELO_CAS = {"00050": ("balance", "normal"), "00051": ("balance", "abreviado"), "00052": ("balance", "pymes"),
                   "00075": ("ecpn", "normal"), "00076": ("ecpn", "abreviado"), "00077": ("ecpn", "pymes"),
                   "00053": ("pyg", "normal"), "00054": ("pyg", "abreviado"), "00055": ("pyg", "pymes")}
    _ie = texto.lower().find("estados de cuentas")
    if _ie >= 0:
        _modelo = {}
        for _m in re.finditer(r"X\s*(0\d{4})", texto[_ie:_ie + 1200]):
            _info = _MODELO_CAS.get(_m.group(1))
            if _info:
                _modelo[_info[0]] = _info[1]
        if _modelo:
            out["modelo_estados"] = _modelo

    # --- A. Administradores: filas "NIF  F/J  [RPTE]  Nombre..." bajo la cabecera de columnas del apartado A
    #     ("NIF F/J RPTE. Apellidos... Domicilio Código Provincial"). El ancla es esa cabecera de columnas (la
    #     fila de datos viene justo debajo); se corta al llegar a B. Participaciones.
    for ln in _bloque(lineas, r"NIF\s+F/J\s+RPTE\..*Apellidos y nombre / Raz.n social",
                      [r"B\.\s*Participaciones directas"], 12):
        m = re.match(r"\s*(" + _NIF_RE + r")\s+([FJ])\b\s*([A-Z]?)\s+(.+?)\s*$", ln)
        if not m:
            continue
        nombre = re.sub(r"\s{2,}.*$", "", m.group(4)).strip()      # corta domicilio/cód. provincial (>=2 espacios)
        if nombre:
            out["administradores"].append({"nif": m.group(1), "nombre": nombre, "fj": m.group(2)})

    # --- B.2. Participaciones de personas/entidades EN la declarante: "NIF [RPTE] F/J Nombre ... pais Nom %".
    #     Ancla = la cabecera de columnas "NIF RPTE. Otra ... Apellidos ... Nominal % Particip." (la fila de datos
    #     viene justo debajo); se corta en "Suma de porcentajes" o el siguiente apartado.
    for ln in _bloque(lineas, r"\bNIF\b\s+RPTE\..*Apellidos y nombre / Raz.n social.*(Nominal|Particip)",
                      [r"Suma de porcentajes", r"^\s*C\.\s", r"^\s*D\.\s", r"^\s*E\.\s"], 14):
        # se exige NIF al inicio y, al final, [provincia 2 díg | país 2 letras] Nominal % -> ancla de la fila.
        # OJO: para socio ESPAÑOL el campo 104 es la PROVINCIA (2 díg, p.ej. 28), no un país de 2 letras; si solo
        # se captura el país (letras) el .200 sale con B.2 sin provincia -> AEAT rechaza EMALR31 («parcialmente
        # rellena»). Por eso el grupo acepta 2 dígitos O 2 letras.
        # `[A-Z]?(?=NIF)`: tolera una letra ESPURIA pegada antes del NIF (artefacto de columna de pdftotext
        # -layout; visto en RIV II: el socio mayoritario salía como «N<NIF>…» y se perdía, dejando B.2 parcial
        # → EMALR31). El lookahead evita comerse la 1ª letra de un NIF que empieza por letra (B/J…).
        m = re.match(r"\s*[A-Z]?(?=" + _NIF_RE + r")(" + _NIF_RE + r")\s+(?:([A-Z])\s+)?([FJ])\s+(.+?)\s{2,}"
                     r"(\d{1,2}|[A-Z]{2})?\s*([\d.,]+)\s+([\d.,]+)\s*$", ln)
        if not m:
            continue
        nombre = re.sub(r"\s{2,}.*$", "", m.group(4)).strip()
        nominal = _num_es(m.group(6))
        pct = _num_es(m.group(7))
        _prov = (m.group(5) or "").strip()
        out["participaciones_b2"].append({
            "nif": m.group(1), "fj": m.group(3), "nombre": nombre, "pais": _prov or None,
            "nominal": nominal, "pct": (pct / 100.0) if pct is not None else None})  # % PDF (60,00) -> FRACCIÓN

    # --- B.1. Participaciones de la DECLARANTE en otras entidades ("sociedades en las que participa"): bloque
    #     VERTICAL "Datos de la participada:" (NIF / Nombre / país / % / valor nominal / valor en libros /
    #     dividendos). Se perdía → pág 2 B.1 EN BLANCO (REDEVCO). Best-effort por etiqueta; el `.200` N-1 lo trae
    #     posicional y más fiable. `pct` en FRACCIÓN (99,95% -> 0.9995), homogéneo con B.2.
    def _b1_trailing(ln):
        t = re.split(r"\.{3,}", ln, maxsplit=1)[-1] if "..." in ln else ln
        return t.replace("\xa0", " ").strip()

    def _b1_num(v):
        mm = re.search(r"-?\d[\d.]*(?:,\d+)?", v.replace("\xa0", " "))   # importe ES (1.234.567,89) aislado del relleno
        return _num_es(mm.group(0)) if mm else None
    _b1_cur = None
    for ln in _bloque(lineas, r"B\.1\.?\s*Participaciones de la declarante",
                      [r"B\.2\.?\s*Participaciones de personas", r"^\s*C\.\s", r"^\s*D\.\s"], 160):
        low = ln.lower()
        if "datos de la participada" in low:
            if _b1_cur and _b1_cur.get("nif"):
                out["participaciones_b1"].append(_b1_cur)
            _b1_cur = {}
            continue
        if _b1_cur is None:
            continue
        v = _b1_trailing(ln)
        if re.search(r"equivalente al nif|^\s*nif\b", low):
            mm = re.search(r"([A-Z]{0,2}\d[\dA-Za-z]{5,})", v)
            if mm:
                _b1_cur["nif"] = mm.group(1)
        elif "nombre o raz" in low:
            _b1_cur["nombre"] = re.sub(r"\s{2,}.*$", "", v)[:40]
        elif re.search(r"c.digo provincia", low):
            mm = re.search(r"\b([A-Z]{2})\b", v)
            if mm:
                _b1_cur["pais"] = mm.group(1)
        elif "porcentaje de participaci" in low:
            p = _b1_num(v)
            _b1_cur["pct"] = (p / 100.0) if p is not None else None
        elif "valor nominal total" in low:
            _b1_cur["nominal"] = _b1_num(v)
        elif "valor en libros" in low:
            _b1_cur["valor_libros"] = _b1_num(v)
        elif "ingresos por dividendos" in low:
            _b1_cur["dividendos"] = _b1_num(v)
    if _b1_cur and _b1_cur.get("nif"):
        out["participaciones_b1"].append(_b1_cur)
    # B.1 por POSICIONES (columnar): si la tabla B.1 se lee bien por pdfplumber (con provincia/país), GANA sobre
    # la versión por etiquetas de `pdftotext` (que pierde la provincia en el layout columnar → participada que la
    # AEAT rechaza). Solo sustituye si extrae al menos una participada COMPLETA (NIF + provincia/país).
    _b1_col = _b1_columnar(path)
    if _b1_col:
        out["participaciones_b1"] = _b1_col

    # --- F. Titular real: fila "tipo_doc NIF Apellidos" + línea de detalle (fecha nac / residencia /
    #     nacionalidad). El flag 144 (exención) se trata más abajo, con cautela (la etiqueta está SIEMPRE impresa).
    bloque_tr = _bloque(lineas, r"F\.\s*Identificaci.n del titular real",
                        [r"G\.\s*Secretario del Consejo", r"Secretario del Consejo de Administraci.n"], 14)
    for j, ln in enumerate(bloque_tr):
        m = re.match(r"\s*\d?\s+(" + _NIF_RE + r")\s+(.+?)\s*$", ln)
        if not m:
            continue
        nombre = re.sub(r"\s{2,}.*$", "", m.group(2)).strip()
        # extra (secundario, best-effort) = [nacionalidad, residencia, fecha_nac]. La línea de detalle del PDF es
        # "País expedición | Fecha nac (DD/MM/AAAA) | País residencia | Nacionalidad" -> país-largo=residencia,
        # código de 2 letras=nacionalidad. NIF+nombre son lo crítico del cubo 2; estos campos NO bloquean.
        nac = res = fnac = ""
        for sig in bloque_tr[j + 1:j + 4]:
            mf = re.search(_FECHA_RE, sig)
            if mf:
                fnac = _fecha_pdf_a_dr(mf.group(0))
            resto = re.sub(_FECHA_RE, "", sig)
            cods = re.findall(r"\b([A-Z]{2})\b", resto)               # códigos ISO de país (ES, NL, …)
            largos = re.findall(r"\b([A-ZÁÉÍÓÚÑ]{3,})\b", resto)      # nombres de país (ESPAÑA, …)
            if cods:
                nac = nac or cods[-1]
            if largos:
                res = res or largos[0]
        # 148 (país de expedición del documento) NO se extrae ni se emite: la AEAT lo declara «NO REQUERIDO»
        # (rechazo 02B1480 si llega con contenido). El bloque del titular se completa con 145/146/147 + extra.
        out["titulares_reales"].append({"nif": m.group(1), "nombre": nombre, "extra": [nac, res, fnac]})
        break
    # 144 (D23): exención de identificar titular real (art.4.2 Ley 10/2010). La etiqueta del formulario está
    # SIEMPRE impresa, así que NO basta su presencia: se marca SOLO si está MARCADA (X/✓ inmediatamente antes de
    # la etiqueta) y NO se ha extraído titular real. Si no hay marca ni titular -> NO se inventa 144 (M4/D23
    # propondrá el administrador como titular real con marca de revisión). Conservador: nunca 144 por defecto.
    if not out["titulares_reales"]:
        m144 = re.search(r"([X✓✔])\s*Entidad sin obligaci.n de identificar el titular real", texto, re.I)
        if m144:
            out["caracteres"]["00144"] = "1"

    # --- G. Secretario del Consejo: fila "Apellidos y nombre ... NIF" (ORDEN INVERTIDO: nombre antes que NIF).
    for ln in _bloque(lineas, r"Secretario del Consejo de Administraci.n",
                      [r"Representantes legales"], 8):
        m = re.match(r"\s*(.+?)\s{2,}(" + _NIF_RE + r")\s*$", ln)
        if m and m.group(1).strip() and not re.search(r"Apellidos y nombre", m.group(1), re.I):
            out["secretario"].append({"nif": m.group(2), "nombre": m.group(1).strip()})
            break

    # --- Representantes legales: filas "Apellidos NIF Fecha_poder Notaría/otros".
    for ln in _bloque(lineas, r"Representantes legales",
                      [r"La autenticidad de este documento", r"^\s*Modelo\b", r"NIF\s+Apellidos y nombre o raz"], 14):
        m = re.match(r"\s*(.+?)\s{2,}(" + _NIF_RE + r")\s+(" + _FECHA_RE + r")?\s*(.*)$", ln)
        if not m or re.search(r"Apellidos y nombre", m.group(1), re.I):
            continue
        out["representantes"].append({
            "nif": m.group(2), "nombre": m.group(1).strip(),
            "extra": [_fecha_pdf_a_dr(m.group(3) or ""), (m.group(4) or "").strip()]})  # [fecha_poder, notaria]
    return out


# Casillas del Modelo 200 (Liquidación IV) verificadas contra DR200e25_extraccion_completa.csv (NO inventadas).
# Estos importes tienen destino directo de liquidación: se precargan, pero el abogado confirma antes de firmar.
#   01766 Total retenciones e ingresos a cuenta (efectuadas) · 01784 (imputadas por agrupaciones/UTEs)
#   00601 1er pago fraccionado (Estado) · 00603 2º · 00605 3er  (Modelo 202)
_DATOS_FISCALES_CASILLAS = [
    ("01766", r"total\s+retenciones\s+e\s+ingresos\s+a\s+cuenta|retenciones\s+e\s+ingresos\s+a\s+cuenta"),
    ("00601", r"(?:1\s*er?\.?|primer)\s*pago\s*fraccionado"),
    ("00603", r"(?:2\s*[ºo]?\.?|2\s*er?\.?|segundo)\s*pago\s*fraccionado"),
    ("00605", r"(?:3\s*er?\.?|tercer)\s*pago\s*fraccionado"),
]

_DATOS_FISCALES_ARRASTRES = [
    ("bin_pendiente", r"bases?\s+imponibles?\s+negativas?|BINs?|pendientes?\s+de\s+compensar",
     "BIN/deduccion pendiente: mapear al cuadro de arrastre y decidir aplicacion en HITL"),
    ("deduccion_pendiente", r"deducciones?.{0,80}pendientes?|pendiente.{0,80}deducciones?",
     "deduccion pendiente: arrastre a revisar contra N-1 y datos fiscales AEAT"),
]

_DATOS_FISCALES_AJUSTES_HITL = [
    ("sanciones", r"sanciones?",
     "si esta contabilizado como gasto, candidato a ajuste extracontable positivo; no autoaplicar"),
    ("recargos", r"recargos?",
     "si esta contabilizado como gasto, candidato a ajuste extracontable positivo; no autoaplicar"),
    ("intereses_demora", r"inter[eé]s(?:es)?\s+de\s+demora",
     "clasificar naturaleza y signo con el abogado; no autoaplicar"),
]

_DATOS_FISCALES_GESTION = [
    ("comprobacion", r"comprobaci[oó]n|inspecci[oó]n|procedimiento|rectificativa",
     "incidencia de gestion: revisar impacto antes de firmar"),
    ("operaciones_terceros", r"notarial|registral|catastro|inmueble|transmisi[oó]n",
     "informacion de terceros: contrastar con contabilidad y posibles ajustes"),
]


def _extraer_importe_linea(ln, eur_re):
    importes = eur_re.findall(ln)
    if not importes:
        return None
    return _num_es(importes[-1])


def _buscar_eventos_datos_fiscales(texto, reglas, eur_re):
    eventos = []
    for tipo, patron, tratamiento in reglas:
        rx = re.compile(patron, re.I)
        for ln in texto.splitlines():
            if not rx.search(ln):
                continue
            eventos.append({
                "tipo": tipo,
                "importe": _extraer_importe_linea(ln, eur_re),
                "tratamiento": tratamiento,
                "requiere_revision": True,
            })
    return eventos


def parse_datos_fiscales(path) -> dict:
    """PDF de DATOS FISCALES de la AEAT -> contrato fiscal de intake. BEST-EFFORT.

    Extrae:
      - `casillas`: destinos directos de liquidacion verificados contra el DR (retenciones/pagos fraccionados).
      - `arrastres`: BINs/deducciones pendientes, para cuadro de arrastre y decision HITL.
      - `ajustes_hitl`: sanciones, recargos e intereses de demora, nunca autoaplicados.
      - `gestion`: comprobaciones, rectificativas y operaciones de terceros a contrastar.

    NO inventa casillas ni importes: lo que no se extrae con confianza se OMITE. `estado` = captado (hay
    informacion fiscal util) / parcial (hay texto pero solo categorias HITL o directos incompletos) / vacio.
    `requiere_revision=True` SIEMPRE (extracción de PDF = revisión del abogado obligatoria). 0 PII en logs.
    ADR-001: el motor NO firma el número fiscal; esto solo PRECARGA para que el abogado confirme en la FICHA."""
    out = {"fuente": "datos_fiscales_pdf", "casillas": {}, "estado": "vacio",
           "arrastres": [], "ajustes_hitl": [], "gestion": [],
           "requiere_revision": True, "requiere_vision": False}
    texto, tiene_texto = _pdf_a_texto(path)
    if not tiene_texto:
        out["requiere_vision"] = True
        return out
    _eur = re.compile(r"-?\d{1,3}(?:\.\d{3})*,\d{2}\b")
    for cod, etiqueta_re in _DATOS_FISCALES_CASILLAS:
        if cod in out["casillas"]:
            continue
        anc = re.compile(etiqueta_re, re.I)
        for ln in texto.splitlines():
            if not anc.search(ln):
                continue
            importes = _eur.findall(ln)
            if importes:
                val = _num_es(importes[-1])           # el importe (último de la línea, tras los puntos de relleno)
                if val is not None:
                    out["casillas"][cod] = val
            break
    out["arrastres"] = _buscar_eventos_datos_fiscales(texto, _DATOS_FISCALES_ARRASTRES, _eur)
    out["ajustes_hitl"] = _buscar_eventos_datos_fiscales(texto, _DATOS_FISCALES_AJUSTES_HITL, _eur)
    out["gestion"] = _buscar_eventos_datos_fiscales(texto, _DATOS_FISCALES_GESTION, _eur)
    n = len(out["casillas"])
    n_info = n + len(out["arrastres"]) + len(out["ajustes_hitl"]) + len(out["gestion"])
    out["estado"] = "captado" if n_info and n >= len(_DATOS_FISCALES_CASILLAS) else ("parcial" if n_info else "vacio")
    return out


def comparar(previo: dict, actual_csv: str) -> list:
    act = {}
    for r in csv.reader(open(actual_csv, encoding="utf-8-sig"), delimiter=";"):
        if r and re.fullmatch(r"\d{5}", str(r[0]).strip()):
            act[r[0].strip()] = float(r[4])
    difs = []
    for c in sorted(set(previo["casillas"]) | set(act)):
        p, a = previo["casillas"].get(c), act.get(c)
        difs.append(dict(casilla=c, previo=p, actual=a,
                         delta=(round((a or 0) - (p or 0), 2))))
    return difs

def _resumen_precarga_deidentificado(p: dict) -> dict:
    """Resumen 0-PII del `precarga` (presencia/conteo de campos, sin volcar NIF/nombres). Para validar M1/M2
    sobre un `.200`/PDF real sin filtrar datos del cliente."""
    ident = p.get("identificativos") or {}
    out = {
        "fuente": p.get("fuente"),
        "identificativos_presentes": sorted(k for k in ident if ident.get(k) not in (None, "", {})),
        "n_administradores": len(p.get("administradores") or []),
        "n_representantes": len(p.get("representantes") or []),
        "n_secretario": len(p.get("secretario") or []),
        "n_participaciones_b2": len(p.get("participaciones_b2") or []),
        "n_titulares_reales": len(p.get("titulares_reales") or []),
        "caracteres_set": sorted((p.get("caracteres") or {}).keys()),
        "suma_pct_b2": round(sum((s.get("pct") or 0.0) for s in (p.get("participaciones_b2") or [])), 4),
    }
    if "requiere_vision" in p:          # M2 (PDF): añade los flags de fallback/HITL
        out["requiere_vision"] = bool(p.get("requiere_vision"))
        out["requiere_revision"] = bool(p.get("requiere_revision"))
    return out


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--xml", default=None)
    ap.add_argument("--doscientos", default=None, help="`.200` N-1 -> extrae el dict `precarga` (resumen 0-PII)")
    ap.add_argument("--pdf", default=None, help="PDF del 200 N-1 (fallback) -> extrae el dict `precarga` (resumen 0-PII)")
    ap.add_argument("--ejercicio", default="2024")
    ap.add_argument("--actual", default=None)
    ap.add_argument("--out", default=None)
    a = ap.parse_args()
    if a.doscientos or a.pdf:
        import json as _json
        prec = parse_200(a.doscientos, ejercicio=a.ejercicio) if a.doscientos \
            else parse_pdf(a.pdf, ejercicio=a.ejercicio)
        print(_json.dumps(_resumen_precarga_deidentificado(prec), ensure_ascii=False, indent=2))
        return
    if not a.xml:
        ap.error("indica --xml <previo.xml>, --doscientos <previo.200> o --pdf <previo.pdf>")
    prev = parse_xml(a.xml)
    print(f"OK · ejercicio previo={prev['ejercicio']} · rama={prev['rama']} · casillas={len(prev['casillas'])}")
    if a.out:
        with open(a.out, "w", encoding="utf-8-sig", newline="") as f:
            w = csv.writer(f, delimiter=";"); w.writerow(["casilla", "importe_previo"])
            for c in sorted(prev["casillas"]): w.writerow([c, round(prev["casillas"][c], 2)])
    if a.actual:
        difs = comparar(prev, a.actual)
        print(f"Comparativa con actual: {len(difs)} casillas")
        for d in difs[:12]:
            print(f"  {d['casilla']}: previo={d['previo']} actual={d['actual']} Δ={d['delta']}")

if __name__ == "__main__":
    main()
