#!/usr/bin/env python3
"""extractor_markdown.py — Partidas estructuradas desde el Markdown del OCR (Docling) [D14+].

El OCR por servicio (Opción 1, `ocr_client`) devuelve Markdown con **tablas** (Layout + TableFormer):

    | Partida | Notas | 2024 | 2023 |
    |---|---|---|---|
    | Inmovilizado material | 5 | 1.234.567,89 | 1.100.000,00 |
    | Total activo no corriente | | 9.000.000,00 | 8.500.000,00 |

Este módulo convierte ese Markdown en **partidas** `{etiqueta, importe, importes[], multi, fila}` mucho
más fiel que la heurística de una sola línea (`extractor_ccaa.candidatos`). Es para **cuentas anuales en
PDF** (inferencia, NO fuente de verdad): toda partida va a revisión humana (HITL). Aplica el filtro de
agregación (estilo "Aduana Matemática" de persona_tax): salta filas de Total/Subtotal/cabecera/separador.

Números en formato español: `1.234.567,89`, `(1.234)` y `1.234-` como negativos. Determinista, stdlib.
"""
from __future__ import annotations

import re
from typing import List, Optional

# Filas de agregación a saltar (no son partidas elementales): total, subtotal, suma…
_AGG_RE = re.compile(
    r"\b(total(?:es)?|subtotal|suma\s+de|importe\s+neto\s+de\s+la\s+cifra)\b", re.IGNORECASE
)
# Una celda "numérica" candidata a importe (admite miles con punto/espacio, decimales, paréntesis, signo).
_NUM_CELL = re.compile(r"^[-(]?\d[\d.\s]*(?:,\d+)?\)?-?$")
# ¿Parece monetario? tiene decimales ",dd" o ≥4 dígitos (descarta refs de nota tipo "5").
_DEC2 = re.compile(r",\d{2}\b")


def _num(s: str) -> Optional[float]:
    """Parsea un número en formato español. Devuelve None si no es numérico."""
    t = (s or "").strip().replace("\xa0", " ")
    if not t:
        return None
    neg = t.startswith("-") or t.endswith("-") or (t.startswith("(") and t.endswith(")"))
    t = t.strip().lstrip("-").rstrip("-").strip("()").strip()
    t = t.replace(".", "").replace(" ", "").replace(",", ".")
    if not re.match(r"^\d+(\.\d+)?$", t):
        return None
    v = float(t)
    return -v if neg else v


def _es_monetario(cell: str) -> bool:
    """¿La celda parece un importe? decimales ",dd", separador de miles, o ≥5 dígitos.

    Excluye enteros de 4 dígitos (años de cabecera tipo 2024) y refs de nota (un dígito).
    """
    c = cell.strip()
    if _DEC2.search(c):
        return True
    if re.search(r"\d[.\s]\d", c):  # separador de miles (1.234 / 1 234)
        return True
    return len(re.sub(r"\D", "", c)) >= 5


def _es_anyo(v: Optional[float]) -> bool:
    return v is not None and float(v).is_integer() and 1900 <= v <= 2100


def _celdas(linea: str) -> Optional[list]:
    """Devuelve las celdas de una fila Markdown `| a | b |`, o None si no es fila de tabla."""
    ln = linea.strip()
    if not (ln.startswith("|") or ln.count("|") >= 2):
        return None
    return [c.strip() for c in ln.strip("|").split("|")]


def _es_separador(celdas: list) -> bool:
    vis = [c for c in celdas if c]
    return bool(vis) and all(re.match(r"^:?-{2,}:?$", c) for c in vis)


def _siguiente_no_vacia(lineas: list, i: int) -> str:
    for j in range(i + 1, len(lineas)):
        if lineas[j].strip():
            return lineas[j].strip()
    return ""


def extraer_partidas(markdown: str) -> List[dict]:
    """Markdown (OCR) -> [{etiqueta, importe, importes[], multi, fila}]. Salta totales/cabeceras."""
    partidas: List[dict] = []
    lineas = markdown.splitlines()
    for i, raw in enumerate(lineas):
        ln = raw.strip()
        if not ln:
            continue
        celdas = _celdas(ln)
        if celdas is not None:
            if _es_separador(celdas):
                continue
            # Cabecera de tabla: la fila inmediatamente seguida de un separador `|---|---|`.
            sig = _celdas(_siguiente_no_vacia(lineas, i))
            if sig is not None and _es_separador(sig):
                continue
        else:
            # Línea plana "etiqueta ……… importe" (sin tabla): un único importe al final.
            m = re.search(r"(.+?)\s+([-(]?\d[\d.\s]*,\d{2}\)?-?)\s*$", ln)
            if not m:
                continue
            celdas = [m.group(1).strip(), m.group(2).strip()]

        nums = [(c, _num(c)) for c in celdas if _num(c) is not None]
        textos = [c for c in celdas if c and _num(c) is None]
        if not nums or not textos:
            continue
        etiqueta = max(textos, key=len)
        if not re.search(r"[A-Za-zÁÉÍÓÚÑáéíóúñ]", etiqueta):
            continue
        if _AGG_RE.search(etiqueta):  # fila de agregación -> no es partida elemental
            continue
        importes = [v for _, v in nums]
        monetarios = [v for c, v in nums if _es_monetario(c)]
        # Fila de solo años (cabecera sin separador): no es partida.
        if not monetarios and all(_es_anyo(v) for v in importes):
            continue
        # Importe elegido: la PRIMERA celda monetaria. Si NINGUNA celda parece monetaria, el único número
        # es una ref de nota / código: NO es un importe -> `dudoso`, importe None (no inventar; el
        # consumidor lo omite + a_confirmar). Antes se cogía max(importes) y colaba el nº de nota al
        # número firmado (Codex HIGH + auto-revisión T1.2).
        dudoso = not monetarios
        elegido = None if dudoso else monetarios[0]
        partidas.append({
            "etiqueta": etiqueta[:90],
            "importe": None if elegido is None else round(elegido, 2),
            "importes": [round(x, 2) for x in importes],
            # `multi` = ambigüedad real de ejercicio = varias columnas MONETARIAS (no la columna de nota).
            "multi": len(monetarios) > 1,
            "dudoso": dudoso,
            "fila": i,
        })
    return partidas


if __name__ == "__main__":
    import json
    import sys

    md = sys.stdin.read()
    print(json.dumps(extraer_partidas(md), ensure_ascii=False, indent=1))
