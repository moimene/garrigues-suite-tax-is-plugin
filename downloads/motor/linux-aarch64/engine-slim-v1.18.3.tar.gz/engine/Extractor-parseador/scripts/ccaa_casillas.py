#!/usr/bin/env python3
"""ccaa_casillas.py — Matcher CCAA → casillas AEAT (EPIC B, 2026-06-25). DETERMINISTA.

Toma PARTIDAS del balance/PyG de las cuentas anuales (`{etiqueta, importe}`; p. ej. las que produce
`extractor_markdown` sobre el Markdown del OCR de la CCAA) y las asigna a CASILLAS del Modelo 200 contable
casando la ETIQUETA contra el RÓTULO oficial del catálogo (`catalogo_contable.json` → `por_casilla`):
  1) coincidencia EXACTA normalizada (sin colisiones)   2) ALIAS conocido (`_ALIASES`)   3) INFERENCIA fuzzy
Carga asistida (Cowork): exacto/alias entran; lo fuzzy se marca «inferida» (revisar); lo demás «sin_mapear».
NO inventa.

ROL (2026-06-25, EPIC B LLM-primario): la lectura primaria de la CCAA la hace el **LLM por visión** (skill
`ccaa-a-sys-a3`), que infiere el Sumas y Saldos y captura los totales declarados; el motor lo verifica y firma.
Este matcher es un **cross-check determinista OPCIONAL**: dadas las PARTIDAS de la CCAA (que puede extraer el
propio LLM, sin OCR), confirma a qué casilla cae cada etiqueta. `ccaa_a_casillas` (vía OCR/Docling) queda como
**fallback** para escaneados que el LLM no pueda leer. El parser comprueba; no sustituye al LLM.
"""
from __future__ import annotations

import re
import unicodedata
from difflib import SequenceMatcher

# Alias de etiquetas de la CCAA cuyo rótulo difiere del del catálogo AEAT (carga asistida; ampliar por casos).
# Clave = etiqueta normalizada (_norm); valor = casilla. Se aplican ENTRE el match exacto y el fuzzy.
_ALIASES = {
    "creditos a largo plazo con partes vinculadas": "00120",   # -> Créditos a empresas (grupo/asoc, l/p)
    "creditos a corto plazo con partes vinculadas": "00162",   # -> Créditos a empresas (grupo/asoc, c/p)
}


def _norm(s) -> str:
    s = unicodedata.normalize("NFKD", str(s or "")).encode("ascii", "ignore").decode()
    return re.sub(r"[^a-z0-9 ]", " ", s.lower()).strip()


def _rotulo(v) -> str:
    if isinstance(v, dict):
        return v.get("etiqueta") or v.get("rotulo") or v.get("denominacion") or v.get("desc") or ""
    return str(v)


def _indices(por_casilla):
    """{rótulo normalizado → casilla} EXACTO (sin colisiones) + nombres/tokens para la inferencia fuzzy."""
    exact, col, nn, nt = {}, set(), {}, {}
    for cas, v in por_casilla.items():
        k = _norm(_rotulo(v))
        if not k:
            continue
        if k in exact and exact[k] != cas:
            col.add(k)
        else:
            exact[k] = cas
        nn[cas] = k
        nt[cas] = frozenset(t for t in k.split() if len(t) >= 2)
    for k in col:
        exact.pop(k, None)
    return exact, nn, nt


def _fuzzy(etiqueta, nn, nt, floor=0.6):
    dn = _norm(etiqueta)
    if not dn:
        return None, 0.0
    dtok = frozenset(t for t in dn.split() if len(t) >= 2)
    best, sc = None, 0.0
    for cas, nm in nn.items():
        seq = SequenceMatcher(None, dn, nm).ratio()
        tk = nt.get(cas, frozenset())
        tok = (len(dtok & tk) / len(dtok | tk)) if (dtok or tk) else 0.0
        s = 0.5 * seq + 0.5 * tok
        if s > sc:
            best, sc = cas, s
    return (best, round(sc, 3)) if sc >= floor else (None, round(sc, 3))


def mapear(partidas, por_casilla, floor=0.6) -> dict:
    """partidas: [{etiqueta, importe}] → {casillas, mapeadas, sin_mapear, resumen}. Suma por casilla."""
    exact, nn, nt = _indices(por_casilla)
    casillas, mapeadas, sin = {}, [], []
    for p in partidas:
        if isinstance(p, dict):
            et, imp = p.get("etiqueta"), p.get("importe")
        elif isinstance(p, (list, tuple)):
            et, imp = (p[0] if p else ""), (p[1] if len(p) > 1 else None)
        else:
            et, imp = str(p), None
        cas = exact.get(_norm(et))
        metodo, sc = "exacto", 1.0
        if not cas and _norm(et) in _ALIASES:
            cas, metodo, sc = _ALIASES[_norm(et)], "alias", 1.0
        if not cas:
            cas, sc = _fuzzy(et, nn, nt, floor)
            metodo = "inferida" if cas else "sin_mapear"
        if cas and imp is not None:
            casillas[cas] = round(casillas.get(cas, 0.0) + float(imp), 2)
            mapeadas.append({"etiqueta": et, "casilla": cas, "importe": imp, "metodo": metodo, "score": sc})
        else:
            sin.append({"etiqueta": et, "importe": imp, "score": sc})
    return {
        "casillas": casillas, "mapeadas": mapeadas, "sin_mapear": sin,
        "resumen": {"n": len(partidas), "mapeadas": len(mapeadas), "sin_mapear": len(sin),
                    "exactas": sum(1 for m in mapeadas if m["metodo"] == "exacto"),
                    "inferidas": sum(1 for m in mapeadas if m["metodo"] == "inferida")},
    }


def ccaa_a_casillas(pdf_path, por_casilla, floor=0.6) -> dict:
    """Orquesta la CADENA completa CCAA(PDF) → casillas:
        OCR (`ocr_client.convertir`, persona_tax) → Markdown → partidas (`extractor_markdown.extraer_partidas`)
        → matcher (`mapear`).
    Requiere `OCR_SERVICE_URL` configurado (si no, devuelve casillas vacías con el motivo del OCR). Degrada con
    gracia (el OCR nunca lanza). El resultado es un BORRADOR de carga asistida (HITL): revisar lo «inferida».
    """
    import os
    import sys
    _here = os.path.dirname(os.path.abspath(__file__))
    _repo = os.path.dirname(os.path.dirname(_here))
    for _p in (_here, os.path.join(_repo, "engine_service")):
        if _p not in sys.path:
            sys.path.insert(0, _p)
    import ocr_client          # noqa: E402  (HTTP a persona_tax)
    import extractor_markdown  # noqa: E402  (Markdown OCR → partidas)
    r = ocr_client.convertir(path=pdf_path)
    md = (r.get("markdown") or "") if isinstance(r, dict) else ""
    if not md:
        return {"casillas": {}, "mapeadas": [], "sin_mapear": [], "resumen": {"n": 0},
                "ocr": (r.get("motivo") if isinstance(r, dict) else "sin markdown")}
    partidas = extractor_markdown.extraer_partidas(md)
    out = mapear(partidas, por_casilla, floor)
    out["ocr"] = {"backend": r.get("backend"), "tablas": r.get("tablas"), "n_partidas": len(partidas)}
    return out
