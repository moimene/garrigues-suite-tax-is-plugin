"""Validador de CUADRE de la proyección normal->abreviado (gate de completitud).

Cada IMPORTE-hoja del .200 normal debe tener UN destino en una casilla emitible-en-abreviado. Si una hoja
queda sin destino, su importe se PIERDE y el balance abreviado descuadra -> Open lo rechaza.

Destino de una hoja-hoja L (casilla SIN fórmula cap04, valor!=0):
  - L mismo, si L es 'emitible-abreviado' (marcador A y sin hijos-A en el árbol de fórmulas) -> identidad.
  - el target del rollup cuyo 'from' contiene L.
  - el ancestro más cercano por el árbol de fórmulas cap04 que sea emitible-abreviado.
  - si nada -> PERDIDA (reportar).

Determinista, 0 PII (solo imprime códigos de casilla y conteos, nunca importes).
"""
from __future__ import annotations

import sys
from decimal import Decimal
from pathlib import Path

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
from extraer_perfiles_cap04 import parse_cap04  # noqa: E402
from transformar_200_abreviado import (Declaracion200, cargar_catalogo, cargar_rollups,  # noqa: E402
                                       cargar_xsd_importables)


def construir_arbol():
    """{casilla: set(hijos)} desde las fórmulas embebidas de cap04 (régimen general)."""
    arbol = {}
    for sec, ents in parse_cap04().items():
        for e in ents:
            if e["formula"]:
                arbol.setdefault(e["casilla"], set()).update(e["formula"])
    return arbol


def marcadores():
    cat = cargar_catalogo()["casillas"]
    return {c: set(m.get("modelos", [])) for c, m in cat.items()}, cat


def emitible_abreviado(cas, arbol, mk, letra="A"):
    """`letra`-marcado y SIN hijos `letra` (en ese perfil es una hoja donde se entra el importe).
    letra='A' abreviado · 'P' PYMES."""
    if letra not in mk.get(cas, set()):
        return False
    hijos = arbol.get(cas, set())
    return not any(letra in mk.get(h, set()) for h in hijos)


def ancestros(cas, arbol):
    """casillas que tienen a `cas` (directa o transitivamente) como descendiente."""
    padres = {p for p, hs in arbol.items() if cas in hs}
    out = set(padres)
    for p in list(padres):
        out |= ancestros(p, arbol)
    return out


def destino(L, arbol, mk, from2target, targets_set=frozenset(), letra="A"):
    if L in targets_set:                       # un target declarado es emitible (carrier)
        return L, "target"
    if emitible_abreviado(L, arbol, mk, letra):
        return L, "identidad"
    if L in from2target:
        return from2target[L], "rollup"
    # ancestro emitible más cercano (BFS por niveles)
    nivel = {p for p, hs in arbol.items() if L in hs}
    visto = set()
    while nivel:
        cand = sorted(c for c in nivel if emitible_abreviado(c, arbol, mk, letra))
        if cand:
            return cand[0], "ancestro"
        visto |= nivel
        nivel = {p for c in nivel for p, hs in arbol.items() if c in hs} - visto
    return None, "PERDIDA"


def validar(entidad_path, familias=("balance",), perfil="abreviado"):
    letra = {"abreviado": "A", "pymes": "P"}[perfil]
    arbol = construir_arbol()
    mk, cat = marcadores()
    rol = cargar_rollups()
    from2target = {}
    targets_set = set()
    for fam in familias:
        for t, r in rol.get("targets", {}).get(perfil, {}).get(fam, {}).items():
            targets_set.add(t)
            for s in r.get("from", []):
                from2target[s] = t
    calc = rol.get("calculada_en_abreviado", {})
    calc_set = {c for fam in familias for c in calc.get(fam, [])}
    if perfil == "pymes":   # subtotales que abreviado emite pero PYMES recompone (p.ej. 00202 -> 00208 vía detalle)
        calcp = rol.get("calculada_en_pymes", {})
        calc_set |= {c for fam in familias for c in calcp.get(fam, [])}
    fam_pags = {"balance": ["DP200003", "DP200004", "DP200005", "DP200006"],
                "pyg": ["DP200007", "DP200008"], "ecpn": ["DP200009", "DP200010", "DP200011"]}
    pags = [p for f in familias for p in fam_pags[f]]
    xsd = cargar_xsd_importables()
    d = Declaracion200(entidad_path)
    perdidas, destinos = [], {}
    for pag in pags:
        if not d._page_span(pag):
            continue
        for c in d.presentes(pag):
            if arbol.get(c):   # tiene fórmula => subtotal, no es hoja-hoja
                continue
            if c not in xsd.get(pag, set()) or c in calc_set:   # calculada => Open la recalcula, no es hoja
                continue
            dest, via = destino(c, arbol, mk, from2target, targets_set, letra)
            if dest is None:
                perdidas.append(c)
            else:
                destinos.setdefault(via, []).append(c)
    return {"perdidas": sorted(set(perdidas)), "n_destinos": {k: len(v) for k, v in destinos.items()}}


if __name__ == "__main__":
    import argparse, json  # noqa: E401
    ap = argparse.ArgumentParser()
    ap.add_argument("paths", nargs="+")
    ap.add_argument("--familias", default="balance")
    ap.add_argument("--perfil", default="abreviado", choices=["abreviado", "pymes"])
    a = ap.parse_args()
    fams = tuple(x.strip() for x in a.familias.split(",") if x.strip())
    for p in a.paths:
        r = validar(p, familias=fams, perfil=a.perfil)
        nombre = Path(p).stem
        print(f"{nombre}: perdidas={r['perdidas']} | destinos={r['n_destinos']}")
