"""Perfiles de estados contables del Modelo 200 (normal / abreviado / PYMES).

Spec: docs/MODELO200_2025_PERFILES_ESTADOS_CONTABLES_IMPLEMENTACION.md (PEC-001/006).

DP200001B declara qué modelo se cumplimenta: campo 14 Balance · 15 ECPN · 16 PyG
(0 No consta · 1 Normal · 2 Abreviado · 3 PYMES). La AEAT valida la COHERENCIA entre el perfil declarado y las
casillas emitidas. En v1.18 el motor soporta normal, abreviado y PYMES mediante proyección de estados contables.
En el `.200`, el ECPN abreviado/PYMES se omite siempre (campo 15 = 0) porque es voluntario y se entrega por el XML
contable; Balance y PyG se declaran según la configuración/precarga del expediente. Determinista, 0 PII.
"""
from __future__ import annotations

from dataclasses import dataclass

PERFIL_A_CODIGO = {"normal": 1, "abreviado": 2, "pymes": 3, "no_consta": 0}
CODIGO_A_PERFIL = {0: "no_consta", 1: "normal", 2: "abreviado", 3: "pymes"}
PERFILES_VALIDOS = {"normal", "abreviado", "pymes"}
# v1.18: normal, abreviado y PYMES están soportados. La excepción operativa vive en el emisor del `.200`:
# para abreviado/PYMES no se emiten DP200009/10/11 y DP200001B campo 15 queda en 0 (no consta).
PERFILES_SOPORTADOS = {"normal", "abreviado", "pymes"}


def normalizar_perfil(v):
    """Acepta 'normal'/'abreviado'/'pymes', los códigos 1/2/3, o 0/''/None (=no consta → None).
    Devuelve el perfil canónico, None (no consta) o 'DESCONOCIDO' (valor inesperado → bloquea)."""
    if v is None:
        return None
    s = str(v).strip().lower()
    if s in PERFILES_VALIDOS:
        return s
    if s in ("", "0", "no_consta", "no consta", "nc"):
        return None
    return {"1": "normal", "2": "abreviado", "3": "pymes"}.get(s, "DESCONOCIDO")


@dataclass(frozen=True)
class PerfilEstadosContables:
    """Perfil por familia (balance/ecpn/pyg) + procedencia. `fuente`/`confirmado` documentan de dónde viene."""
    balance: str = "normal"
    ecpn: str = "normal"
    pyg: str = "normal"
    fuente: str = "default"
    confirmado: bool = False
    config_version: str | None = None

    def codigo_balance(self) -> int:
        return PERFIL_A_CODIGO.get(self.balance, 1)

    def codigo_ecpn(self) -> int:
        return PERFIL_A_CODIGO.get(self.ecpn, 1)

    def codigo_pyg(self) -> int:
        return PERFIL_A_CODIGO.get(self.pyg, 1)

    def familias(self) -> dict:
        return {"balance": self.balance, "ecpn": self.ecpn, "pyg": self.pyg}

    def es_todo_normal(self) -> bool:
        return all(p == "normal" for p in (self.balance, self.ecpn, self.pyg))

    def soportado(self) -> bool:
        """True solo si TODAS las familias usan un perfil soportado."""
        return all(p in PERFILES_SOPORTADOS for p in (self.balance, self.ecpn, self.pyg))

    def familias_no_soportadas(self) -> list:
        return [f for f, p in self.familias().items() if p not in PERFILES_SOPORTADOS]


def _perfil_de_fuente(src, default):
    """Una fuente (str para las 3 familias, o dict por familia) → PerfilEstadosContables parcial, o None si la
    fuente no aporta nada. 'DESCONOCIDO' se conserva (lo bloquea quien resuelve/valida)."""
    if not src:
        return None
    if isinstance(src, str):
        p = normalizar_perfil(src)
        if p and p != "DESCONOCIDO":
            return (p, p, p)
        if p == "DESCONOCIDO":
            return ("DESCONOCIDO",) * 3
        return None
    if isinstance(src, dict):
        b, e, g = (normalizar_perfil(src.get("balance")), normalizar_perfil(src.get("ecpn")),
                   normalizar_perfil(src.get("pyg")))
        if any(x for x in (b, e, g)):
            return (b or default, e or default, g or default)
    return None


def resolver_perfil_estados(*, expediente_config=None, solicitud_usuario=None, pagina01b_perfil=None,
                            precarga_n1_perfil=None, ccaa_perfil=None, default="normal") -> PerfilEstadosContables:
    """Resuelve el perfil por PRIORIDAD (spec §6): config confirmada > usuario > pagina01b > N-1 > CCAA > default.
    Las fuentes de menor prioridad solo PROPONEN; una config confirmada no se pisa. 0/'' (no consta) no pisa un
    valor de mayor prioridad."""
    if expediente_config and expediente_config.get("confirmado"):
        pe = expediente_config.get("perfil_estados") or {}
        return PerfilEstadosContables(
            balance=normalizar_perfil(pe.get("balance")) or default,
            ecpn=normalizar_perfil(pe.get("ecpn")) or default,
            pyg=normalizar_perfil(pe.get("pyg")) or default,
            fuente="expediente_config", confirmado=True,
            config_version=str(expediente_config.get("config_version") or "") or None)
    for fuente, src in (("usuario", solicitud_usuario), ("pagina01b", pagina01b_perfil),
                        ("justificante_n1", precarga_n1_perfil), ("ccaa", ccaa_perfil)):
        trip = _perfil_de_fuente(src, default)
        if trip:
            return PerfilEstadosContables(trip[0], trip[1], trip[2], fuente=fuente)
    return PerfilEstadosContables(default, default, default, fuente="default")
