"""Autocontrol del `.200` ANTES de importar en la AEAT.

Valida las reglas de consistencia que el importador de Sociedades WEB recalcula y que hemos ido descubriendo
importación a importación (roll-up del balance/PyG, identidades de cuadre, desglose de BINs, web de gastos
financieros del art. 16, reserva de capitalización = resultado, matriz última = declarante, datos de la DID).
Devuelve la lista de incumplimientos para corregirlos SIN gastar una importación — rompe el bucle de
"un error por importación tumba la declaración entera".

Es un control LOCAL y honesto (regla dura 5): no replica todo el motor AEAT, solo las reglas verificadas
contra importaciones reales del caso GIP. Cada regla cita su error AEAT. 0 PII (opera sobre casillas).

Uso:

- `validar(...)`: autocontrol legacy, devuelve incumplimientos simples.
- `validar_importabilidad(...)`: capa nueva, devuelve informe estructurado DR + autocontrol + HITL/Open.
"""
import re

import modelo200_parser as mp

_TOL = 0.01
SUBTOTALES_NO_IMPORTABLES_200 = {"00208"}  # OpenWeb recalcula/rechaza contenido no cero (E25400208).


def casillas_por_pagina(doc, dr):
    """{pagina: {casilla: float}} del `.200`, PAGE-AWARE — delega en el parser ESTRUCTURAL `modelo200_parser`
    (decodifica el ancho fijo, respeta homónimos entre páginas, distingue casilla/constante/campo_pos). Separa
    PARSEAR (modelo200_parser, sin reglas) de VALIDAR (este módulo, las reglas). Toma la primera ocurrencia."""
    parsed = mp.parse_text(doc, dr, include_fields=True)
    cpp = mp.casillas_por_pagina(parsed, significant_only=False)
    out = {}
    for page, casillas in cpp.items():
        d = {}
        for cas, entries in casillas.items():
            v = entries[0]["valor"] if entries else "0"
            try:
                d[cas] = float(v)
            except (ValueError, TypeError):
                d[cas] = 0.0
        out[page] = d
    return out


def validar(doc, dr, ejercicio="2025", subtotales=None, bin_limite_pct=None):
    """Lista de incumplimientos {regla, error_aeat, detalle, pagina}. Vacía = el `.200` es internamente
    consistente según las reglas conocidas (no garantiza import limpio, pero descarta lo ya aprendido).
    `bin_limite_pct` (0.70/0.50/0.25 según tramo INCN art.26): si se pasa, comprueba el límite de compensación
    de BINs (EMR01520)."""
    cp = casillas_por_pagina(doc, dr)
    viol = []

    def val(pg, c):
        return cp.get(pg, {}).get(c, 0.0)

    def chk(ok, regla, error, detalle, pagina="", bloqueante=True):
        if not ok:
            viol.append({"regla": regla, "error_aeat": error, "detalle": detalle, "pagina": pagina,
                         "bloqueante": bloqueante})

    def eq(a, b):
        return abs(a - b) < _TOL

    # --- 1) Roll-up del balance/PyG: cada subtotal = Σ de sus componentes (en su misma página) ---
    pg_de = {}
    for pg, campos in dr.items():
        for c in campos:
            if c.get("casilla"):
                pg_de.setdefault(c["casilla"], pg)
    for sub, comp in (subtotales or {}).items():
        if sub in SUBTOTALES_NO_IMPORTABLES_200:
            continue
        pg = pg_de.get(sub)
        if not pg:
            continue
        s = round(sum(val(pg, c) for c in comp), 2)
        chk(eq(val(pg, sub), s), f"subtotal {sub}=Σcomp", "E254..",
            f"{sub}={val(pg, sub)} pero Σ{comp}={s}", pg)

    # --- 2) Identidades de cuadre ---
    chk(eq(val("DP200004", "00180"), val("DP200006", "00252")), "ACTIVO=PN+PASIVO", "—",
        f"00180={val('DP200004','00180')} vs 00252={val('DP200006','00252')}")
    chk(eq(val("DP200008", "00327"), val("DP200012", "00500")) or val("DP200012", "00500") == 0,
        "resultado 00327=00500", "—",
        f"00327={val('DP200008','00327')} vs 00500(p12)={val('DP200012','00500')}")

    # --- 2b) Cascada de la liquidación (las identidades que el importador recalcula y que tumbaron la BI) ---
    r501 = val("DP200012", "00501")
    a417 = val("DP200013", "00417")
    d418 = val("DP200013", "00418")
    bip = val("DP200014", "00550")
    bi = val("DP200014", "00552")
    comp = val("DP200014", "00547")
    # R1.a (veredicto del juez): puente 00501 = 00500 + 00301 − 00302 (resultado contable corregido por IS).
    # 00301 = gasto por IS (aumento, +), 00302 = ingreso por IS (disminución, +). Se valida sobre las casillas
    # FINALES del .200 (tras la reubicación de signo de engines). Solo si la página 12 trae el resultado contable.
    r500_12 = val("DP200012", "00500")
    if r501 or r500_12:
        c301 = val("DP200012", "00301")
        c302 = val("DP200012", "00302")
        chk(eq(r501, round(r500_12 + c301 - c302, 2)), "00501=00500+00301−00302", "EMAL501",
            f"00501={r501} vs 00500+00301−00302={round(r500_12 + c301 - c302, 2)}", "DP200012")
    if r501 or a417 or d418 or bip:
        # BI previa = resultado contable corregido + aumentos − disminuciones (lo que rompió la diferencia
        # temporal de GF cuando 00363 subía sin su 00364): el invariante que guarda ese fix.
        chk(eq(bip, round(r501 + a417 - d418, 2)), "BI previa 00550=00501+00417−00418", "EMALP13_2",
            f"00550={bip} vs 00501+00417−00418={round(r501 + a417 - d418, 2)}", "DP200014")
        # NOTA (auditoría adversarial codex 2026-06-19): NO se valida "00340=00417"/"02301=00417". Según el DR,
        # 00340 (DP200013) es la línea "Impuesto extranjero soportado - Aumentos" y 02301 (DP200020B) es
        # "Corrección PERMANENTE - Aumentos"; 00417 es el TOTAL. Solo coinciden porque el harness agrupa todas
        # las correcciones en una línea — es una invariante del HARNESS, no del importador (daría falso positivo
        # si el detalle se repartiera). El invariante real es 00417=Σ(líneas de aumento), que aquí es trivial.
    if bip or bi:
        # BI = BI previa − compensación de BINs (00552 = 00550 − 00547).
        chk(eq(bi, round(bip - comp, 2)), "BI 00552=00550−00547", "E25400552",
            f"00552={bi} vs 00550−00547={round(bip - comp, 2)}", "DP200014")
    if bin_limite_pct and (comp or bip):
        # Límite de compensación de BINs art. 26: 00547 ≤ max(1M, %tramo × BI previa) — error EMR01520.
        # GUARDA (auditoría codex 2026-06-19): las "rentas que no limitan la compensación" (quitas/esperas y
        # reversiones, casillas 00545/00925/01509 de DP200014) elevan el tope legítimamente; si están pobladas,
        # el tope simple NO aplica → no marcar (evita falso positivo). Tampoco se prorratea el millón si el
        # período es < 1 año (el harness es 0A, período completo): documentado, no contemplado aquí.
        excep = any(val("DP200014", c) for c in ("00545", "00925", "01509"))
        if not excep:
            limite = max(1_000_000.0, round(bin_limite_pct * bip, 2))
            chk(comp <= limite + _TOL, "BINs 00547≤límite art.26", "EMR01520",
                f"00547={comp} > límite({int(bin_limite_pct * 100)}%×00550={bip})={limite}", "DP200015")

    # --- 3) Desglose de BINs (página 15): 00547 = Σ aplicado por año; 00671 = 00670 − 00547 ---
    aplicado = sum(val("DP200015", c) for c in ("01046", "01520", "01593", "01826", "02194", "00195", "00152",
                                                "00897", "00010", "03403"))
    if val("DP200015", "00547") or aplicado:
        chk(eq(val("DP200015", "00547"), round(aplicado, 2)), "BINs 00547=Σaplicado", "EMD00547/E25400547",
            f"00547={val('DP200015','00547')} vs Σaplicado={round(aplicado,2)}", "DP200015")
        chk(eq(val("DP200015", "00671"), round(val("DP200015", "00670") - val("DP200015", "00547"), 2)),
            "BINs 00671=00670−00547", "E25400671", "futuro≠pendiente−compensado", "DP200015")

    # --- 4) Web de gastos financieros (página 20, art. 16) ---
    g = lambda c: val("DP200020", c)
    if g("01256") or g("02369"):
        chk(g("01256") <= g("02369") + _TOL, "GF 01256≤02369", "22890", f"01256={g('01256')}>02369={g('02369')}", "DP200020")
        chk(eq(g("01214"), g("01256")), "GF 01214=01256", "E25401214", f"01214={g('01214')}", "DP200020")
        chk(eq(g("03585"), g("01256")), "GF 03585=01256", "22820", f"03585={g('03585')}", "DP200020")
        chk(eq(g("03587"), g("01257")), "GF 03587=01257", "22940", f"03587={g('03587')}", "DP200020")
        # 01260 (total GF no deducibles) = c2 (01243, no deducible bloque 1 art.16.5) + l2 (01257, no deducible
        # bloque 2 art.16.1). Para una ETVE (bloque 1) c2>0; para GF ordinarios (bloque 2) 01243=0 → 01260=01257.
        chk(eq(g("01260"), round(g("01243") + g("01257"), 2)), "GF 01260=01243+01257", "E25401260",
            f"01260={g('01260')} vs 01243+01257={round(g('01243') + g('01257'), 2)}", "DP200020")
        chk(eq(g("01216"), g("01257")), "GF 01216=01257", "E25401216", f"01216={g('01216')}", "DP200020")
        # Identidades del bloque "límite art.16" (aprendidas del import GIP 2025). 01248 (gasto neto) lo RECALCULA
        # el importador y NO se emite (E25401248) → solo se chequean 22880/22895 si el `.200` trae 01248.
        if g("01248"):
            chk(eq(round(g("01256") + g("01257"), 2), g("01248")), "GF 01256+01257=01248", "22880",
                f"01256+01257={round(g('01256') + g('01257'), 2)} vs 01248={g('01248')}", "DP200020")
            # 01257 (GF no deducible, pendiente futuro) = max(0, 01248−02369): cuando el GF neto NO supera el
            # límite (02369, con suelo 1M), NO hay exceso y 01257=0. El tope correcto es max(0,·); sin el suelo
            # a cero, toda sociedad con GF neto < 1M (RHS negativo) fallaba en falso (REDEVCO/ARIOSO 2026-06-28).
            _exceso_gf = max(0.0, round(g("01248") - g("02369"), 2))
            chk(g("01257") <= _exceso_gf + _TOL, "GF 01257≤max(0,01248−02369)", "22895",
                f"01257={g('01257')} > max(0,01248−02369)={_exceso_gf}", "DP200020")
        # Límite total a la deducción = límite del período + adición B.O. ejercicios anteriores (Manual pág 291):
        # 02369 = 01249 + 01255 (cuando el GF neto supera 01249 y 01249 > 1M). Era el bug que dejaba 01257 ficticio.
        if g("01255"):
            chk(eq(g("02369"), round(g("01249") + g("01255"), 2)), "GF 02369=01249+01255", "E25402369",
                f"02369={g('02369')} vs 01249+01255={round(g('01249') + g('01255'), 2)}", "DP200020")
        chk(eq(val("DP200012", "00364"), round(g("01258") + g("01259"), 2)), "GF 00364=01258+01259", "9461",
            f"00364={val('DP200012','00364')} vs 01258+01259={round(g('01258') + g('01259'), 2)}", "DP200020/DP200012")
        # 9460: 01260 (GF no deducible) ↔ 00363 (ajuste pág 12). El importador DERIVA 00363 desde la página 20,
        # así que el `.200` NO lo emite explícito (evita el doble conteo en 00417): por eso aquí, si 00363 está a
        # 0 con 01260>0, es el enfoque "vía única página 20" (correcto), no un incumplimiento. Solo se marca si
        # 00363 está emitido Y no coincide con 01260.
        if val("DP200012", "00363"):
            chk(eq(g("01260"), val("DP200012", "00363")), "GF 01260=00363", "9460",
                f"01260={g('01260')} vs 00363={val('DP200012','00363')}", "DP200020/DP200012")
        # Aviso (NO es código AEAT, es chequeo interno) — CRÍTICO: el "i1) Resultado de explotación" de la hoja GF
        # (01250) debería coincidir con el del PyG (00296). Si la hoja GF lo trae INFLADO respecto al PyG, está
        # forzando un beneficio operativo (BO) positivo y por tanto un límite GF (02369=30%·BO) más alto del real.
        # Al cuadrar 01250=00296 el importador recalcula 01249=30%·BO; si el BO REAL es negativo (típico en ETVE:
        # los ingresos son dividendos/plusvalías que NO van al resultado de explotación), 01249<0 y el límite cae
        # al SUELO de 1.000.000 € (art. 16.1) → más GF no deducibles, más 00363, más cuota. Es DECISIÓN FISCAL del
        # abogado (no se adivina): confirmar el resultado de explotación real y, si el BO es negativo, aplicar el
        # suelo de 1M. (Ver doc 2026-06-19, §"BO negativo".)
        # CORRECCIÓN 2026-06-21 (verificado contra import real, GIP 2025 presentada): este control es un AVISO DE REVISIÓN,
        # no un FRECH bloqueante. Si el B.O. de la hoja GF (01250) no concilia con el resultado de explotación
        # contable (00296), el límite 02369 cambia según el CRITERIO del abogado — leniente (01250 tal cual) o
        # estricto (conciliar con 00296, que puede bajar el límite al suelo de 1M art.16.1 y subir la cuota). Es
        # DECISIÓN FISCAL: NO se autocuadra. El .200 presentado (leniente) importó limpio con este
        # aviso → bloqueante=False. El abogado elige el criterio en el cuestionario (ver addendum UX criterio GF).
        # Codex finding 4: solo se compara si la entidad TRAE la página 7 (PyG/00296); sin ella no hay con qué
        # conciliar → no marcar (evita falso positivo en entidades con páginas contables no estándar).
        if "DP200007" in cp:
            chk(eq(g("01250"), val("DP200007", "00296")),
                "GF 01250=00296 resultado explotación (AVISO revisión: decisión de criterio GF)",
                "INT-GF-RE",
                f"resultado explotación hoja GF 01250={g('01250')} ≠ PyG 00296={val('DP200007','00296')} "
                f"(Δ={round(g('01250') - val('DP200007', '00296'), 2)}) — el límite GF (02369) depende del "
                f"criterio: leniente (01250 de la hoja GF tal cual) o estricto (conciliar 01250 con 00296, que "
                f"puede bajar el límite al suelo de 1M art.16.1 y subir la cuota). DECISIÓN FISCAL del abogado; "
                f"NO se autocuadra. El importador AEAT lo admite como AVISO (verificado contra import real "
                f"2026-06-21); no bloquea la firma.",
                "DP200020/DP200007", bloqueante=False)

    # --- 4b) Corrección por Impuesto sobre Sociedades (20966/20967): si 00326 (impuesto, pág 8) ≥ 0, la casilla
    # 00301 (pág 12) NO puede tener contenido y 00302 = 00326. El motor reubica el IS de 00301 a 00302. ---
    is_326 = val("DP200008", "00326")
    if is_326 > 0:
        chk(eq(val("DP200012", "00301"), 0.0), "IS 00301 sin contenido (00326≥0)", "20966",
            f"00301={val('DP200012','00301')}≠0", "DP200012", bloqueante=False)
        chk(eq(val("DP200012", "00302"), is_326), "IS 00302=00326", "20967",
            f"00302={val('DP200012','00302')} vs 00326={is_326}", "DP200012", bloqueante=False)

    # --- 5) Distribución del resultado (DP200020D, página 20 quater): base de reparto = aplicación ---
    # 00650 (base reparto PyG) = 00653 (base reparto total) = 00500 si 00500>0 (16200); y la APLICACIÓN total
    # 00666 = la base 00653 (16211: todo lo repartido se aplica). NO es "reserva de capitalización" ni
    # "nivelación" (malentendido anterior): es el cuadro de distribución del resultado.
    r500 = val("DP200012", "00500")
    if r500 > 0:
        for c in ("00650", "00653"):
            chk(eq(val("DP200020D", c), r500), f"distribución {c}=00500", "16200",
                f"{c}={val('DP200020D', c)} vs 00500={r500}", "DP200020D")
        chk(eq(val("DP200020D", "00666"), val("DP200020D", "00653")), "distribución 00666=00653", "16211",
            f"00666={val('DP200020D', '00666')} vs 00653={val('DP200020D', '00653')}", "DP200020D")
        # 00654 (a reservas) es subtotal de 01270(capitalización)+01271(nivelación)+01522(otras): el importador
        # lo recalcula desde el detalle (codex 2026-06-19). Solo se chequea si 00654 está poblado.
        d654 = val("DP200020D", "00654")
        if d654:
            sub = round(val("DP200020D", "01270") + val("DP200020D", "01271") + val("DP200020D", "01522"), 2)
            chk(eq(d654, sub), "distribución 00654=01270+01271+01522", "16210",
                f"00654={d654} vs Σdetalle={sub}", "DP200020D")

    # --- 6) Matriz última = declarante (si caracter 00082) ---
    r1b = re.search(r"<T20001B00>(.*?)</T20001B00>", doc)
    r1 = re.search(r"<T20001000>(.*?)</T20001000>", doc)
    es_matriz = bool(r1) and len(r1.group(0)) > 217 and ("<T20001000>" + r1.group(1))[216] == "1"
    if es_matriz and r1b:
        rec = "<T20001B00>" + r1b.group(1)
        faltan = [c.get("num") for c in dr.get("DP200001B", [])
                  if c.get("num") in (9, 10, 12) and not rec[c["posicion"] - 1:c["posicion"] - 1 + c["longitud"]].strip()]
        chk(not faltan, "matriz última completa", "10034/10042", f"campos vacíos {faltan}", "DP200001B")

    # --- 7) DID: importe a ingresar = 00621 (si a ingresar) ---
    rdid = re.search(r"<T200DID00>(.*?)</T200DID00>", doc)
    if rdid:
        rec = "<T200DID00>" + rdid.group(1)
        ing = int(re.sub(r"\D", "", rec[425:442] or "0")) / 100
        c621 = abs(val("DP200DID", "00621"))
        grupo_fiscal = bool(val("DP200001", "00009")) or bool(val("DP200001", "00010"))
        if c621 > 0 and not grupo_fiscal:
            chk(eq(ing, c621), "DID importe=00621", "EMALID10", f"ingreso={ing} vs 00621={c621}", "DP200DID")

    return viol


def validar_importabilidad(doc, dr, ejercicio="2025", subtotales=None, bin_limite_pct=None,
                           errores_aeat_text=None):
    """Informe completo de importabilidad probable.

    Es una fachada lazy para mantener `autocontrol_200.py` como punto de entrada historico sin mezclar aqui la
    capa nueva HITL. Devuelve el dict de `validacion_importabilidad_200.analizar(...)`.
    """
    import validacion_importabilidad_200 as importabilidad
    return importabilidad.analizar(doc, dr, ejercicio, subtotales=subtotales,
                                   bin_limite_pct=bin_limite_pct,
                                   errores_aeat_text=errores_aeat_text)


def validar_importabilidad_path(path, ejercicio="2025", errores_aeat_path=None, out_json=None, out_md=None):
    """Atajo de fichero para CLI/scripts de lote."""
    import validacion_importabilidad_200 as importabilidad
    return importabilidad.analizar_path(path, ejercicio=ejercicio, errores_aeat_path=errores_aeat_path,
                                        out_json=out_json, out_md=out_md)


def main():   # pragma: no cover
    import os
    import sys
    sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
    import json
    import dr200
    doc = open(sys.argv[1], encoding="latin1").read()
    ej = sys.argv[2] if len(sys.argv) > 2 else "2025"
    dr = dr200.cargar_dr(ejercicio=ej)
    ROOT = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
    sub = json.load(open(os.path.join(ROOT, "Extractor-parseador", "data", "campaigns", ej,
                                       "mapeo_pgc_aeat.json"), encoding="utf-8")).get("subtotales")
    viol = validar(doc, dr, ej, subtotales=sub)
    if not viol:
        print("AUTOCONTROL: ✓ sin incumplimientos conocidos")
    else:
        print(f"AUTOCONTROL: {len(viol)} incumplimiento(s):")
        for x in viol:
            print(f"  [{x['error_aeat']}] {x['regla']} — {x['detalle']} ({x['pagina']})")


if __name__ == "__main__":
    main()
