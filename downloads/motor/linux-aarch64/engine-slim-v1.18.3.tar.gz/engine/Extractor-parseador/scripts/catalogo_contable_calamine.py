#!/usr/bin/env python3
"""catalogo_contable_calamine.py — Catálogo contable + validaciones de formato del Modelo 200.

Variante de `catalogo_contable.py` que lee el diseño de registro oficial DR200e25.xls con
python-calamine (no xlrd) y, además del catálogo contable, emite las validaciones de FORMATO
por casilla (columnas Validación / Contenido / Tipo / Lon del diseño de registro).

Fuente oficial: diseño de registro DR200e25.xls (AEAT). Páginas contables DP200003-DP200011:
  Balance (págs. 3-6) · Cuenta de PyG (7-8) · Estado de cambios en el PN (9-11).

Estructura de cada hoja DP200xxx:
  filas 0-2: banner (Agencia Tributaria / Modelo 200 / vers.)
  fila   3 : cabecera  Nº | Posic. | Lon | Tipo | Descripción | Validación | Contenido
  filas 4+: datos. La CASILLA va embebida en la Descripción como [NNNNN]; cuando hay varios
            corchetes (referencias cruzadas) la casilla PROPIA del campo es la del FINAL.

IMPORTANTE (verificado sobre el fichero): la columna Validación contiene SÓLO reglas de FORMATO
(OBLIGATORIO / Constante "..." / "En blanco" / eco de la etiqueta del campo / vacío). NO contiene
fórmulas de consistencia inter-casilla del tipo [00552]=[00550]-[00547]. Ese ruleset de cuadres
NO está en este fichero (lo publica la AEAT como documento de "validaciones" aparte).

Salidas (mismo schema que catalogo_contable_2025.json para que campaign.resolve lo recoja):
  catalogo_contable.json   — por página: bloque, constante, lista ordenada de campos
                             {casilla, tcode, orden, posicion, longitud, tipo, etiqueta, descripcion}
                             + índice plano por_casilla.
  validaciones_formato.json — {casilla: {obligatorio, tipo, longitud, contenido}} (scope contable).

Uso:
  python3 catalogo_contable_calamine.py --dr200 <DR200e25.xls> --ejercicio 2024 \
      --out-catalogo ../data/campaigns/2024/catalogo_contable.json \
      --out-validaciones ../data/campaigns/2024/validaciones_formato.json
"""
from __future__ import annotations
import argparse, json, re
from pathlib import Path

from python_calamine import CalamineWorkbook

PAGINAS = [f"DP2000{n:02d}" for n in range(3, 12)]  # DP200003..DP200011 (páginas contables)
BLOQUE = {**{f"Pagina{n:02d}": "Balance" for n in (3, 4, 5, 6)},
          **{f"Pagina{n:02d}": "CuentaPyG" for n in (7, 8)},
          **{f"Pagina{n:02d}": "CambiosPN" for n in (9, 10, 11)}}
BLOQUES = {"Balance": ["Pagina03", "Pagina04", "Pagina05", "Pagina06"],
           "CuentaPyG": ["Pagina07", "Pagina08"],
           "CambiosPN": ["Pagina09", "Pagina10", "Pagina11"]}

CASILLA_RE = re.compile(r"\[(\d{3,5})\]")


def _cell(row, idx):
    return str(row[idx]).strip() if len(row) > idx and row[idx] is not None else ""


def _int(val):
    try:
        return int(float(val))
    except (ValueError, TypeError):
        return None


def limpiar_etiqueta(desc: str) -> str:
    """'Balance: Activo (I) - Activo - Desarrollo [00103]' -> 'Desarrollo'."""
    d = CASILLA_RE.sub("", desc).strip()
    if " - " in d:
        d = d.split(" - ")[-1].strip()
    return re.sub(r"\s+", " ", d)


def extraer(dr200: str, ejercicio: str):
    wb = CalamineWorkbook.from_path(dr200)
    name_map = {s.strip(): s for s in wb.sheet_names}  # algunas hojas traen espacios

    paginas, por_casilla, validaciones = {}, {}, {}
    total_campos = 0

    for nm in PAGINAS:
        real = name_map.get(nm)
        if real is None:
            continue
        data = wb.get_sheet_by_name(real).to_python()
        pag_key = f"Pagina{int(nm[5:]):02d}"
        constante = None
        campos = []
        for r in range(5, len(data)):
            row = data[r]
            desc = _cell(row, 4)
            cont = _cell(row, 6)
            val = _cell(row, 5)
            tipo = _cell(row, 3)
            # constante de página (fila "Página." con Contenido Constante "NN000")
            if "Página" in desc and "0" in cont:
                mc = re.search(r"(\d{5})", cont)
                if mc:
                    constante = mc.group(1)
            m = CASILLA_RE.search(desc)
            # casilla PROPIA = última referencia entre corchetes de la descripción
            todas = CASILLA_RE.findall(desc)
            if not todas:
                continue
            casilla = todas[-1].zfill(5)
            pos = _int(_cell(row, 1))
            lon = _int(_cell(row, 2))
            orden_raw = _cell(row, 0)
            campo = dict(
                casilla=casilla,
                tcode="T" + casilla,
                orden=_int(orden_raw) if orden_raw.replace(".", "").isdigit() else None,
                posicion=pos,
                longitud=lon,
                tipo=tipo or "N",
                etiqueta=limpiar_etiqueta(desc),
                descripcion=re.sub(r"\s+", " ", desc),
            )
            campos.append(campo)
            por_casilla[casilla] = dict(pagina=pag_key, bloque=BLOQUE.get(pag_key), **campo)
            # validación de FORMATO por casilla (scope contable)
            validaciones[casilla] = dict(
                obligatorio=(val.upper() == "OBLIGATORIO"),
                tipo=tipo or "N",
                longitud=lon,
                contenido=cont or None,
            )
        paginas[pag_key] = dict(bloque=BLOQUE.get(pag_key), hoja=real,
                                constante=constante or f"{int(nm[5:]):02d}000", campos=campos)
        total_campos += len(campos)

    catalogo = dict(modelo="200", ejercicio=str(ejercicio), fuente=Path(dr200).name,
                    total_campos=total_campos, bloques=BLOQUES,
                    paginas=paginas, por_casilla=por_casilla)
    return catalogo, validaciones


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--dr200", required=True)
    ap.add_argument("--ejercicio", default="2024")
    ap.add_argument("--out-catalogo", required=True)
    ap.add_argument("--out-validaciones", required=True)
    a = ap.parse_args()

    catalogo, validaciones = extraer(a.dr200, a.ejercicio)

    for path, obj in ((a.out_catalogo, catalogo), (a.out_validaciones, validaciones)):
        Path(path).parent.mkdir(parents=True, exist_ok=True)
        Path(path).write_text(json.dumps(obj, ensure_ascii=False, indent=1), encoding="utf-8")

    print(f"OK · {catalogo['total_campos']} campos en {len(catalogo['paginas'])} páginas")
    print(f"   catálogo      -> {a.out_catalogo}")
    print(f"   validaciones  -> {a.out_validaciones} ({len(validaciones)} casillas)")
    for p, v in catalogo["paginas"].items():
        print(f"   {p} [{v['bloque']}] const={v['constante']} · {len(v['campos'])} campos")


if __name__ == "__main__":
    main()
