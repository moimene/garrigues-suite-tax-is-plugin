#!/usr/bin/env python3
"""service.py — API FastAPI que expone el pipeline (subir por clase -> procesar -> descargar).

Endpoints:
  GET  /                      -> sirve web/index.html (front de subida/revisión/export)
  POST /procesar              -> recibe documentos (multipart) + empresa/ejercicio, ejecuta el
                                 pipeline y devuelve el manifest + enlaces de descarga.
  GET  /descargar/{run}/{f}   -> descarga un fichero de salida del run.
  GET  /salud                 -> healthcheck.

Arranque local:  uvicorn service:app --reload   (desde la carpeta scripts/)
Requisitos: fastapi, uvicorn, python-multipart (ver requirements.txt).
"""
from __future__ import annotations
import shutil, sys, uuid
from pathlib import Path

from fastapi import FastAPI, UploadFile, File, Form
from fastapi.responses import HTMLResponse, JSONResponse, FileResponse

SCRIPTS = Path(__file__).resolve().parent
ROOT = SCRIPTS.parent
sys.path.insert(0, str(SCRIPTS))
import pipeline  # noqa: E402

RUNS = ROOT / "salidas" / "_runs"
RUNS.mkdir(parents=True, exist_ok=True)

app = FastAPI(title="Extractor-Parseador Contable IS (EPC-IS)", version="1.0")

@app.get("/salud")
def salud():
    return {"estado": "ok", "modulo": "EPC-IS"}

@app.get("/", response_class=HTMLResponse)
def home():
    idx = ROOT / "web" / "index.html"
    return idx.read_text(encoding="utf-8") if idx.exists() else "<h1>EPC-IS</h1><p>web/index.html no encontrado.</p>"

@app.post("/procesar")
async def procesar(empresa: str = Form(""), ejercicio: str = Form("2025"),
                   ficheros: list[UploadFile] = File(...)):
    run = uuid.uuid4().hex[:12]
    indir = RUNS / run / "in"; outdir = RUNS / run / "out"
    indir.mkdir(parents=True, exist_ok=True)
    docs = []
    for uf in ficheros:
        dest = indir / Path(uf.filename).name
        with open(dest, "wb") as f:
            shutil.copyfileobj(uf.file, f)
        docs.append(str(dest))
    try:
        man = pipeline.run(docs, str(outdir), empresa=empresa, ejercicio=ejercicio)
    except Exception as e:  # noqa: BLE001
        return JSONResponse(status_code=500, content={"error": str(e)})
    man["run"] = run
    man["descargas"] = [f"/descargar/{run}/{s}" for s in man.get("salidas", [])]
    return man

@app.get("/descargar/{run}/{fichero}")
def descargar(run: str, fichero: str):
    p = (RUNS / run / "out" / Path(fichero).name)
    if not p.exists():
        return JSONResponse(status_code=404, content={"error": "no encontrado"})
    return FileResponse(str(p), filename=p.name)
