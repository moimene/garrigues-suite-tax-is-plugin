#!/usr/bin/env python3
"""Contrato de datos canónico de la ingesta (EPIC B / B1) — `CuentaCanonica` + helpers de provenance.

Documenta y valida (de forma ligera, sin dependencias) la forma de una fila del canónico que viaja por la
tubería EPC: extractor → normalizador → builder/servicio. El número que firma el XML debe ser SIEMPRE
trazable a su celda de origen (fichero/hoja/fila/col), por eso `_fuente` es parte del contrato.
"""
from __future__ import annotations

from typing import Optional, TypedDict


class FuenteCelda(TypedDict, total=False):
    """Provenance por valor: de qué fichero/hoja/fila/columna salió el dato (auditoría / HITL)."""
    fichero: str
    hoja: str
    fila: int
    col: dict          # {campo: índice_columna} (p.ej. {"cuenta": 0, "saldo_final": 5})
    pagina: int        # PDF/OCR
    bbox: list         # PDF/OCR (opcional)


class CuentaCanonica(TypedDict, total=False):
    """Fila canónica de la ingesta (contrato B1). `total=False`: los consumidores existentes añaden claves;
    lo OBLIGATORIO para considerarla trazable lo verifica `provenance_ok`."""
    cuenta: str                 # código de origen (bruto)
    denom: str                  # denominación de origen (bruto)
    debe: float
    haber: float
    saldo: float
    codigo_canonico: Optional[str]   # PGC mapeado (None si no_mapeado)
    denominacion: Optional[str]      # denominación oficial del maestro PGC
    metodo: str                      # exacto|prefijo_Nd|fuzzy|grupo_Nd|no_mapeado
    confianza: float                 # [0..1]
    revisar: bool                    # va a la cola HITL
    _fuente: FuenteCelda             # provenance (obligatorio para trazabilidad)


def provenance_ok(row: dict) -> bool:
    """True si la fila tiene provenance mínima trazable: `_fuente` dict con `fichero`. Es el invariante que
    el número firmado debe cumplir (no se acepta un importe sin origen conocido)."""
    f = (row or {}).get("_fuente")
    return isinstance(f, dict) and bool(f.get("fichero"))
