#!/usr/bin/env python3
"""Parser determinista de plantillas "Balance y PyG" ya agregadas.

Entrada esperada: XLSX con codigo de linea en col. C, etiqueta en col. D e importe ajustado en col. E.
Salida: casillas contables del Modelo 200. No infiere por fuzzy: el codigo de linea de la plantilla es
la clave canonica y las etiquetas solo sirven como trazabilidad.
"""
from __future__ import annotations

import argparse
import json
import re
import unicodedata
from pathlib import Path


# Plantilla CCAA/Grupo Garrigues observada en GRUMASA 2025. Valores de PyG en origen:
# ingresos negativos, gastos positivos. En Modelo 200 la convencion es la inversa.
BALANCE_CODE_TO_CASILLA = {
    110000: "00101", 120000: "00102", 121000: "00103", 122000: "00104",
    122010: "00105", 122020: "00106", 122030: "00107", 122040: "00109",
    122050: "00111", 122060: "00112", 122070: "00113", 122080: "00114",
    122090: "00115", 123000: "00116", 123010: "00117", 123020: "00118",
    123030: "00119", 123040: "00120", 123050: "00121", 123060: "00122",
    123070: "00123", 124000: "00126", 124010: "00127", 124020: "00128",
    124030: "00129", 124040: "00130", 124050: "00131", 124060: "00134",
    124070: "00136", 124080: "00137", 124100: "00138", 125000: "00139",
    126000: "00140", 130000: "00141", 140000: "00144", 141000: "00147",
    142000: "00148", 142010: "00149", 142020: "00150", 142030: "00153",
    142040: "00154", 142050: "00155", 142060: "00156", 142070: "00157",
    143000: "00158", 143010: "00160", 143020: "00161", 143030: "00162",
    143040: "00163", 143050: "00164", 143060: "00165", 143070: "00168",
    144000: "00169", 144010: "00170", 144020: "00171", 144030: "00172",
    144040: "00173", 144050: "00176", 144060: "00177", 144070: "00178",
    144080: "00179", 145000: "00180",
    210000: "00185", 211000: "00186", 212000: "00187", 213000: "00188",
    214000: "00189", 214010: "00190", 214020: "00191", 214030: "00192",
    214040: "00193", 214060: "00194", 214050: "00195", 215000: "00196",
    215010: "00197", 215020: "00198", 215030: "00199", 216000: "00200",
    217000: "00201", 218000: "00202", 220000: "00203", 220010: "00204",
    220020: "00207", 220030: "00209", 220050: "00210", 230000: "00211",
    230010: "00212", 230020: "00213", 230030: "00214", 230040: "00215",
    240000: "00216", 241000: "00217", 241010: "00218", 241020: "00219",
    241030: "00220", 242000: "00221", 242010: "00223", 242020: "00224",
    243000: "00225", 243010: "00228", 243020: "00229", 244000: "00230",
    244010: "00231", 244020: "00232", 244030: "00233", 244050: "00234",
    245000: "00235", 245010: "00236", 245020: "00238", 245030: "00239",
    246000: "00240", 250000: "00243", 251000: "00244", 251010: "00245",
    251020: "00246", 251030: "00247", 251040: "00248", 252000: "00250",
    252010: "00252",
}

PYG_CODE_TO_CASILLA = {
    301000: "00255", 302000: "00256", 302010: "00257", 304900: "00706",
    316000: "00707", 302020: "00258", 302030: "00259", 303000: "00260",
    303010: "00261", 303020: "00262", 304000: "00263", 305000: "00264",
    305010: "00265", 305020: "00266", 305030: "00269", 306010: "00270",
    306020: "00271", 306030: "00274", 306040: "00278", 301900: "00279",
    307000: "00280", 307010: "00281", 307020: "00282", 307030: "00283",
    308000: "00284", 309000: "00285", 302900: "00286", 303900: "00287",
    310000: "00288", 311000: "00291", 4040201: "00710", 4040301: "00710",
    307040: "00295", 306000: "00295", 312000: "00296", 313000: "00297",
    314000: "00298", 3049001: "00299", 305900: "00300", 315000: "00301",
    3160001: "00302", 306900: "00303", 400000: "00305", 401000: "00306",
    401010: "00307", 401020: "00308", 401030: "00309", 401900: "00324",
    402000: "00310",
    403000: "00311", 404000: "00312", 404010: "00313", 404020: "00314",
    404030: "00319", 405000: "00325", 405010: "00326", 405020: "00327",
    406000: "00328", 406020: "00500",
}

IGNORABLE_CODES = {300000, 405030, 406010}

# Detalle conservador cuando la plantilla solo trae un total que el DR/Open recalcula desde hijos. Se emite
# tambien el total, porque el `.200` de ancho fijo lo valida; el hijo evita subtotal != suma de componentes.
DETAIL_FALLBACKS = {
    142020: ["00152"],   # clientes: sin split L/P-C/P -> corriente
    246000: ["00242"],   # proveedores: sin split L/P-C/P -> corriente
    303010: ["00760"],   # consumo mercaderias: sin compras/variacion -> compras
    303020: ["00762"],   # consumo materias primas: sin compras/variacion -> compras
    305020: ["00268"],   # ingresos accesorios: sin arrendamientos/resto -> resto
    307000: ["00254"],   # servicios exteriores: sin profesionales/resto -> resto
    404020: ["00316"],   # deterioros financieros: sin grupo/no grupo -> otras empresas
}


def _detail_fallbacks(code: int, importe: float) -> list[str]:
    """Desgloses mínimos para subtotales que Open recalcula desde hijos."""
    out = list(DETAIL_FALLBACKS.get(code, ()))
    if code == 311000:
        # Resultado por enajenaciones y otras: sin split beneficio/perdida, volcar en el hijo coherente
        # con el signo Modelo 200. Así 00291 no queda como subtotal aislado frente a 00292/00293.
        out.append("00292" if importe >= 0 else "00293")
    return out


def _num(v):
    if v is None:
        return None
    if isinstance(v, str):
        s = v.strip().replace(".", "").replace(",", ".")
        if not s or s in {"-", "—"}:
            return None
        try:
            return float(s)
        except ValueError:
            return None
    try:
        return float(v)
    except (TypeError, ValueError):
        return None


def _add(casillas: dict[str, float], casilla: str, valor: float):
    casillas[casilla] = round(casillas.get(casilla, 0.0) + float(valor), 2)


def _norm_label(v) -> str:
    s = "" if v is None else str(v)
    s = unicodedata.normalize("NFKD", s)
    s = "".join(ch for ch in s if not unicodedata.combining(ch))
    s = re.sub(r"\s+", " ", s.replace("\xa0", " ")).strip().lower()
    s = s.rstrip(" -")
    return s


BALANCE_FORMULADO_MAP = {
    # Activo
    "activo no corriente": ["00101"],
    "inmovilizado intangible": ["00102"],
    "fondo de comercio": ["00106"],
    "otro inmovilizado intangible": ["00109"],
    "inmovilizado material": ["00111"],
    "terrenos y construcciones": ["00112"],
    "instalaciones tecnicas y otro inmovilizado material": ["00113"],
    "inmovilizado en curso y anticipos": ["00114"],
    "inversiones financieras a largo plazo en empresas del grupo y asociadas": ["00118"],
    "instrumentos de patrimonio": ["00119"],
    "activos por impuesto diferido": ["00134"],
    "activo corriente": ["00136"],
    "existencias": ["00138", "00140"],
    "deudores comerciales y otras cuentas a cobrar": ["00149"],
    "clientes por ventas y prestaciones de servicios": ["00150", "00152"],
    "clientes, empresas del grupo y asociadas": ["00153"],
    "deudores varios": ["00154"],
    "personal": ["00155"],
    "activos por impuesto corriente": ["00156"],
    "otros creditos con las administraciones publicas": ["00157"],
    "inversiones en empresas del grupo y asociadas a corto plazo": ["00160"],
    "creditos a empresas del grupo y asociadas a corto plazo": ["00162"],
    "periodificaciones a corto plazo": ["00176"],
    "efectivo y otros liquidos equivalentes": ["00177"],
    "tesoreria": ["00178"],
    "total activo": ["00180"],
    # Patrimonio neto y pasivo
    "patrimonio neto": ["00185"],
    "fondos propios": ["00186"],
    "capital suscrito": ["00187", "00188"],
    "prima de emision": ["00190"],
    "reserva de revalorizacion": ["00702"],
    "otras reservas": ["00193"],
    "resultado del ejercicio": ["00199"],
    "pasivo no corriente": ["00210"],
    "provisiones a largo plazo": ["00211"],
    "obligaciones por prestaciones a largo plazo al personal": ["00212"],
    "deudas a largo plazo": ["00216"],
    "otros pasivos financieros": ["00221"],
    "pasivos por impuesto diferido": ["00224"],
    "pasivo corriente": ["00228"],
    "provisiones a corto plazo": ["00230", "00704"],
    "deudas a corto plazo": ["00231"],
    "deudas con empresas del grupo y asociadas a corto plazo": ["00238"],
    "acreedores comerciales y otras cuentas a pagar": ["00239"],
    "proveedores": ["00240", "00242"],
    "proveedores, empresas del grupo y asociadas": ["00243"],
    "acreedores varios": ["00244"],
    "remuneraciones pendientes de pago": ["00245"],
    "otras deudas con las administraciones publicas": ["00247"],
    "pasivos por impuesto corriente": ["00246"],
    "total patrimonio neto y pasivo": ["00252"],
}


BALANCE_FORMULADO_ACTIVO_MAP = {
    k: BALANCE_FORMULADO_MAP[k] for k in (
        "activo no corriente", "inmovilizado intangible", "fondo de comercio",
        "otro inmovilizado intangible", "inmovilizado material", "terrenos y construcciones",
        "instalaciones tecnicas y otro inmovilizado material", "inmovilizado en curso y anticipos",
        "inversiones financieras a largo plazo en empresas del grupo y asociadas",
        "instrumentos de patrimonio", "activos por impuesto diferido", "activo corriente",
        "existencias", "deudores comerciales y otras cuentas a cobrar",
        "clientes por ventas y prestaciones de servicios", "clientes, empresas del grupo y asociadas",
        "deudores varios", "personal", "activos por impuesto corriente",
        "otros creditos con las administraciones publicas",
        "inversiones en empresas del grupo y asociadas a corto plazo",
        "creditos a empresas del grupo y asociadas a corto plazo", "periodificaciones a corto plazo",
        "efectivo y otros liquidos equivalentes", "tesoreria", "total activo",
    )
}


BALANCE_FORMULADO_PASIVO_MAP = {
    k: BALANCE_FORMULADO_MAP[k] for k in (
        "patrimonio neto", "fondos propios", "capital suscrito", "prima de emision",
        "reserva de revalorizacion", "otras reservas", "resultado del ejercicio",
        "pasivo no corriente", "provisiones a largo plazo",
        "obligaciones por prestaciones a largo plazo al personal", "deudas a largo plazo",
        "pasivos por impuesto diferido", "pasivo corriente", "provisiones a corto plazo",
        "deudas a corto plazo", "deudas con empresas del grupo y asociadas a corto plazo",
        "acreedores comerciales y otras cuentas a pagar", "proveedores",
        "proveedores, empresas del grupo y asociadas", "acreedores varios",
        "remuneraciones pendientes de pago", "otras deudas con las administraciones publicas",
        "pasivos por impuesto corriente", "total patrimonio neto y pasivo",
    )
}
BALANCE_FORMULADO_PASIVO_MAP["periodificaciones a corto plazo"] = ["00250"]


PYG_FORMULADO_MAP = {
    "importe neto de la cifra de negocios": ["00255"],
    "ventas": ["00256"],
    "prestacion de servicios": ["00257"],
    "variacion de existencias de productos terminados y en curso de fabricacion": ["00258"],
    "aprovisionamientos": ["00260"],
    "consumo de materias primas y otras materias consumibles": ["00262", "00762"],
    "trabajos realizados por otras empresas": ["00263"],
    "deterioro de mercaderias, materias primas y otros aprovisionamientos": ["00264"],
    "gastos de personal": ["00270"],
    "sueldos, salarios y asimilados": ["00271"],
    "cargas sociales": ["00274"],
    "otros gastos de explotacion": ["00279"],
    "servicios exteriores": ["00280", "00254"],
    "tributos": ["00281"],
    "amortizacion del inmovilizado": ["00284"],
    "deterioro y resultado por enajenaciones del inmovilizado": ["00287", "00291"],
    "otros resultados": ["00295"],
    "resultado de explotacion": ["00296"],
    "ingresos financieros": ["00297"],
    "de participaciones en instrumentos de patrimonio en empresas del grupo y asociadas": ["00298", "00299"],
    "de valores negociables y otros instrumentos financieros": ["00301", "00303"],
    "gastos financieros": ["00305"],
    "por deudas con empresas del grupo y asociadas": ["00306"],
    "por deudas con terceros": ["00307"],
    "diferencias de cambio": ["00312"],
    "resultado financiero": ["00324"],
    "resultado antes de impuestos": ["00325"],
    "impuestos sobre beneficios": ["00326"],
    "resultado del ejercicio": ["00327", "00500"],
}


def _cerrar_derivadas_formuladas(casillas: dict[str, float], tolerancia=0.01):
    reservas = sum(casillas.get(c, 0.0) for c in ("00192", "00193", "00702", "01001", "01002",
                                                  "00712", "00766", "00767"))
    if abs(reservas) >= tolerancia and abs(casillas.get("00191", 0.0)) < tolerancia:
        casillas["00191"] = round(reservas, 2)

    det_291 = casillas.get("00291", 0.0)
    if det_291 < -tolerancia and abs(casillas.get("00293", 0.0)) < tolerancia:
        casillas["00293"] = round(det_291, 2)
    elif det_291 > tolerancia and abs(casillas.get("00292", 0.0)) < tolerancia:
        casillas["00292"] = round(det_291, 2)


def _parse_estados_formulados(wb, p: Path, tolerancia=0.01) -> dict | None:
    if "Balance" not in wb.sheetnames or "P&L" not in wb.sheetnames:
        return None

    casillas: dict[str, float] = {}
    lineage = []
    sin_mapear = []

    def add_from_sheet(ws, label_cols, val_col, mapping, bloque):
        section = None
        for row_idx, row in enumerate(ws.iter_rows(values_only=True), 1):
            raw_val = row[val_col - 1] if len(row) >= val_col else None
            if isinstance(raw_val, str) and re.fullmatch(r"\d{1,2}\.\d{1,2}\.\d{2,4}", raw_val.strip()):
                continue
            val = _num(raw_val)
            if val is None or abs(val) < tolerancia:
                continue
            matched = False
            for label_col in label_cols:
                label = row[label_col - 1] if len(row) >= label_col else None
                key = _norm_label(label)
                if not key:
                    continue
                if key in {"patrimonio neto", "pasivo no corriente", "pasivo corriente"}:
                    section = key
                cas_list = mapping.get(key)
                if key == "otros pasivos financieros":
                    cas_list = ["00236"] if section == "pasivo corriente" else ["00221"]
                if not cas_list:
                    continue
                for cas in cas_list:
                    _add(casillas, cas, val)
                lineage.append({"hoja": ws.title, "fila": row_idx, "etiqueta": str(label or ""),
                                "casillas": list(cas_list), "importe_modelo200": round(val, 2),
                                "bloque": bloque})
                matched = True
                break
            if not matched:
                labels = [str(row[c - 1]) for c in label_cols if len(row) >= c and row[c - 1]]
                if labels:
                    sin_mapear.append({"hoja": ws.title, "fila": row_idx, "etiqueta": " | ".join(labels),
                                       "importe": round(val, 2), "bloque": bloque})

    add_from_sheet(wb["Balance"], (3,), 5, BALANCE_FORMULADO_ACTIVO_MAP, "balance_activo")
    add_from_sheet(wb["Balance"], (8,), 10, BALANCE_FORMULADO_PASIVO_MAP, "balance_pn_pasivo")
    add_from_sheet(wb["P&L"], (3,), 5, PYG_FORMULADO_MAP, "pyg")
    _cerrar_derivadas_formuladas(casillas, tolerancia=tolerancia)
    checks = validar_casillas(casillas, tolerancia=tolerancia)
    apto = bool(casillas) and not sin_mapear and all(c["ok"] for c in checks)
    return {
        "ok": apto,
        "fuente": str(p),
        "hoja": "Balance+P&L",
        "casillas": {k: round(v, 2) for k, v in sorted(casillas.items()) if abs(v) >= tolerancia},
        "lineage": lineage,
        "sin_mapear": sin_mapear,
        "checks": checks,
        "motivo": "; ".join(c["detalle"] for c in checks if not c["ok"]) or (
            f"{len(sin_mapear)} linea(s) materiales sin mapear" if sin_mapear else None),
    }


def _cerrar_residuales_pyg(casillas: dict[str, float], tolerancia=0.01):
    """Completa hijos mínimos de subtotales PyG que Open recalcula en el `.200`."""
    # 00705 = 00706 + 00707 + 00708; 00255 = 00256 + 00257 + 00711 + 00705.
    holding_detalle = round(sum(casillas.get(c, 0.0) for c in ("00706", "00707", "00708")), 2)
    if abs(holding_detalle) >= tolerancia and abs(casillas.get("00705", 0.0)) < tolerancia:
        _add(casillas, "00705", holding_detalle)
    total = casillas.get("00255", 0.0)
    if abs(total) >= tolerancia:
        hijos = ("00256", "00257", "00711", "00705")
        residual = round(total - sum(casillas.get(c, 0.0) for c in hijos), 2)
        if abs(residual) >= tolerancia and abs(casillas.get("00705", 0.0)) < tolerancia:
            _add(casillas, "00705", residual)


def parse_xlsx(path: str | Path, tolerancia=0.01) -> dict:
    from openpyxl import load_workbook

    p = Path(path)
    wb = load_workbook(p, data_only=True, read_only=True)
    ws = wb[wb.sheetnames[0]]
    casillas: dict[str, float] = {}
    lineage = []
    sin_mapear = []
    en_pyg = False

    for row_idx, row in enumerate(ws.iter_rows(values_only=True), 1):
        code_raw = row[2] if len(row) > 2 else None
        label = row[3] if len(row) > 3 else None
        raw_val = row[4] if len(row) > 4 else None
        if isinstance(code_raw, str) and "CUENTA DE" in code_raw.upper():
            en_pyg = True
            continue
        if not isinstance(code_raw, (int, float)):
            continue
        code = int(code_raw)
        val = _num(raw_val)
        if val is None:
            continue
        if code in IGNORABLE_CODES:
            continue
        casilla = (PYG_CODE_TO_CASILLA if en_pyg or code >= 300000 else BALANCE_CODE_TO_CASILLA).get(code)
        if not casilla:
            if abs(val) >= tolerancia:
                sin_mapear.append({"fila": row_idx, "codigo": code, "etiqueta": str(label or ""), "importe": val})
            continue
        importe = -val if (en_pyg or code >= 300000) else val
        _add(casillas, casilla, importe)
        for detalle in _detail_fallbacks(code, importe):
            _add(casillas, detalle, importe)
        lineage.append({"fila": row_idx, "codigo": code, "etiqueta": str(label or ""), "casilla": casilla,
                        "importe_origen": round(val, 2), "importe_modelo200": round(importe, 2)})

    _cerrar_residuales_pyg(casillas, tolerancia=tolerancia)
    if not casillas and not lineage and not sin_mapear:
        formulado = _parse_estados_formulados(wb, p, tolerancia=tolerancia)
        if formulado is not None:
            return formulado
    checks = validar_casillas(casillas, tolerancia=tolerancia)
    apto = bool(casillas) and not sin_mapear and all(c["ok"] for c in checks)
    return {
        "ok": apto,
        "fuente": str(p),
        "hoja": ws.title,
        "casillas": {k: round(v, 2) for k, v in sorted(casillas.items()) if abs(v) >= tolerancia},
        "lineage": lineage,
        "sin_mapear": sin_mapear,
        "checks": checks,
        "motivo": "; ".join(c["detalle"] for c in checks if not c["ok"]) or (
            f"{len(sin_mapear)} linea(s) materiales sin mapear" if sin_mapear else None),
    }


def validar_casillas(casillas: dict[str, float], tolerancia=0.01) -> list[dict]:
    def g(c):
        return round(float(casillas.get(c, 0.0)), 2)

    checks = []
    dif_bal = round(g("00180") - g("00252"), 2)
    checks.append({"regla": "balance_cuadra", "ok": abs(dif_bal) <= tolerancia,
                   "detalle": f"00180 - 00252 = {dif_bal:.2f}"})
    dif_res = round(g("00199") - g("00500"), 2)
    checks.append({"regla": "resultado_balance_pyg", "ok": abs(dif_res) <= tolerancia,
                   "detalle": f"00199 - 00500 = {dif_res:.2f}"})
    return checks


def main():
    ap = argparse.ArgumentParser(description="Balance y PyG agregado -> casillas contables Modelo 200")
    ap.add_argument("xlsx")
    ap.add_argument("--out-json")
    args = ap.parse_args()
    out = parse_xlsx(args.xlsx)
    txt = json.dumps(out, ensure_ascii=False, indent=2)
    if args.out_json:
        Path(args.out_json).write_text(txt + "\n", encoding="utf-8")
    print(txt)
    raise SystemExit(0 if out["ok"] else 1)


if __name__ == "__main__":
    main()
