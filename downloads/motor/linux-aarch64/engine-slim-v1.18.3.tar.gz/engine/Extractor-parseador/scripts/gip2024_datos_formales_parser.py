#!/usr/bin/env python3
"""Parser de datos formales GIP 2024."""
from __future__ import annotations

import argparse
import json
import math
import re
from pathlib import Path

import pandas as pd

import caso_local

DEFAULT_PATH = caso_local.path("datos_formales")


def _clean(v):
    if v is None or pd.isna(v):
        return ""
    if hasattr(v, "strftime"):
        return v.strftime("%Y-%m-%d")
    return str(v).strip()


def _num(v):
    if v is None or pd.isna(v):
        return None
    try:
        return float(v)
    except Exception:
        s = str(v).strip().replace(",", ".")
        try:
            return float(s)
        except ValueError:
            return None


def _rows(path, sheet=None):
    # Hoja parametrizable para generalizar a otras sociedades con la MISMA plantilla de datos formales; por
    # defecto "GIP" si existe (retrocompat) y si no la primera hoja del libro.
    xls = pd.ExcelFile(path)
    if sheet is None:
        sheet = "GIP" if "GIP" in xls.sheet_names else xls.sheet_names[0]
    df = pd.read_excel(xls, sheet_name=sheet, header=None, dtype=object)
    for idx, row in df.iterrows():
        yield idx + 1, [_clean(v) for v in row.tolist()]


def _section(rows, title_prefix):
    start = None
    for i, vals in rows:
        joined = " ".join(v for v in vals if v)
        if joined.startswith(title_prefix):
            start = i
            break
    if start is None:
        return []
    out = []
    for i, vals in rows:
        if i <= start:
            continue
        joined = " ".join(v for v in vals if v)
        if i > start + 1 and re.match(r"^\d+\.\s+", joined):
            break
        if any(vals):
            out.append((i, vals))
    return out


def _nonempty(vals):
    return [v for v in vals if v]


def _people_from_section(rows, title):
    sec = _section(rows, title)
    people = []
    for _i, vals in sec:
        non = _nonempty(vals)
        if not non or non[0] == "Nombre y apellidos":
            continue
        if non[0].startswith("*"):
            continue
        if len(non) > 1:
            people.append({"nombre": non[0], "nif": non[1], "extra": non[2:]})
    return people


_IBAN_RE = re.compile(r"^[A-Z]{2}\d{2}[A-Z0-9]+$")


def _empleados_validos(non):
    """(empleados, warnings): valida que los 2 primeros valores sean recuentos NO negativos y finitos. Si
    no, no los emite y AVISA — en otra plantilla la fila fija podría no contener los empleados, y emitirla
    en silencio daría un .200 falso. Convierte 'leer la celda equivocada' en aviso ruidoso (regla dura 5)."""
    fijo = _num(non[0]) if len(non) > 0 else None
    no_fijo = _num(non[1]) if len(non) > 1 else None
    if (fijo is None or no_fijo is None or not math.isfinite(fijo) or not math.isfinite(no_fijo)
            or fijo < 0 or no_fijo < 0):
        return ({"fijo": None, "no_fijo": None},
                ["empleados: la fila esperada no contiene 2 recuentos no negativos; revisar plantilla."])
    return {"fijo": fijo, "no_fijo": no_fijo}, []


def _iban_mod97(iban):
    """Validación ISO 13616 (mod-97): mueve los 4 primeros caracteres al final, convierte letras a dígitos
    (A=10..Z=35) y comprueba `mod 97 == 1`. Rechaza textos que solo 'parecen' un IBAN."""
    if not (15 <= len(iban) <= 34):
        return False
    reordenado = iban[4:] + iban[:4]
    try:
        numero = "".join(str(int(c, 36)) for c in reordenado)   # ValueError si hay algún no-alfanumérico
    except ValueError:
        return False
    return int(numero) % 97 == 1


def _iban_valido(iban):
    """(iban, warnings): valida un IBAN de verdad (forma + checksum mod-97). Si no lo es, lo descarta con
    aviso para no emitir basura en la domiciliación del DID."""
    iban = (iban or "").replace(" ", "").upper()
    if not iban:
        return "", []
    if _IBAN_RE.match(iban) and _iban_mod97(iban):
        return iban, []
    return "", ["IBAN: la celda esperada no es un IBAN valido (checksum); no se emite (revisar plantilla)."]


def parse(path=DEFAULT_PATH, sheet=None):
    path = str(path)
    rows = list(_rows(path, sheet))
    warnings = []

    empleados = {"fijo": None, "no_fijo": None}
    for i, vals in rows:
        if i == 15:
            empleados, _w = _empleados_validos(_nonempty(vals))
            warnings.extend(_w)

    secretario = _people_from_section(rows, "3. SECRETARIO")
    representantes = _people_from_section(rows, "4. REPRESENTANTES")
    administradores = _people_from_section(rows, "5. ADMINISTRADORES")
    titulares = _people_from_section(rows, "6. IDENTIFICACIÓN DEL TITULAR REAL")

    participadas = []
    for i, vals in rows:
        non = _nonempty(vals)
        if 47 <= i <= 51 and non:
            participadas.append({
                "nombre": non[0], "nif": non[1], "pais": non[2],
                "porcentaje": _num(non[3]), "nominal": _num(non[4]), "valor_libros": _num(non[5]),
            })

    socios = []
    for i, vals in rows:
        non = _nonempty(vals)
        if 57 <= i <= 60 and non:
            socios.append({
                "nombre": non[0], "nif": non[1], "pais": non[2],
                "porcentaje": _num(non[3]), "nominal": _num(non[4]),
            })

    if not participadas:
        warnings.append("participadas: 0 localizadas en las filas esperadas; confirmar (¿correcto, o la plantilla desplaza las filas?).")
    if not socios:
        warnings.append("socios: 0 localizados en las filas esperadas; confirmar (¿correcto, o la plantilla desplaza las filas?).")

    iban = ""
    banco = ""
    for i, vals in rows:
        if i == 67:
            non = _nonempty(vals)
            iban, _w = _iban_valido(non[0] if non else "")
            warnings.extend(_w)
            banco = non[1] if len(non) > 1 else ""

    casillas = {}
    if empleados["fijo"] is not None:
        casillas["00041"] = f"{empleados['fijo']:.2f}"
    if empleados["no_fijo"] is not None:
        casillas["00042"] = f"{empleados['no_fijo']:.2f}"

    # GIP es ETVE y matriz ultima de grupo multinacional en el .200 real; el XLS lo infiere por participadas
    # extranjeras y socios/no residentes, pero no lo marca con una celda booleana. Se emite como candidato
    # trazable y se advierte.
    casillas["00011"] = "1"
    casillas["00082"] = "1"
    casillas["00039"] = "1"
    warnings.append("00011/00082/00039 son flags formales inferidos del expediente GIP y validados contra el .200 real; revisar en campaña general.")

    campos_pos = {
        "DP200001B": {"14": "1", "15": "1", "16": "1"},
        "DP200DID": {"26": "1" if iban.startswith("ES") else "", "27": iban, "29": banco},
    }

    return {
        "source": "datos_formales",
        "path": path,
        "casillas": casillas,
        "campos_pos": campos_pos,
        "empleados": empleados,
        "secretario": secretario,
        "representantes": representantes,
        "administradores": administradores,
        "titulares_reales": titulares,
        "participadas": participadas,
        "socios": socios,
        "cuenta_bancaria": {"iban": iban, "banco": banco},
        "warnings": warnings,
    }


def to_casillas(parsed):
    return dict(parsed.get("casillas") or {})


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("path", nargs="?", default=DEFAULT_PATH)
    ap.add_argument("--out")
    args = ap.parse_args()
    data = parse(args.path)
    text = json.dumps(data, ensure_ascii=False, indent=2, default=str)
    if args.out:
        Path(args.out).write_text(text, encoding="utf-8")
    print(text)


if __name__ == "__main__":
    main()
