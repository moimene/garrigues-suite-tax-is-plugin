#!/usr/bin/env python3
"""harness.py — Detección de clase de documento y enrutado al motor (PRD §7.2).

Decide, para cada documento, qué clase es y qué motor lo procesa:
  sumas_y_saldos   -> motor_sys           (determinista)
  declaracion_previa -> parser_declaracion_previa (determinista)
  cuentas_anuales  -> extractor_ccaa       (inferencia)
  datos_clave      -> carga directa (JSON)
"""
from __future__ import annotations
import os, re
from pathlib import Path

def _peek(path, n=4000):
    try:
        return Path(path).read_bytes()[:n].decode("latin-1", "replace").lower()
    except Exception:
        return ""

def detectar_clase(path: str) -> tuple[str, str]:
    ext = os.path.splitext(path)[1].lower()
    nombre = os.path.basename(path).lower()

    if ext == ".json" or "datos_clave" in nombre or "caracteres" in nombre:
        return "datos_clave", "carga_directa"

    if ext == ".xml":
        if re.search(r"mod200\d{4}", _peek(path)):
            return "declaracion_previa", "parser_declaracion_previa"
        return "desconocido", "-"

    if ext in (".xls", ".xlsx", ".xlsm", ".csv"):
        # SyS si parece balance de sumas y saldos
        head = _peek(path)
        if any(k in nombre for k in ("sumas", "saldos", "balance", "sys")):
            return "sumas_y_saldos", "motor_sys"
        if ("cuenta" in head or "codigo" in head or "código" in head) and ("saldo" in head or "debe" in head or "haber" in head):
            return "sumas_y_saldos", "motor_sys"
        return "sumas_y_saldos", "motor_sys"   # por defecto, tratar tabla contable como SyS

    if ext == ".pdf":
        if any(k in nombre for k in ("declarac", "modelo 200", "modelo200", "mod200", "200 ")):
            return "declaracion_previa", "extractor_ccaa"   # PDF de declaración -> inferencia
        return "cuentas_anuales", "extractor_ccaa"

    return "desconocido", "-"

if __name__ == "__main__":
    import sys
    for p in sys.argv[1:]:
        clase, motor = detectar_clase(p)
        print(f"{clase:20s} {motor:28s} {os.path.basename(p)}")
