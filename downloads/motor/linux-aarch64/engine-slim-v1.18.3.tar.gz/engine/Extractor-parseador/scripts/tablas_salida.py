#!/usr/bin/env python3
"""tablas_salida.py — Tablas de salida de la ingesta (D14).

A partir de las cuentas YA normalizadas al PGC (salida de `normalizador_pgc.normalizar`) construye
vistas de control para el revisor (HITL), incrementando las "tablas de salida" de la ingesta:

  - agregado_pgc : saldo por GRUPO PGC (1..7) con su descripción (inequívoco).
  - pyg          : Σ ingresos (grupo 7) − Σ gastos (grupo 6) -> `resultado` (≈ casilla 00500).
  - balance      : masas por SIGNO en los grupos de balance (1..5): saldos deudores -> activo,
                   acreedores -> patrimonio neto + pasivo; `descuadre` = activo − (pn+pasivo).
  - cobertura    : nº de cuentas y % del saldo (en magnitud) cubierto por cuentas mapeadas al PGC.

IMPORTANTE: estas tablas son ORIENTATIVAS (vista de control). El balance/PyG/ECPN que se FIRMAN y
validan contra el XSD (Fase A) los produce el pipeline contable (`builder.proyectar`), no este módulo.
El cuadre del `balance` es exacto solo si la SyS es de CIERRE (grupos 6/7 regularizados en el resultado
del grupo 1). Determinista, sin dependencias nuevas.
"""
from __future__ import annotations

import os
import re
import sys

# parser-core (núcleo compartido de la suite fiscal): asegúralo en sys.path aunque este script
# se importe de forma aislada (sus tests sólo añaden el dir de scripts).
_ROOT = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
if _ROOT not in sys.path:
    sys.path.insert(0, _ROOT)
from parser_core.coverage import cobertura_pgc  # noqa: E402

GRUPOS = {
    "1": "Financiación básica (patrimonio neto y pasivo no corriente)",
    "2": "Activo no corriente",
    "3": "Existencias",
    "4": "Acreedores y deudores por operaciones comerciales",
    "5": "Cuentas financieras",
    "6": "Compras y gastos",
    "7": "Ventas e ingresos",
}
GRUPOS_BALANCE = {"1", "2", "3", "4", "5"}


def _cod(c: dict) -> str:
    """Código PGC de la cuenta: prefiere el canónico normalizado; cae al código de origen."""
    return re.sub(r"\D", "", str(c.get("codigo_canonico") or c.get("cuenta") or ""))


def _saldo(c: dict) -> float:
    """Saldo de la cuenta: usa saldo final si lo hay; si no, debe − haber (convención SyS)."""
    for k in ("sf", "saldo_final", "saldo"):
        v = c.get(k)
        if v not in (None, ""):
            try:
                return float(v)
            except (TypeError, ValueError):
                pass
    try:
        return float(c.get("debe", 0) or 0) - float(c.get("haber", 0) or 0)
    except (TypeError, ValueError):
        return 0.0


def construir(canonico: list) -> dict:
    """canónico (list[dict] con codigo_canonico/cuenta/debe/haber/sf) -> tablas de salida."""
    canonico = canonico or []

    # --- agregado por grupo PGC (1..7) ---
    por_grupo: dict = {}
    for c in canonico:
        g = (_cod(c) or "?")[:1]
        por_grupo.setdefault(g, 0.0)
        por_grupo[g] += _saldo(c)
    agregado_pgc = [
        {"grupo": g, "descripcion": GRUPOS.get(g, "(sin grupo)"), "saldo": round(por_grupo[g], 2)}
        for g in sorted(por_grupo)
    ]

    # --- PyG: ingresos (7) − gastos (6) ---
    gastos = round(sum(_saldo(c) for c in canonico if _cod(c)[:1] == "6"), 2)
    ingresos = round(sum(-_saldo(c) for c in canonico if _cod(c)[:1] == "7"), 2)  # grupo 7 = saldo acreedor
    pyg = {
        "ingresos_grupo_7": ingresos,
        "gastos_grupo_6": gastos,
        "resultado": round(ingresos - gastos, 2),
        "nota": "Resultado ≈ casilla 00500 (Σ grupo 7 − Σ grupo 6).",
    }

    # --- Balance por signo en grupos 1..5 ---
    activo = 0.0
    pn_pasivo = 0.0
    for c in canonico:
        if _cod(c)[:1] not in GRUPOS_BALANCE:
            continue
        s = _saldo(c)
        if s >= 0:
            activo += s          # saldo deudor -> activo
        else:
            pn_pasivo += -s      # saldo acreedor -> patrimonio neto + pasivo
    balance = {
        "activo": round(activo, 2),
        "patrimonio_neto_y_pasivo": round(pn_pasivo, 2),
        "descuadre": round(activo - pn_pasivo, 2),
        "cuadra": abs(activo - pn_pasivo) < 0.01,
        "nota": "Orientativo (reclasificación por signo, grupos 1–5). Cuadre exacto si la SyS es de cierre.",
    }

    # --- Cobertura del mapeo PGC (parser-core compartido: patrón Coverage Warnings) ---
    cobertura = cobertura_pgc(canonico, _saldo)

    return {
        "agregado_pgc": agregado_pgc,
        "pyg": pyg,
        "balance": balance,
        "cobertura": cobertura,
    }


if __name__ == "__main__":
    import json

    demo = [
        {"cuenta": "2100", "codigo_canonico": "2100", "debe": 500000, "haber": 0},
        {"cuenta": "5720", "codigo_canonico": "572", "debe": 300000, "haber": 0},
        {"cuenta": "1000", "codigo_canonico": "100", "debe": 0, "haber": 600000},
        {"cuenta": "7000", "codigo_canonico": "700", "debe": 0, "haber": 800000},
        {"cuenta": "6000", "codigo_canonico": "600", "debe": 600000, "haber": 0},
    ]
    print(json.dumps(construir(demo), ensure_ascii=False, indent=1))
