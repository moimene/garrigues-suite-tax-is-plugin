#!/usr/bin/env python3
"""Normaliza un XLS oficial DR200 AEAT al CSV que consume dr200.py.

Entrada: libro DR200 .xls/.xlsx.
Salida: CSV con columnas pagina_hoja,num_campo,posicion,longitud,tipo,descripcion,validacion,contenido,casillas.

El extractor generico conserva tambien filas de leyenda si parecen numeradas. Para el emisor de ancho fijo
solo son campos utiles los que tienen posicion y longitud numericas. La casilla se deriva literalmente del
primer patron [00000] de la descripcion, igual que la extraccion DR200e25 ya existente.
"""
import csv
import os
import re
import sys

import extraer_dr

SALIDA_COLS = [
    "pagina_hoja",
    "num_campo",
    "posicion",
    "longitud",
    "tipo",
    "descripcion",
    "validacion",
    "contenido",
    "casillas",
]

_CASILLA_RE = re.compile(r"\[(\d{5})\]")


def _es_entero(v) -> bool:
    return str(v or "").strip().isdigit()


def normalizar(path: str) -> list[dict]:
    out = []
    for r in extraer_dr.extraer(path):
        posicion = (r.get("posicion") or "").strip()
        longitud = (r.get("longitud") or "").strip()
        if not (_es_entero(posicion) and _es_entero(longitud)):
            continue
        descripcion = r.get("descripcion") or ""
        m = _CASILLA_RE.search(descripcion)
        out.append({
            "pagina_hoja": (r.get("hoja") or "").strip(),
            "num_campo": (r.get("num") or "").strip(),
            "posicion": posicion,
            "longitud": longitud,
            "tipo": (r.get("tipo") or "").strip(),
            "descripcion": descripcion.strip(),
            "validacion": (r.get("validacion") or "").strip(),
            "contenido": (r.get("contenido") or "").strip(),
            "casillas": m.group(1) if m else "",
        })
    return out


def escribir_csv(registros: list[dict], salida: str) -> None:
    with open(salida, "w", encoding="utf-8", newline="") as fh:
        w = csv.DictWriter(fh, fieldnames=SALIDA_COLS)
        w.writeheader()
        w.writerows(registros)


if __name__ == "__main__":
    if len(sys.argv) < 2:
        print("Uso: python3 normalizar_dr200.py <DR200.xls|xlsx> [salida.csv]", file=sys.stderr)
        raise SystemExit(2)
    src = sys.argv[1]
    dst = sys.argv[2] if len(sys.argv) > 2 else os.path.splitext(src)[0] + "_extraccion_completa.csv"
    regs = normalizar(src)
    escribir_csv(regs, dst)
    paginas = {r["pagina_hoja"] for r in regs}
    casillas = {r["casillas"] for r in regs if r["casillas"]}
    print(f"{os.path.basename(src)}: {len(paginas)} paginas · {len(regs)} campos · {len(casillas)} casillas")
    print(f"  -> {dst}")
