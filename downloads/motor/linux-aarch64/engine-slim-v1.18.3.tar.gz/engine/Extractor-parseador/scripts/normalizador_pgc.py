#!/usr/bin/env python3
"""Normalización de cuentas al PGC canónico (D9/D12) — escalera de mapeo + confianza.

Para cada cuenta de un mayor/SyS la mapea al maestro PGC oficial (904 cuentas, RD 1514/2007) por:
  1) código EXACTO   2) PREFIJO (subcuenta -> cuenta 4d/3d)   3) FUZZY por denominación
  4) GRUPO (1-2 díg, baja confianza)   5) no_mapeado
con un MÉTODO y una CONFIANZA [0..1]. Las dudosas (confianza < umbral) van a una COLA DE REVISIÓN
(humano en el bucle). NO inventa códigos: lo no resoluble se marca para revisión, nunca se rellena.

Patrón Persona Document AI: extraer -> normalizar canónico (mapeo ontológico exacto->prefijo->fuzzy con
score) -> confianza por campo -> gating HITL. Sin dependencias nuevas (difflib stdlib).
"""
import csv
import os
import re
import unicodedata
from difflib import SequenceMatcher

ROOT = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
MAESTRO_DEFAULT = os.path.join(ROOT, "suite-is", "rules", "pgc", "maestro_pgc.csv")

UMBRAL_IMPORTE = 0.95  # confianza mínima del IMPORTE para auto-aceptar (best-practice IDP, campos numéricos)
UMBRAL_DENOM = 0.88    # confianza mínima de la DENOMINACIÓN/mapeo (campos descriptivos, EPIC B B4)


def _norm(s) -> str:
    """Normaliza texto para fuzzy: minúsculas, sin acentos, sin puntuación."""
    s = unicodedata.normalize("NFKD", str(s or "")).encode("ascii", "ignore").decode()
    return re.sub(r"[^a-z0-9 ]", " ", s.lower()).strip()


def cargar_maestro(path=MAESTRO_DEFAULT) -> dict:
    """{codigo: denominacion} del maestro PGC oficial (904)."""
    m = {}
    with open(path, encoding="utf-8") as fh:
        r = csv.reader(fh, delimiter=";")
        next(r, None)  # cabecera
        for row in r:
            if len(row) >= 2 and row[0].strip().isdigit():
                m[row[0].strip()] = row[1].strip()
    return m


def mapear_cuenta(codigo, denom, maestro, nombres_norm) -> dict:
    cod = re.sub(r"\D", "", str(codigo or ""))
    # 1) EXACTO
    if cod and cod in maestro:
        return {"codigo_canonico": cod, "denominacion": maestro[cod], "metodo": "exacto", "confianza": 1.0}
    # 2) PREFIJO a cuenta significativa (4 luego 3 dígitos)
    for n in range(min(len(cod), 10) - 1, 2, -1):
        pref = cod[:n]
        if pref in maestro:
            return {"codigo_canonico": pref, "denominacion": maestro[pref],
                    "metodo": f"prefijo_{n}d", "confianza": 0.97 if n >= 4 else 0.92}
    # 3) FUZZY por denominación
    dn = _norm(denom)
    if dn:
        best, ratio = max(
            ((c, SequenceMatcher(None, dn, nm).ratio()) for c, nm in nombres_norm.items()),
            key=lambda x: x[1], default=(None, 0.0),
        )
        if best and ratio >= 0.6:
            return {"codigo_canonico": best, "denominacion": maestro[best],
                    "metodo": "fuzzy", "confianza": round(ratio, 3)}
    # 4) GRUPO (1-2 dígitos) — baja confianza, a revisar
    for n in (2, 1):
        pref = cod[:n]
        if pref in maestro:
            return {"codigo_canonico": pref, "denominacion": maestro[pref],
                    "metodo": f"grupo_{n}d", "confianza": 0.5}
    # 5) sin mapeo
    return {"codigo_canonico": None, "denominacion": None, "metodo": "no_mapeado", "confianza": 0.0}


_IMPORTE_KEYS = ("debe", "haber", "saldo", "sf", "saldo_final")


def _importe_ilegible(c) -> bool:
    """True si la fila TRAE campos de importe pero TODOS son None: el extractor no pudo LEER el número
    (motor_sys.num() devuelve None ante una celda no numérica, sin levantar flag 'dudoso'). Distingue
    'present-and-zero' (cero LIMPIO, legible) de 'absent/unreadable' (None, ilegible) — un SyS real tiene
    cuentas a cero legítimas que NO deben bloquear (test_cero_limpio_no_es_bloqueo)."""
    presentes = [c[k] for k in _IMPORTE_KEYS if k in c]
    return bool(presentes) and all(v is None for v in presentes)


def confianza_importe(c) -> float:
    """B4 (EPIC B): confianza del IMPORTE de una cuenta = calidad de lectura del número, NO su cuadre.
      - 0.0  si `dudoso` (OCR no halló nº) o el importe es ILEGIBLE (None en tabular; cero LIMPIO ≠ ilegible)
      - 0.5  si `multi` (varias columnas monetarias: ambigüedad real de cuál es el importe del ejercicio)
      - 1.0  tabular limpio (al menos un campo de importe legible, incluido un cero explícito)
    Nunca inventa: lo ilegible (0.0) o ambiguo (0.5) NO se auto-acepta; lo enruta a humano (rama)."""
    if c.get("dudoso") or _importe_ilegible(c):
        return 0.0
    if c.get("multi"):
        return 0.5
    return 1.0


def rama_hitl(metodo, conf_denom, conf_importe, umbral=UMBRAL_IMPORTE, umbral_denom=UMBRAL_DENOM) -> str:
    """B4 (EPIC B): ruteo HITL por los DOS ejes de confianza (importe ≥0,95 · denominación ≥0,88).
      - bloqueo : sin código (no_mapeado) o importe ILEGIBLE (conf_importe==0) -> nunca al importador sin humano
      - auto    : ambos ejes por encima de su umbral -> entra sin tocar
      - revision: mapeado pero un eje flojo (denom débil o importe ambiguo) -> humano confirma"""
    if metodo == "no_mapeado" or conf_importe <= 0.0:
        return "bloqueo"
    if conf_denom >= umbral_denom and conf_importe >= umbral:
        return "auto"
    return "revision"


def _tokens(s) -> frozenset:
    """Conjunto de tokens (>=2 chars) de una denominación normalizada, para el matching token-set."""
    return frozenset(t for t in _norm(s).split() if len(t) >= 2)


def sugerencias_top(codigo, denom, maestro, nombres_norm, nombres_tokens, top=3) -> list:
    """B2 (EPIC B): TOP-N candidatos PGC para una cuenta dudosa (cola HITL) — exacto/prefijo si existe +
    fuzzy(token-set) con SCORE. NUNCA elige por ti: ofrece alternativas ordenadas para que el humano
    confirme (regla 'nunca inventar'). El score fuzzy mezcla secuencia (SequenceMatcher) y solape de
    tokens (Jaccard), robusto a la reordenación de palabras de las denominaciones contables."""
    out, ya = [], set()
    cod = re.sub(r"\D", "", str(codigo or ""))
    if cod and cod in maestro:
        out.append({"codigo_canonico": cod, "denominacion": maestro[cod], "score": 1.0, "metodo": "exacto"})
        ya.add(cod)
    else:
        for n in range(min(len(cod), 10) - 1, 2, -1):
            if cod[:n] in maestro:
                out.append({"codigo_canonico": cod[:n], "denominacion": maestro[cod[:n]],
                            "score": 0.97 if n >= 4 else 0.92, "metodo": f"prefijo_{n}d"})
                ya.add(cod[:n])
                break
    dn, dn_tok = _norm(denom), _tokens(denom)
    if dn:
        scored = []
        for c, nm in nombres_norm.items():
            seq = SequenceMatcher(None, dn, nm).ratio()
            tk = nombres_tokens.get(c, frozenset())
            tok = (len(dn_tok & tk) / len(dn_tok | tk)) if (dn_tok or tk) else 0.0
            scored.append((c, round(0.5 * seq + 0.5 * tok, 3)))
        scored.sort(key=lambda x: x[1], reverse=True)
        for c, sc in scored:
            if sc < 0.3 or c in ya:
                continue
            out.append({"codigo_canonico": c, "denominacion": maestro[c], "score": sc, "metodo": "fuzzy"})
            ya.add(c)
            if len(out) >= top:
                break
    return out[:top]


def normalizar(cuentas, maestro=None, umbral=UMBRAL_IMPORTE, umbral_denom=UMBRAL_DENOM) -> dict:
    """cuentas: [{cuenta, denom/descripcion, debe?, haber?, saldo?/sf?, dudoso?, multi?}] -> canónico +
    revisión + resumen, con CONFIANZA POR CAMPO (importe ≥`umbral` · denominación ≥`umbral_denom`) y ruteo
    HITL (`rama`: auto/revisión/bloqueo) — EPIC B B4. Es aditivo: no cambia el código/saldo mapeado."""
    maestro = maestro or cargar_maestro()
    nombres_norm = {c: _norm(d) for c, d in maestro.items()}
    nombres_tokens = {c: _tokens(d) for c, d in maestro.items()}   # B2: cache para el matching token-set
    canonico, revision = [], []
    for c in cuentas:
        m = mapear_cuenta(c.get("cuenta"), c.get("denom") or c.get("descripcion"), maestro, nombres_norm)
        conf_denom = m["confianza"]                       # eje DENOMINACIÓN/mapeo (=confianza histórica)
        conf_importe = confianza_importe(c)               # eje IMPORTE (calidad de lectura del número)
        rama = rama_hitl(m["metodo"], conf_denom, conf_importe, umbral, umbral_denom)
        revisar = rama != "auto"                          # revisión y bloqueo van a la cola HITL
        row = {**c, **m, "confianza_denom": conf_denom, "confianza_importe": conf_importe,
               "rama": rama, "revisar": bool(revisar)}
        canonico.append(row)
        if revisar:
            revision.append({
                "cuenta_origen": c.get("cuenta"),
                "denom_origen": c.get("denom") or c.get("descripcion"),
                "sugerencia": m["codigo_canonico"], "metodo": m["metodo"], "confianza": conf_denom,
                # Confianza POR CAMPO + rama HITL (B4): la UI muestra qué eje falla y por qué bloquea/revisa.
                "confianza_denom": conf_denom, "confianza_importe": conf_importe, "rama": rama,
                # Provenance en la COLA (B1): el abogado ve de dónde vino la cuenta dudosa (fichero/fila/celda).
                "_fuente": c.get("_fuente"),
                # TOP-N sugerencias con score (B2): alternativas ordenadas para que el humano elija (no inventa).
                "sugerencias": sugerencias_top(c.get("cuenta"), c.get("denom") or c.get("descripcion"),
                                               maestro, nombres_norm, nombres_tokens),
            })
    n = len(canonico)
    return {
        "canonico": canonico,
        "revision": revision,
        "resumen": {
            "cuentas": n,
            "exactas": sum(1 for r in canonico if r["metodo"] == "exacto"),
            "prefijo": sum(1 for r in canonico if r["metodo"].startswith("prefijo")),
            "fuzzy": sum(1 for r in canonico if r["metodo"] == "fuzzy"),
            "grupo": sum(1 for r in canonico if r["metodo"].startswith("grupo")),
            "no_mapeadas": sum(1 for r in canonico if r["metodo"] == "no_mapeado"),
            # Desglose HITL por rama (B4): auto entra solo; en_revision + bloqueos = cola = a_revisar.
            "auto": sum(1 for r in canonico if r["rama"] == "auto"),
            "en_revision": sum(1 for r in canonico if r["rama"] == "revision"),
            "bloqueos": sum(1 for r in canonico if r["rama"] == "bloqueo"),
            "a_revisar": len(revision),
            "confianza_media": round(sum(r["confianza_denom"] for r in canonico) / n, 3) if n else 1.0,
            "confianza_importe_media": round(sum(r["confianza_importe"] for r in canonico) / n, 3) if n else 1.0,
        },
    }


if __name__ == "__main__":
    import json
    demo = [
        {"cuenta": "5720", "denom": "Banco c/c"},
        {"cuenta": "57200001", "denom": "Banco Santander c/c"},
        {"cuenta": "", "denom": "Bancos e instituciones de crédito c/c vista, euros"},
        {"cuenta": "ZZZ", "denom": "cuenta inventada sin sentido"},
    ]
    print(json.dumps(normalizar(demo)["resumen"], ensure_ascii=False, indent=1))
