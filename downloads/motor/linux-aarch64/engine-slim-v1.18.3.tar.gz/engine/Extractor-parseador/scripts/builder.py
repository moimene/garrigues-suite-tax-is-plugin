#!/usr/bin/env python3
"""builder.py — Proyección canónico contable -> Modelo 200 (parte contable).

Entrada : canónico (agrupado 4 dígitos: cuenta;denom;saldo_final;debe;haber;saldo_inicial),
          mapeo PGC->casilla (data/mapeo_pgc_aeat_<ej>.json) y catálogo (data/catalogo_contable_<ej>.json).
Salida  : XML mod200<ej> contable (Balance/CuentaPyG/CambiosPN) · XLS de estados contables AEAT ·
          casillas.csv · lineage_casillas.csv · cuadres_builder.md.

Signo por bloque (convención SyS: deudor>0, acreedor<0):
  Activo   -> casilla += saldo_final
  PN/Pasivo-> casilla += -saldo_final
  PyG      -> casilla += -saldo_final  (ingreso + / gasto -)
Resultado del ejercicio R = Σ_PyG(-saldo_final) -> casillas 00199 (balance) y 00500 (PyG).
Cuadre garantizado por construcción: TOTAL ACTIVO (00180) == TOTAL PN+PASIVO (00252).

El XML node = T+casilla. Estructura y orden = catálogo (schema-first del DR200). Solo se emiten
casillas con valor (minOccurs=0). Codificación ISO-8859-1 (como el esquema AEAT).
"""
from __future__ import annotations
import argparse, csv, json, sys
import reconciliador  # noqa: E402  (gate fail-closed de cuadre, B3 — chokepoint de emisión AEAT)
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))   # para importar campaign en modo CLI

# -------------------------------------------------------------------- utils
def fmt_es(x):
    if x is None: return ""
    neg = x < 0
    s = f"{abs(x):,.2f}".replace(",", "§").replace(".", ",").replace("§", ".")
    return ("-" if neg else "") + s

def fmt_xml(x):                       # 2 decimales, punto decimal, sin miles
    return f"{round(x, 2):.2f}"

def cargar_canonico(path):
    filas = []
    for r in csv.reader(open(path, encoding="utf-8-sig"), delimiter=";"):
        if r and str(r[0]).strip().isdigit():
            filas.append(dict(cuenta=r[0].strip(), denom=r[1],
                              sf=float(r[2]), debe=float(r[3]), haber=float(r[4]), si=float(r[5])))
    return filas

# -------------------------------------------------------------------- core
def proyectar(canonico, mapeo, catalogo):
    reglas = sorted([r for r in mapeo["reglas"] if r["prefijo"].isdigit()],
                    key=lambda r: -len(r["prefijo"]))
    def match(c4):
        for r in reglas:
            if c4.startswith(r["prefijo"]):
                return r
        return None

    casillas = {}                 # casilla -> importe
    lineage = []                  # cuenta -> casilla
    pyg_grupos = {"expl_ing": 0.0, "expl_gas": 0.0, "fin_ing": 0.0, "fin_gas": 0.0, "impuesto": 0.0}
    sec = {"ANC": 0.0, "AC": 0.0, "PN": 0.0, "PNC": 0.0, "PC": 0.0}
    no_map = []
    no_map_detalle = []   # cuentas sin casilla CON saldo material (rompen 00180=00252) -> residuo HITL explícito

    for f in canonico:
        c4, sf = f["cuenta"], f["sf"]
        r = match(c4)
        if not r:
            no_map.append(c4)
            if abs(sf) >= 0.01:   # solo las MATERIALES forman el residuo (las de saldo 0 son ruido informativo)
                no_map_detalle.append({"cuenta": c4, "denom": f.get("denom", ""), "saldo": round(sf, 2)})
            lineage.append(dict(cuenta=c4, denom=f["denom"], casilla="", bloque="", val=""))
            continue
        # Regla SIGN-CONDITIONAL (opcional, general): si la cuenta tiene saldo ACREEDOR (sf<0) y la regla
        # declara `casilla_acreedor`, la partida se reasigna a esa casilla (y, si se indican, a su bloque/sección
        # acreedores). Las reglas SIN `casilla_acreedor` no cambian: siguen usando `casilla`/`bloque`/`seccion`
        # simples (deudor y acreedor a la misma casilla). Caso 552 (D24, abogado 2026-06-28): cuenta corriente con
        # el grupo → deudor (sf>0) = activo financiero C/P (00162); acreedor (sf<0) = deuda C/P con el grupo (00238,
        # pasivo corriente). Un saldo acreedor NO debe ir a 00162 (que está en el ACTIVO). El signo está disponible
        # aquí en `sf` (convención SyS: deudor>0, acreedor<0); el bloque acreedor recoloca la sección correctamente.
        acreedor = sf < 0 and r.get("casilla_acreedor")
        casilla = r["casilla_acreedor"] if acreedor else r["casilla"]
        bloque = r.get("bloque_acreedor", r["bloque"]) if acreedor else r["bloque"]
        seccion = r.get("seccion_acreedor", r["seccion"]) if acreedor else r["seccion"]
        val = sf if bloque == "Activo" else -sf          # PN/Pasivo/PyG -> -sf
        casillas[casilla] = round(casillas.get(casilla, 0.0) + val, 2)
        if bloque in ("Activo",):
            sec[seccion] += val
        elif bloque in ("PN", "Pasivo"):
            sec[seccion] += val
        else:                                            # PyG
            pyg_grupos[seccion] = pyg_grupos.get(seccion, 0.0) + val
        lineage.append(dict(cuenta=c4, denom=f["denom"], casilla=casilla,
                            bloque=bloque, val=round(val, 2)))

    # resultado
    R = round(sum(pyg_grupos.values()), 2)
    rc = mapeo["resultado_casillas"]
    casillas[rc["explotacion"]] = round(pyg_grupos["expl_ing"] + pyg_grupos["expl_gas"], 2)
    casillas[rc["financiero"]] = round(pyg_grupos["fin_ing"] + pyg_grupos["fin_gas"], 2)
    casillas[rc["antes_impuestos"]] = round(casillas[rc["explotacion"]] + casillas[rc["financiero"]], 2)
    casillas[rc["impuesto"]] = round(pyg_grupos["impuesto"], 2)
    casillas[rc["continuadas"]] = round(casillas[rc["antes_impuestos"]] + casillas[rc["impuesto"]], 2)
    casillas[rc["pyg"]] = R
    casillas[rc["balance"]] = R                          # 00199 resultado del ejercicio (en PN)
    sec["PN"] += R                                       # el resultado forma parte del PN

    # headers de sección + totales
    secdef = mapeo["secciones_balance"]
    for s, d in secdef.items():
        casillas[d["header"]] = round(sec[s], 2)
    tot = mapeo["totales"]
    casillas["00180"] = round(sec["ANC"] + sec["AC"], 2)
    casillas["00252"] = round(sec["PN"] + sec["PNC"] + sec["PC"], 2)

    # Subtotales INTERMEDIOS del balance/PyG (roll-up): subtotal = suma de sus hijos (hojas o subtotales).
    # El importador AEAT los recalcula y EXIGE en el .200 (van en casillas.csv); el XML XSD NO los emite
    # (no están en el esquema, los recompone la AEAT). 2024: el mapeo no trae 'subtotales' -> no se computa
    # nada (byte-idéntico). El header de sección (00101/00136/…) lo sigue calculando `sec` (no en 'subtotales').
    subt = mapeo.get("subtotales", {})

    def _suma_sub(cas, pila):
        if cas in pila:
            return 0.0
        if cas in subt:
            return round(sum(_suma_sub(h, pila | {cas}) for h in subt[cas]), 2)
        return casillas.get(cas, 0.0)

    for cas in subt:
        v = _suma_sub(cas, frozenset())
        if abs(v) >= 0.005:
            casillas[cas] = v

    cuadre = dict(total_activo=casillas["00180"], total_pnpasivo=casillas["00252"],
                  dif=round(casillas["00180"] - casillas["00252"], 2),
                  resultado=R, no_map=no_map, no_map_detalle=no_map_detalle,
                  n_casillas=len([k for k, v in casillas.items() if v]))
    return casillas, lineage, cuadre, pyg_grupos, sec

# -------------------------------------------------------------------- XML
def casillas_calculadas(mapeo):
    """Casillas que la AEAT RECALCULA y NO admite en la «Importación de datos contables»
    (devuelve «la clave XXXXX … no está habilitada para su cumplimentación»): subtotales de
    roll-up, headers de sección, totales de balance y subtotales de resultado de la PyG.

    NO incluye las casillas-hoja que el motor deriva pero la AEAT SÍ admite como entrada en el
    import contable: 00199 (resultado del ejercicio en el balance) y 00326 (impuesto s/ beneficios).

    Verificado contra el simulador Sociedades WEB Open 2025 (import real, 2026-06-26): las casillas
    rechazadas para el caso CYA (00111/00138/00177/00211/00255) son exactamente las claves de
    `mapeo["subtotales"]` presentes en el XML. Los headers/totales/result-PyG ya los excluía el XSD,
    pero se añaden aquí por robustez (si el XSD se regenera incluyéndolos). El `.200` (DR200) SÍ los
    exige y se construye aparte — esta exclusión solo afecta al XML contable."""
    if not mapeo:
        return set()
    calc = set(mapeo.get("subtotales", {}))                                   # subtotales de balance/PyG
    calc |= {d["header"] for d in mapeo.get("secciones_balance", {}).values() if d.get("header")}
    calc |= set(mapeo.get("totales", {}))                                     # 00180, 00252
    rc = mapeo.get("resultado_casillas", {})
    for k in ("pyg", "explotacion", "financiero", "antes_impuestos", "continuadas"):
        if rc.get(k):
            calc.add(rc[k])                                                   # 00500/00296/00324/00325/00327
    return calc                                                              # (NO 00199 ni 00326: importables)


def construir_xml(casillas, xsd_campos, rama="Normal", mapeo=None):
    """Emite el XML usando SOLO las casillas importables del XSD y en su ORDEN (xs:sequence).
    Los subtotales/totales/resultados calculados que no existen en el XSD (00101, 00180, 00185,
    00252, 00296, 00324, 00500, ...) NO se emiten: los recompone la AEAT al importar.

    Además, si se pasa `mapeo`, se EXCLUYEN las casillas calculadas (`casillas_calculadas`) aunque
    el XSD las incluya por error: el import de datos contables las rechaza como «no habilitada para
    su cumplimentación» (validado en el simulador AEAT 2025)."""
    raiz = xsd_campos["raiz"]
    pags = xsd_campos["paginas"]                      # pagina -> [casillas en orden del esquema]
    excluir = casillas_calculadas(mapeo)
    def page_xml(pkey):
        out = [f"      <T{c}>{fmt_xml(casillas[c])}</T{c}>"
               for c in pags.get(pkey, [])
               if c not in excluir and casillas.get(c) is not None and abs(casillas.get(c, 0)) >= 0.005]
        return f"    <{pkey}>\n" + "\n".join(out) + f"\n    </{pkey}>" if out else ""
    def bloque_xml(nombre, paginas):
        ps = [p for p in (page_xml(x) for x in paginas) if p]
        return f"  <{nombre}>\n" + "\n".join(ps) + f"\n  </{nombre}>" if ps else ""
    bloques = [bloque_xml(n, xsd_campos["bloques"][n]) for n in ("Balance", "CuentaPyG", "CambiosPN")]
    cuerpo = "\n".join(b for b in bloques if b)
    return (f'<?xml version="1.0" encoding="ISO-8859-1"?>\n<{raiz}>\n <{rama}>\n'
            f"{cuerpo}\n </{rama}>\n</{raiz}>\n")

# -------------------------------------------------------------------- XLS
def construir_xlsx(casillas, catalogo, path, empresa, ejercicio):
    import openpyxl
    from openpyxl.styles import Font, PatternFill, Alignment
    wb = openpyxl.Workbook()
    green = PatternFill("solid", fgColor="004438"); white = Font(color="FFFFFF", bold=True)
    bold = Font(bold=True)
    bloque_pag = {"Balance": catalogo["bloques"]["Balance"],
                  "CuentaPyG": catalogo["bloques"]["CuentaPyG"],
                  "CambiosPN": catalogo["bloques"]["CambiosPN"]}
    titulos = {"Balance": "Balance", "CuentaPyG": "Cuenta de PyG", "CambiosPN": "ECPN"}
    first = True
    for bloque, paginas in bloque_pag.items():
        ws = wb.active if first else wb.create_sheet()
        ws.title = titulos[bloque]; first = False
        ws.append(["Casilla", f"{titulos[bloque]} — {empresa} {ejercicio}", "Importe (€)"])
        for c in ws[1]:
            c.fill = green; c.font = white
        ws.column_dimensions['A'].width = 9
        ws.column_dimensions['B'].width = 62
        ws.column_dimensions['C'].width = 20
        for p in paginas:
            for campo in catalogo["paginas"][p]["campos"]:
                v = casillas.get(campo["casilla"])
                if v is None or abs(v) < 0.005:
                    continue
                etiqueta = campo["etiqueta"]
                es_total = etiqueta.isupper()
                ws.append([campo["casilla"], etiqueta, round(v, 2)])
                row = ws[ws.max_row]
                row[2].number_format = '#,##0.00'
                if es_total:
                    for cell in row: cell.font = bold
        ws.freeze_panes = "A2"
    wb.save(path)

# -------------------------------------------------------------------- run
def build(canonico_csv, mapeo_json, catalogo_json, outdir, empresa="", ejercicio="2025", xsd_campos_json=None):
    canonico = cargar_canonico(canonico_csv)
    # GATE FAIL-CLOSED de cuadre (B3 / EPIC B): este es el chokepoint que ESCRIBE el XML mod200 +
    # estados_contables_aeat.xlsx. Un canónico descuadrado (Σdebe≠Σhaber o Σdeudor≠Σacreedor, céntimos
    # exactos) NO debe emitir AEAT por NINGUNA vía (CLI `python builder.py`, pipeline, servicio).
    reconciliador.exigir_cuadre(canonico)
    mapeo = json.load(open(mapeo_json, encoding="utf-8"))
    catalogo = json.load(open(catalogo_json, encoding="utf-8"))
    if not xsd_campos_json:                                  # resolver por campaña (ejercicio)
        try:
            import campaign
            xsd_campos_json = campaign.resolve(ejercicio)["xsd_campos"]
        except Exception:
            cand = Path(catalogo_json).parent / f"xsd_campos_{ejercicio}.json"
            xsd_campos_json = str(cand if cand.exists() else Path(catalogo_json).parent / "xsd_campos_2024.json")
    xsd_campos = json.load(open(xsd_campos_json, encoding="utf-8"))
    casillas, lineage, cuadre, pyg, sec = proyectar(canonico, mapeo, catalogo)
    # B3: el balance AEAT proyectado también debe cuadrar (00180=00252, sin no_map) antes de escribir nada.
    reconciliador.exigir_cuadre_proyeccion(cuadre)
    out = Path(outdir); out.mkdir(parents=True, exist_ok=True)

    xml = construir_xml(casillas, xsd_campos, mapeo=mapeo)
    (out / f"modelo200_contable_{ejercicio}.xml").write_bytes(xml.encode("iso-8859-1", "replace"))
    construir_xlsx(casillas, catalogo, out / "estados_contables_aeat.xlsx", empresa, ejercicio)

    with open(out / "casillas.csv", "w", encoding="utf-8-sig", newline="") as f:
        w = csv.writer(f, delimiter=";"); w.writerow(["casilla", "tcode", "bloque", "etiqueta", "importe"])
        for cod in sorted(k for k, v in casillas.items() if abs(v) >= 0.005):
            info = catalogo["por_casilla"].get(cod, {})
            w.writerow([cod, "T" + cod, info.get("bloque", ""), info.get("etiqueta", ""), round(casillas[cod], 2)])
    with open(out / "lineage_casillas.csv", "w", encoding="utf-8-sig", newline="") as f:
        w = csv.writer(f, delimiter=";"); w.writerow(["cuenta", "denominacion", "casilla", "bloque", "importe"])
        for l in lineage: w.writerow([l["cuenta"], l["denom"], l["casilla"], l["bloque"], l["val"]])

    ok = abs(cuadre["dif"]) < 0.01
    md = [f"# Cuadres del builder · {empresa} {ejercicio}", "",
          f"- Casillas con valor: **{cuadre['n_casillas']}**",
          f"- TOTAL ACTIVO (00180) = **{fmt_es(cuadre['total_activo'])}**",
          f"- TOTAL PN+PASIVO (00252) = **{fmt_es(cuadre['total_pnpasivo'])}**",
          f"- Diferencia balance = **{fmt_es(cuadre['dif'])}** → {'✅ cuadra' if ok else '🔴 DESCUADRE'}",
          f"- Resultado del ejercicio (00500/00199) = **{fmt_es(cuadre['resultado'])}**",
          "",
          "## Resultado P y G (componentes)",
          f"- Resultado de explotación (00296) = {fmt_es(casillas.get('00296',0))}",
          f"- Resultado financiero (00324) = {fmt_es(casillas.get('00324',0))}",
          f"- Resultado antes de impuestos (00325) = {fmt_es(casillas.get('00325',0))}",
          f"- Impuesto sobre beneficios (00326) = {fmt_es(casillas.get('00326',0))}",
          ]
    if cuadre["no_map"]:
        md += ["", f"## Cuentas sin mapear ({len(cuadre['no_map'])})",
               "> No impiden el cuadre; se computa el resultado aparte. Revisar mapeo si procede.",
               "", ", ".join(cuadre["no_map"])]
    (out / "cuadres_builder.md").write_text("\n".join(md) + "\n", encoding="utf-8")
    cuadre["cuadra"] = ok
    return cuadre

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--canonico", required=True)
    ap.add_argument("--mapeo", default=str(Path(__file__).resolve().parent.parent / "data" / "mapeo_pgc_aeat_2025.json"))
    ap.add_argument("--catalogo", default=str(Path(__file__).resolve().parent.parent / "data" / "catalogo_contable_2025.json"))
    ap.add_argument("--outdir", required=True)
    ap.add_argument("--empresa", default="")
    ap.add_argument("--ejercicio", default="2025")
    ap.add_argument("--xsd-campos", default=None)
    a = ap.parse_args()
    c = build(a.canonico, a.mapeo, a.catalogo, a.outdir, a.empresa, a.ejercicio, a.xsd_campos)
    print(f"{'OK ✅' if c['cuadra'] else 'DESCUADRE 🔴'} · casillas={c['n_casillas']} · "
          f"TOTAL ACTIVO={fmt_es(c['total_activo'])} · TOTAL PN+PASIVO={fmt_es(c['total_pnpasivo'])} · "
          f"dif={fmt_es(c['dif'])} · resultado={fmt_es(c['resultado'])}")
    if c["no_map"]:
        print("Sin mapear:", ", ".join(c["no_map"]))

if __name__ == "__main__":
    main()
