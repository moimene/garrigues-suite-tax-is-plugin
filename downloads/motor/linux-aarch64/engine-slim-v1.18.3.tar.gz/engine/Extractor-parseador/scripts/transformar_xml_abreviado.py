"""Transforma el XML contable mod200 (Balance/PyG/ECPN) emitido como NORMAL en ABREVIADO.

El importador "Importación de datos contables" de Sociedades WEB Open valida el XML contra mod200YYYY.xsd
y contra el ESTADO DE CUENTAS declarado en la UI (normal/abreviado/PYMES). El XML NO lleva flags de modelo:
el abreviado se selecciona en pantalla. Por tanto el XML abreviado = XML normal con SOLO las casillas
emitibles-en-abreviado (XSD∩A o carrier del mapa), con el detalle (N)-only reagrupado en sus carriers.

Reusa el MISMO mapa certificado (estados_contables_rollups.json) y catálogo que el transform del .200.
Determinista, 0 PII (no imprime importes).
"""
from __future__ import annotations

import re
import sys
from decimal import Decimal, ROUND_HALF_UP
from pathlib import Path
import xml.etree.ElementTree as ET

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
from transformar_200_abreviado import cargar_catalogo, cargar_rollups, cargar_xsd_importables  # noqa: E402
import dr200  # noqa: E402

SECCION_DE_PAGINA = {  # DR page -> (sección XML, PaginaNN)
    "DP200003": ("Balance", "Pagina03"), "DP200004": ("Balance", "Pagina04"),
    "DP200005": ("Balance", "Pagina05"), "DP200006": ("Balance", "Pagina06"),
    "DP200007": ("CuentaPyG", "Pagina07"), "DP200008": ("CuentaPyG", "Pagina08"),
    "DP200009": ("CambiosPN", "Pagina09"), "DP200010": ("CambiosPN", "Pagina10"),
    "DP200011": ("CambiosPN", "Pagina11"),
}


def _casilla_pagina(dr):
    idx = {}
    for pag, campos in dr.items():
        for c in campos:
            cas = c.get("casilla")
            if cas and cas not in idx:
                idx[cas] = pag
    return idx


def leer_xml(path):
    """{casilla: Decimal(euros)} desde el XML contable (elementos T#####)."""
    txt = Path(path).read_text(encoding="latin-1")
    out = {}
    for m in re.finditer(r"<T(\d{5})>\s*(-?[\d.]+)\s*</T\d{5}>", txt):
        try:
            out[m.group(1)] = Decimal(m.group(2))
        except Exception:
            pass
    root = re.search(r"<(MOD200\d{4})>", txt)
    return out, (root.group(1) if root else "MOD2002025")


def proyectar_dict(casillas, perfil="abreviado", familias=("balance", "pyg", "ecpn"),
                   catalogo=None, rollups=None, ejercicio="2025"):
    catalogo = catalogo or cargar_catalogo()
    rollups = rollups or cargar_rollups()
    cat = catalogo["casillas"]
    cas2pag = _casilla_pagina(dr200.cargar_dr(ejercicio=ejercicio))
    xsd = cargar_xsd_importables(ejercicio)
    letra = {"abreviado": "A", "pymes": "P"}[perfil]
    rolls = rollups.get("targets", {}).get(perfil, {})
    targets = {t: r for fam in familias for t, r in rolls.get(fam, {}).items()}
    fuentes = {s for r in targets.values() for s in r.get("from", [])}
    calc = rollups.get("calculada_en_abreviado", {})
    calc_set = {c for fam in familias for c in calc.get(fam, [])}
    if perfil == "pymes":
        # PYMES agrega MÁS que abreviado: subtotales que en abreviado son CARRIER (se emiten) en PYMES son
        # CALCULADOS (Open los recompone; su valor fluye por el detalle al super-carrier PYMES). p.ej. 00202
        # (Ajustes cambios valor) es target en abreviado pero calc en PYMES (su valor va por 00203-207 -> 00208).
        calcp = rollups.get("calculada_en_pymes", {})
        calc_set |= {c for fam in familias for c in calcp.get(fam, [])}
    fam_pags = {p for fam in familias
                for p in catalogo.get("familias", {}).get(fam, {}).get("paginas", [])}

    def importable(cas):
        if cas in fuentes:
            return False
        if cas in calc_set:
            return False
        if cas in targets:
            return True
        pag = cas2pag.get(cas)
        return pag in xsd and cas in xsd[pag] and letra in cat.get(cas, {}).get("modelos", [])

    out, informe = {}, {"removidas": [], "targets": []}
    # solo casillas de las familias pedidas
    presente = {c: v for c, v in casillas.items() if cas2pag.get(c) in fam_pags}
    for c, v in presente.items():
        if importable(c):
            out[c] = v
        else:
            informe["removidas"].append(c)
    for t, r in targets.items():
        if cas2pag.get(t) not in fam_pags:
            continue
        orig = presente.get(t) or Decimal(0)
        suma = sum((presente.get(s) or Decimal(0)) for s in r.get("from", []))
        val = (orig if orig != 0 else suma) if r.get("op") == "propio_o_suma" else orig + suma
        if val and val != 0:
            out[t] = val
            informe["targets"].append(t)
        elif t in out and (not val):
            del out[t]
    return out, informe, cas2pag


def aplicar_perfil_estados_contables(contable, familias=("balance", "pyg", "ecpn"), ejercicio="2025",
                                     perfil="abreviado", mantener_calculadas=False):
    """Proyecta el dict CONTABLE {casilla: valor} al PERFIL pedido (abreviado/PYMES) para las familias dadas,
    CONSERVANDO las casillas que no son de estados contables. Devuelve (contable_proyectado, informe). Spec §7.

    PYMES agrega MÁS que abreviado: comparte los carriers de abreviado (XSD∩P) y, además, 00202 (Ajustes, A-no-P)
    colapsa en 00208 (Ajustes en PN PYMES). Reusa el mismo mapa CERTIFICADO en Open
    (estados_contables_rollups.json). Opt-in: el llamador decide. Los valores de salida se devuelven como str
    de euros (formato que consume construir_fichero).

    `mantener_calculadas` (DESTINO `.200`, NO XML): tras plegar el detalle (N)-only en sus carriers, RE-AÑADE los
    subtotales/totales/resultados CALCULADOS (`calculada_en_<perfil>`) a su valor NORMAL. El XML los EXCLUYE (Open
    los rellena) pero el `.200` es de ancho fijo y Open VALIDA LA HOJA ENTERA: si una casilla calculada queda a 0.00
    la RECHAZA («se ha calculado un valor X y el valor importado es 0.00», reimport REAL NS BILBAO 2026-06-30). El
    plegado CONSERVA los subtotales (el carrier captura su detalle dentro del mismo subárbol) → el valor que Open
    recompone desde los carriers plegados == el subtotal normal, así que re-ponerlo es coherente. Los carriers
    (00115/00177/00195/00202…) NO son calculadas: son HOJAS emitibles del perfil (Open no las recompone)."""
    catalogo = cargar_catalogo()
    cas2pag = _casilla_pagina(dr200.cargar_dr(ejercicio=str(ejercicio)))
    fam_pags = {p for fam in familias
                for p in catalogo.get("familias", {}).get(fam, {}).get("paginas", [])}
    cas_dec = {}
    for c, v in (contable or {}).items():
        s = str(v).strip()
        if s in ("", "None"):
            continue
        try:
            cas_dec[c] = Decimal(s.replace(",", "."))
        except Exception:
            pass
    abrev, informe, _ = proyectar_dict(cas_dec, perfil=perfil, familias=familias,
                                       catalogo=catalogo, ejercicio=ejercicio)
    # conservar lo que NO es de estados de esas familias; reemplazar los estados por la proyección abreviado
    out = {c: v for c, v in (contable or {}).items() if cas2pag.get(c) not in fam_pags}
    out.update({c: _fmt(v) for c, v in abrev.items()})
    if mantener_calculadas:
        # CALC SET = el GIP-verificado del mapeo (subtotales roll-up + headers de sección + totales 00180/00252 +
        # resultados PyG): las casillas que Open REALMENTE recompone (verificadas contra import real). MENOS los
        # subtotales que el abreviado/PYMES COLAPSA (SUBTOTALES_COLAPSADOS_200): su detalle se promueve a un carrier
        # del nivel superior, así que Open los RECHAZA en el `.200` («la casilla NNNNN no puede tener contenido»).
        # NO se re-añaden -> quedan a 0.00 (Open lo acepta para una casilla fuera del modelo abreviado).
        mapeo = _cargar_mapeo(ejercicio)
        rollups = cargar_rollups()
        letra = {"abreviado": "A", "pymes": "P"}[perfil]
        targets_perfil = {
            t
            for fam in familias
            for t in ((rollups.get("targets") or {}).get(perfil) or {}).get(fam, {})
        }
        calc_set = set(mapeo.get("subtotales", {}))
        calc_set |= {d.get("header") for d in mapeo.get("secciones_balance", {}).values() if d.get("header")}
        calc_set |= set(mapeo.get("totales", {}))
        _rc = mapeo.get("resultado_casillas", {})
        calc_set |= {_rc[k] for k in ("pyg", "explotacion", "financiero", "antes_impuestos", "continuadas") if _rc.get(k)}
        colapsadas = set(SUBTOTALES_COLAPSADOS_200)
        if perfil == "pymes":
            # PYMES COLAPSA MÁS que abreviado: las casillas `calculada_en_pymes` (p.ej. 00202 Ajustes por cambios de
            # valor -> super-carrier 00208 Ajustes en PN) NO existen como línea en PYMES; la proyección ya las quita,
            # pero están en `mapeo['subtotales']` y se re-añadirían por error -> Open RECHAZA 00202 junto al carrier
            # 00208 («no puede tener contenido»). Codex 2026-06-30. Fuente autoritativa: los rollups certificados.
            _calcp = rollups.get("calculada_en_pymes", {})
            colapsadas |= {c for fam in familias for c in _calcp.get(fam, [])}
        calc_set -= colapsadas
        for c in calc_set:
            info = (catalogo.get("casillas") or {}).get(c) or {}
            modelos = set(info.get("modelos") or [])
            if modelos and letra not in modelos and c not in targets_perfil:
                # Reimport real GMD Turistica 2025: 00705 es subtotal normal, pero en abreviado/PYMES queda
                # plegado en 00255. Reanadirlo por estar en `mapeo["subtotales"]` provoca E25400705.
                continue
            if c in cas_dec:                       # subtotal/total/result CALCULADO -> valor NORMAL (ancho fijo lo exige)
                out[c] = _fmt(cas_dec[c])
    return out, informe


# (HISTÓRICO — lección de 2 reimports reales NS BILBAO, 2026-06-30.) Se creyó que 00126/00231 eran subtotales que
# el abreviado COLAPSA y por eso había que NO emitirlos (en el 1er reimport Open los rechazó «no puede tener
# contenido»). FALSO: ese rechazo era SÍNTOMA del detalle (N)-only SIN PLEGAR en el fichero — con 00116/00117/00131
# con contenido, Open invalida también su subtotal. Con el detalle PLEGADO en sus carriers, Open RECOMPONE
# 00126 = Σ(00127..00133) = 00133 (donde se plegó 00131) y EXIGE ese valor (2º reimport: «se ha calculado 139541.40
# y el valor importado es 0.00»). Conclusión: el abreviado NO colapsa ningún subtotal FUERA de su subárbol — TODOS
# se re-añaden a su valor normal (su carrier vive dentro del propio subtotal). El único colapso REAL es PYMES con
# 00202 -> super-carrier 00208 (FUERA del subárbol), que se excluye aparte vía `calculada_en_pymes`. Por eso este
# set queda VACÍO. (Mantengo el gancho por si el cap04 documenta algún colapso abreviado verdadero en el futuro.)
SUBTOTALES_COLAPSADOS_200 = set()


def _cargar_mapeo(ejercicio="2025"):
    import json
    # EJERCICIO-SCOPED (Codex 2026-06-30): cada campaña tiene su propia topología de subtotales; NO heredar la de
    # 2025 para otro año (fail-closed: el 2024 tiene 0 subtotales). DATA apunta a campaigns/2025 -> se resuelve la
    # campaña del ejercicio pedido. (La proyección de perfiles solo está certificada para 2025.)
    from transformar_200_abreviado import DATA
    return json.loads((DATA.parent / str(ejercicio) / "mapeo_pgc_aeat.json").read_text(encoding="utf-8"))


def _fmt(v: Decimal) -> str:
    return str(v.quantize(Decimal("0.01"), rounding=ROUND_HALF_UP))


def cargar_xsd_orden(ejercicio="2025") -> dict:
    """{DP200NN: {casilla: indice}} con el ORDEN de los <xs:element T#####> en el XSD (la SECUENCIA es
    obligatoria: el importador valida cvc-complex-type.2.4.a si los elementos van desordenados)."""
    from transformar_200_abreviado import DATA
    xsd = (DATA / f"mod200{ejercicio}_normal.xsd").read_text(encoding="utf-8")
    pg2dp = {"03": "DP200003", "04": "DP200004", "05": "DP200005", "06": "DP200006",
             "07": "DP200007", "08": "DP200008", "09": "DP200009", "10": "DP200010", "11": "DP200011"}
    out = {}
    for pg, dp in pg2dp.items():
        m = re.search(r'tipo_Pagina%s">(.*?)</xs:complexType>' % pg, xsd, re.S)
        orden = re.findall(r'name="T(\d{5})"', m.group(1)) if m else []
        out[dp] = {c: i for i, c in enumerate(orden)}
    return out


def emitir_xml(casillas_abrev, cas2pag, root="MOD2002025", ejercicio="2025") -> str:
    orden = cargar_xsd_orden(ejercicio)
    secciones = {}  # seccion -> {PaginaNN -> [(casilla,val,dp)]}
    for cas, v in casillas_abrev.items():
        dp = cas2pag.get(cas)
        sp = SECCION_DE_PAGINA.get(dp)
        if not sp:
            continue
        sec, pag = sp
        secciones.setdefault(sec, {}).setdefault(pag, []).append((cas, v, dp))
    lines = ['<?xml version="1.0" encoding="ISO-8859-1"?>', f"<{root}>", " <Normal>"]
    for sec in ("Balance", "CuentaPyG", "CambiosPN"):
        if sec not in secciones:
            continue
        lines.append(f"  <{sec}>")
        for pag in sorted(secciones[sec]):
            lines.append(f"    <{pag}>")
            # ORDEN del XSD (no numérico): obligatorio para pasar la validación de estructura
            filas = sorted(secciones[sec][pag], key=lambda x: orden.get(x[2], {}).get(x[0], 9999))
            for cas, v, _ in filas:
                lines.append(f"      <T{cas}>{_fmt(v)}</T{cas}>")
            lines.append(f"    </{pag}>")
        lines.append(f"  </{sec}>")
    lines += [" </Normal>", f"</{root}>", ""]
    return "\n".join(lines)


def transformar(path_in, path_out, perfil="abreviado", familias=("balance", "pyg", "ecpn"), ejercicio="2025"):
    casillas, root = leer_xml(path_in)
    abrev, informe, cas2pag = proyectar_dict(casillas, perfil=perfil, familias=familias, ejercicio=ejercicio)
    Path(path_out).write_text(emitir_xml(abrev, cas2pag, root=root, ejercicio=ejercicio), encoding="latin-1")
    return {"n_in": len(casillas), "n_out": len(abrev), "removidas": len(informe["removidas"]),
            "targets": informe["targets"], "out": path_out}


if __name__ == "__main__":
    import argparse, json  # noqa: E401
    ap = argparse.ArgumentParser()
    ap.add_argument("path")
    ap.add_argument("--out", required=True)
    ap.add_argument("--familias", default="balance,pyg,ecpn")
    ap.add_argument("--ejercicio", default="2025")
    ap.add_argument("--perfil", default="abreviado", choices=["abreviado", "pymes"])
    a = ap.parse_args()
    fams = tuple(x.strip() for x in a.familias.split(",") if x.strip())
    print(json.dumps(transformar(a.path, a.out, perfil=a.perfil, familias=fams, ejercicio=a.ejercicio),
                     ensure_ascii=False))
