#!/usr/bin/env python3
"""Clasificador de documentos contables/fiscales (EPIC B / D12 + tipología ampliada D14, Stage 0).

Reusa `harness.detectar_clase` del EPC (clase base + motor) y AÑADE, sin tocar el enrutado del
pipeline EPC:
  - una CLASE más fina (tipología ampliada): libro_mayor, libro_diario, balance_situacion, pyg,
    memoria, modelo_202, modelo_222, además de las base (sumas_y_saldos, cuentas_anuales,
    declaracion_previa, datos_clave),
  - la FAMILIA de procesamiento (tabular / pdf / pdf_o_xml / json),
  - el DESTINO (qué consume la salida: contable / auditoria / declaracion / pagos_fraccionados / …),
  - una CONFIANZA y la extensión.

Así cada fichero se enruta al extractor correcto y la UI sabe a qué tabla/ruta alimenta:
  tabular (SyS/balance/PyG/mayor) -> extractor_contable;  PDF (CCAA/memoria/declaración) -> extractor_ccaa
  (+ OCR por HTTP si hace falta, D14).
"""
import os
import re
import sys
import unicodedata

_HERE = os.path.dirname(os.path.abspath(__file__))
if _HERE not in sys.path:
    sys.path.insert(0, _HERE)
import harness  # noqa: E402  (detectar_clase, reusado)

# clase -> (familia, destino). Cubre la tipología ampliada (D14).
TIPOLOGIA = {
    "sumas_y_saldos": ("tabular", "contable"),
    "balance_situacion": ("tabular", "contable"),
    "pyg": ("tabular", "contable"),
    "libro_mayor": ("tabular", "auditoria"),
    "libro_diario": ("tabular", "auditoria"),
    "cuentas_anuales": ("pdf", "contable_inferencia"),
    "memoria": ("pdf", "notas"),
    "declaracion_previa": ("pdf_o_xml", "declaracion"),
    "modelo_202": ("pdf_o_xml", "pagos_fraccionados"),
    "modelo_222": ("pdf_o_xml", "pagos_fraccionados_grupos"),
    "datos_clave": ("json", "parametros"),
    "desconocido": ("-", "-"),
}


def _sa(s: str) -> str:
    """Minúsculas sin acentos (para casar nombres con/sin tilde)."""
    return unicodedata.normalize("NFKD", str(s or "")).encode("ascii", "ignore").decode().lower()


def _refinar_clase(clase: str, nombre: str, head: str) -> str:
    """Afina la clase base (de harness) a la tipología ampliada, por nombre y luego contenido."""
    n = _sa(nombre)
    h = _sa(head)
    # 1) por nombre de fichero (lo más fiable cuando está presente).
    # Modelos 202/222 con frontera de dígito: "202" NO debe casar dentro de un año ("2024").
    if re.search(r"(?<!\d)222(?!\d)", n):
        return "modelo_222"
    if re.search(r"(?<!\d)202(?!\d)", n):
        return "modelo_202"
    if "mayor" in n:
        return "libro_mayor"
    if "diario" in n:
        return "libro_diario"
    if "memoria" in n:
        return "memoria"
    if any(k in n for k in ("perdidas", "ganancias", "pyg", "p y g", "pyg", "resultados")):
        return "pyg"
    if "situacion" in n:  # "balance de situación" (≠ "balance de sumas y saldos")
        return "balance_situacion"
    # 2) por contenido, solo si la base es tabular genérica (SyS)
    if clase == "sumas_y_saldos":
        tiene_masas = ("activo" in h) and ("pasivo" in h or "patrimonio" in h)
        tiene_debe_haber = ("debe" in h) and ("haber" in h)
        if tiene_masas and not tiene_debe_haber:
            return "balance_situacion"
    return clase


def clasificar(path: str) -> dict:
    clase_base, motor = harness.detectar_clase(path)
    ext = os.path.splitext(path)[1].lower()
    nombre = os.path.basename(path)
    head = harness._peek(path) if hasattr(harness, "_peek") else ""
    clase = _refinar_clase(clase_base, nombre, head)
    familia, destino = TIPOLOGIA.get(clase, ("-", "-"))
    confianza = 0.95 if clase_base not in ("desconocido", "-") else 0.3
    # más específico que la base -> un punto más de confianza (cap a 0.99)
    if clase != clase_base and clase != "desconocido":
        confianza = min(0.99, confianza + 0.02)
    es_pdf = ext == ".pdf" or motor == "extractor_ccaa"
    return {
        "clase": clase,
        "clase_base": clase_base,
        "familia": familia,
        "destino": destino,
        "motor": motor,
        "extension": ext,
        "es_pdf": es_pdf,
        "confianza": round(confianza, 2),
    }


if __name__ == "__main__":
    import json

    for p in sys.argv[1:]:
        print(json.dumps(clasificar(p), ensure_ascii=False))
