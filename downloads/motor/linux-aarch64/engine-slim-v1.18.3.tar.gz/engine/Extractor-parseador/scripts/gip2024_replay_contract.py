#!/usr/bin/env python3
"""Contrato comun para parsers del replay GIP 2024.

Cada parser debe poder devolver:
{
  "source": "liquidacion",
  "casillas": {"00552": 11068602.43},
  "campos_pos": {"DP200001": {"7": "B12345678"}},
  "warnings": [...]
}

Este modulo mezcla esas salidas sin decidir criterio fiscal. Si dos fuentes dan valores distintos para la
misma casilla/campo, registra conflicto y conserva el valor de mayor prioridad.
"""
from __future__ import annotations

import argparse
import json
from decimal import Decimal, InvalidOperation
from pathlib import Path


DEFAULT_PRIORITIES = {
    "datos_formales": 90,
    "liquidacion": 80,
    "datos_fiscales": 70,
    "balance_pyg": 60,
    "sumas_saldos": 50,
    "ccaa_ocr": 30,
}


def norm_casilla(cod) -> str:
    s = str(cod or "").strip()
    return s.zfill(5) if s.isdigit() and len(s) <= 5 else s


def comparable(v):
    if v in (None, ""):
        return ""
    try:
        return Decimal(str(v)).quantize(Decimal("0.01"))
    except (InvalidOperation, ValueError):
        return str(v).strip()


def _priority(source: dict) -> int:
    name = source.get("source") or source.get("category") or ""
    return int(source.get("priority", DEFAULT_PRIORITIES.get(name, 10)))


def merge_sources(sources: list[dict]) -> dict:
    merged_casillas = {}
    casilla_meta = {}
    merged_campos = {}
    campo_meta = {}
    conflicts = []
    warnings = []

    for src in sources:
        source_name = src.get("source") or src.get("category") or "unknown"
        prio = _priority(src)
        warnings.extend({"source": source_name, "warning": w} for w in src.get("warnings", []))

        for cod, val in (src.get("casillas") or {}).items():
            cod = norm_casilla(cod)
            if val in (None, ""):
                continue
            prev = merged_casillas.get(cod)
            if prev is not None and comparable(prev) != comparable(val):
                conflicts.append({
                    "kind": "casilla",
                    "key": cod,
                    "kept": prev,
                    "candidate": val,
                    "kept_source": casilla_meta[cod]["source"],
                    "candidate_source": source_name,
                })
                if prio <= casilla_meta[cod]["priority"]:
                    continue
            merged_casillas[cod] = val
            casilla_meta[cod] = {"source": source_name, "priority": prio}

        for page, fields in (src.get("campos_pos") or {}).items():
            page = str(page).strip()
            merged_campos.setdefault(page, {})
            campo_meta.setdefault(page, {})
            for num, val in (fields or {}).items():
                num = str(num).strip()
                if val in (None, ""):
                    continue
                prev = merged_campos[page].get(num)
                if prev is not None and comparable(prev) != comparable(val):
                    conflicts.append({
                        "kind": "campo_pos",
                        "key": f"{page}.{num}",
                        "kept": prev,
                        "candidate": val,
                        "kept_source": campo_meta[page][num]["source"],
                        "candidate_source": source_name,
                    })
                    if prio <= campo_meta[page][num]["priority"]:
                        continue
                merged_campos[page][num] = val
                campo_meta[page][num] = {"source": source_name, "priority": prio}

    return {
        "casillas": merged_casillas,
        "campos_pos": merged_campos,
        "meta": {
            "casillas": casilla_meta,
            "campos_pos": campo_meta,
            "conflicts": conflicts,
            "warnings": warnings,
        },
    }


def load_sources(paths: list[str]) -> list[dict]:
    return [json.loads(Path(p).read_text(encoding="utf-8")) for p in paths]


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("json", nargs="+")
    ap.add_argument("--out")
    args = ap.parse_args()
    merged = merge_sources(load_sources(args.json))
    text = json.dumps(merged, ensure_ascii=False, indent=2, default=str)
    if args.out:
        Path(args.out).write_text(text, encoding="utf-8")
    print(text)


if __name__ == "__main__":
    main()
