"""Generador del catálogo de perfiles de estados contables (Fase 1) desde cap04.

Produce:
  - estados_contables_perfiles.json: por casilla, en qué modelos aparece (N/A/P) y su clasificación
    (emitible/calculada/bloqueada) por perfil. La pertenencia al modelo sale de los marcadores cap04
    (parser row-aware); 'calculada' = subtotal con fórmula (Open lo recalcula).
  - NO escribe rollups: esos se AUTORIZAN a mano (estados_contables_rollups.json) y se certifican en Open.

Determinista, 0 PII.
"""
from __future__ import annotations

import json
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from extraer_perfiles_cap04 import parse_cap04  # noqa: E402

DATA = Path(__file__).resolve().parents[1] / "data/campaigns/2025"

# Páginas por sección/familia (DR Modelo 200, régimen general).
SECCION_PAGINAS = {
    "balance_activo": (["DP200003", "DP200004"], "balance"),
    "balance_pn_pasivo": (["DP200005", "DP200006"], "balance"),
    "pyg": (["DP200007", "DP200008"], "pyg"),
    "ecpn": (["DP200009", "DP200010", "DP200011"], "ecpn"),
}


def construir_catalogo() -> dict:
    secciones = parse_cap04()
    casillas: dict[str, dict] = {}
    for sec, ents in secciones.items():
        paginas, familia = SECCION_PAGINAS[sec]
        for e in ents:
            cas = e["casilla"]
            modelos = e["modelos"]
            es_subtotal = bool(e["formula"])  # tiene fórmula => Open lo calcula
            # clasificación por perfil
            def clasif(letra):
                if letra not in modelos:
                    return "bloqueada"
                return "calculada" if es_subtotal else "emitible"
            casillas.setdefault(cas, {
                "seccion": sec,
                "familia": familia,
                "modelos": sorted(modelos),
                "es_subtotal": es_subtotal,
                "es_agregado_abreviado": ("A" in modelos and "N" not in modelos),
                "normal": clasif("N"),
                "abreviado": clasif("A"),
                "pymes": clasif("P"),
                "label": e["label"],
            })
    return casillas


def main():
    casillas = construir_catalogo()
    out = {
        "ejercicio": "2025",
        "version": "2025-estado-contable-v2-fase1",
        "estado": "FASE_1_catalogo_marcadores",
        "nota": ("Catálogo de pertenencia al modelo (N/A/P) por casilla, derivado del parser row-aware de "
                 "cap04 (régimen general, páginas 3-11; excluye Banco de España 27-33). 'calculada'=subtotal "
                 "con fórmula. Los rollups (Resto/Otros) se autorizan a mano en estados_contables_rollups.json "
                 "y se certifican en Open antes de activar abreviado/PYMES. Spec: "
                 "docs/MODELO200_2025_PERFILES_ESTADOS_CONTABLES_IMPLEMENTACION.md"),
        "fuentes": {"cap04": "suite-is/Manual_Sociedades_2025_md/04_Cap04_Estados_contables_modelo_200.md",
                    "dr": "DR200e25", "open_evidencia": ["ARIOSO 2026-06-27", "RRE/RIV IV/SERINDE 2026-06-29"]},
        "familias": {
            "balance": {"paginas": ["DP200003", "DP200004", "DP200005", "DP200006"], "dp200001b_campo": 14},
            "ecpn": {"paginas": ["DP200009", "DP200010", "DP200011"], "dp200001b_campo": 15},
            "pyg": {"paginas": ["DP200007", "DP200008"], "dp200001b_campo": 16},
        },
        "perfiles": {
            "normal": {"codigo_dp200001b": 1, "estado": "validado"},
            "abreviado": {"codigo_dp200001b": 2, "estado": "experimental", "soportado": False},
            "pymes": {"codigo_dp200001b": 3, "estado": "experimental", "soportado": False},
        },
        "casillas": dict(sorted(casillas.items())),
    }
    dest = DATA / "estados_contables_perfiles.json"
    dest.write_text(json.dumps(out, ensure_ascii=False, indent=1), encoding="utf-8")
    n_abr = sum(1 for c in casillas.values() if "A" in c["modelos"])
    n_nonly = sum(1 for c in casillas.values() if c["modelos"] == ["N"])
    print(f"OK · {len(casillas)} casillas · abreviado-válidas={n_abr} · normal-only={n_nonly} → {dest}")


if __name__ == "__main__":
    main()
