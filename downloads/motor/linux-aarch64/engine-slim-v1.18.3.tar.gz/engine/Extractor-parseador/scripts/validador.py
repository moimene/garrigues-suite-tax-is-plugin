#!/usr/bin/env python3
"""validador.py — Valida el XML contable Modelo 200 antes de entregarlo.

Tres niveles:
  1. ESTRUCTURAL (contra catálogo): raíz MOD200<ej>, una sola rama, bloques/páginas en orden, cada
     T##### existe y pertenece a su página, importes con 2 decimales y punto decimal.
  2. NEGOCIO (cuadres): TOTAL ACTIVO (00180) == TOTAL PN+PASIVO (00252); 00500==00199==00327;
     00325==00296+00324; 00327==00325+00326.
  3. XSD (si data/mod200<ej>.xsd está presente): validación formal con lxml. Si no, se omite con aviso
     (Sociedades WEB valida contra ese esquema; descárgalo a data/ para activar este nivel).

Gating: si hay errores 🔴 estructurales o de cuadre, no se debe entregar el fichero.
Uso: python3 validador.py --xml <fichero.xml> --catalogo ../data/catalogo_contable_2025.json [--xsd ../data/mod2002025.xsd] [--out validacion_xml.md]
"""
from __future__ import annotations
import argparse, json, re
import xml.etree.ElementTree as ET
from pathlib import Path

ORDEN_BLOQUES = ["Balance", "CuentaPyG", "CambiosPN"]

def fmt_es(x):
    if x is None: return ""
    neg = x < 0
    s = f"{abs(x):,.2f}".replace(",", "§").replace(".", ",").replace("§", ".")
    return ("-" if neg else "") + s

def validar(xml_path, catalogo_path, xsd_path=None):
    cat = json.load(open(catalogo_path, encoding="utf-8"))
    por_casilla = cat["por_casilla"]
    errores, avisos, casillas = [], [], {}

    raw = Path(xml_path).read_bytes()
    try:
        txt = raw.decode("iso-8859-1")
    except Exception:
        txt = raw.decode("utf-8", "replace")
    try:
        root = ET.fromstring(txt)
    except ET.ParseError as e:
        return dict(ok=False, errores=[f"XML mal formado: {e}"], avisos=[], casillas={})

    # raíz
    if not re.fullmatch(r"MOD200\d{4}", root.tag):
        errores.append(f"Raíz inesperada: <{root.tag}> (se esperaba MOD200<ejercicio>)")
    ramas = list(root)
    if len(ramas) != 1:
        errores.append(f"Debe haber exactamente 1 rama hija; hay {len(ramas)}")
    rama = ramas[0] if ramas else None

    # bloques en orden
    if rama is not None:
        bloques = [b.tag for b in rama]
        orden_ok = [b for b in bloques if b in ORDEN_BLOQUES]
        if orden_ok != sorted(orden_ok, key=ORDEN_BLOQUES.index):
            errores.append(f"Bloques fuera de orden: {bloques}")
        for bloque in rama:
            for pagina in bloque:
                pkey = pagina.tag
                if pkey not in cat["paginas"]:
                    errores.append(f"Página desconocida: {pkey}"); continue
                cas_validas = {c["casilla"] for c in cat["paginas"][pkey]["campos"]}
                for campo in pagina:
                    m = re.fullmatch(r"T(\d{5})", campo.tag)
                    if not m:
                        errores.append(f"Nodo no válido: <{campo.tag}> en {pkey}"); continue
                    casilla = m.group(1)
                    if casilla not in por_casilla:
                        errores.append(f"Casilla inexistente en catálogo: {casilla} ({pkey})")
                    elif casilla not in cas_validas:
                        errores.append(f"Casilla {casilla} no pertenece a {pkey} "
                                       f"(es de {por_casilla[casilla]['pagina']})")
                    val = (campo.text or "").strip()
                    if not re.fullmatch(r"-?\d+\.\d{2}", val):
                        errores.append(f"Importe mal formateado en {campo.tag}: '{val}' (esperado -?\\d+.\\d\\d)")
                    else:
                        casillas[casilla] = float(val)

    # cuadres de negocio
    def g(c): return casillas.get(c, 0.0)
    def chk(nombre, a, b, tol=0.02):
        if abs(a - b) > tol:
            errores.append(f"Cuadre {nombre}: {fmt_es(a)} ≠ {fmt_es(b)} (dif {fmt_es(a-b)})")
    if "00180" in casillas or "00252" in casillas:
        chk("TOTAL ACTIVO (00180) = TOTAL PN+PASIVO (00252)", g("00180"), g("00252"))
    if "00500" in casillas:
        chk("Resultado PyG (00500) = Resultado balance (00199)", g("00500"), g("00199"))
        chk("Resultado continuadas (00327) = Resultado PyG (00500)", g("00327"), g("00500"))
    if "00325" in casillas:
        chk("Resultado antes imptos (00325) = explotación (00296) + financiero (00324)",
            g("00325"), g("00296") + g("00324"))
    if "00327" in casillas:
        chk("Resultado continuadas (00327) = antes imptos (00325) + impuesto (00326)",
            g("00327"), g("00325") + g("00326"))

    # XSD opcional
    xsd_estado = "omitida (esquema no provisto)"
    if xsd_path and Path(xsd_path).exists():
        try:
            from lxml import etree
            schema = etree.XMLSchema(etree.parse(str(xsd_path)))
            doc = etree.fromstring(raw)
            if schema.validate(doc):
                xsd_estado = "✅ válido contra XSD"
            else:
                xsd_estado = "🔴 inválido contra XSD"
                for e in schema.error_log:
                    errores.append(f"XSD: {e.message} (línea {e.line})")
        except ImportError:
            xsd_estado = "omitida (lxml no instalado)"
        except Exception as e:
            xsd_estado = f"error validando XSD: {e}"
    else:
        avisos.append("Validación XSD omitida: deja data/mod200<ej>.xsd para activarla "
                      "(Sociedades WEB valida contra ese esquema).")

    return dict(ok=len(errores) == 0, errores=errores, avisos=avisos,
                casillas=casillas, xsd=xsd_estado, n=len(casillas))

def escribir(res, out):
    md = ["# Validación del XML contable Modelo 200", "",
          f"Resultado: {'✅ APTO' if res['ok'] else '🔴 NO APTO (no entregar)'}  ·  "
          f"casillas={res['n']}  ·  XSD: {res['xsd']}", ""]
    if res["errores"]:
        md += [f"## Errores ({len(res['errores'])})"] + [f"- 🔴 {e}" for e in res["errores"]] + [""]
    if res["avisos"]:
        md += [f"## Avisos ({len(res['avisos'])})"] + [f"- 🟡 {a}" for a in res["avisos"]] + [""]
    if res["ok"]:
        md += ["Sin errores estructurales ni de cuadre. Listo para validación XSD y/o importación."]
    Path(out).write_text("\n".join(md) + "\n", encoding="utf-8")

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--xml", required=True)
    ap.add_argument("--catalogo", default=str(Path(__file__).resolve().parent.parent / "data" / "catalogo_contable_2025.json"))
    ap.add_argument("--xsd", default=None)
    ap.add_argument("--out", default=None)
    a = ap.parse_args()
    res = validar(a.xml, a.catalogo, a.xsd)
    if a.out: escribir(res, a.out)
    print(("✅ APTO" if res["ok"] else "🔴 NO APTO") + f" · casillas={res['n']} · XSD: {res['xsd']}")
    for e in res["errores"][:20]: print("  🔴", e)
    for w in res["avisos"]: print("  🟡", w)

if __name__ == "__main__":
    main()
