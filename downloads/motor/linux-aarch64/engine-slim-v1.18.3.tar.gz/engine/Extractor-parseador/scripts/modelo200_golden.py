#!/usr/bin/env python3
from __future__ import annotations
"""Oraculo/golden diff para ficheros .200 del Modelo 200.

Lee un .200 con el DR normalizado del ejercicio y compara estructura y campos de casilla con valor.
No contiene reglas fiscales; es una herramienta de control para replay contra declaraciones reales.
"""
import argparse
import json
import re
from collections import Counter, defaultdict
from pathlib import Path

import dr200


def tag_to_page(dr: dict) -> dict:
    out = {}
    for page, campos in dr.items():
        line = dr200.emitir_registro(campos)
        m = re.match(r"<(T200[^>]+)>", line)
        if m:
            out[m.group(1)] = page
    return out


def records(path: str | Path, dr: dict) -> list[dict]:
    """Devuelve registros internos del .200, sin el wrapper DP200000."""
    path = Path(path)
    s = path.read_bytes().decode("latin1", "replace")
    starts = [m.start() for m in re.finditer(r"<T200[^>]+>", s)]
    page_by_tag = tag_to_page(dr)
    counts = Counter()
    out = []
    for st in starts[1:]:
        tag = re.match(r"<(T200[^>]+)>", s[st:]).group(1)
        close = s.find(f"</{tag}>", st)
        if close < 0:
            out.append({"tag": tag, "occ": counts[tag] + 1, "page": page_by_tag.get(tag),
                        "record": s[st:], "closed": False})
            continue
        counts[tag] += 1
        out.append({"tag": tag, "occ": counts[tag], "page": page_by_tag.get(tag),
                    "record": s[st:close + len(f"</{tag}>")], "closed": True})
    return out


def raw_value(campo: dict, rec: str) -> str:
    pos = campo["posicion"] - 1
    return rec[pos:pos + campo["longitud"]]


def has_present_value(campo: dict, raw: str) -> bool:
    if not campo.get("casilla"):
        return False
    tipo = (campo.get("tipo") or "").lower()
    if tipo == "n" or (tipo.startswith("num") and campo["longitud"] == 17):
        return bool(raw) and raw != "0" * len(raw)
    if tipo.startswith("num"):
        return bool(raw) and raw != "0" * len(raw)
    return bool(raw.strip())


def decode_numeric(campo: dict, raw: str) -> list[float]:
    tipo = (campo.get("tipo") or "").lower()
    length = campo["longitud"]
    clean = raw.strip()
    if not clean:
        return []
    out = []
    if tipo == "n" or (tipo.startswith("num") and length == 17):
        sign = -1 if clean.startswith("N") else 1
        digits = re.sub(r"\D", "", clean)
        if digits:
            out.append(sign * int(digits) / 100.0)
    elif tipo.startswith("num"):
        digits = re.sub(r"\D", "", clean)
        if digits:
            out.append(float(int(digits)))
            if length == 4:
                out.append(float(int(digits)) / 100.0)
    return out


def present_fields(path: str | Path, dr: dict) -> list[dict]:
    fields = []
    for rec in records(path, dr):
        page = rec.get("page")
        if not page:
            continue
        for campo in dr.get(page, []):
            raw = raw_value(campo, rec["record"])
            if has_present_value(campo, raw):
                fields.append({
                    "tag": rec["tag"],
                    "occ": rec["occ"],
                    "page": page,
                    "casilla": campo["casilla"],
                    "posicion": campo["posicion"],
                    "longitud": campo["longitud"],
                    "tipo": campo["tipo"],
                    "raw": raw,
                    "values": decode_numeric(campo, raw),
                    "descripcion": campo["descripcion"],
                })
    return fields


def field_key(field: dict) -> tuple:
    return field["tag"], field["occ"], field["casilla"], field["posicion"]


def compare(real_200: str | Path, generated_200: str | Path, ejercicio="2024") -> dict:
    dr = dr200.cargar_dr(ejercicio=str(ejercicio))
    real_records = records(real_200, dr)
    gen_records = records(generated_200, dr)
    real_fields = present_fields(real_200, dr)
    gen_fields = present_fields(generated_200, dr)
    gen_map = {field_key(f): f for f in gen_fields}
    real_map = {field_key(f): f for f in real_fields}

    missing = [f for f in real_fields if field_key(f) not in gen_map]
    extra = [f for f in gen_fields if field_key(f) not in real_map]
    different = []
    for key, real in real_map.items():
        gen = gen_map.get(key)
        if gen and gen["raw"] != real["raw"]:
            different.append({"key": key, "real": real, "generated": gen})

    by_tag = defaultdict(lambda: Counter())
    for f in real_fields:
        by_tag[f["tag"]]["real"] += 1
    for f in gen_fields:
        by_tag[f["tag"]]["generated"] += 1
    for f in missing:
        by_tag[f["tag"]]["missing"] += 1
    for f in extra:
        by_tag[f["tag"]]["extra"] += 1
    for f in different:
        by_tag[f["key"][0]]["different"] += 1

    return {
        "ejercicio": str(ejercicio),
        "real_records": len(real_records) + 1,        # incluye wrapper
        "generated_records": len(gen_records) + 1,
        "real_present_fields": len(real_fields),
        "generated_present_fields": len(gen_fields),
        # correct_fields = casillas reales reconstruidas CON EL MISMO VALOR. Se cuenta directamente sobre los
        # mapas deduplicados por field_key (robusto si el DR repitiera una clave): una casilla generada con
        # valor DISTINTO al real cuenta en `different`, NO como acierto. NO es generated_present_fields (que
        # incluye los valores equivocados).
        "correct_fields": sum(1 for k, rf in real_map.items()
                              if k in gen_map and gen_map[k]["raw"] == rf["raw"]),
        "missing_fields": len(missing),
        "extra_fields": len(extra),
        "different_common_fields": len(different),
        # 'limpio' = la SUPERFICIE de casillas-con-valor coincide (0 missing/extra/different). NO implica
        # `.200` presentable ni bit-perfect: no mira registros sin casilla, campos alfanuméricos ni
        # `missing_records`. Para "presentable" hace falta además el import real en Sociedades WEB.
        "limpio": not missing and not extra and not different,
        "missing_records": _record_delta(real_records, gen_records),
        "by_tag": {tag: dict(counts) for tag, counts in sorted(by_tag.items())},
        "missing": missing,
        "extra": extra,
        "different": different,
    }


def _record_delta(real_records, gen_records):
    real = Counter((r["tag"], r["occ"]) for r in real_records)
    gen = Counter((r["tag"], r["occ"]) for r in gen_records)
    return [{"tag": tag, "occ": occ} for (tag, occ), n in sorted((real - gen).items()) for _ in range(n)]


def compact_summary(result: dict) -> dict:
    return {k: v for k, v in result.items() if k not in {"missing", "extra", "different"}}


def errores(result: dict) -> list:
    """Lista legible de casillas que NO cuadran contra el real (faltantes + valor distinto). Sirve para
    GATEAR el replay: si no está vacía, el `.200` generado no reproduce el oráculo casilla-a-casilla."""
    out = []
    for m in result.get("missing", []):
        out.append(f"FALTA {m['page']}.{m['casilla']} (real={m['values']})")
    for d in result.get("different", []):
        r, g = d["real"], d["generated"]
        out.append(f"DISTINTO {r['page']}.{r['casilla']}: real={r['values']} generado={g['values']}")
    return out


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--real", required=True)
    ap.add_argument("--generated", required=True)
    ap.add_argument("--ejercicio", default="2024")
    ap.add_argument("--out")
    args = ap.parse_args()
    result = compare(args.real, args.generated, ejercicio=args.ejercicio)
    if args.out:
        out = Path(args.out)
        out.parent.mkdir(parents=True, exist_ok=True)
        out.write_text(json.dumps(result, ensure_ascii=False, indent=2), encoding="utf-8")
    print(json.dumps(compact_summary(result), ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
