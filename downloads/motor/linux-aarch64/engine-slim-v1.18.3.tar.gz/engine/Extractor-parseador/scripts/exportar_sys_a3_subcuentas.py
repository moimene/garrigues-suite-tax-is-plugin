#!/usr/bin/env python3
"""exportar_sys_a3_subcuentas.py — Variante SUBCUENTAS del fichero de importación A3 (compuerta Moi64).

Para la compuerta humana de la "convención A3": el motor emite SIEMPRE el A3 AGRUPADO a 4 dígitos
(`motor_sys.escribir_a3_xlsx` → `agrupado_4d.xlsx`). Este helper emite la MISMA plantilla A3 (Wolters
Kluwer a3ASESOR | soc) pero con las cuentas SIN AGRUPAR — las subcuentas tal cual vienen del SyS de
origen — para poder importar AMBAS convenciones en a3ASESOR y decidir cuál acepta (4d vs subcuentas).

Mantiene IDÉNTICAS el resto de reglas A3 (reusa `motor_sys.HEADERS_A3` y `motor_sys._cent`):
  - cabeceras exactas (Cuenta | Descripción | Saldo Final | Debe | Haber | Saldo Inicial), datos desde fila 4;
  - cuentas 129x SIN saldo final (A3 reconstruye el resultado);
  - saldos acreedores en negativo (los toma con el signo del SyS de origen);
  - cuadre cent-exact (tol=0): Σdebe=Σhaber ∧ Σdeudor=Σacreedor; FAIL-CLOSED (si descuadra, NO se emite).

NO altera el número-firmado ni el agrupado 4d canónico (ruta separada; A3 = legacy D7). Solo añade una
emisión alternativa para la prueba de importación real (no entra en el flujo de firma del XML AEAT).
"""
import argparse
import os
import sys
from decimal import Decimal
from pathlib import Path

_HERE = os.path.dirname(os.path.abspath(__file__))
if _HERE not in sys.path:
    sys.path.insert(0, _HERE)
import extractor_contable  # noqa: E402  (extrae subcuentas con provenance, sin agrupar)
import motor_sys           # noqa: E402  (HEADERS_A3, _cent — reglas A3 compartidas)


def _filas_subcuentas(cuentas) -> tuple:
    """Subcuentas del extractor → filas A3 `[cuenta, denom, sf, debe, haber, si]` SIN agrupar a 4d, con la
    regla 129x (saldo final en blanco). Dedup por código (suma) por si una subcuenta aparece repetida;
    conserva la granularidad de subcuenta (no trunca a 4 dígitos)."""
    acc, orden = {}, []
    for c in cuentas:
        cod = str(c.get("cuenta") or "").strip()
        if not cod:
            continue
        if cod not in acc:
            acc[cod] = {"denom": c.get("denom") or "", "debe": 0.0, "haber": 0.0, "sf": 0.0, "si": 0.0}
            orden.append(cod)
        a = acc[cod]
        a["debe"] += float(c.get("debe") or 0)
        a["haber"] += float(c.get("haber") or 0)
        a["sf"] += float(c.get("saldo") or 0)
        a["si"] += float(c.get("si") or 0)
    filas, avisos = [], []
    for cod in orden:
        a = acc[cod]
        sf = round(a["sf"], 2)
        if cod.startswith("129"):                      # PyG: A3 lo quiere VACÍO (balance antes del cierre)
            if abs(sf) > 0:
                avisos.append(f"Cuenta {cod} (PyG) traía saldo final {sf}; va VACÍO en A3 (balance pre-cierre).")
            sf = None
        filas.append([cod, a["denom"], sf, round(a["debe"], 2), round(a["haber"], 2), round(a["si"], 2)])
    return filas, avisos


def _control(filas) -> dict:
    """Cuadre cent-exact (tol=0) idéntico al de `escribir_a3_xlsx`: Σdebe=Σhaber ∧ Σdeudor=Σacreedor sobre
    el saldo final CON signo (acreedores negativos)."""
    _c = motor_sys._cent
    td = sum((_c(f[3]) for f in filas), Decimal("0"))
    th = sum((_c(f[4]) for f in filas), Decimal("0"))
    sd = sum((_c(f[2]) for f in filas if f[2] is not None and f[2] > 0), Decimal("0"))
    sa = sum((-_c(f[2]) for f in filas if f[2] is not None and f[2] < 0), Decimal("0"))
    return dict(n_cuentas=len(filas), total_debe=float(td), total_haber=float(th),
                saldo_deudor=float(sd), saldo_acreedor=float(sa),
                cuadra_debe_haber=td == th, cuadra_deudor_acreedor=sd == sa)


def exportar(path_sys, outdir, empresa="", ejercicio="", nif="", filename="agrupado_subcuentas.xlsx") -> dict:
    """SyS (con subcuentas) → A3 xlsx SUBCUENTAS (misma plantilla/reglas, sin agrupar a 4d). FAIL-CLOSED:
    si el SyS descuadra al céntimo tras la regla 129x, NO se emite (A3 lo rechazaría)."""
    ext = extractor_contable.extraer_cuentas(path_sys)   # ya descarta filas-etiqueta de subtotal/footer (B5)
    if ext.get("error"):
        return {"ok": False, "motivo": ext["error"]}
    filas, avisos = _filas_subcuentas(ext["cuentas"])
    ctrl = _control(filas)
    if not (ctrl["cuadra_debe_haber"] and ctrl["cuadra_deudor_acreedor"]):
        return {"ok": False, "control": ctrl, "avisos": avisos,
                "motivo": "descuadre (subcuentas) tras regla 129x: A3 rechazaría el fichero; no se emite"}
    import openpyxl
    wb = openpyxl.Workbook()
    ws = wb.active
    ws.title = "Sumas y Saldos"
    ws.append(["Nif Sociedad", nif or ""])
    ws.append(["Nombre Sociedad", empresa or ""])
    ws.append(motor_sys.HEADERS_A3)
    for f in filas:
        ws.append(f)
    for colu, w in {"A": 14, "B": 44, "C": 16, "D": 16, "E": 16, "F": 16}.items():
        ws.column_dimensions[colu].width = w
    for r in range(4, ws.max_row + 1):
        ws[f"A{r}"].number_format = "@"                  # cuenta como TEXTO (no la trunca Excel)
        for colu in ("C", "D", "E", "F"):
            cell = ws[f"{colu}{r}"]
            if isinstance(cell.value, (int, float)):
                cell.number_format = "#,##0.00"
    Path(outdir).mkdir(parents=True, exist_ok=True)
    p = Path(outdir) / filename
    wb.save(p)
    return {"ok": True, "fichero": str(p), "control": ctrl, "avisos": avisos}


def main():
    ap = argparse.ArgumentParser(
        description="Emite el A3 en convención SUBCUENTAS (sin agrupar a 4d) para la prueba de importación.")
    ap.add_argument("--input", required=True, help="SyS/mayor con subcuentas (.xls/.xlsx/.csv)")
    ap.add_argument("--outdir", required=True)
    ap.add_argument("--empresa", default="")
    ap.add_argument("--ejercicio", default="")
    ap.add_argument("--nif", default="")
    ap.add_argument("--filename", default="agrupado_subcuentas.xlsx")
    a = ap.parse_args()
    res = exportar(a.input, a.outdir, a.empresa, a.ejercicio, a.nif, a.filename)
    if res["ok"]:
        print(f"OK · A3 SUBCUENTAS · {res['control']['n_cuentas']} subcuentas → {res['fichero']}")
        for av in res.get("avisos", []):
            print(f"  · aviso: {av}")
    else:
        print(f"NO emitido (fail-closed): {res['motivo']}")
        raise SystemExit(1)


if __name__ == "__main__":
    main()
