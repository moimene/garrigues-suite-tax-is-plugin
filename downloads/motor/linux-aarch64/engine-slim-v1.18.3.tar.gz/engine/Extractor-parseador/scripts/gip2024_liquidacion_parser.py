#!/usr/bin/env python3
"""Parser conservador de la liquidacion GIP 2024.

Lee el workbook interno de liquidacion y devuelve casillas candidatas del Modelo 200. Los mapeos incluidos
son los que se identifican por etiqueta directa del Excel y por el DR2024/oraculo GIP 2024.
"""
from __future__ import annotations

import argparse
import json
import math
import re
from pathlib import Path

import pandas as pd

import caso_local


DEFAULT_PATH = caso_local.path("liquidacion")


def _num(v):
    if v is None or pd.isna(v):
        return None
    if isinstance(v, (int, float)):
        return float(v)
    s = str(v).strip().replace("\u00a0", " ")
    if not s:
        return None
    s = s.replace(" ", "")
    if "," in s and "." in s:
        s = s.replace(".", "").replace(",", ".")
    elif "," in s:
        s = s.replace(",", ".")
    try:
        return float(s)
    except ValueError:
        return None


def _round2(v):
    return None if v is None else round(float(v), 2)


def _ceil2_abs(v):
    if v is None:
        return None
    return math.ceil((abs(float(v)) - 1e-9) * 100) / 100


def _ceil2_pos(v):
    if v is None:
        return None
    return math.ceil((float(v) - 1e-9) * 100) / 100


def _round2_abs(v):
    return None if v is None else _round2(abs(float(v)))


def _limite_gf_161(limite_30, adicion=0.0, suelo=1_000_000.0, dias_periodo=365, dias_anio=365):
    """Límite de deducibilidad de gastos financieros del art. 16.1 LIS (casilla 02369).

    NO es "30% del beneficio operativo" a secas (veredicto del juez R3.1): es
    max(30%·B.O. + adición de B.O. de ejercicios anteriores; 1.000.000 € prorrateado por la
    duración del período). Componentes:
      · `limite_30` = 30%·B.O. del período (casilla 01249);
      · `adicion`   = adición de B.O. de ejercicios anteriores (casilla 01255, art.16.2; el Manual 2025
        y el autocontrol exigen 02369 = max(01249 + 01255; suelo) — Codex adversarial finding 2).
    El suelo de 1M garantiza una deducibilidad mínima aunque el 30%·B.O. sea inferior o NEGATIVO
    (típico en una ETVE: los ingresos son dividendos/plusvalías que NO van al resultado de explotación).
    El millón se prorratea si el período impositivo es < 1 año (R3.3 / C17); para un año completo el
    factor es 1. OJO: este suelo es del art. 16.1 (GF) y NO debe confundirse con el suelo de 1M del
    art. 26 (compensación de BINs). Robusto ante parámetros extremos (Codex finding 5): `limite_30=None`
    → opera solo el suelo; suelo<0 se clampa a 0; dias_periodo se acota a [1, dias_anio]; dias_anio<=0 → 365."""
    # Ingeniería inversa del importador AEAT EN VIVO (2026-06-19): 02369 = max(suelo; max(0, 01249) + 01255).
    # El 30%·B.O. (01249) NEGATIVO se CLAMPA a 0 ANTES de sumar la adición de B.O. de ejercicios anteriores
    # (01255) — NO 01249+01255. Para GIP (01255=0) da igual; para B.O. negativo + 01255>0, NO.
    base = max(0.0, (float(limite_30) if limite_30 is not None else 0.0)) + (float(adicion) if adicion else 0.0)
    suelo = max(0.0, float(suelo))
    dias_anio = dias_anio if dias_anio and dias_anio > 0 else 365
    dias = min(max(1, int(dias_periodo)), dias_anio)
    suelo_efectivo = suelo if dias >= dias_anio else round(suelo * dias / dias_anio, 2)
    return _round2(max(base, suelo_efectivo))


def _rows(path, sheet):
    df = pd.read_excel(path, sheet_name=sheet, header=None, dtype=object)
    for idx, row in df.iterrows():
        vals = row.tolist()
        label = ""
        for val in vals:
            if pd.notna(val) and not isinstance(val, (int, float)):
                label = str(val).strip()
                break
        nums = [_num(v) for v in vals if _num(v) is not None]
        yield idx + 1, label, nums, vals


def _first_by_label(path, sheet, needle):
    needle = needle.lower()
    for _idx, label, nums, _vals in _rows(path, sheet):
        if needle in label.lower() and nums:
            return nums[-1]
    return None


def _liquidacion(path, sheet="Liquidación IS 2024"):
    # Hoja parametrizable: el ejercicio 2025 trae la liquidación en 'GIS 2025' (estimación), con la mayoría
    # de las etiquetas iguales (B.I., cuota…). Por defecto la de 2024 (retrocompat).
    labels = {}
    for _idx, label, nums, _vals in _rows(path, sheet):
        if label and nums and label not in labels:
            labels[label] = nums[-1]
    return labels


BIN_CASILLAS = {
    2015: ("01045", "01046", "01047"),
    2016: ("01519", None, "01521"),
    2017: ("01592", None, "01594"),
    2018: ("01825", None, "01827"),
    2019: ("02193", None, "02195"),
    2020: ("00194", None, "00196"),
    2021: ("00151", None, "00164"),
    2023: ("00009", None, "00020"),
}

# Tripletes (pendiente, APLICADO en esta liquidación, futuro) del detalle de compensación de BINs por año de
# generación (DP200015) para 2025. A diferencia de 2024, en 2025 se aplica también el 2016 → hay que emitir la
# casilla "Aplicado" de cada año (verificadas contra el DR2025; son por año de generación). Sin el aplicado
# completo, el importador recalcula la compensación 00547 con un desglose incompleto y descuadra la BI.
BIN_CASILLAS_2025 = {
    2015: ("01045", "01046", "01047"),
    2016: ("01519", "01520", "01521"),
    2017: ("01592", "01593", "01594"),
    2018: ("01825", "01826", "01827"),
    2019: ("02193", "02194", "02195"),
    2020: ("00194", "00195", "00196"),
    2021: ("00151", "00152", "00164"),
    2022: ("00896", "00897", "00898"),
    2023: ("00009", "00010", "00020"),
    2024: ("03402", "03403", "03404"),
}


def _bins(path, casillas_map=None, aplicado_ceil=True):
    casillas_map = casillas_map or BIN_CASILLAS
    redondeo_ap = _ceil2_abs if aplicado_ceil else _round2_abs   # 2024 redondea el aplicado hacia arriba; 2025 normal
    out = {}
    rows = []
    for _idx, label, nums, vals in _rows(path, "BINs"):
        year = int(_num(vals[1])) if len(vals) > 1 and _num(vals[1]) is not None else None
        if year in casillas_map:
            start = _num(vals[2]) if len(vals) > 2 else None
            applied = _num(vals[3]) if len(vals) > 3 else None
            future = _num(vals[4]) if len(vals) > 4 else None
            if start is not None:
                c_start, c_applied, c_future = casillas_map[year]
                start2 = _round2(start)
                applied2 = redondeo_ap(applied) if applied not in (None, 0) else None
                future2 = _round2(start2 - applied2) if applied2 is not None else _round2(future)
                out[c_start] = start2
                if c_applied and applied2 is not None:
                    out[c_applied] = applied2
                if c_future:
                    out[c_future] = future2
                rows.append({"year": year, "start": start2, "applied": applied2, "future": future2})
        elif str(label).lower().startswith("total"):
            start = _num(vals[2]) if len(vals) > 2 else None
            applied = _num(vals[3]) if len(vals) > 3 else None
            if start is not None and applied is not None:
                start2 = _round2(start)
                applied2 = redondeo_ap(applied)
                out["00670"] = start2
                out["00547"] = applied2
                out["00671"] = _round2(start2 - applied2)
    return out, rows


GF_CASILLAS = {
    "Gasto financiero": "01245",
    "Ingreso financiero": "01247",
    "Gasto financiero neto": "01248",
    "Resultado de explotación": "01250",
    "Amortización del inmovilizado": "01251",
    "Ingresos, gastos o rentas que forman parte del BO": "02368",
    "30% Bº OPERATIVO": "01249",
    "BENEFICIO OPERATIVO DE EJERCICIOS ANTERIORES ADICIONADO": "01255",
    "GASTO FINANCIERO NETO DEDUCIBLE": "01256",
}

GF_PENDIENTES = {
    2019: ("01982", "01983", None),
    2020: ("02258", None, "02260"),
    2021: ("02404", None, "02406"),
    2022: ("01103", None, "01105"),
    2023: ("01398", None, "01400"),
}

# Tripletes (inicio, aplicado, futuro) de "Pendiente adición por límite de beneficio operativo" del ejercicio
# 2025 (DP200020). A diferencia de 2024, en 2025 SÍ hay aplicación, así que se mapea la casilla "Aplicado en
# esta liquidación" de cada año (verificado contra el DR2025; las casillas son por AÑO DE GENERACIÓN, estables
# año a año). Cuadra: por año inicio−aplicado=futuro; y la suma = total (00538/00539/00546).
GF_PENDIENTES_2025 = {
    2020: ("02258", "02259", None),       # 2020 totalmente aplicado en 2025; el DR2025 no trae su 'futuro'
    2021: ("02404", "02405", "02406"),
    2022: ("01103", "01104", "01105"),
    2023: ("01398", "01399", "01400"),
    2024: ("02769", "02770", "02772"),
}


def _cascada_cuota(bi, tipo=0.25, ddi=0.0, bonificaciones=0.0, deducciones=0.0, retenciones=0.0,
                   pagos=0.0, tipo_min=0.15, min_30bis=None):
    """Cascada de cuota del Modelo 200 (veredicto del juez R6): rompe la propagación MONOLÍTICA
    00562=00582=00592=…=00621 que anulaba minoraciones (C7). Encadena correctamente:
      · 00562 (cuota íntegra) = tipo × base imponible POSITIVA (R6.5: nunca sobre base negativa);
      · 00582 (cuota íntegra ajustada) = max(0, 00562 − bonificaciones − DDI 00571)  (R6.2);
      · 00592 (cuota líquida) = max(0, 00582 − deducciones arts.35-39/Ley 49/2002)  (R6.3);
      · 00599 = 00592 − retenciones/ingresos a cuenta;  00611/01586/00621 = 00599 − pagos fraccionados (R6.4);
      · 00619 (cuota líquida mínima art.30bis) = tipo_min × base positiva (informativa; el gating subjetivo
        y la comparación con 00592 son del Paso 9 / R7).
    Para GIP 2025 todas las minoraciones son 0 → la cadena colapsa a la cuota íntegra (mismo número que el
    monolito), pero por CÁLCULO, no por asignación. Tipo parametrizable (R6.1).
    ALCANCE (Codex finding 3): es la cascada NORMAL sin rectificativa ni abonos — 00611=01586=00621 solo es
    válido cuando no hay 00615/00633/00617/00083/01042/01893 (eslabones de 01586) ni 01578/01584 (rectificativa).
    Para GIP esos conceptos son 0; si aparecieran, habría que extender el helper con esos parámetros.
    `min_30bis` (cuota líquida mínima art.30bis, casilla 00619) es un SUELO VINCULANTE de 00592 cuando la entidad
    está en el ámbito subjetivo (R6.6/R7.4): si las deducciones bajan 00592 por debajo del mínimo, prevalece el
    mínimo. None = no aplica (caso GIP, donde además no hay deducciones → no muerde).

    FÓRMULAS EXACTAS del importador AEAT EN VIVO (ingeniería inversa Codex 2026-06-19; ref.
    docs/memoria/2026-06-19-triangulacion-ingenieria-inversa-importador.md) — para la generalización a las otras
    declaraciones con minoraciones activas (NO afecta a GIP, que tiene todo a 0; pendiente confirmar con un .200
    sintético con minoraciones):
        00582 = max(0, (00562 + 01038) − Σbonif/DDI[00567+00568+00563+00815+00566+00576+00569+00570+01344+
                01280+00572+00571+00573+00575+00577+00581])
        00592 = max(0, 00582 − Σdeduc_14B)   con 00619 como suelo vinculante
        00599 = (00625/100) × (00592 − 01766 − 01784)         [retenciones e ingresos a cuenta]
        00611 = 00599 − (00601 + 00603 + 00605)               [pagos fraccionados]
        01586 = 00611 + 00615 + 00633 + 00617 − 00083 − 01042 − 01893
        00621 = 01586  (en rectificativa: 01586 − 01578 + 01584)"""
    bi_pos = max(0.0, _num(bi) or 0.0)
    c562 = _round2(bi_pos * tipo)
    c582 = _round2(max(0.0, c562 - (_num(bonificaciones) or 0.0) - (_num(ddi) or 0.0)))
    c592 = _round2(max(0.0, c582 - (_num(deducciones) or 0.0)))
    if min_30bis is not None:                       # suelo vinculante art.30bis (R6.6): la cuota líquida no baja del mínimo
        c592 = _round2(max(c592, _num(min_30bis) or 0.0))
    c599 = _round2(c592 - (_num(retenciones) or 0.0))
    c611 = _round2(c599 - (_num(pagos) or 0.0))
    return {"00562": c562, "00582": c582, "00592": c592, "00599": c599,
            "00611": c611, "01586": c611, "00621": c611, "00619": _round2(bi_pos * tipo_min)}


def _gastos_financieros(path, sheet="Limitación Gastos financieros", pendientes=None, pend_min_row=37,
                        aeat_calcula=True, regimen="general", limite_30=None, dias_periodo=365,
                        suelo_gf=1_000_000.0, adicion_01255=0.0, gf_adq=None, gf_ord=None,
                        resultado_explotacion_real=None):
    """Limitación de gastos financieros (art. 16 LIS → DP200020) desde su hoja. Parametrizable por `sheet`
    (2024: 'Limitación Gastos financieros'; 2025: 'GF'), por el mapa de `pendientes` por año y por
    `pend_min_row` (en 2024 hay dos tablas y solo cuenta la rectificada desde la fila 37; en 2025 hay una sola,
    `pend_min_row=0`). Sin esta página el importador exige la 20 (EMALP20). `aeat_calcula`=False (2025) NO emite
    las casillas que el importador RECALCULA y rechaza como input ('no puede tener contenido': 01248 gasto neto,
    02438/01214 gasto neto deducible) y fija 02369 (límite art.16.1) = el 30% del B.O. (01249)."""
    pendientes = pendientes or GF_PENDIENTES
    out = {}
    for _idx, label, nums, _vals in _rows(path, sheet):
        for expected_label, casilla in GF_CASILLAS.items():
            matches = label == expected_label or (
                expected_label == "Ingresos, gastos o rentas que forman parte del BO"
                and label.startswith(expected_label)
            )
            if matches and nums:
                if not aeat_calcula and casilla == "01248":
                    continue                               # 2025: el gasto financiero neto lo computa el importador
                if casilla == "01249":
                    out[casilla] = (_ceil2_pos if aeat_calcula else _round2)(nums[-1])
                else:
                    out[casilla] = _round2(abs(nums[-1]) if casilla.startswith("0124") else nums[-1])
        if label == "Gasto financiero" and nums:
            out["01246"] = _round2(abs(nums[-1]))
        if label == "GASTO FINANCIERO NETO DEDUCIBLE" and nums and aeat_calcula:
            out["02369"] = _round2(abs(nums[-1]) + 0.01)  # el modelo 200 redondea el limite total un centimo arriba
            out["02438"] = _round2(abs(nums[-1]))
            out["01214"] = _round2(abs(nums[-1]))
        if label and str(label).strip().lower() == "total" and len(nums) >= 3:
            # En la seccion rectificada (2024) / única (2025), estos totales cuadran con el .200 real.
            out["00538"] = _round2(nums[0])
            out["00539"] = _round2(abs(nums[1]))
            out["00546"] = _round2(nums[2])

    # Detalle por ejercicio de generación.
    df = pd.read_excel(path, sheet_name=sheet, header=None, dtype=object)
    for i, row in df.iterrows():
        vals = [_num(v) for v in row.tolist()]
        vals = [v for v in vals if v is not None]
        if vals and int(vals[0]) in pendientes and len(vals) >= 3:
            year = int(vals[0])
            # En 2024 hay dos tablas y solo cuenta la rectificada (desde la fila 37); en 2025 una sola (min 0).
            if pend_min_row and i + 1 < pend_min_row:
                continue
            c_start, c_applied, c_future = pendientes[year]
            out[c_start] = _round2(vals[1])
            if c_applied:
                out[c_applied] = _round2(abs(vals[2]))
            if c_future:
                out[c_future] = _round2(vals[3] if len(vals) >= 4 else vals[2])
    if not aeat_calcula:
        # 02369 = límite del período (01249 = 30% B.O.), TAL CUAL lo trae la hoja GF del abogado. NOTA: el
        # importador USA este 01249 para recalcular 02369; si la hoja GF tiene 01249 demasiado bajo (porque su
        # resultado de explotación 01250 es inconsistente, aviso 10250), solo deduce esa parte y rechaza el resto.
        # La deducibilidad ÍNTEGRA del GF (que exige la BI-oráculo) depende de un dato fiscal del abogado (límite
        # real 01249 o mecanismo de adición de B.O. anteriores 01255+pendientes): NO se adivina aquí. Ver 10250.
        # Límite del art.16.1 (02369) = max(30%·B.O.; suelo 1M prorrateado) — veredicto del juez R3.1/R3.2/R3.3.
        # El 30%·B.O. REAL lo aporta el abogado (`limite_30`, dato de hecho D1); si no se pasa, se usa el de la
        # hoja GF (01249), que en GIP viene INFLADO (el aviso/gate INT-GF-RE lo señala). Cuando el B.O. real es
        # negativo (típico ETVE: ingresos = dividendos/plusvalías que no van al resultado de explotación),
        # 30%·B.O. ≤ 0 < suelo → el límite cae al suelo de 1M y el GF no deducible (y la cuota) suben.
        # Reconciliación 01250↔00296 (R10.5 / decisión del abogado): el ÚNICO componente inflado del B.O. del
        # art.16 era el resultado de explotación (01250). Al fijarlo = 00296 (PyG real), el importador recalcula
        # 01249 = 01249_hoja − 30%·(01250_hoja − 00296); el delta de los demás componentes (01251/02368…) se
        # cancela exactamente. Con esto se LIMPIA el gate INT-GF-RE y la cuota queda al criterio estricto.
        if resultado_explotacion_real is not None and out.get("01250") is not None and out.get("01249") is not None:
            if limite_30 is None:
                limite_30 = _round2(out["01249"] - 0.30 * (out["01250"] - resultado_explotacion_real))
            out["01250"] = _round2(resultado_explotacion_real)
        if limite_30 is not None:
            out["01249"] = _round2(limite_30)         # el 30%·B.O. real sustituye al inflado de la hoja
        base_30 = out.get("01249")
        if base_30 is not None:
            # 02369 = max(01249 + 01255; suelo). El helper admite la adición de B.O. de ejercicios anteriores
            # (01255, art.16.2) — Codex finding 2 — PERO solo debe entrar con un dato CONFIRMADO por el abogado
            # (R2.6/C4): la hoja GF de GIP trae un 01255 crudo que NO es una adición válida y parse() lo fuerza a 0
            # (no hay adición), así que aquí `adicion` queda 0 por defecto y el 01255 confirmado se cableará en el
            # Paso 5 (R4.2). Mantener 02369 y el 01255 del .200 coherentes (autocontrol E25402369 solo chequea si 01255≠0).
            out["02369"] = _limite_gf_161(base_30, adicion=adicion_01255, suelo=suelo_gf,
                                          dias_periodo=dias_periodo)
        if "01256" in out and "02369" in out:
            neto = out["01256"]                       # 'GASTO FINANCIERO NETO DEDUCIBLE' = gasto financiero neto
            limite = out["02369"]                     # límite del art.16.1 = max(30% B.O.; suelo 1M)
            if regimen == "etve":
                # Criterio ESTRICTO art.16.5 (decisión del abogado 2026-06-19, confirmada contra el BOE; Codex
                # adversarial finding 1): el GF de deuda para ADQUISICIÓN DE PARTICIPACIONES va al BLOQUE 1
                # (art.16.5, casillas 01240-01243) con un límite adicional PROPIO = 30%·B.O. propio (+ adición
                # 01255), que NO tiene suelo de 1M — el suelo de 1.000.000 € es EXCLUSIVO del art.16.1 (02369).
                # El c2 que NO pasa el filtro 16.5 queda BLOQUEADO y se arrastra (art.16.5 §2); SOLO el c1 que pasa
                # fluye al bloque 2 (art.16.1), donde opera el suelo. Con B.O. negativo, limite_165 = 0 → c1 = 0 →
                # nada llega al bloque 2 → el suelo de 1M del 16.1 NO rescata el GF de adquisición. La mecánica de
                # la página 20 (01246 calculada = solo c1) impide físicamente el trasvase.
                limite_165 = max(0.0, _round2((base_30 or 0.0) + (adicion_01255 or 0.0)))
                gf_adq_v = _round2(gf_adq) if gf_adq is not None else _round2(neto)   # default GIP: GF 100% adquisición
                gf_ord_v = _round2(gf_ord) if gf_ord is not None else 0.0
                out["01240"] = gf_adq_v               # a) GF de adquisición de participaciones (bloque 1, art.16.5)
                out["01241"] = _round2(limite_165)    # b) límite adicional art.16.5 = 30%·B.O. propio (SIN suelo)
                if gf_ord_v:
                    out["01245"] = gf_ord_v           # e) GF ordinarios del período (bloque 2, art.16.1) si los hay
                c1 = _round2(min(gf_adq_v, limite_165))           # c1) deducibles tras el filtro del 16.5
                out["01242"] = c1
                out["01243"] = _round2(gf_adq_v - c1)            # c2) NO deducibles por el 16.5 (se arrastran)
                base_b2 = _round2(c1 + gf_ord_v)                 # lo que llega al bloque 2 (c1 del 16.5 + GF ordinario)
                out["01246"] = base_b2                # f) calculada por AEAT (= c1 + 01245)
                out["01248"] = base_b2                # h) GF netos del bloque 2 (= 01246 − 01247, 01247=0)
                out["01256"] = _round2(min(base_b2, limite))     # l1) deducibles por el 16.1 (con suelo 02369)
                out["01257"] = _round2(max(0.0, base_b2 - limite))  # l2) NO deducibles por el 16.1 (exceso sobre 02369)
                out["03586"] = out["01243"]           # detalle pág 26: GF no deducible bloque 1 (= 01243, valid. 22810)
            else:
                # Régimen GENERAL (default): GF ordinarios → BLOQUE 2 (art. 16.1). 01245 = input; 01246/01248 = neto
                # (calculadas por AEAT, con 01247 ingresos fin.=0). El no deducible es el exceso sobre el límite (l2).
                out["01245"] = _round2(neto)          # e) GF del período no afectados por art. 16.5/83
                out["01246"] = _round2(neto)          # f) = c1(0) + e (calculada por AEAT)
                out["01248"] = _round2(neto)          # h) GF netos del período (= 01246 − 01247)
                out["01256"] = _round2(min(neto, limite))     # l1) deducibles por el límite del 30% B.O.
                out["01257"] = _round2(neto - out["01256"])   # l2) NO deducibles (exceso sobre el límite)
            # Total GF no deducibles del período (= c2 + l2) → alimenta 00363 y el arrastre 01215:
            out["01260"] = _round2((_num(out.get("01243")) or 0.0) + out["01257"])
            out["01215"] = _round2(out["01260"])      # GF pendientes de deducir en períodos FUTUROS (arrastre)
            out["03585"] = out["01256"]
            out["01214"] = out["01256"]
            out["03587"] = out["01257"]
            out["01216"] = out["01257"]
    return out


_EXENCION_PREFIJOS = (
    "exención sobre dividendos",
    "exencion sobre dividendos",
    "exención sobre plusvalías",
    "exencion sobre plusvalias",
)


def _arrastre_gf_01215(pendiente_inicial, aplicado, nuevo_no_deducible):
    """Arrastre ACUMULADO de gastos financieros no deducibles a períodos futuros (art.16, casilla 01215) —
    veredicto del juez R4.3: 01215 = saldo pendiente al INICIO del período − aplicado este período (00364/
    01258, GF de años anteriores ahora deducibles) + nuevo no deducible del período (01260). NO es solo el
    del período. Para GIP estricto (sin pendiente inicial aplicable ni aplicación) = el nuevo no deducible
    (10.320.686,98), que es el valor del .200 import-confirmado."""
    return _round2((_num(pendiente_inicial) or 0.0) - (_num(aplicado) or 0.0) + (_num(nuevo_no_deducible) or 0.0))


def _recorte_exencion_art21(bruto, excepcion_2111=False, recorte=0.05):
    """Recorte del 5% por gastos de gestión del art.21.10 LIS (veredicto del juez R9): la exención de
    dividendos/plusvalías de cartera se reduce un 5% desde 2021 → solo el 95% del importe BRUTO es la
    disminución computable. Las excepciones tasadas del art.21.11 (`excepcion_2111=True`) mantienen el 100%.
    Ser ETVE NO exime del recorte (R9.4): el 100% solo procede con la excepción explícita, nunca por régimen.
    La disminución neta se enruta luego por tipo de renta/residencia (00370/02181 dividendos res./no res.,
    02183/02185 transmisiones, 00385/00386 ETVE), no a un agregado en 00418 (R9.3). Devuelve el NETO."""
    b = _num(bruto) or 0.0
    return _round2(b if excepcion_2111 else b * (1.0 - recorte))


def _exenciones(labels):
    """Exenciones art.21 LIS itemizadas, capturadas por su PREFIJO fiscal (no por la razón social de la
    participada). El detalle de cada etiqueta —que en el Excel incluye el nombre de la entidad— queda solo
    en la salida en runtime; NO se escribe ningún literal de cliente en el código (regla dura 2)."""
    out = []
    for label, valor in (labels or {}).items():
        if str(label).strip().lower().startswith(_EXENCION_PREFIJOS):
            out.append({"concepto": label, "importe": _round2(valor)})
    return out


def parse(path=DEFAULT_PATH, sheet_liq=None, sheet_gf=None, gf_pendientes=None, gf_pend_min_row=37,
          bin_casillas=None, bin_aplicado_ceil=True, gf_aeat_calcula=True, bin_limite_pct=None,
          regimen="general", gf_limite_30=None, dias_periodo=365, suelo_gf=1_000_000.0,
          gf_adicion_01255=0.0, gf_adq=None, gf_ord=None, gf_01250_real=None):
    path = str(path)
    labels = _liquidacion(path, sheet_liq or "Liquidación IS 2024")
    casillas = {}
    warnings = []

    def get(label):
        return labels.get(label)

    casillas.update({
        "00500": _round2(get("RESULTADOS CONTABLES INDIVIDUALES")),
        "00301": _round2(get("Gasto/Ingreso por IS: 6300")),
        "00501": _round2(get("RESULTADO CONTABLE CORREGIDO POR  IS")),
        "00340": _round2(get("Ajustes positivos")),
        "00417": _round2(get("Ajustes positivos")),
        "00386": _round2(abs(get("Ajustes negativos") or 0)),
        "00418": _round2(abs(get("Ajustes negativos") or 0)),
        "00550": _round2(get("B.I. Previa")),
        "00547": _round2(abs(get("Compensación pérdidas") or 0)),
        "00552": _round2(get("B.I. después de la compensación de BINs")),
        "01330": _round2(get("B.I. después de la compensación de BINs")),
        "00558": "25.00",
        "00562": _round2(get("Cuota íntegra (tipo 25%)")),
        "00571": _round2(abs(get("DDI Internacional (generada en el ejercicio 2020)") or 0)),
        "00582": _round2(get("Cuota íntegra ajustada")),
        "00592": _round2(get("Cuota líquida")),
        "00599": _round2(get("Cuota a ingresar/devolver")),
        "00611": _round2(get("Cuota a ingresar/devolver")),
        "01586": _round2(get("Cuota a ingresar/devolver")),
        "00621": _round2(get("Cuota a ingresar/devolver")),
    })
    if casillas.get("00417") is not None:
        casillas["02301"] = casillas["00417"]
        casillas["03051"] = casillas["00417"]
    if casillas.get("00418") is not None:
        casillas["02302"] = casillas["00418"]
        casillas["03226"] = casillas["00418"]
    if casillas.get("00500") is not None:
        for cod in ("00650", "00653", "00654", "01522", "00666"):
            casillas[cod] = casillas["00500"]
    if casillas.get("00552") is not None:
        casillas["00619"] = _round2(casillas["00552"] * 0.15)

    try:                                              # BINs/GF en hojas propias: fail-soft si la plantilla
        bin_cas, bin_rows = _bins(path, casillas_map=bin_casillas, aplicado_ceil=bin_aplicado_ceil)
    except Exception as e:   # noqa: BLE001
        bin_cas, bin_rows = {}, []
        warnings.append(f"BINs no extraídos (¿hoja distinta?): {e}")
    casillas.update(bin_cas)

    ddi = casillas.get("00571")
    if ddi:
        casillas.update({
            "02324": ddi, "02326": ddi, "02327": ddi,
            "00131": ddi, "00132": ddi,
            "02325": "25.00",
            "00103": "25.0000",
        })

    try:
        casillas.update(_gastos_financieros(path, sheet=sheet_gf or "Limitación Gastos financieros",
                                            pendientes=gf_pendientes, pend_min_row=gf_pend_min_row,
                                            aeat_calcula=gf_aeat_calcula, regimen=regimen,
                                            limite_30=gf_limite_30, dias_periodo=dias_periodo,
                                            suelo_gf=suelo_gf, adicion_01255=gf_adicion_01255,
                                            gf_adq=gf_adq, gf_ord=gf_ord,
                                            resultado_explotacion_real=gf_01250_real))
    except Exception as e:   # noqa: BLE001
        warnings.append(f"Gastos financieros (limitación) no extraídos (¿hoja distinta?): {e}")
    if not gf_aeat_calcula and any(c in casillas for c in ("01245", "01250", "01256")) and "02369" not in casillas:
        warnings.append("GF 2025: gastos financieros extraídos pero SIN el límite 02369 (¿etiqueta "
                        "'30% Bº OPERATIVO' renombrada/ausente?) — la página 20 saldría incompleta, revisar.")
    if gf_limite_30 is not None:
        # Codex finding 3 (compuerta humana, regla dura 5): `gf_limite_30` corrige el 01249 y el 02369 (y, en
        # cascada, la BI/cuota correctas), PERO el importador AEAT RECALCULA 01249 desde los componentes del B.O.
        # de la hoja (01250 resultado explotación, 01251 amortizaciones, 02368 ingresos de participaciones). Si
        # esos componentes siguen INFLADOS, el .200 NO importará limpio (E25401249/E25402369): el número es el
        # correcto, pero para una importación sin errores el abogado debe aportar un 01250 (y componentes)
        # CONCILIADO con 00296. El gate INT-GF-RE permanece bloqueante hasta esa conciliación.
        warnings.append("GF 2025: 02369 recalculado al suelo de 1M con el 30%·B.O. real (gf_limite_30); la cuota "
                        "es la correcta del veredicto, pero el .200 solo importará LIMPIO si el 01250/01251/02368 "
                        "de la hoja GF se concilian con 00296 (el importador recalcula 01249). Compuerta humana: "
                        "import real en Sociedades WEB.")

    # --- Limitación de GF (art. 16 LIS, BLOQUE 1 ETVE): ajuste positivo 00363 + recálculo de la cascada ---
    # CONFIRMADO por el abogado (2026-06-19): GIP es ETVE y sus GF derivan de deuda de adquisición de
    # participaciones → bloque 1 (art. 16.5). El GF NO deducible es el c2 (01243) que NO pasa el límite del 16.5;
    # 01260 = c2 + l2 (l2=0). Como el resultado contable incluye el GF íntegro, el c2 se AÑADE como ajuste
    # positivo 00363 (= 01260, validación 9460; sin 00364: revierte en años futuros). El importador NO lo
    # auto-deriva (verificado: al suprimirlo calculó 00417 sin GF), así que se emite explícito. La Estimación del
    # workbook no traía el ajuste → su BI/cuota estaban MAL: se recalcula la cascada (BI previa → BINs → BI → cuota).
    gf_nd = _num(casillas.get("01260")) or 0.0         # total GF no deducible del período (c2 + l2)
    if not gf_aeat_calcula and gf_nd and casillas.get("00501") is not None:
        casillas["01255"] = 0.0                            # no hay adición válida de B.O. de ejercicios anteriores
        # Configuración DEFINITIVA del importador (mapeada por el abogado tras 7 importaciones, 2026-06-19):
        #  · 00363 (pág 12) SE EMITE explícito = 01260: la validación 9460 es de COINCIDENCIA (01260=00363), el
        #    sistema NO lo auto-deriva. Es una de las casillas individuales que el importador suma para 00417.
        #  · 02303/02309 (pág 20 bis) NO se emiten: están BLOQUEADAS (E25402303/E25402309); el sistema auto-genera
        #    la clasificación temporaria desde 00363. Emitir 00363 Y 02303 a la vez = doble conteo (00417=27,9M).
        #  · 01215 (pág 20) = arrastre del c2: completa la página 20 (ya emitido en el post-step GF).
        casillas["00363"] = _round2(gf_nd)                 # ajuste positivo art.16 (pág 12) = 01260 (9460); NO 00364
        if casillas.get("00417") is not None:
            casillas["00417"] = _round2((_num(casillas["00417"]) or 0.0) + gf_nd)   # total = Σindividuales (incl. 00363)
        # Cascada: BI previa = 00501 + 00417 − 00418
        bi_previa = _round2(_num(casillas["00501"]) + (_num(casillas.get("00417")) or 0.0)
                            - (_num(casillas.get("00418")) or 0.0))
        casillas["00550"] = bi_previa
        # Compensación de BINs = min(disponible 00670, max(1M, %tramo × BI previa)); se RE-DISTRIBUYE oldest-first
        pct = bin_limite_pct if bin_limite_pct is not None else 0.5
        disp = _num(casillas.get("00670")) or 0.0
        comp = _round2(min(disp, max(1_000_000.0, pct * bi_previa)))
        restante = comp
        for year in sorted(bin_casillas or {}):
            c_pend, c_apl, c_fut = bin_casillas[year]
            pend = _num(casillas.get(c_pend)) or 0.0
            if pend <= 0:
                continue
            apl = _round2(min(restante, pend))
            casillas[c_apl] = apl
            casillas[c_fut] = _round2(pend - apl)
            restante = _round2(max(0.0, restante - apl))
        casillas["00547"] = comp
        if casillas.get("00670") is not None:
            casillas["00671"] = _round2(disp - comp)
        bi = _round2(bi_previa - comp)
        casillas["00552"] = bi
        casillas["01330"] = bi
        # Cascada de cuota (R6 del veredicto): rompe la propagación MONOLÍTICA 00562=…=00621 que anulaba las
        # minoraciones (C7). Cada eslabón resta su minorando y la cuota se calcula sobre base POSITIVA (R6.5).
        # Para GIP 2025 todas las minoraciones son 0 (00571 DDI=0) → la cadena colapsa a la cuota íntegra (mismo
        # número), pero por CÁLCULO. Tipo general 25% parametrizable (R6.1). 00619 = 15%×BI (cuota mín. art.30bis).
        # Codex finding 2 / R8: NO restar la DDI (00571) sin verificar el LÍMITE del art.31 (renta extranjera +
        # impuesto soportado). Hasta implementar R8 se pasa ddi=0 (no se firma una DDI no verificada) y, si la hoja
        # 2025 trae 00571>0, se avisa fail-closed. Para GIP 2025 00571=0 → sin efecto.
        ddi_v = _num(casillas.get("00571")) or 0.0
        if ddi_v > 0:
            warnings.append(f"GF 2025: DDI 00571={ddi_v} presente pero el límite del art.31 (R8) NO está verificado "
                            "(renta/impuesto extranjero) — NO se descuenta en la cuota líquida; revisar antes de firmar.")
        for _c, _v in _cascada_cuota(bi, tipo=0.25, ddi=0.0).items():
            if _c == "00619" or casillas.get(_c) is not None:
                casillas[_c] = _v

    unmapped = {
        "retencion_soportada_extranjero": _round2(get("Retenciones soportadas en extranjero - Impuestos a las ganancias")),
        "ibp": _round2(get("Otros gastos no deducibles - Impuestos sobre Bienes Personales")),
        "exenciones": _exenciones(labels),
    }
    warnings.append("Los importes itemizados de ajustes se conservan en unmapped; el .200 GIP 2024 agrupa aumentos en 00340 y disminuciones en 00386.")
    return {
        "source": "liquidacion",
        "path": path,
        "casillas": {k: v for k, v in casillas.items() if v not in (None, "")},
        "bins": bin_rows,
        "unmapped": unmapped,
        "warnings": warnings,
    }


def to_casillas(parsed):
    return dict(parsed.get("casillas") or {})


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("path", nargs="?", default=DEFAULT_PATH)
    ap.add_argument("--out")
    args = ap.parse_args()
    data = parse(args.path)
    text = json.dumps(data, ensure_ascii=False, indent=2, default=str)
    if args.out:
        Path(args.out).write_text(text, encoding="utf-8")
    print(text)


if __name__ == "__main__":
    main()
