"""Emisión de los DATOS FORMALES del Modelo 200 (.200) — capa COMPARTIDA.

Estos son los apartados que el importador AEAT Sociedades WEB exige y cuya ausencia/incompletitud dispara
errores (186/187 socios, 2827 titular real, 144 secretario, 146/153 representante):
- DP200002 apartado A (administrador) + B.2 (socios; 6 por registro, 7+ en continuación 'C').
- DP200002B apartado F (titular real; 1 por registro, 2..N en continuación 'C') + G (secretario,
  representantes con fecha de poder + notario).

Vive aparte del builder GIP para que lo usen IGUAL el harness de replay (CLI) y el motor de servicio
(`dr200.construir_declaracion`), de modo que el `.200` que genera la aplicación sea importable, no solo el
del replay. Módulo SIN dependencias del proyecto (ni caso_local ni parsers): entra {casilla/campo: valor}
keyado por num_campo del DR. 0 PII.
"""
from __future__ import annotations

import datetime
import re

_PAIS_ISO2 = {
    "ESPAÑA": "", "ESPANA": "", "ARGENTINA": "AR", "BRASIL": "BR", "URUGUAY": "UY",
    "PANAMA": "PA", "PANAMÁ": "PA", "ESTADOS UNIDOS": "US", "EEUU": "US", "MEXICO": "MX",
    "MÉXICO": "MX", "CHILE": "CL", "PERU": "PE", "PERÚ": "PE", "COLOMBIA": "CO", "PORTUGAL": "PT",
}
_NIF_JURIDICA = set("ABCDEFGHJNPQRSUVW")


def _a_float(v):
    """Importe a float admitiendo formato europeo ('2.486.355,42') o ya numérico. 0.0 si no se puede."""
    if v in (None, ""):
        return 0.0
    if isinstance(v, (int, float)):
        return float(v)
    s = str(v).strip().replace(" ", "")
    if "," in s and "." in s:
        s = s.replace(".", "").replace(",", ".")
    elif "," in s:
        s = s.replace(",", ".")
    try:
        return float(s)
    except ValueError:
        return 0.0


def _iso2_pais(pais):
    """País -> código ISO2 (campo de 2 letras del DR). Conocido por mapa; ya-ISO2 se deja; desconocido ->
    '' (no inventa). España -> '' (las participadas/socios españoles van con país en blanco)."""
    p = str(pais or "").strip().upper()
    if p in _PAIS_ISO2:
        return _PAIS_ISO2[p]
    return p[:2] if len(p) == 2 else ""


def _grupo21_campos(formales):
    """Campos de las entidades del grupo en DP200021 a partir de las participadas: NIF[k]=campo 7+2(k-1),
    país[k]=campo 8+2(k-1) (k=1..12). Para extranjeras el NIF se prefija con el ISO2 (convención AEAT) y el
    país va relleno; para españolas el país va en blanco. La regla exige estos NIF si 00987 tiene valor
    (error EMALP21_4). No inventa: usa las participadas que ya extrae el parser de datos formales.
    FUENTE ÚNICA: gip2024_replay_builder lo importa de aquí (evita drift; el golden lo cubre byte-idéntico)."""
    campos = {}
    for k, part in enumerate((formales.get("participadas") or [])[:12], start=1):
        nif = str(part.get("nif") or "").strip()
        if not nif:
            continue
        iso = _iso2_pais(part.get("pais"))
        # Prefijo ISO2 solo si NO viene ya en el NIF (evita 'ARAR...' que el emisor truncaría a 15).
        nif_out = nif if (not iso or nif.upper().startswith(iso)) else (iso + nif)
        campos[7 + 2 * (k - 1)] = nif_out
        campos[8 + 2 * (k - 1)] = iso
    return campos


def _fj(nif):
    """F (persona física) / J (jurídica) por la letra inicial del NIF: letra de sociedad -> J; X/Y/Z o
    dígito (DNI/NIE de persona) -> F. Heurística suficiente para el campo tipo-persona del DR."""
    return "J" if str(nif)[:1].upper() in _NIF_JURIDICA else "F"


def _administradores_campos(administradores):
    """A — relación de administradores (DP200002, campos 6..35; hasta 5 slots en la página base)."""
    campos = {}
    for k, admin in enumerate([a for a in (administradores or []) if str(a.get("nif") or "").strip()][:5], start=1):
        base = 6 + 6 * (k - 1)
        nif = str(admin.get("nif")).strip()
        campos[base] = nif
        campos[base + 1] = admin.get("fj") or _fj(nif)
        campos[base + 2] = str(admin.get("rpte") or "0").strip()[:1] or "0"
        campos[base + 3] = _nombre(admin.get("nombre"))
    return campos


def _nombre(persona):
    """Nombre tal cual lo entrega el expediente. El importador valida la PRESENCIA (errores 2827/144/146/
    186/187); el orden 'APELLIDOS, NOMBRE' es dato del XLS, no se inventa ni se reordena aquí."""
    return str(persona or "").strip()


def _fecha_aaaammdd(v):
    """Fecha -> 'AAAAMMDD' VALIDADA como fecha de calendario real, o '' si no es parseable. Acepta objetos
    date/datetime/Timestamp (de Excel, con o sin hora), ISO 'AAAA-MM-DD', europeo 'DD/MM/AAAA' o 'DD-MM-AAAA',
    'AAAAMMDD', y descarta una componente de hora ('AAAA-MM-DD HH:MM:SS'). Robusta a quién la llame: no depende
    de que el parser haya hecho strftime antes. Evita '15/01/2020'->'15012020' (un AAAAMMDD inválido de 8
    dígitos que pasaría desapercibido)."""
    if v is None:
        return ""
    if hasattr(v, "year") and hasattr(v, "month") and hasattr(v, "day"):   # date/datetime/Timestamp de Excel
        try:
            d = datetime.date(int(v.year), int(v.month), int(v.day))
            return f"{d.year:04d}{d.month:02d}{d.day:02d}"
        except (ValueError, TypeError):
            return ""
    s = str(v).strip()
    if not s:
        return ""
    s = s.split()[0]                          # descarta una componente de hora si viene 'AAAA-MM-DD HH:MM:SS'
    partes = re.split(r"[/\-.]", s)
    if len(partes) == 3:
        a, b, c = partes
        if len(a) == 4:                       # AAAA-MM-DD (ISO)
            anio, mes, dia = a, b, c
        elif len(c) == 4:                     # DD-MM-AAAA (europeo)
            anio, mes, dia = c, b, a
        else:
            return ""
    elif re.fullmatch(r"\d{8}", s):           # AAAAMMDD (ya formateado)
        anio, mes, dia = s[:4], s[4:6], s[6:8]
    else:
        return ""
    try:
        d = datetime.date(int(anio), int(mes), int(dia))
    except (ValueError, TypeError):
        return ""
    return f"{d.year:04d}{d.month:02d}{d.day:02d}"


def _socios_campos(socios):
    """B.2 — participaciones de personas/entidades EN la declarante (DP200002, campos 100..141; hasta 6
    slots de 7). Resuelve 186/187. % en centésimas (0,2562 -> 2562) por MÉTODO DEL RESTO MAYOR: la suma de
    los slots = round(Σ%·10000) (el redondeo independiente daría 9999 con tres tercios). Parcial (<100%)
    no se infla a 100."""
    validos = [s for s in (socios or [])[:6] if str(s.get("nif") or "").strip()]
    idx_pct = [i for i, s in enumerate(validos) if s.get("porcentaje") is not None]
    cent = {}
    if idx_pct:
        raw = {i: _a_float(validos[i].get("porcentaje")) * 10000 for i in idx_pct}
        cent = {i: int(v) for i, v in raw.items()}
        sobran = int(round(sum(raw.values()))) - sum(cent.values())
        for i in sorted(idx_pct, key=lambda i: (raw[i] - int(raw[i]), -i), reverse=True)[:sobran]:
            cent[i] += 1
    campos = {}
    for k, s in enumerate(validos, start=1):
        base, i = 100 + 7 * (k - 1), k - 1
        nif = str(s.get("nif")).strip()
        campos[base] = nif
        campos[base + 1] = "0"
        campos[base + 2] = _fj(nif)
        campos[base + 3] = _nombre(s.get("nombre"))
        campos[base + 4] = _iso2_pais(s.get("pais"))
        if s.get("nominal") is not None:
            campos[base + 5] = s.get("nominal")
        if i in cent:
            campos[base + 6] = str(cent[i])
    return campos


def _titular_campos(titular, continuacion=False):
    """F — identificación del titular real (DP200002B, campos 144..151; 1 por registro; 2..N en
    continuación campo 5='C'). extra = [nacionalidad, residencia, fecha]."""
    nif = str(titular.get("nif") or "").strip()
    extra = titular.get("extra") or []
    campos = {144: "0", 145: "1", 146: nif, 147: _nombre(titular.get("nombre"))}
    if continuacion:
        campos[5] = "C"

    # País del titular real → ISO2. A DIFERENCIA de socios/participadas (donde España va EN BLANCO), en el
    # bloque F del titular real España SÍ debe ir como "ES": la AEAT exige país de residencia (150) y
    # nacionalidad (151) rellenos o salta 2830 (reimport REDEVCO 2026-06-28). GIP-safe: su titular llega del
    # `.200` ya en ISO2 ('ES'), no como nombre 'ESPAÑA', así que este mapeo no altera su salida byte-idéntica.
    def _pais_tit(p):
        s = str(p or "").strip().upper()
        if s in ("ESPAÑA", "ESPANA", "ESP", "724"):
            return "ES"
        return _iso2_pais(p)

    if len(extra) >= 1 and str(extra[0]).strip():
        campos[151] = _pais_tit(extra[0])
    if len(extra) >= 2 and str(extra[1]).strip():
        campos[150] = _pais_tit(extra[1])
    # País de expedición del documento (148): NO se emite. La AEAT lo declara «NO REQUERIDO» y rechaza con
    # 02B1480 («se intenta importar el valor ES que no es un valor correcto») si llega con contenido (reimport
    # REDEVCO 2026-06-28). El bloque del titular real se completa con 145/146/147 + 149/150/151 (sin 148).
    if len(extra) >= 3:
        fecha = _fecha_aaaammdd(extra[2])
        if fecha:
            campos[149] = fecha
    return campos


def _representantes_campos(representantes):
    """G — representantes legales (DP200002B, hasta 3 slots de 4: nombre/nif/fecha de poder AAAAMMDD/
    notario; campos 154..165). El importador exige el slot COMPLETO (error 153). extra = [fecha, notario]."""
    campos = {}
    for k, r in enumerate((representantes or [])[:3], start=1):
        if not str(r.get("nif") or "").strip():
            continue
        base = 154 + 4 * (k - 1)
        ex = r.get("extra") or []
        campos[base] = _nombre(r.get("nombre"))
        campos[base + 1] = str(r.get("nif")).strip()
        if len(ex) >= 1:
            fec = _fecha_aaaammdd(ex[0])
            if fec:
                campos[base + 2] = fec
        if len(ex) >= 2 and str(ex[1]).strip():
            campos[base + 3] = str(ex[1]).strip()
    return campos


def _b1_campos(participadas):
    """Legacy helper for B.1 participadas.

    Kept for parsers/tests that need the positional mapping. formal_page_entries only uses it for simple B.1
    blocks; complex B.1 is carried as post-import/HITL data because OpenWeb 2025 rejects fragile totals.
    """
    campos = {}
    totals = {"nominal": 0.0, "valor_libros": 0.0, "dividendos": 0.0}
    has_total = {k: False for k in totals}
    for k, p in enumerate([p for p in (participadas or []) if str(p.get("nif") or "").strip()][:3], start=1):
        b = 36 + 18 * (k - 1)
        campos[b] = str(p.get("nif")).strip()
        campos[b + 1] = _nombre(p.get("nombre"))
        if p.get("pais"):
            campos[b + 2] = _iso2_pais(p.get("pais")) or str(p.get("pais"))[:2].upper()
        if p.get("pct") is not None:
            campos[b + 3] = int(round(float(p["pct"]) * 10000))      # fracción → Num(5), 2 decimales
        if p.get("nominal") is not None:
            campos[b + 4] = p["nominal"]
            totals["nominal"] += _a_float(p["nominal"])
            has_total["nominal"] = True
        if p.get("valor_libros") is not None:
            campos[b + 5] = p["valor_libros"]
            totals["valor_libros"] += _a_float(p["valor_libros"])
            has_total["valor_libros"] = True
        if p.get("dividendos") is not None:
            campos[b + 6] = p["dividendos"]
            totals["dividendos"] += _a_float(p["dividendos"])
            has_total["dividendos"] = True
    # Totales B.1 (campos 90/91/92 = 01501/01502/01503). Solo se usan en el caso simple sin continuaciones.
    for campo, key in ((90, "nominal"), (91, "valor_libros"), (92, "dividendos")):
        if has_total[key]:
            campos[campo] = round(totals[key], 2)
    return campos


def b1_emitible_dr(participadas):
    """True si B.1 es suficientemente simple para emitirlo por DR200.

    Evidencia OpenWeb 2025:
    - B.1 simple (hasta 3 participadas, sin continuación) puede importar, normalmente con avisos 44/45/46.
    - B.1 complejo con continuaciones/totales parciales produjo SUN: 0200900/0200910/0200920 y E254R2C5T.

    Por prudencia solo emitimos el caso simple y completo; el resto queda como JSON post-import.
    """
    rows = [p for p in (participadas or []) if str(p.get("nif") or "").strip()]
    if not rows or len(rows) > 3:
        return False
    for p in rows:
        nif = str(p.get("nif") or "").strip()
        nombre = str(p.get("nombre") or "").strip()
        pais = str(p.get("pais") or "").strip()
        if len(nif) < 5 or len(nif) > 15 or not nombre or not pais:
            return False
    return True


def formal_page_entries(formales):
    """Páginas de datos formales como entries {page, campos_pos, casillas}: administrador + socios B.2
    (DP200002, 7+ socios en continuación 'C') y titular real + secretario + representante (DP200002B,
    titulares 2..N en continuación 'C'). `formales` = dict del parser de datos formales (o equivalente):
    administradores/socios/titulares_reales/secretario/representantes (listas de {nombre,nif,extra,...})."""
    entries = []
    socios = [s for s in (formales.get("socios") or []) if str(s.get("nif") or "").strip()]
    participadas_b1 = [p for p in (formales.get("participadas_b1") or []) if str(p.get("nif") or "").strip()]
    emitir_b1 = b1_emitible_dr(participadas_b1)
    # B.1 se emite solo si es simple y consistente (<=3 participadas completas, sin continuación). Si exige
    # continuación o viene incompleto, se deja como post-import: SUN 2025 demostró que los totales 01501/01502/01503
    # se vuelven frágiles y OpenWeb rechaza el bloque.
    n_dp2 = max(1 if (formales.get("administradores") or socios or emitir_b1) else 0,
                (len(socios) + 5) // 6)
    for i in range(n_dp2):
        dp2 = {}
        if i == 0:
            dp2.update(_administradores_campos(formales.get("administradores")))
            if emitir_b1:
                dp2.update(_b1_campos(participadas_b1))
        else:
            dp2[5] = "C"
        dp2.update(_socios_campos(socios[i * 6:(i + 1) * 6]))
        if dp2 and dp2 != {5: "C"}:
            entries.append({"page": "DP200002", "campos_pos": dp2, "casillas": {}})

    titulares = formales.get("titulares_reales") or []
    secretario = (formales.get("secretario") or [{}])[0]
    representantes = [r for r in (formales.get("representantes") or []) if str(r.get("nif") or "").strip()]
    if titulares or secretario.get("nif") or representantes:
        # [A5 §3] Sin titular real identificado: 144 = "1" (entidad SIN obligación de identificar titular real,
        # exención art.4.2 Ley 10/2010) cierra el error AEAT 2830. DECISIÓN DEL ABOGADO (HITL): si la entidad SÍ
        # debe declarar titular real, aportar `titulares_reales`. El export lo señala con un aviso (no es default
        # silencioso): ver el aviso "titular real (144=1)" emitido por exportar_base.
        base = _titular_campos(titulares[0]) if titulares else {144: "1"}
        if secretario.get("nif"):
            base[152] = _nombre(secretario.get("nombre"))
            base[153] = secretario.get("nif", "")
        base.update(_representantes_campos(representantes))
        entries.append({"page": "DP200002B", "campos_pos": base, "casillas": {}})
        for t in titulares[1:]:
            entries.append({"page": "DP200002B", "campos_pos": _titular_campos(t, continuacion=True),
                            "casillas": {}})

    # DP200021 (página 21): grupo mercantil con dominante española → INCN del grupo (00987) + NIF/país de las
    # participadas. El importador exige 00987 + ≥1 NIF si la entidad marca grupo (aviso 21200 / error EMALP21_4).
    # Capa formal del N-1 (el abogado actualiza el INCN del grupo del año en curso en Sociedades WEB).
    g21 = _grupo21_campos(formales)
    incn_grupo = formales.get("incn_grupo")
    if g21 or incn_grupo not in (None, ""):
        cas21 = {"00987": incn_grupo} if incn_grupo not in (None, "") else {}
        entries.append({"page": "DP200021", "campos_pos": g21, "casillas": cas21})
    return entries
