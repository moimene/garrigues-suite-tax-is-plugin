#!/usr/bin/env python3
"""Configuración LOCAL del caso (identidad de la sociedad + rutas de los ficheros fuente).

Este módulo NO contiene datos de cliente: los lee de `Extractor-parseador/caso_local.json`
(gitignored). Si ese fichero no existe, devuelve valores SINTÉTICOS del demo (NIF B12345678) y rutas
vacías, de modo que los scripts y los tests funcionan sin PII en el árbol y los tests que necesitan
fuentes reales hacen `pytest.skip` limpio (regla dura 2: 0 PII en árbol e historial).

Precedencia por clave: variable de entorno `GIP2024_<CLAVE>` > `caso_local.json` > default sintético.
La forma del JSON está documentada en `caso_local.example.json` (sí versionado, sintético).
"""
from __future__ import annotations

import json
import os
from pathlib import Path

_HERE = Path(__file__).resolve().parent
_JSON = _HERE.parent / "caso_local.json"   # Extractor-parseador/caso_local.json (gitignored)

_DEFAULTS = {
    "nif": "B12345678",
    "razon_social": "EMPRESA DEMO SL",
    "paths": {"balance": "", "liquidacion": "", "datos_formales": "", "real_200": ""},
    # Fuentes del ejercicio 2025 (replay 2025): SyS (contable), Estimación GIS (liquidación), datos formales
    # (se arrastran del 2024) y el .ses real como oráculo de formato.
    "paths_2025": {"sys": "", "estimacion": "", "datos_formales": "", "ses": ""},
    "expected": {},
    "overrides": [],
    "golden_200": [],
    "casos": [],
    "aux": {},
}


def _load() -> dict:
    data = {"nif": _DEFAULTS["nif"], "razon_social": _DEFAULTS["razon_social"],
            "paths": dict(_DEFAULTS["paths"]), "paths_2025": dict(_DEFAULTS["paths_2025"]),
            "expected": {}, "overrides": [], "golden_200": [], "casos": [], "aux": {}}
    if _JSON.exists():
        try:
            disk = json.loads(_JSON.read_text(encoding="utf-8"))
        except (ValueError, OSError):
            disk = {}
        for clave in ("nif", "razon_social"):
            if disk.get(clave):
                data[clave] = disk[clave]
        for clave, valor in (disk.get("paths") or {}).items():
            data["paths"][clave] = valor
        for clave, valor in (disk.get("paths_2025") or {}).items():
            data["paths_2025"][clave] = valor
        for clave in ("expected", "aux", "facts_2025"):
            if isinstance(disk.get(clave), dict):
                data[clave] = disk[clave]
        for clave in ("overrides", "golden_200", "casos"):
            if isinstance(disk.get(clave), list):
                data[clave] = disk[clave]
    return data


def nif() -> str:
    return os.environ.get("GIP2024_NIF") or _load()["nif"]


def razon_social() -> str:
    return os.environ.get("GIP2024_RAZON_SOCIAL") or _load()["razon_social"]


def path(clave: str) -> str:
    """Ruta del fichero fuente `clave` (balance/liquidacion/datos_formales/real_200), o '' si no
    está configurado (los tests hacen skip; `os.path.exists('')` es False)."""
    env = os.environ.get(f"GIP2024_{clave.upper()}")
    if env:
        return env
    return (_load().get("paths") or {}).get(clave, "")


def path_2025(clave: str) -> str:
    """Ruta de la fuente 2025 `clave` (sys/estimacion/datos_formales/ses), o '' si no está configurada."""
    env = os.environ.get(f"GIP2025_{clave.upper()}")
    if env:
        return env
    return (_load().get("paths_2025") or {}).get(clave, "")


def facts_2025() -> dict:
    """Datos de HECHO fiscales confirmados por el abogado para el ejercicio 2025 (no extraíbles del workbook),
    que dirigen el cálculo del motor en vez de los hardcodes (Paso 1 del plan post-veredicto). Claves típicas:
    `gf_limite_30` (30%·B.O. REAL del art.16.1, casilla 01249; negativo si el B.O. es negativo → suelo 1M en 16.1),
    `gf_adq`/`gf_ord` (reparto del GF entre deuda de adquisición 16.5 y ordinario 16.1; default GIP = 100% adq),
    `gf_adicion_01255` (adición de B.O. de ejercicios anteriores, art.16.2), `incn_12m` (INCN de los 12 meses
    previos al inicio, tramo BIN art.26 y ámbito art.30bis), `bin_limite_pct` (0.70/0.50/0.25), `dias_periodo`.
    Es PII de cliente: vive SOLO en caso_local.json (gitignored). Vacío si no está configurado → el replay usa
    los defaults provisionales y el autocontrol marca fail-closed lo no confirmado (regla dura 5)."""
    f = (_load().get("facts_2025") or {})
    return f if isinstance(f, dict) else {}


def expected(grupo: str) -> dict:
    """Valores numéricos esperados del caso real por grupo ('liquidacion'/'contable'), para que los
    tests no versionen cifras de cliente. Vacío si no hay caso_local.json (los tests hacen skip)."""
    return (_load().get("expected") or {}).get(grupo, {})


def overrides() -> list:
    """Datos manuales/proyectados por casilla aportados por el abogado, que el harness no puede extraer de
    los workbooks (p. ej. 00987 cifra de negocios de grupo, o ajustes manuales). Cada entrada:
    {pagina, casilla, valor, estado: auto|revisar|manual_requerido|bloqueado, fuente?, regla?}.
    Vacío si no hay caso_local.json. Es PII de cliente: vive solo en el fichero gitignored."""
    ov = _load().get("overrides")
    return ov if isinstance(ov, list) else []


def golden_200() -> list:
    """`.200` reales adicionales para validación estructural multi-entidad (holdout de generalización del
    formato). Cada entrada: {path, ejercicio}. Son PII: viven solo en caso_local.json (gitignored)."""
    gs = _load().get("golden_200")
    return gs if isinstance(gs, list) else []


def aux() -> dict:
    """Metadatos del bloque `<AUX>` del DP200000: `marca` (lo que el software real escribe en el reservado,
    p. ej. 'E'), `version` (versión del programa, p. ej. 'F 1.05') y `nif_eedd` (NIF de la Empresa de
    Desarrollo). Vacío por defecto → `<AUX>` en blanco. Para importar en Sociedades WEB suele requerirse
    poblarlo con los valores que use tu software AEAT (cópialos de un `.200` real). Solo en caso_local.json."""
    a = _load().get("aux")
    a = a if isinstance(a, dict) else {}
    return {"marca": str(a.get("marca") or ""), "version": str(a.get("version") or ""),
            "nif_eedd": str(a.get("nif_eedd") or "")}


def casos() -> list:
    """Casos (sociedad + ejercicio) de la CAMPAÑA. Si caso_local.json define `casos`, los usa; si no,
    devuelve un único caso con la config singular (retrocompat). Cada caso:
    {id, nif, razon_social, ejercicio, paths:{balance,liquidacion,datos_formales,real_200}, overrides:[...]}.
    Es PII: vive solo en el fichero gitignored."""
    data = _load()
    cs = data.get("casos")
    if isinstance(cs, list) and cs:
        return [c for c in cs if isinstance(c, dict)]
    return [{
        "id": "caso", "nif": data["nif"], "razon_social": data["razon_social"],
        "ejercicio": "2024", "paths": dict(data["paths"]), "overrides": list(data["overrides"]),
    }]
