#!/usr/bin/env python3
"""dr200.py — Diseño de Registro (DR) oficial del Modelo 200: formato de IMPORTACIÓN de ancho fijo.

El XSD de la AEAT cubre SOLO los estados contables (pág. 03-54). La declaración COMPLETA —identificativos
(DP200001/001B/002) + liquidación (DP200012-014B)— se importa por el DR de ancho fijo (Diseño de Registro,
BOE), que NO tiene XSD. Este módulo parsea la extracción campo-a-campo del DR oficial
(`docs/info soporte/DR200e25_extraccion_completa.csv`: posicion/longitud/tipo/contenido/casilla) y emite los
registros de ancho fijo de cada página.

Nunca inventa: cada campo sale del DR oficial; las constantes del DR se rellenan solas, y lo no provisto va
en blanco (An) o a ceros (Num) según el tipo. La validez DEFINITIVA es la importación real en Sociedades WEB
(no hay XSD que validar) — compuerta humana, como el A3.
"""
import csv
import os
import datetime
import re
from decimal import Decimal, InvalidOperation, ROUND_HALF_UP

ROOT = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
DR_CSV_DEFAULT = os.path.join(ROOT, "docs", "info soporte", "DR200e25_extraccion_completa.csv")
DR_CSV_BY_EJERCICIO = {
    "2024": os.path.join(ROOT, "docs", "info soporte", "DR200e24_extraccion_completa.csv"),
    "2025": DR_CSV_DEFAULT,
}

_CONST_QUOTED_RE = re.compile(r'Constante[^"]*"+([^"]*)"+', re.IGNORECASE)
_CONST_UNQUOTED_RE = re.compile(r'Constante\.?\s+(\S+)', re.IGNORECASE)
_RAW_TAG_RE = re.compile(r'</?T[0-9A-Z]+>|<T|>', re.IGNORECASE)


def _int(v):
    v = (v or "").strip()
    return int(v) if v.isdigit() else None


def path_dr(ejercicio=None, path=None) -> str:
    """Ruta del DR normalizado. Si el ejercicio no esta onboarded, mantiene el default historico 2025."""
    if path:
        return path
    return DR_CSV_BY_EJERCICIO.get(str(ejercicio or ""), DR_CSV_DEFAULT)


def cargar_dr(path=None, ejercicio=None) -> dict:
    """DR → {pagina: [campo, …]} con campo = {num, posicion, longitud, tipo, descripcion, validacion,
    contenido, casilla}. Cada lista ordenada por `posicion`."""
    paginas = {}
    with open(path_dr(ejercicio=ejercicio, path=path), encoding="utf-8-sig") as fh:
        for row in csv.DictReader(fh):
            pag = (row.get("pagina_hoja") or "").strip()
            if not pag:
                continue
            paginas.setdefault(pag, []).append({
                "num": _int(row.get("num_campo")),
                "posicion": _int(row.get("posicion")),
                "longitud": _int(row.get("longitud")),
                "tipo": (row.get("tipo") or "").strip(),
                "descripcion": (row.get("descripcion") or "").strip(),
                "validacion": (row.get("validacion") or "").strip(),
                "contenido": (row.get("contenido") or "").strip(),
                "casilla": (row.get("casillas") or "").strip(),
            })
    for pag in paginas:
        paginas[pag].sort(key=lambda c: c.get("posicion") or 0)
    return paginas


_CARACTER_TRUE = {"1", "x", "s", "si", "sí", "true", "y", "yes", "verdadero"}


def _sanear_caracteres(caracteres):
    """[A5 FIX D2] Los CARACTERES de la página 1 son flags 0/1 (An·1). Una marca booleana ('1'/'x'/'si'/…)
    -> "1"; cualquier valor falsy, texto o etiqueta -> se omite (queda "0" por defecto). Evita escribir texto
    en un campo de 1 carácter (importador AEAT: «Caracteres no válidos»)."""
    if not caracteres:
        return caracteres
    out = {}
    for k, v in caracteres.items():
        sv = str(v).strip().lower()
        if sv in _CARACTER_TRUE:            # marca booleana -> "1"; falsy/texto/etiqueta -> se omite (queda "0")
            out[str(k).strip()] = "1"
    return out


def constante(campo) -> str:
    """Valor constante del DR para un campo.

    La extracción del XLS oficial no es homogénea: unas celdas vienen como `Constante "200"`, otras como
    `Constante </T20003000>` y algunos cierres aparecen directamente como `</T20001000>`. Normalizamos esas
    tres formas y dejamos como dato normal cualquier otro contenido del DR.
    """
    contenido = (campo.get("contenido") or "").strip()
    m = _CONST_QUOTED_RE.search(contenido)
    if m:
        return m.group(1)
    m = _CONST_UNQUOTED_RE.search(contenido)
    if m:
        return m.group(1).strip('"')
    if _RAW_TAG_RE.fullmatch(contenido):
        return contenido
    return None


def fmt_importe_dr(val, longitud) -> str:
    """Importe monetario (campos tipo 'N') en formato DR — codificación OFICIAL (DR200, nota DP200001:
    "los importes son de 15 enteros (o N + 14) y 2 decimales"): céntimos (euros × 100, ROUND_HALF_UP,
    2 decimales implícitos, sin separador), justificado a la DERECHA con ceros. NEGATIVO = constante 'N' en
    la PRIMERA posición + el valor absoluto en (longitud − 1). Generaliza a cualquier longitud con 2 decimales.
    (El fichero como TODO no tiene XSD: la validez final es la importación real en Sociedades WEB.)"""
    try:
        cent = int((Decimal(str(val)) * 100).to_integral_value(rounding=ROUND_HALF_UP))
    except (InvalidOperation, ValueError, TypeError):
        return "0" * longitud
    if cent < 0:
        return "N" + str(-cent)[-(longitud - 1):].rjust(longitud - 1, "0")   # DR: negativo -> 'N' + (L-1) díg.
    return str(cent)[-longitud:].rjust(longitud, "0")


def emitir_registro(campos, casillas=None, campos_pos=None) -> str:
    """Línea de ancho fijo de UNA página del DR. Rellena: (1) las CONSTANTES del DR, (2) los campos con
    `casilla` desde `casillas` {codigo: valor}, (3) los campos sin casilla (identificativos) desde
    `campos_pos` {num_campo: valor}. An = justificado a la IZQUIERDA con espacios; Num = a la DERECHA con
    ceros (un Num vacío va a ceros, como exige el DR). La longitud total = max(posicion+longitud-1)."""
    casillas = casillas or {}
    campos_pos = campos_pos or {}
    util = [c for c in campos if c.get("posicion") and c.get("longitud")]
    if not util:
        return ""
    total = max(c["posicion"] + c["longitud"] - 1 for c in util)
    buf = [" "] * total
    for c in util:
        pos, length, num = c["posicion"], c["longitud"], c.get("num")
        cst = constante(c)
        if cst is not None:
            val = cst
        elif c.get("casilla") and c["casilla"] in casillas:
            val = casillas[c["casilla"]]
        elif num in campos_pos:
            val = campos_pos[num]
        elif str(num) in campos_pos:            # `campos_pos` que llega por HTTP (JSON) trae el num_campo como
            val = campos_pos[str(num)]          # str ("14"); el match int va PRIMERO (path local/golden intacto)
        else:
            val = None
        tipo = (c.get("tipo") or "").strip().lower()
        # MONETARIO = tipo 'N', o 'Num' de longitud 17 (importe oficial: 15 enteros + 2 decimales). Estos
        # ÚLTIMOS estaban mal codificados como "dígitos planos" (re.sub \D): perdían el SIGNO de un importe
        # negativo (p.ej. 00547/00601 en DP200014/14B; revisión adversarial). Ahora usan fmt_importe_dr
        # (céntimos + signo 'N'), igual que los 'N'. Los 'Num' cortos (año, página, tipo de gravamen,
        # indicador, contador, nº justificante) NO son importes -> dígitos planos a ceros por la izquierda.
        if tipo == "n" or (tipo.startswith("num") and length == 17):   # MONETARIO (céntimos + signo)
            # Columna de DISMINUCIONES: el importe va como valor POSITIVO (el signo lo da la columna). Un negativo
            # escribiría la constante 'N' en un campo que el importador rechaza como "caracteres no válidos"
            # (p.ej. 00312/00314 pág 13). fmt_importe_dr ya sanea lo no-numérico a ceros; aquí evitamos el 'N' en
            # disminuciones (recomendación del equipo fiscal, informe 2026-06-24). Golden intacto: las disminuciones
            # del .200 real ya van positivas (importó limpio), así que abs() es no-op sobre el golden.
            if val not in (None, "") and c.get("casilla") and "isminuc" in (c.get("descripcion") or "").lower():
                try:
                    val = abs(float(str(val).replace(",", ".")))
                except (ValueError, TypeError):
                    pass
            s = fmt_importe_dr(val, length) if val not in (None, "") else "0" * length
        elif tipo.startswith("num"):                      # numérico plano corto (año, indicador, contador): ceros izda
            s = (re.sub(r"\D", "", str(val))[-length:].rjust(length, "0")) if val not in (None, "") else "0" * length
        else:                                            # An: texto, izquierda + espacios a la derecha
            s = ("" if val is None else str(val))[:length].ljust(length)
        for i, ch in enumerate(s[:length]):
            buf[pos - 1 + i] = ch
    return "".join(buf)


def emitir_pagina(dr, pagina, casillas=None, campos_pos=None) -> str:
    """Atajo: emite el registro de `pagina` del DR cargado."""
    return emitir_registro(dr.get(pagina, []), casillas=casillas, campos_pos=campos_pos)


# ----------------------------------------------------------------- declaración completa
# Identificativos amigables -> nº de campo de DP200001 (por coincidencia de descripción del DR oficial).
def mapear_identificativos(dr, datos) -> dict:
    """{nif, razon_social, ejercicio} (amigable) -> {num_campo: valor} de DP200001. Solo mapea lo provisto;
    NUNCA inventa (un dato ausente no se rellena -> va en blanco en el registro)."""
    campos = dr.get("DP200001", [])

    def find(*kw):
        for c in campos:
            d = (c.get("descripcion") or "").lower()
            if all(k in d for k in kw):
                return c.get("num")
        return None

    candidatos = {
        "nif": find("identificación", "nif"),
        "razon_social": find("identificación", "apellidos"),   # "Apellidos y nombre o Razón Social"
        "ejercicio": find("ejercicio"),
    }
    out = {}
    for clave, num in candidatos.items():
        if num is not None and datos.get(clave) not in (None, ""):
            out[num] = datos[clave]

    # Código CNAE de la actividad principal (DP200001 campo 18, Num·4). Cierra el aviso AEAT 196. La descripción
    # del DR varía por ejercicio ("C.N.A.E." en 2024, "CNAE-2025" en 2025): se NORMALIZA (sin puntos/guiones)
    # para casar ambas. Se SANEA a ≤4 dígitos; ausente -> va en blanco (NO se inventa; el previo trae 2009).
    def _find_cnae():
        for c in campos:
            d = re.sub(r"[^a-z0-9]", "", (c.get("descripcion") or "").lower())
            if "cnae" in d and "actividadprincipal" in d:
                return c.get("num")
        return None

    num_cnae = _find_cnae()
    if num_cnae is not None and datos.get("cnae") not in (None, ""):
        _cn = re.sub(r"\D", "", str(datos["cnae"]))[:4]
        if _cn:
            out[num_cnae] = _cn

    # Periodo impositivo (OBLIGATORIO: el importador da EMALFINI1 si falta). Por defecto el AÑO NATURAL del
    # ejercicio (01/01–31/12), que es el caso general; un ejercicio PARTIDO se pasa explícito en
    # datos["periodo"] = {"inicio": AAAAMMDD, "fin": AAAAMMDD}. No es "inventar" un dato: es el período que
    # implica el propio ejercicio para una entidad de año natural.
    ej = str(datos.get("ejercicio") or "").strip()
    if ej.isdigit() and len(ej) == 4:
        per = datos.get("periodo") or {}

        def _ymd(v, defecto):
            s = re.sub(r"\D", "", str(v or ""))
            return s[:8] if len(s) >= 8 else defecto

        ini, fin = _ymd(per.get("inicio"), f"{ej}0101"), _ymd(per.get("fin"), f"{ej}1231")
        for num, val in {
            find("año", "inicio"): ini[0:4], find("mes", "inicio"): ini[4:6], find("día", "inicio"): ini[6:8],
            find("año", "final"): fin[0:4], find("mes", "final"): fin[4:6], find("día", "final"): fin[6:8],
        }.items():
            if num is not None and num not in out:
                out[num] = val
        # Tipo de ejercicio (OBLIGATORIO 1/2/3, error EMALEJER9): 1 = año natural; 2 = 12 meses no natural;
        # 3 = inferior a 12 meses. Se deriva del período (override: datos["tipo_ejercicio"]).
        num_tipo = find("tipo de ejercicio")
        if num_tipo is not None and num_tipo not in out:
            tipo = str(datos.get("tipo_ejercicio") or "").strip()
            if tipo not in ("1", "2", "3"):
                try:
                    di = datetime.date(int(ini[0:4]), int(ini[4:6]), int(ini[6:8]))
                    dfin = datetime.date(int(fin[0:4]), int(fin[4:6]), int(fin[6:8]))
                    if ini[4:8] == "0101" and fin[4:8] == "1231" and ini[0:4] == fin[0:4]:
                        tipo = "1"                                  # año natural
                    else:
                        tipo = "2" if (dfin - di).days >= 364 else "3"   # 12 meses no natural / inferior al año
                except ValueError:
                    tipo = "1"
            out[num_tipo] = tipo
    return out


def _tipo_ejercicio_de_periodo(ini, fin, override=""):
    """Tipo de ejercicio 1/2/3 (1=año natural, 2=12 meses no natural, 3=inferior al año) derivado del período
    AAAAMMDD inicio/fin; `override` ('1'/'2'/'3') lo fuerza."""
    t = str(override or "").strip()
    if t in ("1", "2", "3"):
        return t
    try:
        di = datetime.date(int(ini[0:4]), int(ini[4:6]), int(ini[6:8]))
        df = datetime.date(int(fin[0:4]), int(fin[4:6]), int(fin[6:8]))
        if ini[4:8] == "0101" and fin[4:8] == "1231" and ini[0:4] == fin[0:4]:
            return "1"
        return "2" if (df - di).days >= 364 else "3"
    except ValueError:
        return "1"


def mapear_identificativos_did(dr, datos) -> dict:
    """Identificativos de la página DP200DID (documento de ingreso/devolución): NIF, razón social, ejercicio,
    tipo de ejercicio, período impositivo y la marca de Cuenta Corriente Tributaria ('0'). Sin ellos el
    importador da EMALEJER1 (ejercicio), EMALEJER9 (tipo), DID0090 (período) y DID0060 (CCT). Mismos criterios
    que DP200001 (año natural por defecto). Devuelve {num_campo: valor}; no inventa importes (la liquidación de
    la DID viene de sus casillas)."""
    campos = dr.get("DP200DID", [])

    def find(*kw, excl=()):
        for c in campos:
            d = (c.get("descripcion") or "").lower()
            if all(k in d for k in kw) and not any(e in d for e in excl):
                return c.get("num")
        return None

    out = {}
    n_cct = find("cuenta corriente tributaria")
    if n_cct is not None:
        out[n_cct] = "0"                                   # CCT: no se usa (marca '0', no en blanco)
    n_nif = find("identificación", "nif")
    if n_nif is not None and datos.get("nif"):
        out[n_nif] = datos["nif"]
    n_rs = find("identificación", "apellidos")
    if n_rs is not None and datos.get("razon_social"):
        out[n_rs] = datos["razon_social"]
    ej = str(datos.get("ejercicio") or "").strip()
    if not (ej.isdigit() and len(ej) == 4):
        return out
    n_ej = find("identificación", "ejercicio")
    if n_ej is not None:
        out[n_ej] = ej
    per = datos.get("periodo") or {}

    def _ymd(v, defecto):
        s = re.sub(r"\D", "", str(v or ""))
        return s[:8] if len(s) >= 8 else defecto

    ini, fin = _ymd(per.get("inicio"), f"{ej}0101"), _ymd(per.get("fin"), f"{ej}1231")
    n_per = find("período impositivo", excl=("inicio", "fin"))
    if n_per is not None:
        out[n_per] = "0A"                                  # período impositivo (año natural completo)
    for num, val in {
        find("inicio", "año"): ini[0:4], find("inicio", "mes"): ini[4:6], find("inicio", "día"): ini[6:8],
        find("fin", "año"): fin[0:4], find("fin", "mes"): fin[4:6], find("fin", "día"): fin[6:8],
    }.items():
        if num is not None and num not in out:
            out[num] = val
    n_tipo = find("tipo de ejercicio")
    if n_tipo is not None:
        out[n_tipo] = _tipo_ejercicio_de_periodo(ini, fin, datos.get("tipo_ejercicio"))
    # Importe a ingresar / a devolver: debe COINCIDIR con la cuota a ingresar/devolver 00621 (error EMALID10).
    res = datos.get("resultado")
    if res not in (None, ""):
        try:
            rv = float(str(res).strip().replace(".", "").replace(",", ".") if ("," in str(res) and "." in str(res))
                       else str(res).strip().replace(",", "."))
        except (ValueError, TypeError):
            rv = 0.0
        if rv > 0:
            n_ing = find("importe a ingresar")
            if n_ing is not None:
                out[n_ing] = rv                       # valor numérico ya parseado (emitir_registro→céntimos);
            n_mod = find("modalidad de ingreso")       # 'I' (Ingreso): el blanco es incompatible con tipo 'I'
            if n_mod is not None:                      # de declaración (a ingresar) -> EMALID16.
                out[n_mod] = "I"
        elif rv < 0:                                  # guardar el crudo `res` zerea un importe europeo "1.234,56"
            n_dev = find("importe a devolver")
            if n_dev is not None:
                out[n_dev] = abs(rv)
    return out


# Páginas del marco de entidad NORMAL donde viven las casillas CONTABLES y las de LIQUIDACIÓN. La AEAT
# REUTILIZA los mismos códigos de casilla entre páginas y entre marcos de entidad (Banco de España DP20003x,
# aseguradoras DP20004x, IIC/SGR DP20005x), e incluso entre el ECPN y la liquidación dentro del marco normal
# (revisión adversarial: el código 00547 = compensación BINs en DP200014 y = ECPN en DP200011). Emitir un
# valor a TODA página con ese código escribiría en campos homónimos de OTRO concepto/marco. Por eso se separa
# por ORIGEN del dato: el contable solo va a páginas contables; la liquidación solo a páginas de liquidación.
PAGINAS_CONTABLE = ["DP200003", "DP200004", "DP200005", "DP200006", "DP200007", "DP200008",
                    "DP200009", "DP200010", "DP200011"]
PAGINAS_LIQUIDACION = ["DP200012", "DP200013", "DP200014", "DP200014B", "DP200DID"]

def _blank_zero_casillas_DESACTIVADO(linea: str, campos: list[dict], casillas: set[str]) -> str:
    # NOTA (2026-06-29): blanquear casillas numéricas computadas en el .200 de ancho fijo NO funciona — la AEAT
    # (Sociedades WEB Open) las rechaza como «Caracteres no válidos» (verificado por bytes + reimport real:
    # 02258/00538/00546 salían como 17 espacios y Open las rechazó). El .200 exige CEROS en esas casillas; el
    # bloqueo GF real es de VALOR (02369 = suelo 1M art.16.1), no de serialización. Función conservada solo como
    # referencia histórica; NO se invoca.
    out = list(linea)
    for c in campos or []:
        if c.get("casilla") not in casillas:
            continue
        pos, length = c.get("posicion"), c.get("longitud")
        if not pos or not length:
            continue
        raw = "".join(out[pos - 1:pos - 1 + length])
        if raw and not raw.strip("0 "):
            out[pos - 1:pos - 1 + length] = [" "] * length
    return "".join(out)


def _emitir_en_paginas(dr, paginas, casillas) -> dict:
    """{pagina: linea} para cada página del allowlist `paginas` que tenga alguna `casilla` con valor."""
    con_valor = {k for k, v in (casillas or {}).items() if v not in (None, "")}
    out = {}
    for pag in paginas:
        campos = dr.get(pag)
        if campos and any(c.get("casilla") in con_valor for c in campos):
            out[pag] = emitir_registro(campos, casillas=casillas)
    return out


def construir_declaracion(dr, identificativos=None, contable=None, liquidacion=None, casillas=None,
                          paginas_extra=None, formales=None, caracteres=None, ecpn=None, pagina01b=None,
                          liq_detalle=None, did=None) -> str:
    """Declaración DR de ancho fijo (multi-página, sin separadores). Emite SIEMPRE los identificativos
    (DP200001) + las casillas CONTABLES en sus páginas contables normales (PAGINAS_CONTABLE) + las casillas
    de LIQUIDACIÓN en sus páginas de liquidación (PAGINAS_LIQUIDACION). Separar por ORIGEN evita escribir un
    valor en campos homónimos de otro marco/concepto (los códigos se reutilizan). `casillas` = alias
    retrocompatible de `contable`. `identificativos` = salida de `mapear_identificativos`. NUNCA inventa.

    Si `formales` (dict con administradores/socios/titulares_reales/secretario/representantes) se aporta,
    emite ADEMÁS los DATOS FORMALES (DP200002 apartado A + B.2 socios; DP200002B titular/secretario/
    representante; con registros de continuación 'C') vía `formal200`, para que el `.200` del MOTOR sea
    importable igual que el del replay (cierra los errores 186/187/2827/144/146/153 de Sociedades WEB)."""
    caracteres = _sanear_caracteres(caracteres)   # [A5 FIX D2] flags 0/1, nunca texto (Caracteres no válidos)
    contable = dict(contable or {})
    if casillas:
        contable.update(casillas)                  # alias retrocompatible (contable/general)
    liquidacion = liquidacion or {}
    idmap = identificativos or {}
    lineas = {}
    dp1 = dr.get("DP200001")
    if dp1 is not None:                            # identificativos + caracteres de la declaración + casillas DP1
        # Los CARACTERES (flags ETVE/grupo/matriz… de DP200001) se arrastran del ejercicio anterior y van SOLO
        # en DP200001, no en el bucle de páginas (sus códigos se reutilizan como concepto distinto en otras
        # páginas: p.ej. 00011 = ETVE en DP1 pero deducción Canarias en DP200016B).
        dp1_casillas = {**contable, **(caracteres or {})}
        lineas["DP200001"] = emitir_registro(dp1, casillas=dp1_casillas, campos_pos=idmap)
    if pagina01b and "DP200001B" in dr:               # DP200001B (modelo de estados de cuentas + matriz última +
        # personal) ARRASTRADO del ejercicio anterior por num_campo. Es config estable (capa 1): declara QUÉ
        # modelo de cuentas usa la entidad (Balance/ECPN/PyG = 1 normal/2 abrev/3 PYMES); sin ella el importador
        # rechaza las páginas 3-11 (EMALP311 "debe haber cumplimentado algún estado de cuentas").
        lineas["DP200001B"] = emitir_registro(dr["DP200001B"], campos_pos=pagina01b)
    lineas.update(_emitir_en_paginas(dr, PAGINAS_CONTABLE, contable))
    lineas.update(_emitir_en_paginas(dr, PAGINAS_LIQUIDACION, liquidacion))
    if did and "DP200DID" in dr:                   # [A5 FIX B] DP200DID con cabecera SIEMPRE (ejercicio/tipo/período/
        # CCT/NIF) además de las casillas de liquidación: sin la cabecera el importador da EMALEJER1/9, DID0090,
        # DID0060. `did` = mapear_identificativos_did (campos por num_campo, no pisan las casillas de liq.). Antes
        # solo se re-emitía si la página YA estaba en `lineas` (había liquidación); ahora se emite siempre que haya
        # `did` (que el llamador solo aporta con liquidación), para garantizar la cabecera del DID.
        lineas["DP200DID"] = emitir_registro(dr["DP200DID"], casillas=liquidacion, campos_pos=did)
    if liq_detalle:                                # páginas de DETALLE de la liquidación (BINs DP200015,
        for pg, cas in liq_detalle.items():        # correcciones DP200020B, regímenes DP200026x…) page-keyed:
            if pg in dr and cas:                   # cada una SOLO con sus casillas únicas (sin homónimos de core).
                lineas[pg] = emitir_registro(dr[pg], casillas=cas)
    if formales:                                   # datos formales (DP200002/DP200002B) — capa compartida
        import formal200
        for entry in formal200.formal_page_entries(formales):
            pg = entry["page"]
            if pg in dr:                           # base + continuaciones 'C' se concatenan bajo su tag
                rec = emitir_registro(dr[pg], casillas=entry.get("casillas") or {},
                                      campos_pos=entry.get("campos_pos"))
                lineas[pg] = lineas.get(pg, "") + rec
    if ecpn:                                       # ECPN page-keyed {pagina: {casilla: valor}}; cada página se
        for pg, cas in ecpn.items():               # emite con SUS casillas contables + las del ECPN (evita
            if pg in dr and cas:                   # homónimos: los códigos del ECPN no se vuelcan a otras pág.)
                en_pg = {c["casilla"]: contable[c["casilla"]] for c in dr[pg]
                         if c.get("casilla") in contable}
                lineas[pg] = emitir_registro(dr[pg], casillas={**en_pg, **cas})
    for pag in (paginas_extra or []):             # páginas forzadas (escapatoria explícita)
        if pag in dr and pag not in lineas:
            # [A5 FIX C] SOLO liquidación: no arrastrar casillas CONTABLES homónimas (00312/00324…) a una
            # página de liquidación forzada (la página 13 lleva sus totales de liquidación, no la PyG contable).
            lineas[pag] = emitir_registro(dr[pag], casillas=liquidacion)
    if "DP200020B" in lineas:                       # [A5 K2] DP200020B[00417]/[00418] son SUBTOTALES del cuadro
        # 20BIS que AEAT DERIVA de las subcasillas internas (02301..02308). Con esas subcasillas vacías el subtotal
        # debe ir a 0 (E25400417): no propagar el total de aumentos/disminuciones (homónimo de DP200013[00417]).
        # Se sanea SOLO esta página (DP200013[00417] = total aumentos P&G queda intacto).
        _r2 = lineas["DP200020B"]
        _aum = any(_r2[_p - 1:_p + 16].strip("0 ") for _p in (47, 81, 13, 115))   # 02301/02303/02305/02307
        _dis = any(_r2[_p - 1:_p + 16].strip("0 ") for _p in (64, 98, 30, 132))   # 02302/02304/02306/02308
        if not _aum:
            _r2 = _r2[:148] + "0" * 17 + _r2[165:]                                 # 00417 (pos 149, len 17) -> 0
        if not _dis:
            _r2 = _r2[:165] + "0" * 17 + _r2[182:]                                 # 00418 (pos 166, len 17) -> 0
        lineas["DP200020B"] = _r2
    return "".join(lineas[p] for p in sorted(lineas))


def construir_fichero(dr, ejercicio, identificativos=None, contable=None, liquidacion=None, casillas=None,
                      discriminante="0", periodo="0A", tipo="0000", version_ed="", nif_ed="",
                      formales=None, caracteres=None, ecpn=None, pagina01b=None, liq_detalle=None, did=None,
                      paginas_extra=None) -> str:
    """Fichero COMPLETO de importación de la declaración (envoltorio DP200000 + páginas), según el DR oficial:
        <T200 d EJ per tipo>  <AUX>…</AUX>  [registros de página]  </T200 d EJ per tipo>
    El tag se PARAMETRIZA por ejercicio (la 'constante' del DR es solo el ejemplo 2025). `discriminante`='0'
    (Normal/Abreviado/PYMES); versión/NIF de la EEDD en blanco para una importación no-EEDD. El bloque AUX
    respeta las posiciones del DR (pos 18-328). Contenido = `construir_declaracion` (contable + liquidación
    separados por origen). `casillas` = alias retro de `contable`. Sin XSD: la validez del fichero como TODO
    (envoltorio + ensamblaje) la confirma la importación real en Sociedades WEB."""
    ej = str(ejercicio)
    tag = f"200{discriminante}{ej}{periodo}{tipo}"                # 200 + discr(1) + ejercicio(4) + periodo(2) + tipo(4)
    abre = f"<T{tag}>"                                            # DP200000 campo 1 (len 17)
    cierra = f"</T{tag}>"                                         # DP200000 campo 13 (len 18)
    aux = "<AUX>" + " " * 70 + version_ed[:4].ljust(4) + " " * 4 + nif_ed[:9].ljust(9) + " " * 213 + "</AUX>"
    contenido = construir_declaracion(dr, identificativos=identificativos, contable=contable,
                                      liquidacion=liquidacion, casillas=casillas, formales=formales,
                                      caracteres=caracteres, ecpn=ecpn, pagina01b=pagina01b,
                                      liq_detalle=liq_detalle, did=did, paginas_extra=paginas_extra)
    return abre + aux + contenido + cierra


# ----------------------------------------------------------------- ecosistema de modelos (cableado honesto)
# Casillas del 200 cuya cifra PROCEDE de otro modelo del ecosistema (ver docs/info soporte/ECOSISTEMA_MODELOS_IS.md,
# verificadas casilla-a-casilla contra el DR200). El export NO puede fabricarlas; las MARCA como dependientes para
# no presentar ceros como dato completo (regla dura 5). casilla -> (modelo_origen, concepto).
CASILLAS_OTROS_MODELOS = {
    "00601": ("202", "Pago fraccionado 1P - Estado"),
    "00602": ("202", "Pago fraccionado 1P - D. Forales/Navarra"),
    "00603": ("202", "Pago fraccionado 2P - Estado"),
    "00604": ("202", "Pago fraccionado 2P - D. Forales/Navarra"),
    "00605": ("202", "Pago fraccionado 3P - Estado"),
    "00606": ("202", "Pago fraccionado 3P - D. Forales/Navarra"),
    "00004": ("242", "Correcciones por Impuesto Complementario (Pillar Two) — DP200012"),
    "01766": ("216/210", "Total retenciones e ingresos a cuenta - Efectuados a la entidad"),
    "01784": ("216/210", "Total retenciones e ingresos a cuenta - Imputados por AIEs y UTEs"),
}


def _tiene_valor(v) -> bool:
    """True si v es un importe no vacío y no cero (un 0 o vacío = casilla SIN rellenar)."""
    if v in (None, ""):
        return False
    try:
        return Decimal(str(v)) != 0
    except (InvalidOperation, ValueError, TypeError):
        return bool(str(v).strip())


def casillas_dependientes(casillas=None) -> list:
    """Para las casillas del 200 que dependen de otro modelo (CASILLAS_OTROS_MODELOS), informa si están
    rellenas en `casillas` {codigo: valor} o PENDIENTES. NUNCA inventa: solo informa de la dependencia."""
    casillas = casillas or {}
    return [{"casilla": cod, "modelo": modelo, "concepto": concepto,
             "presente": _tiene_valor(casillas.get(cod))}
            for cod, (modelo, concepto) in CASILLAS_OTROS_MODELOS.items()]


if __name__ == "__main__":
    dr = cargar_dr()
    print(f"DR cargado: {len(dr)} páginas · {sum(len(v) for v in dr.values())} campos")
    for p in ("DP200001", "DP200012", "DP200014B"):
        print(f"  {p}: {len(dr.get(p, []))} campos")
