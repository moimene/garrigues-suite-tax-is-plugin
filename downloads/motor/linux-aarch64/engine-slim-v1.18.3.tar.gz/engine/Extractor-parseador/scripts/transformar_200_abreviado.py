"""Transforma un .200 emitido como BALANCE NORMAL en uno con estados contables ABREVIADO (o PYMES),
por EDICIÓN IN-PLACE byte-precisa (no re-emisión): solo toca las casillas de estados contables que cambian
y los flags DP200001B 14/15/16; todo lo demás queda byte-idéntico (no perturba lo que ya importa limpio).

Mecánica del .200 (DR de ancho fijo, sin XSD): cada página es un registro que EMPIEZA por su tag-constante
`<T200NN000>`; una casilla X de la página P está en file[offset(tag_P) + (pos_X-1) : ...+len_X].

Reglas de proyección abreviado (catálogo+rollups de cap04, certificadas en Open):
  - REMOVE: casillas (N)-only presentes → a ceros.
  - ROLLUP: cada casilla-agregado abreviado (A-sin-N: «Resto»/«Otros…») = suma de sus fuentes (N)-only.
  - Flags: DP200001B campos 14/15/16 (pos 156/157/158) = 2 (abreviado) / 3 (PYMES).
  - El resto (subtotales (N,A,P) emitibles, totales) se conserva.

Determinista, 0 PII (opera sobre bytes; nunca imprime importes).
"""
from __future__ import annotations

import re
import sys
from decimal import Decimal, ROUND_HALF_UP
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
import dr200  # noqa: E402

TAG_RE = re.compile(r"<(T[0-9A-Z]{2,14})>")


def _tag_de_pagina(page: str) -> str:
    code = page[5:]  # tras "DP200"
    if code.startswith("0"):
        code = code[1:]
    return "T200" + code.ljust(5, "0")


def localizar_registros(doc: str) -> dict[str, tuple[int, int]]:
    """{pagina: (inicio, fin)} de cada registro de página en el fichero (inicio = posición del '<' del tag)."""
    hits = [(m.start(), m.group(1)) for m in TAG_RE.finditer(doc)]
    # mapa tag->pagina invirtiendo la derivación sobre las páginas del DR
    spans = {}
    for i, (start, tag) in enumerate(hits):
        end = hits[i + 1][0] if i + 1 < len(hits) else len(doc)
        spans.setdefault(tag, (start, end))
    return spans


class Declaracion200:
    def __init__(self, path: str, ejercicio: str = "2025"):
        self.path = path
        self.ejercicio = str(ejercicio)
        self.doc = Path(path).read_text(encoding="latin-1")
        self.buf = list(self.doc)
        self.dr = dr200.cargar_dr(ejercicio=self.ejercicio)
        self._spans = localizar_registros(self.doc)
        self._tag2page = {_tag_de_pagina(p): p for p in self.dr}

    def _page_span(self, page: str):
        return self._spans.get(_tag_de_pagina(page))

    def _campo_casilla(self, page: str, casilla: str):
        for c in self.dr.get(page, []):
            if c.get("casilla") == casilla and c.get("posicion") and c.get("longitud"):
                return c
        return None

    def _campo_num(self, page: str, num: int):
        for c in self.dr.get(page, []):
            if c.get("num") == num and c.get("posicion") and c.get("longitud"):
                return c
        return None

    def leer_casilla(self, page: str, casilla: str):
        span = self._page_span(page)
        c = self._campo_casilla(page, casilla)
        if not span or not c:
            return None
        ini = span[0] + c["posicion"] - 1
        raw = "".join(self.buf[ini:ini + c["longitud"]])
        return raw

    def leer_importe(self, page: str, casilla: str):
        raw = self.leer_casilla(page, casilla)
        if raw is None:
            return None
        s = raw.strip()
        dig = re.sub(r"\D", "", s)
        if not dig:
            return Decimal(0)
        val = Decimal(dig) / 100
        return -val if "N" in s.upper() else val

    def _escribir_en(self, ini: int, s: str):
        for i, ch in enumerate(s):
            self.buf[ini + i] = ch

    def escribir_importe(self, page: str, casilla: str, val) -> bool:
        span = self._page_span(page)
        c = self._campo_casilla(page, casilla)
        if not span or not c:
            return False
        length = c["longitud"]
        s = dr200.fmt_importe_dr(val, length)
        self._escribir_en(span[0] + c["posicion"] - 1, s)
        return True

    def poner_a_cero(self, page: str, casilla: str) -> bool:
        c = self._campo_casilla(page, casilla)
        if not c:
            return False
        return self.escribir_importe(page, casilla, 0)

    def escribir_flag_num(self, page: str, num: int, valor: str) -> bool:
        span = self._page_span(page)
        c = self._campo_num(page, num)
        if not span or not c:
            return False
        self._escribir_en(span[0] + c["posicion"] - 1, valor[:c["longitud"]].rjust(c["longitud"], "0"))
        return True

    def presentes(self, page: str) -> list[str]:
        """Casillas de la página con valor != 0/vacío."""
        out = []
        for c in self.dr.get(page, []):
            cas = c.get("casilla")
            if cas:
                v = self.leer_importe(page, cas)
                if v not in (None, Decimal(0)):
                    out.append(cas)
        return out

    def guardar(self, out_path: str):
        Path(out_path).write_text("".join(self.buf), encoding="latin-1")


DATA = Path(__file__).resolve().parents[1] / "data/campaigns/2025"
CAMPO_DP1B = {"balance": 14, "ecpn": 15, "pyg": 16}
CODIGO_PERFIL = {"abreviado": "2", "pymes": "3", "normal": "1"}


def cargar_catalogo():
    import json
    return json.loads((DATA / "estados_contables_perfiles.json").read_text(encoding="utf-8"))


def cargar_xsd_importables(ejercicio="2025") -> dict:
    """{DP200NN: set(casillas importables)} desde el XSD oficial (tipo_PaginaNN). Las casillas del DR que NO
    están en el XSD son CALCULADAS por Open (no importables). Autoridad de emitible vs calculada."""
    xsd = (DATA / f"mod200{ejercicio}_normal.xsd").read_text(encoding="utf-8")
    pg2dp = {"03": "DP200003", "04": "DP200004", "05": "DP200005", "06": "DP200006",
             "07": "DP200007", "08": "DP200008", "09": "DP200009", "10": "DP200010", "11": "DP200011"}
    out = {}
    for pg, dp in pg2dp.items():
        m = re.search(r'tipo_Pagina%s">(.*?)</xs:complexType>' % pg, xsd, re.S)
        out[dp] = set(re.findall(r'name="T(\d{5})"', m.group(1))) if m else set()
    return out


def cargar_rollups():
    import json
    return json.loads((DATA / "estados_contables_rollups.json").read_text(encoding="utf-8"))


def _casilla_pagina(dr) -> dict:
    idx = {}
    for pag, campos in dr.items():
        for c in campos:
            cas = c.get("casilla")
            if cas and cas not in idx:
                idx[cas] = pag
    return idx


def proyectar(decl: "Declaracion200", perfil: str = "abreviado", familias=("balance",),
              catalogo=None, rollups=None) -> dict:
    """Proyecta el .200 (cargado) al perfil dado para las familias indicadas. Devuelve un informe.
    Lee TODOS los importes fuente ANTES de escribir (evita corromper sumas)."""
    catalogo = catalogo or cargar_catalogo()
    rollups = rollups or cargar_rollups()
    cas2pag = _casilla_pagina(decl.dr)
    cat = catalogo["casillas"]
    rolls = (rollups.get("targets", {}).get(perfil, {}))
    xsd = cargar_xsd_importables(decl.ejercicio)
    letra = {"abreviado": "A", "pymes": "P"}[perfil]
    informe = {"perfil": perfil, "familias": list(familias), "removidas": [], "targets": [],
               "perdidas": [], "flags": {}, "avisos": []}

    fam_paginas = set()
    for fam in familias:
        fam_paginas |= set(catalogo.get("familias", {}).get(fam, {}).get("paginas", []))

    targets = {t: r for fam in familias for t, r in rolls.get(fam, {}).items()}
    fuentes_rollup = {s for r in targets.values() for s in r.get("from", [])}
    calc = rollups.get("calculada_en_abreviado", {})
    calc_set = {c for fam in familias for c in calc.get(fam, [])}
    if perfil == "pymes":   # PYMES recompone subtotales que abreviado emite (p.ej. 00202 -> 00208 vía detalle)
        calcp = rollups.get("calculada_en_pymes", {})
        calc_set |= {c for fam in familias for c in calcp.get(fam, [])}

    def importable_abreviado(cas):
        if cas in fuentes_rollup:
            return False                       # una fuente SIEMPRE colapsa (no se emite tal cual)
        if cas in calc_set:
            return False                       # subtotal/celda calculada por Open en abreviado (no importable)
        if cas in targets:
            return True                        # un target declarado es emitible-en-abreviado por el mapa
        pag = cas2pag.get(cas)
        return (pag in xsd and cas in xsd[pag] and letra in cat.get(cas, {}).get("modelos", []))

    # 1) leer importes presentes de la familia (todas las casillas del DR en esas páginas) ANTES de escribir
    presente = {}
    for cas in cat:
        pag = cas2pag.get(cas)
        if pag in fam_paginas and decl._page_span(pag):
            v = decl.leer_importe(pag, cas)
            if v not in (None, Decimal(0)):
                presente[cas] = v

    # 2) ESCRIBIR: poner a cero todo lo presente que NO sea importable-en-abreviado (fuentes, N-only, calculadas)
    for cas in list(presente):
        if not importable_abreviado(cas):
            pag = cas2pag.get(cas)
            if decl.poner_a_cero(pag, cas):
                informe["removidas"].append(cas)

    # 3) targets: dos comportamientos según 'op':
    #    - 'propio_o_suma' (carrier-LEAF, p.ej. 00111): la casilla YA retiene el total de su detalle ->
    #      valor = ORIGINAL si presente, si no la SUMA del detalle (evita doble conteo).
    #    - 'suma'/'absorbe' (Resto o carrier GENÉRICO, p.ej. 00193): valor = ORIGINAL (su importe propio) +
    #      SUMA de los pares colapsados (un Resto está ausente -> original 0 -> = suma).
    #    Las fuentes ya están a cero; `presente` se leyó ANTES de tocar nada.
    for target, regla in targets.items():
        pag = cas2pag.get(target)
        if not pag:
            informe["avisos"].append(f"target {target} sin página DR")
            continue
        orig = presente.get(target) or Decimal(0)
        suma = sum((presente.get(s) or Decimal(0)) for s in regla.get("from", []))
        op = regla.get("op", "suma")
        if op == "propio_o_suma":
            val = orig if orig != 0 else suma
        else:
            val = orig + suma
        if val and val != 0:
            if decl.escribir_importe(pag, target, val):
                informe["targets"].append({"casilla": target, "op": op,
                                           "via": "propio" if (op == "propio_o_suma" and orig != 0) else "suma"})
            else:
                informe["avisos"].append(f"target {target} sin campo DR")

    # 4) flags DP200001B
    for fam in familias:
        num = CAMPO_DP1B[fam]
        if decl.escribir_flag_num("DP200001B", num, CODIGO_PERFIL[perfil]):
            informe["flags"][f"campo{num}_{fam}"] = CODIGO_PERFIL[perfil]
        else:
            informe["avisos"].append(f"no se pudo escribir flag {num} ({fam})")

    # 5) ECPN VOLUNTARIO en abreviado/PYMES: si NO se pidió la familia `ecpn`, OMITIRLO LIMPIO — poner a cero
    # DP200009/10/11 (no arrastrar el ECPN NORMAL de la fuente, que daría mismatch en Open) y declarar el modelo
    # ECPN = 0 ("no consta"). El ECPN solo se emite cuando se pide explícitamente (familias incluye 'ecpn').
    if "ecpn" not in familias:
        ecpn_pags = ["DP200009", "DP200010", "DP200011"]
        ecpn_cas = [c for c in cat if cas2pag.get(c) in ecpn_pags]
        for c in ecpn_cas:
            pag = cas2pag.get(c)
            if decl._page_span(pag) and (decl.leer_importe(pag, c) or Decimal(0)) != Decimal(0):
                if decl.poner_a_cero(pag, c):
                    informe["removidas"].append(c)
        if decl.escribir_flag_num("DP200001B", CAMPO_DP1B["ecpn"], "0"):
            informe["flags"]["campo15_ecpn"] = "0"
    return informe


if __name__ == "__main__":
    import argparse
    import json
    ap = argparse.ArgumentParser()
    ap.add_argument("path")
    ap.add_argument("--ejercicio", default="2025")
    ap.add_argument("--dump-estados", action="store_true")
    ap.add_argument("--proyectar", choices=["abreviado", "pymes"])
    ap.add_argument("--familias", default="balance", help="coma-separado: balance,pyg,ecpn")
    ap.add_argument("--out")
    a = ap.parse_args()
    d = Declaracion200(a.path, ejercicio=a.ejercicio)
    if a.proyectar:
        fams = tuple(x.strip() for x in a.familias.split(",") if x.strip())
        inf = proyectar(d, perfil=a.proyectar, familias=fams)
        out = a.out or (a.path.rsplit(".", 1)[0] + f"_{a.proyectar}.200")
        d.guardar(out)
        print(json.dumps(inf, ensure_ascii=False, indent=1))
        print("→", out)
        raise SystemExit(0)
    if a.dump_estados:
        for pg in ("DP200003", "DP200004", "DP200005", "DP200006", "DP200007", "DP200008",
                   "DP200009", "DP200010", "DP200011"):
            span = d._page_span(pg)
            pres = d.presentes(pg) if span else []
            print(f"{pg}: {'PRESENTE' if span else 'AUSENTE':9} casillas!=0: {pres}")
        # flags 14/15/16
        for n in (14, 15, 16):
            span = d._page_span("DP200001B")
            c = d._campo_num("DP200001B", n)
            if span and c:
                raw = "".join(d.buf[span[0] + c["posicion"] - 1: span[0] + c["posicion"] - 1 + c["longitud"]])
                print(f"  DP200001B campo {n} (pos {c['posicion']}): {raw!r}")
