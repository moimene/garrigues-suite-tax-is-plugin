export const meta = {
  name: 'rollups-abreviado-estados-200',
  description: 'Construye y verifica el mapa completo hoja->casilla-importable-abreviado (balance/PyG/ECPN) del Modelo 200, reconciliado contra entidades reales y verificado adversarialmente',
  phases: [
    { title: 'Author', detail: 'un agente por familia: balance/pyg/ecpn autoriza el mapa y auto-reconcilia' },
    { title: 'Verify', detail: 'skeptics cruzan cada mapa contra cap04+XSD y reconciliación' },
    { title: 'Synthesize', detail: 'fusiona en JSON final + informe' },
  ],
}

const REPO = '/Users/moisesmenendez/Dropbox/DESARROLLO/is200transmittalAPP'
const ENTIDADES = [
  `${REPO}/suite-tax-is-plugin/EXPEDIENTES IS TOTALES/REDEVCO/RRE/salida/RRE_2025_modelo200.200`,
  `${REPO}/suite-tax-is-plugin/EXPEDIENTES IS TOTALES/HOSPITALITY (4)/REDEVCO HOSPITALITY/salida/RHVS_2025_modelo200.200`,
  `${REPO}/suite-tax-is-plugin/EXPEDIENTES IS TOTALES/HOSPITALITY (4)/NEXTSTAY BILBAO/salida/NSBILBAO_2025_modelo200.200`,
  `${REPO}/suite-tax-is-plugin/EXPEDIENTES IS TOTALES/HOSPITALITY (4)/NEXTSTAY MALAGA/salida/NSMALAGA_2025_modelo200.200`,
  `${REPO}/suite-tax-is-plugin/EXPEDIENTES IS TOTALES/HOSPITALITY (4)/NEXTSTAY SEVILLA/salida/NSSEVILLA_2025_modelo200.200`,
]

const FAMILIAS = [
  { key: 'balance', paginas: ['DP200003', 'DP200004', 'DP200005', 'DP200006'],
    seccion: 'Balance activo (cap04 ~lin 34-300) y PN+pasivo (~301-677)', totales: '00180 (TOTAL ACTIVO) y 00252 (TOTAL PN+PASIVO), que deben ser iguales' },
  { key: 'pyg', paginas: ['DP200007', 'DP200008'],
    seccion: 'Cuenta de PyG (cap04 ~lin 678-1104)', totales: '00500 (RESULTADO DE LA CUENTA DE PyG)' },
  { key: 'ecpn', paginas: ['DP200009', 'DP200010', 'DP200011'],
    seccion: 'Estado de cambios en el PN (cap04 ~lin 1105-1518)', totales: 'columnas del ECPN; reconcilia PN inicial/final con balance' },
]

const COMUN = `Repo: ${REPO}. Eres experto en el Modelo 200 (Impuesto sobre Sociedades) español y en el modelo ABREVIADO de cuentas anuales (PGC, NECA).

OBJETIVO: el motor convierte un .200 emitido como balance NORMAL (detalle máximo) en ABREVIADO. En abreviado solo existen las casillas marcadas (A) en el Manual y que el XSD lista como importables; las demás (N-only y subtotales calculados) NO se emiten. Cada IMPORTE de una hoja del .200 normal debe acabar en EXACTAMENTE UNA casilla importable-en-abreviado (la suya si lo es, o la casilla agregada "Resto/Otros..." o el subtotal-importable de su grupo). Si un importe no tiene destino, se PIERDE y el balance abreviado descuadra -> Open lo rechaza ("se ha calculado X").

FUENTES AUTORITATIVAS (léelas):
1. XSD: Extractor-parseador/data/campaigns/2025/mod2002025_normal.xsd — cada tipo_PaginaNN lista los <xs:element name="T#####"> IMPORTABLES de esa página. Las casillas del DR que NO están en el XSD son CALCULADAS por Open. IGNORA páginas 27-54 (entidades de crédito/seguros/IIC/SGR, fuera de alcance).
2. Manual cap04: suite-is/Manual_Sociedades_2025_md/04_Cap04_Estados_contables_modelo_200.md — marca cada casilla [00XXX] con (N)/(A)/(P) y trae fórmulas de agregación embebidas (p.ej. "[00136] [00137]+[00138]+[00149]+..."). El parser ya hecho: Extractor-parseador/scripts/extraer_perfiles_cap04.py (función parse_cap04()).
3. Catálogo de marcadores ya generado: Extractor-parseador/data/campaigns/2025/estados_contables_perfiles.json (campo modelos por casilla).
4. DR posiciones: Extractor-parseador/scripts/dr200.py (cargar_dr).
5. Lector de .200: Extractor-parseador/scripts/transformar_200_abreviado.py — clase Declaracion200(path).presentes(pagina) y .leer_importe(pagina,casilla); cargar_xsd_importables().

ENTIDADES REALES para reconciliar (datos de cliente, locales; NO copies importes a la salida, solo úsalos para verificar): ${ENTIDADES.map(e => `"${e}"`).join(', ')}.

REGLA DE PROYECCIÓN: para cada casilla importable-en-abreviado T (XSD ∩ marcador A), define sus 'fuentes' = el conjunto de casillas del .200 normal cuyo importe colapsa en T en abreviado. Una casilla normal mapea a T si T es el agregado abreviado de su grupo (el "Resto/Otros..." A-sin-N, o el subtotal importable-en-abreviado que retiene el detalle). Las casillas importable-en-abreviado que aparecen tal cual mapean a sí mismas (identidad, no hace falta listarlas).

RECONCILIACIÓN (gate duro): para CADA entidad, tras aplicar tu mapa, la suma de los importes de las casillas importable-en-abreviado de ACTIVO debe igualar 00180 original (y PN+PASIVO = 00252), al céntimo. Si no cuadra, hay hojas sin destino: localízalas (casilla presente, no importable-abreviado, sin fuente asignada, cuyo subtotal-padre tampoco está presente) y corrige el mapa. Usa Python con los módulos de arriba para CALCULAR la reconciliación numéricamente (no a ojo).`

const SCHEMA = {
  type: 'object', additionalProperties: false,
  required: ['familia', 'targets', 'reconciliacion', 'hojas_sin_destino', 'notas'],
  properties: {
    familia: { type: 'string' },
    targets: { type: 'object', description: 'casilla_importable_abreviado -> {from:[casillas_normal], parent, comentario}',
      additionalProperties: { type: 'object', additionalProperties: true,
        required: ['from'], properties: { from: { type: 'array', items: { type: 'string' } }, parent: { type: 'string' }, comentario: { type: 'string' } } } },
    reconciliacion: { type: 'object', description: 'entidad_codename -> {activo_ok:bool, pasivo_ok:bool, diff_centimos:int}',
      additionalProperties: true },
    hojas_sin_destino: { type: 'array', items: { type: 'string' }, description: 'casillas presentes en alguna entidad sin destino importable (deben ser [] al cerrar)' },
    notas: { type: 'string' },
  },
}

const VSCHEMA = {
  type: 'object', additionalProperties: false,
  required: ['familia', 'errores', 'veredicto'],
  properties: {
    familia: { type: 'string' },
    errores: { type: 'array', items: { type: 'object', additionalProperties: true,
      required: ['casillas', 'problema', 'fix', 'confianza'],
      properties: { casillas: { type: 'array', items: { type: 'string' } }, problema: { type: 'string' }, fix: { type: 'string' }, confianza: { type: 'string' } } } },
    veredicto: { type: 'string', enum: ['OK', 'CORREGIR'] },
  },
}

phase('Author')
const resultados = await pipeline(
  FAMILIAS,
  (fam) => agent(
    `${COMUN}\n\nTU FAMILIA: ${fam.key} (${fam.seccion}). Páginas DR: ${fam.paginas.join(', ')}. Totales de reconciliación: ${fam.totales}.\nConstruye el mapa COMPLETO de targets y AUTO-RECONCILIA numéricamente contra las 5 entidades iterando hasta que hojas_sin_destino quede vacío (o documenta por qué una hoja no reconcilia). Devuelve el schema.`,
    { label: `author:${fam.key}`, phase: 'Author', schema: SCHEMA, effort: 'high' }
  ),
  // verificación adversarial inmediata por familia (2 lentes), en cuanto su autor termina
  (mapa, fam) => parallel([
    () => agent(`${COMUN}\n\nFAMILIA ${fam.key}. REVISA ADVERSARIALMENTE este mapa propuesto (intenta REFUTARLO): ${JSON.stringify(mapa.targets)}.\nLente CAP04: para cada target y cada fuente, verifica contra el Manual cap04 (cita líneas) que la fuente es realmente (N)-only o calculada y pertenece al grupo del target; que ningún superviviente (N,A,P importable) se metió como fuente; que el target es importable-en-abreviado (XSD ∩ A). Lista errores con fix y confianza.`,
      { label: `verify:cap04:${fam.key}`, phase: 'Verify', schema: VSCHEMA, effort: 'high' }),
    () => agent(`${COMUN}\n\nFAMILIA ${fam.key}. REVISA ADVERSARIALMENTE este mapa (intenta romper la RECONCILIACIÓN): ${JSON.stringify(mapa.targets)}.\nLente RECONCILIACIÓN: ejecuta Python con las 5 entidades; comprueba al céntimo que tras el mapa el total reconcilia, y BUSCA hojas presentes sin destino (casilla con valor, no importable-abreviado, no en ningún 'from', cuyo subtotal-padre importable tampoco esté presente). Reporta cualquier descuadre con la casilla y el delta. Lista errores con fix y confianza.`,
      { label: `verify:recon:${fam.key}`, phase: 'Verify', schema: VSCHEMA, effort: 'high' }),
  ]).then(vs => ({ familia: fam.key, mapa, verificaciones: vs.filter(Boolean) }))
)

phase('Synthesize')
const limpio = resultados.filter(Boolean)
const sintesis = await agent(
  `${COMUN}\n\nSÍNTESIS FINAL. Tienes, por familia, el mapa propuesto y sus verificaciones adversariales:\n${JSON.stringify(limpio).slice(0, 60000)}\n\nProduce el JSON final consolidado estados_contables_rollups.json con estructura {ejercicio:"2025", version, base:"normal", targets:{abreviado:{balance:{...}, pyg:{...}, ecpn:{...}}}, calculada_en_abreviado:{balance:[...],pyg:[...],ecpn:[...]}}. APLICA los fixes de las verificaciones con confianza alta/media. En 'notas' resume qué quedó sin reconciliar y los riesgos para Open. Devuelve SOLO el JSON (sin importes de cliente).`,
  { label: 'synthesize', phase: 'Synthesize', effort: 'high' }
)

return { sintesis, porFamilia: limpio.map(r => ({ familia: r.familia, recon: r.mapa.reconciliacion, sinDestino: r.mapa.hojas_sin_destino, verds: r.verificaciones.map(v => v.veredicto) })) }
