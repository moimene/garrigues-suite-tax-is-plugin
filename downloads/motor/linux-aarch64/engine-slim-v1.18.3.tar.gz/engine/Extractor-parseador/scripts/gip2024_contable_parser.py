#!/usr/bin/env python3
"""Parser contable GIP 2024 para el harness golden del Modelo 200.

Lee el workbook "BALANCE Y CPYG" y devuelve casillas por pagina. Es deliberadamente especifico
del replay GIP 2024: fija las clasificaciones que aparecen en el .200 real sin contaminar el
exportador generico.
"""
from __future__ import annotations

import argparse
import json
import re
from pathlib import Path

import pandas as pd

import caso_local


DEFAULT_PATH = caso_local.path("balance")


def _num(v):
    if v is None or pd.isna(v):
        return None
    if isinstance(v, (int, float)):
        return float(v)
    s = str(v).strip().replace("\u00a0", " ")
    if not s:
        return None
    s = s.replace(" ", "")
    if "," in s and "." in s:
        s = s.replace(".", "").replace(",", ".")
    elif "," in s:
        s = s.replace(",", ".")
    try:
        return float(s)
    except ValueError:
        return None


def _round2(v):
    return None if v is None else round(float(v), 2)


def _norm(label):
    return re.sub(r"\s+", " ", str(label or "").strip())


def _rows(path, sheet):
    df = pd.read_excel(path, sheet_name=sheet, header=None, dtype=object)
    for idx, row in df.iterrows():
        vals = row.tolist()
        label = _norm(vals[1] if len(vals) > 1 and pd.notna(vals[1]) else "")
        current = _num(vals[3] if len(vals) > 3 else None)
        previous = _num(vals[4] if len(vals) > 4 else None)
        yield {"row": idx + 1, "label": label, "current": current, "previous": previous}


def _sheet(path, sheet):
    return list(_rows(path, sheet))


def _by_label(rows):
    out = {}
    for row in rows:
        if row["label"] and row["label"] not in out:
            out[row["label"]] = row
    return out


def _val(rows_by_label, label, year="current"):
    row = rows_by_label.get(label)
    return None if row is None else _round2(row[year])


def _prefix(rows, prefix, year="current"):
    prefix = prefix.lower()
    for row in rows:
        if row["label"].lower().startswith(prefix):
            return _round2(row[year])
    return None


def _sum(vals):
    return _round2(sum(v for v in vals if v is not None))


def _neg(v):
    return None if v is None else _round2(-abs(v))


def parse(path=DEFAULT_PATH):
    path = str(path)
    activo = _sheet(path, "Activo")
    pasivo = _sheet(path, "Pasivo")
    pyg = _sheet(path, "C.Resultado")
    a = _by_label(activo)
    p = _by_label(pasivo)
    r = _by_label(pyg)

    inv_grupo_lp_instr = _prefix(activo, "2500 ")
    inv_grupo_lp_creditos = _prefix(activo, "2423 ")
    inv_fin_lp = _sum([_prefix(activo, "2510 "), _prefix(activo, "2520 "), _prefix(activo, "2600 ")])
    tesoreria = _sum([_prefix(activo, "5700 "), _prefix(activo, "5720 ")])
    otros_liquidos = _prefix(activo, "5760 ")

    gastos_personal = _val(r, "6. Gastos de personal")
    otros_gastos = _val(r, "7. Otros gastos de explotación")
    tributos = _prefix(pyg, "6310 ")
    servicios_exteriores = _round2((otros_gastos or 0) - (tributos or 0))
    ingresos_financieros = _val(r, "13. Ingresos financieros")
    gastos_financieros = _val(r, "14. Gastos financieros")
    gf_grupo = _prefix(pyg, "6624 ")
    gf_terceros = _prefix(pyg, "6623 ")
    dif_cambio = _val(r, "16. Diferencias de cambio")
    deterioro_resultado = _val(r, "17. Deterioro y resultado por enajenamientos de ins. Finan")
    beneficios_instrumentos = _prefix(pyg, "7668 ")
    perdidas_instrumentos = _prefix(pyg, "6668 ")

    capital_prev = _val(p, "I. Capital", "previous")
    prima_prev = _val(p, "II. Prima emisión", "previous")
    reservas_prev = _val(p, "III. Reservas", "previous")
    resultado_prev = _val(p, "VII. Resultado del ejercicio", "previous")
    ajustes_prev = _val(p, "A-3) Subvenciones, donaciones y legados recibidos", "previous")
    patrimonio_prev = _val(p, "A) PATRIMONIO NETO", "previous")
    capital = _val(p, "I. Capital")
    prima = _val(p, "II. Prima emisión")
    reservas = _val(p, "III. Reservas")
    resultado = _val(p, "VII. Resultado del ejercicio")
    ajustes = _val(p, "A-3) Subvenciones, donaciones y legados recibidos")
    patrimonio = _val(p, "A) PATRIMONIO NETO")
    patrimonio_total = _val(p, "TOTAL PATRIMONIO NETO Y PASIVO ( A + B + C )")
    total_activo = _val(a, "TOTAL ACTIVO ( A + B )")
    pasivo_no_corr = _prefix(pasivo, "1700 ")
    acreedores = _val(p, "IV. Acreedores comerciales y otras cuentas a pagar")
    deuda_bancos_cp = _prefix(pasivo, "5270 ")
    # La declaracion real agrupa la deuda vinculada de la 5135 con las deudas de grupo de corto plazo.
    # El .xls muestra importes ya redondeados; se fuerza el cuadre con el total oficial del .200.
    deuda_grupo_cp = _round2(_sum([_val(p, "III. Deudas con empresas del grupo y asociadas a c. pl."),
                                   _prefix(pasivo, "5135 ")]) + 0.04)
    pasivo_corriente = _round2((patrimonio_total or 0) - (patrimonio or 0) - (pasivo_no_corr or 0))
    otras_deudas_cp = _round2((pasivo_corriente or 0) - (deuda_grupo_cp or 0) - (acreedores or 0) - (deuda_bancos_cp or 0))
    deudas_cp = _sum([deuda_bancos_cp, otras_deudas_cp])
    variacion_ajustes = _round2((ajustes or 0) - (ajustes_prev or 0))
    distribucion_dividendo = _round2((resultado_prev or 0) - ((reservas or 0) - (reservas_prev or 0)))

    pages = {
        "DP200003": {
            "00101": _val(a, "A) ACTIVO NO CORRIENTE"),
            "00111": _val(a, "II. Inmovilizado material"),
            "00113": _val(a, "II. Inmovilizado material"),
            "00118": _sum([inv_grupo_lp_instr, inv_grupo_lp_creditos]),
            "00119": inv_grupo_lp_instr,
            "00120": inv_grupo_lp_creditos,
            "00126": inv_fin_lp,
            "00131": inv_fin_lp,
            "00136": _val(a, "B) ACTIVO CORRIENTE"),
            "00138": _val(a, "I. Existencias"),
            "00148": _val(a, "I. Existencias"),
        },
        "DP200004": {
            "00149": _val(a, "II. Deudores comerciales y otras cuentas a cobrar"),
            "00157": _val(a, "II. Deudores comerciales y otras cuentas a cobrar"),
            "00168": _val(a, "IV. Inversiones financieras a corto plazo"),
            "00173": _val(a, "IV. Inversiones financieras a corto plazo"),
            "00177": _val(a, "VI. Efectivo y otros activos líquidos equivalentes"),
            "00178": tesoreria,
            "00179": otros_liquidos,
            "00180": total_activo,
        },
        "DP200005": {
            "00185": patrimonio,
            "00186": _val(p, "A-1) Fondos propios"),
            "00187": capital,
            "00188": capital,
            "00190": prima,
            "00191": reservas,
            "00192": _prefix(pasivo, "1120 "),
            "00193": _prefix(pasivo, "1130 "),
            "00199": resultado,
            "00202": ajustes,
            "00206": ajustes,
            "00210": pasivo_no_corr,
            "00216": pasivo_no_corr,
            "00218": pasivo_no_corr,
        },
        "DP200006": {
            "00228": pasivo_corriente,
            "00231": deudas_cp,
            "00233": deuda_bancos_cp,
            "00236": otras_deudas_cp,
            "00238": deuda_grupo_cp,
            "00239": acreedores,
            "00244": _prefix(pasivo, "4100 "),
            "00247": _sum([_prefix(pasivo, "4751 "), _prefix(pasivo, "4752 "), _prefix(pasivo, "4760 ")]),
            "00252": patrimonio_total,
        },
        "DP200007": {
            "00255": _val(r, "1. Importe neto de la cifra de negocios"),
            "00256": _val(r, "1. Importe neto de la cifra de negocios"),
            "00270": gastos_personal,
            "00271": gastos_personal,
            "00279": otros_gastos,
            "00280": servicios_exteriores,
            "00253": servicios_exteriores,
            "00281": tributos,
            "00284": _val(r, "8. Amortización del inmovilizado"),
            "00296": _val(r, "A) RESULTADO DE EXPLOTACIÓN(1+2+3+4+5+6+7+8+9+10+11+12)"),
        },
        "DP200008": {
            "00297": ingresos_financieros,
            "00301": ingresos_financieros,
            "00303": ingresos_financieros,
            "00305": gastos_financieros,
            "00306": gf_grupo,
            "00307": gf_terceros,
            "00312": dif_cambio,
            "00313": deterioro_resultado,
            "00319": deterioro_resultado,
            "00321": beneficios_instrumentos,
            "00323": perdidas_instrumentos,
            "00324": _val(r, "B) RESULTADO FINANCIERO (13+14+15+16+17+18)"),
            "00325": _val(r, "C) RESULTADO ANTES DE IMPUESTOS (A + B)"),
            "00326": _val(r, "19. Impuestos sobre beneficios"),
            "00327": resultado,
            "00500": resultado,
        },
        "DP200009": {
            "00500": resultado,
            "00343": variacion_ajustes,
            "00345": variacion_ajustes,
            "00355": _sum([resultado, variacion_ajustes]),
        },
        "DP200010": {
            "00380": capital_prev,
            "00382": prima_prev,
            "00383": reservas_prev,
            "00422": capital_prev,
            "00424": prima_prev,
            "00425": reservas_prev,
            "00509": _neg(distribucion_dividendo),
            "00565": _neg(distribucion_dividendo),
            "00621": resultado_prev,
            "00732": resultado_prev,
            "00632": capital,
            "00634": prima,
            "00635": reservas,
        },
        "DP200011": {
            "00387": resultado_prev,
            "00390": ajustes_prev,
            "00393": patrimonio_prev,
            "00429": resultado_prev,
            "00432": ajustes_prev,
            "00435": patrimonio_prev,
            "00443": resultado,
            "00446": variacion_ajustes,
            "00449": _sum([resultado, variacion_ajustes]),
            "00519": _neg(distribucion_dividendo),
            "00575": _neg(distribucion_dividendo),
            "00625": _neg(resultado_prev),
            "00736": _neg(resultado_prev),
            "00639": resultado,
            "00642": ajustes,
            "00645": patrimonio,
        },
    }
    clean_pages = {
        page: {k: v for k, v in vals.items() if v not in (None, "")}
        for page, vals in pages.items()
    }
    flat = {}
    for vals in clean_pages.values():
        flat.update(vals)
    return {
        "source": "balance_pyg",
        "path": path,
        "casillas_by_page": clean_pages,
        "casillas": flat,
        "derived": {
            "servicios_exteriores": servicios_exteriores,
            "variacion_ajustes_pn": variacion_ajustes,
            "distribucion_dividendo": distribucion_dividendo,
        },
        "warnings": [
            "Parser especifico de replay GIP 2024; las clasificaciones contables se han aislado por pagina para evitar casillas reutilizadas."
        ],
    }


def to_casillas_by_page(parsed):
    return dict(parsed.get("casillas_by_page") or {})


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("path", nargs="?", default=DEFAULT_PATH)
    ap.add_argument("--out")
    args = ap.parse_args()
    data = parse(args.path)
    text = json.dumps(data, ensure_ascii=False, indent=2, default=str)
    if args.out:
        Path(args.out).write_text(text, encoding="utf-8")
    print(text)


if __name__ == "__main__":
    main()
