---
documento: REFERENCIA (activo operativo)
titulo: Prompts Harvey — normalización del Sumas y Saldos para A3
modulo: Extractor-Parseador Contable IS (EPC-IS)
origen: prompts en producción en Harvey usados para "extraer para A3"
fecha_captura: 2026-06-06
uso_en_prd: define el "Motor SyS" (ver PRD §9A). Es la lógica razonada (LLM + maestro PGC) que
  convierte un sumas y saldos en bruto en un sumas y saldos validado y agrupado a 4 dígitos
  (formato plantilla A3), con validación humana intermedia.
notas:
  - "Los `()` y `<...>` del texto original son placeholders de los ficheros/inputs que Harvey inyecta
     (archivo de sumas y saldos, maestro PGC, salida previa, correcciones del usuario)."
  - "Se reproducen VERBATIM para no perder matices operativos. Cualquier mejora se versiona aparte."
---

# Prompts Harvey — Sumas y Saldos → A3 (verbatim)

Estos son los dos prompts que hoy se usan en Harvey para preparar la contabilidad de cara a A3. En
EPC-IS sustituyen al "trabajo de limpieza/mapeo" que hace A3 al importar: producen el **canónico
contable** (sumas y saldos validado, PGC a 4 dígitos), que luego el módulo mapea a partidas AEAT
(Balance/PyG/ECPN) y serializa al XSD. Ver PRD §9A.

---

## PROMPT 1 — Fases 1 a 6 (validación, human-in-the-loop; se detiene tras la fase 6)

> Actúa como contable experto en PGC español. Usando el maestro oficial de cuentas del Plan General de Contabilidad y el archivo de sumas y saldos proporcionado (), realiza en UNA sola pasada las fases 1 a 5 que siguen, y prepara la entrega intermedia solicitada (fase 6) sin continuar aún con la agregación final.
>
> Objetivo general: asociar cada fila del sumas y saldos a un código PGC válido a 4 dígitos (o a 3 si el PGC no contempla subcuenta) y preparar una tabla de validación interactiva para revisión del usuario.
>
> #### Fases a ejecutar ahora (1–6, deteniéndote tras la fase 6)
>
> Ejecuta únicamente las fases 1 a 6. No generes todavía el sumas y saldos final. Tras la fase 6, detente y espera la validación o corrección del usuario.
>
> ---
>
> ### 1. Detección de columnas
>
> Identifica automáticamente en el archivo cuáles son:
>
> - La columna de código contable.
> - La columna de descripción.
> - La columna de importe o saldo.
> - Las columnas de Debe y Haber, si existen.
> - La columna de Saldo Inicial, si existe.
>
> Indica qué letra de columna, por ejemplo A, B, C, corresponde a cada rol.
>
> Acepta encabezados habituales, por ejemplo:
>
> `Cuenta`, `Código`, `Código cuenta`, `Cuenta contable`, `Descripción`, `Concepto`, `Texto`, `Saldo`, `Importe`, `Debe`, `Haber`, `Saldo Final`, `Saldo Inicial`.
>
> Si existen columnas separadas de `Debe` y `Haber`, calcula el saldo neto como:
>
> `Saldo neto = Debe − Haber`
>
> Conserva siempre las filas y columnas originales sin alterarlas.
>
> ---
>
> ### 2. Truncado de código
>
> Añade dos campos auxiliares lógicos por fila:
>
> - `Código_4d`: primeros 4 dígitos del código original.
> - `Código_3d`: primeros 3 dígitos del código original.
>
> Reglas:
>
> - Trata códigos vacíos como `"sin código"`.
> - Trata códigos no numéricos como `"sin código"`.
> - No modifiques el código original.
> - Si el código tiene menos de 3 dígitos, conserva los dígitos disponibles y marca la fila para revisión si no puede validarse contra el PGC.
>
> ---
>
> ### 3. Extracción del maestro PGC
>
> Extrae del maestro oficial PGC todas las cuentas con su denominación oficial a:
>
> - 1 dígito.
> - 2 dígitos.
> - 3 dígitos.
> - 4 dígitos.
>
> Utiliza ese maestro como única tabla de referencia.
>
> Reglas estrictas:
>
> - Usa exclusivamente códigos existentes en el maestro oficial PGC.
> - No inventes códigos.
> - No uses cuentas que no estén en el maestro.
> - La denominación PGC debe ser siempre la denominación oficial del maestro.
>
> ---
>
> ### 4. Validación contra el PGC, por fila
>
> Para cada fila del archivo:
>
> 1. Si `Código_4d` existe en el PGC:
>    - Asigna `Código_PGC_asignado = Código_4d`.
>    - Tipo de resolución: `"4d directo"`.
> 2. Si `Código_4d` no existe, pero `Código_3d` existe en el PGC:
>    - Asigna `Código_PGC_asignado = Código_3d`.
>    - Tipo de resolución: `"3d directo"`.
> 3. Si ninguno existe:
>    - Marca la fila como `"no identificada"`.
>    - Pasa la fila a análisis por descripción en la fase 5.
>
> Aunque una fila tenga un código válido en el PGC, no la consideres automáticamente correcta si existe incoherencia clara entre:
>
> - Código.
> - Descripción.
> - Signo del importe.
> - Naturaleza contable esperada.
>
> En ese caso, debe pasar también a la fase 5.
>
> ---
>
> ### 5. Análisis por descripción, coherencia contable y signo
>
> Analiza en detalle todas las filas que cumplan al menos una de estas condiciones:
>
> - Código no identificado.
> - Código vacío.
> - Código no numérico.
> - Código válido pero con descripción incoherente.
> - Código válido pero con posible signo equivocado.
> - Código válido pero con duda razonable sobre su naturaleza contable.
> - Fila que requiera validación humana.
>
> Para cada una de esas filas, determina la cuenta PGC más adecuada, preferentemente a 4 dígitos, usando exclusivamente el maestro oficial PGC.
>
> #### 5.1 Reasignación por descripción
>
> Lee la descripción o concepto y asigna el código PGC más adecuado.
>
> Aplica estrictamente estas reglas guía:
>
> - Amortización acumulada de inmovilizado intangible/material → `280x` / `281x` correspondiente.
> - No confundas amortización acumulada con deterioros: `290x` / `291x` son deterioros, no amortización.
> - `"Gastos anticipados"` → `480`.
> - `"Ingresos anticipados"` / `"previsión de ingresos"` → `485`.
> - Bancos / tesorería en euros → `572`.
> - Bancos / tesorería en moneda extranjera → `573`.
> - Impuesto sobre beneficios, incluido extranjero → `630`.
> - Ajustes positivos en imposición indirecta → `639`.
>
> Si la descripción es claramente incoherente con la familia del código detectado:
>
> - Marca la fila como `"inconsistencia código-descripción"`.
> - Propón la cuenta PGC más adecuada según la descripción.
> - Documenta en notas la cuenta original y la cuenta propuesta.
> - No fuerces la asignación original si la descripción apunta claramente a otra cuenta.
>
> Cuando haya varias opciones plausibles:
>
> - Elige la más específica del PGC.
> - Incluye las alternativas en `Alternativas consideradas`.
> - Explica el motivo en `Notas`.
>
> #### 5.2 Validación del signo contable
>
> Valida también la coherencia del signo del importe o saldo según la naturaleza habitual de la cuenta.
>
> Como regla general:
>
> - Activos, gastos, saldos deudores y tesorería suelen tener naturaleza deudora.
> - Pasivos, patrimonio neto, ingresos, acreedores y cuentas de naturaleza acreedora suelen tener naturaleza acreedora.
>
> Para cada fila analizada:
>
> 1. Determina la naturaleza esperada de la cuenta detectada o propuesta:
>    - `"deudora"`.
>    - `"acreedora"`.
>    - `"mixta / requiere revisión"`.
> 2. Determina el signo observado del importe o saldo:
>    - Positivo.
>    - Negativo.
>    - Cero.
>    - No disponible.
> 3. Si el signo observado es incoherente con la naturaleza habitual de la cuenta:
>    - Marca la fila como `"posible signo equivocado"`.
>    - Destácala obligatoriamente en la tabla de validación de la fase 6.
>    - Analiza si procede proponer una cuenta alternativa de naturaleza compatible con el signo observado.
> 4. Si la descripción confirma que la cuenta original parece correcta, pero el signo parece incorrecto:
>    - Mantén como propuesta la cuenta más coherente por descripción.
>    - Marca la fila como `"posible signo equivocado"`.
>    - Anota en `Notas`: `"La cuenta parece correcta por descripción, pero el signo del importe/saldo debería revisarse"`.
> 5. Si el signo observado sugiere que la cuenta original no es adecuada y la descripción permite una alternativa razonable:
>    - Propón una cuenta PGC alternativa de naturaleza compatible con el signo observado.
>    - Indica en `Notas`:
>      - Cuenta originalmente detectada.
>      - Naturaleza esperada de la cuenta original.
>      - Signo observado.
>      - Cuenta alternativa propuesta.
>      - Motivo de la propuesta.
> 6. Si tanto cuenta como signo son dudosos:
>    - Marca la fila como `"requiere validación humana"`.
>    - Incluye todas las alternativas razonables.
>
> No reasignes automáticamente una cuenta solo por el signo si la descripción no lo justifica. El signo sirve para detectar posibles errores, no para inventar reclasificaciones.
>
> ---
>
> ### 6. Entrega intermedia — Tabla de validación interactiva
>
> Devuelve una tabla de validación interactiva que incluya exclusivamente las filas que cumplan alguna de estas condiciones:
>
> - Filas reasignadas por descripción.
> - Filas con código vacío.
> - Filas con código no numérico.
> - Filas marcadas como `"no identificada"`.
> - Filas marcadas como `"inconsistencia código-descripción"`.
> - Filas con `"posible signo equivocado"`.
> - Filas para las que se proponga una cuenta alternativa por incoherencia entre importe, signo, descripción y naturaleza contable.
> - Filas que requieran validación humana.
> - Filas donde existan varias alternativas razonables.
>
> No incluyas en esta tabla las filas validadas directamente como `"4d directo"` o `"3d directo"` si no presentan ninguna incoherencia.
>
> Antes de la tabla, muestra una línea con las columnas detectadas, usando este formato:
>
> `Columnas detectadas: Código = [letra], Descripción = [letra], Importe/Saldo = [letra], Debe = [letra o no detectada], Haber = [letra o no detectada], Saldo Inicial = [letra o no detectada]`
>
> La tabla debe tener exactamente estas columnas:
>
> `Código original | Descripción | Importe / Saldo observado | Cuenta detectada o existente | Naturaleza esperada | Signo observado | Cuenta PGC propuesta | Denominación PGC propuesta | Tipo de resolución | Motivo de la propuesta | Alternativas consideradas | Notas | ✅ Validar | ✏️ Corregir (indicar código)`
>
> Reglas para esta tabla:
>
> - Destaca claramente la `Cuenta PGC propuesta`.
> - Explica siempre el motivo de la propuesta.
> - Si hay inconsistencia código-descripción, indícalo en `Tipo de resolución`.
> - Si hay posible signo equivocado, indícalo en `Tipo de resolución`.
> - Si propones una cuenta alternativa por signo, explica por qué esa cuenta tiene naturaleza más compatible.
> - Si la cuenta parece correcta pero el signo parece erróneo, no cambies la cuenta solo por el signo; señala que debe revisarse el signo.
> - Si existen alternativas razonables, inclúyelas en `Alternativas consideradas`.
> - En la columna `✅ Validar`, deja espacio para que el usuario escriba `"Validado"`.
> - En la columna `✏️ Corregir (indicar código)`, deja espacio para que el usuario escriba cambios en el formato `codigo cuenta = <código>`.
> - No continúes al sumas y saldos final hasta recibir la validación o corrección del usuario.
>
> ### Reglas estrictas para las fases 1–6
>
> - No inventes códigos fuera del PGC.
> - Usa exclusivamente el maestro oficial PGC.
> - Trata también las filas con código vacío por descripción.
> - Conserva las filas y columnas originales sin alterarlas.
> - Las filas con posible signo equivocado deben aparecer obligatoriamente en la tabla de validación.
> - Cuando se detecte incoherencia de signo, propone una cuenta alternativa de naturaleza compatible solo si la descripción lo permite.
> - Si la descripción confirma la cuenta original pero el signo parece incorrecto, mantén la cuenta por descripción y marca la fila como `"posible signo equivocado"`.
> - La fase 6 es una entrega intermedia: detente ahí y espera validación del usuario.

---

## PROMPT 2 — Continuación tras validación (correcciones + agrupado 4 dígitos)

> Continuación tras la validación del usuario. Usando el maestro oficial , el archivo de sumas y saldos () y la salida previa , aplica las correcciones indicadas por el usuario en :
>
> - Si el usuario escribió 'Validado', no cambies las asignaciones.
> - Si indicó cambios por "codigo cuenta = <código>", sustituye la asignación de esa fila por el código especificado, siempre verificando que el código existe en el PGC; si no existe, mantén la mejor asignación previa y anota en "Notas" que la corrección propuesta no existe en el PGC.
>
> Luego genera el sumas y saldos agrupado a 4 dígitos (si no existe la cuenta a 4 dígitos en el PGC la cuenta de 3 dígitos conviértela a 4 añadiendo un 0 al final, p.e. la cuenta 100 la conviertes a 1000), sumando importes por Código_PGC_asignado y añadiendo su denominación oficial. Muestra todos los números usando el formato español: coma `,` como separador decimal y punto `.` como separador de miles. Por ejemplo: `1.234,56` significa mil doscientos treinta y cuatro con cincuenta y seis.
>
> Entregable final (en texto estructurado, compatible con CSV/Excel):
>
> Tabla "Sumas y saldos — agrupado 4 dígitos" con columnas: Cuenta / Descripción / Saldo Final / Debe / Haber / Saldo Inicial
>
> Reglas estrictas: no inventes códigos fuera del PGC; trata también filas con código vacío por descripción; conserva las filas y columnas originales sin alterarlas.
>
> Salida: primero una línea recordando las letras de columnas detectadas para Código/Descripción/Importe. Después, entrega la tabla solicitada en formato de tabla markdown con encabezados claros.

---

## Lectura para EPC-IS (cómo se productiza)

1. **Etapa A (Prompt 1)** = detección de columnas + truncado + validación contra maestro PGC + análisis
   razonado (descripción/signo/naturaleza) → **tabla de validación interactiva** (solo filas con duda).
   Es el *borrador para revisión* del patrón persona_tax: el extractor no es la fuente de verdad.
2. **Gate humano** = el profesional escribe `Validado` o `codigo cuenta = <código>` por fila. Esto fija
   el canónico. En frontend es la pantalla `extraction`/`validation` (tabla de 14 columnas + acciones).
3. **Etapa B (Prompt 2)** = aplica correcciones (verificando contra PGC) + **agrupa a 4 dígitos**
   (3d→4d con `0` final), suma por `Código_PGC_asignado`, añade denominación oficial, formato español
   → tabla **Cuenta / Descripción / Saldo Final / Debe / Haber / Saldo Inicial** = **formato plantilla
   A3 "Sumas y Saldos"** y, en EPC-IS, el **canónico contable** del ejercicio.
4. **Después (propio de EPC-IS, ya sin A3)**: mapeo PGC→partida AEAT (Balance/PyG/ECPN) + builder XSD
   `mod200<ejercicio>` + validación XSD. Ver PRD §10–§12.

**Decisiones de productización a considerar** (no resueltas por los prompts):

- **Determinismo vs LLM**: las fases 1–2 y 4 (detección, truncado, match exacto contra maestro) pueden
  ser deterministas (script); las fases 5 (descripción/signo) son las que requieren razonamiento LLM.
  Recomendado: capa determinista + LLM solo para lo ambiguo (model policy por coste, como persona_tax).
- **Maestro PGC**: incorporar el maestro oficial (1/2/3/4 dígitos + denominación) como dato versionado
  del módulo (`data/pgc_maestro.csv`), no re-extraerlo cada vez.
- **Reglas guía 5.1**: el set de reglas (280x/281x vs 290x/291x, 480/485, 572/573, 630/639) debe vivir
  en un catálogo editable/versionado, no hardcodeado en el prompt.
- **Trazabilidad**: persistir, por fila, código original → propuesta → resolución → validación humana
  (lineage), no solo el resultado agrupado.
- **Cuadres**: tras agrupar, ejecutar los cuadres de la Aduana contable (Debe=Haber, deudor=acreedor) y
  el tratamiento de la 129/1290 antes de promover a canónico.
