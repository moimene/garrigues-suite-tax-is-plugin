---
documento: NOTA DE SPIKE (memoria/continuidad)
modulo: Extractor-Parseador Contable IS (EPC-IS)
fase: 1 — MVP determinista del Motor SyS
fecha: 2026-06-06
caso: GIP (Sociedad Ejemplo) — ejercicio 2025
estado: ✅ spike verde (cuadres OK, verificación independiente sin diferencias)
---

# Spike Fase 1 — Motor SyS sobre GIP (resultado)

## Qué se ha construido

Primer motor real del módulo (PRD §9A), productizando los 2 prompts de Harvey:

- **`scripts/motor_sys.py`** — Motor SyS determinista (Etapa A + B):
  - **Lector robusto**: `python-calamine` (lee el `.xls` de GIP, generado por *JasperReports*, que
    `xlrd` no abre) con fallback a xlrd/openpyxl/csv.
  - **Detección de columnas** (resolvió: Código=col1, Descripción=col2, Saldo Final=Saldo Actual,
    Debe/Haber=*Actual* acumulado, Saldo Inicial=Saldo Ant.).
  - **Truncado 4d/3d** + **match contra maestro PGC** (4d→3d) + **agrupado a 4 dígitos** (3d→4d con `0`).
  - **Análisis Etapa A**: naturaleza/signo + reglas guía por descripción (480/485, 572/573, 630/639,
    280x/281x, 700→760) → **tabla de validación** (solo filas con duda).
  - **Cuadres** (Σ Debe=Σ Haber, Σ deudor=Σ acreedor, Σ saldo final) y **lineage** por fila.
  - **Formato español** (`1.234,56`).
- **`data/pgc_maestro.csv`** — maestro PGC ampliado (RD 1514/2007): grupos 1-7, subgrupos y cuentas a
  3 dígitos + 4 dígitos clave. Cubre el 100% de los grupos de GIP. (El de `suite-is/rules/pgc/` era un
  seed de 53 filas.)
- **`salidas/GIP_2025/`** — entregables del caso GIP.

## Resultado (GIP 2025)

- **206** filas de cuenta → **60** cuentas agrupadas a 4 dígitos.
- **0 cuentas no identificadas** en el maestro.
- Cuadres: **Σ Debe = Σ Haber = 13.485.488.087,34 ✅** · **Σ deudor = Σ acreedor = 652.050.138,93 ✅**
  · **Σ saldo final (con signo) = 0,00 ✅**.
- **Verificación independiente**: recomputado el agregado desde el origen → **60/60 cuentas, 0 celdas
  con diferencia** frente a la salida del motor. Spot-checks (1000, 1100, 5720, 7000) cuadran.
- **Etapa A levantó 6 filas a revisión**, entre ellas:
  - `7000` "Ingresos netos por partic. de capital" → propone **760** (ingreso de participaciones, no
    70x ventas). *Caso real de inconsistencia código-descripción.*
  - `6310`, `6380` → "posible signo equivocado" (gasto/tributo con saldo negativo).
  - `5410.063/110` (bancos en cuenta de valores) → propone 572 — **propuesta agresiva** de la regla de
    descripción; la rechazaría el humano (son depósitos/ON, no c/c). Indica que las reglas guía 5.1
    necesitan afinado (esperado en un seed).
  - Fila `TOTALES` → excluida del agregado y marcada (subtotal sin código).

## Entregables (`salidas/GIP_2025/`)

| Fichero | Contenido |
|---|---|
| `agrupado_4d_A3.xlsx` | **Sumas y Saldos formato A3** (Cuenta/Descripción/Saldo Final/Debe/Haber/Saldo Inicial), cabecera Garrigues, totales de control. = canónico contable. |
| `agrupado_4d.csv` | Mismo agrupado, CSV `;` (números crudos, reimportable). |
| `agrupado_4d.md` | Mismo agrupado, legible (formato español). |
| `validacion.md` | Tabla de validación Etapa A (14 columnas, 6 filas a revisar). |
| `lineage.csv` | Auditoría: por fila original → c4 → asignado → resolución. |
| `resumen_cuadres.md` | Cuadres + recuentos. |

## Lectura

El pipeline **funciona end-to-end** sobre un SyS real y complejo (holding, miles de millones de
movimiento, fichero JasperReports) y **cuadra**. La salida es el *canónico contable* (formato A3), que
es la entrada del siguiente paso (mapeo PGC→partida AEAT → XSD), ya sin A3.

## Pendiente / siguientes pasos

1. **Afinar reglas guía 5.1** (la de "banco"→572 es demasiado amplia; excluir cuando el código es de
   valores 54x/ON/depósitos). Mover las reglas a catálogo YAML versionado.
2. **Maestro PGC**: completar al cuadro oficial 100% (hoy cubre GIP + comunes) y versionarlo.
3. **Etapa B con correcciones aplicadas**: aplicar las validaciones humanas (`Validado` / `código = X`)
   y regenerar (hoy el agrupado va sobre la asignación determinista, sin aplicar propuestas).
4. **Capa LLM selectiva** para la fase 5 (solo filas ambiguas), con model policy por coste.
5. **Siguiente motor**: mapeo `canónico (4d) → partida AEAT (Balance/PyG/ECPN)` → builder XSD
   `mod200<ejercicio>` + validación XSD. Para GIP, contrastar con su CCAA (PDF) y su declaración 2024.
6. **Comparar** el agrupado con lo que A3 produce para GIP (validación cruzada de la sustitución).

## Cómo reproducir

```bash
cd Extractor-parseador
python3 scripts/motor_sys.py \
  --input "../GIP 2025/GIP-SUMAS Y SALDOS GIP EUROS 311225 VERSION 230426.xls" \
  --outdir salidas/GIP_2025 --empresa "GIP" --ejercicio 2025
# requiere: pip install python-calamine pandas openpyxl
```
