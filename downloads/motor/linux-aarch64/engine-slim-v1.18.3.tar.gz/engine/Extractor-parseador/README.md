# Extractor-Parseador Contable IS (EPC-IS)

Convierte la documentación contable de una sociedad (sumas y saldos, cuentas anuales, declaración del
ejercicio anterior) en los **ficheros contables del Modelo 200 de la AEAT** — XML `mod200<ejercicio>`
(Balance / Cuenta de PyG / ECPN) + XLS de estados contables — de forma cuadrada, validada y trazable,
**sin A3** y **sin calcular la liquidación**.

> Arquitectura y alcance: ver `PRD_Extractor_Parseador_Contable_IS200_2026-06-06.md` (§7 arquitectura,
> §9A motor SyS). Réplica del patrón persona_tax: documentos → canónico → proyección AEAT.

## Pipeline (capas)

```
documentos → harness → motor por clase → canónico (4d) → mapeo PGC→casilla → builder → validador → salidas
```

| Etapa | Script | Entrada → Salida |
|---|---|---|
| **Campaña (versionado)** | `scripts/campaign.py` | `data/campaigns/<ejercicio>/` · `resolve(ejercicio)` resuelve todos los artefactos · `onboard` da de alta un año desde su XSD · `diff` compara campañas |
| Catálogo (schema-first) | `scripts/catalogo_contable.py` | DR200e25.xls → `catalogo_contable.json` (574 campos, casilla↔T-code, etiquetas) |
| Campos XSD (rama Normal) | `scripts/gen_xsd_normal.py` | mod2002024.xsd → `data/xsd_campos_2024.json` + subesquema `mod2002024_normal.xsd` (451 casillas importables, en orden `xs:sequence`) |
| Motor SyS (determinista) | `scripts/motor_sys.py` | sumas y saldos → `agrupado_4d.csv` (canónico A3) + tabla de validación + cuadres |
| Mapeo PGC→AEAT | `data/mapeo_pgc_aeat_2025.json` (gen: `gen_mapeo_pgc_aeat.py`) | cuenta PGC → casilla-hoja del XSD (bloque + signo) |
| Builder | `scripts/builder.py` | canónico + mapeo + campos XSD → **XML mod200** (solo casillas importables, en orden) + **XLS AEAT** + lineage |
| Validador | `scripts/validador.py` | XML → estructural + cuadres + **validación XSD con lxml** contra `mod2002024_normal.xsd` |
| Declaración previa | `scripts/parser_declaracion_previa.py` | `.xml` mod200 → casillas + comparativa (round-trip exacto) |
| Cuentas anuales | `scripts/extractor_ccaa.py` | PDF → borrador (inferencia; hook LLM; fallback determinista) |
| Harness | `scripts/harness.py` | detecta clase de documento → motor |
| Orquestador | `scripts/pipeline.py` | documentos → todas las salidas + `manifest.json` + `INFORME.md` |
| Servicio + web | `scripts/service.py` + `web/index.html` | subir por clase → procesar → descargar |

## Uso rápido

```bash
pip install -r requirements.txt

# 0) versionado por campaña — dar de alta un ejercicio desde su XSD oficial (la AEAT lo publica cada año)
python3 scripts/campaign.py onboard --ejercicio 2026 --xsd /ruta/mod2002026.xsd --base 2025
python3 scripts/campaign.py list                 # campañas disponibles
python3 scripts/campaign.py diff --a 2024 --b 2026   # qué casillas cambió la AEAT
#   (2024 y 2025 ya están dadas de alta en data/campaigns/)

# 1) pipeline end-to-end (un expediente) — el --ejercicio resuelve XSD/campos/mapeo/catálogo de su campaña
python3 scripts/pipeline.py --empresa "GIP" --ejercicio 2025 --outdir salidas/GIP_2025 \
  --docs "/ruta/SUMAS Y SALDOS.xls" "/ruta/CCAA.pdf" "/ruta/declaracion_previa.xml"

# 2) (opcional) servicio web
uvicorn service:app --app-dir scripts --reload      # abre http://127.0.0.1:8000

# 3) tests
python3 -m pytest tests/ -q
```

## Versionado por campaña (ejercicio)

La AEAT publica el diseño/esquema **cada ejercicio**. Todo lo dependiente del año vive en
`data/campaigns/<ejercicio>/` (XSD + `xsd_campos.json` + `mapeo_pgc_aeat.json` + `catalogo_contable.json`
+ `campaign.json`); el PGC (`pgc_maestro.csv`) es compartido. **El `--ejercicio` es el único selector**:
`campaign.resolve(ejercicio)` da al builder/validador el contrato correcto del año.

Alta de un año nuevo (sin tocar código): `campaign.py onboard --ejercicio AAAA --xsd mod200AAAA.xsd --base <año previo>`
→ parsea el XSD oficial (casillas + orden), genera el subesquema de validación, copia el mapeo de la base
y emite `ONBOARDING.md` con el **diff de casillas** (nuevas sin mapear / reglas huérfanas a remapear).
Estado: **2024** = XSD oficial; **2025** = provisional (= 2024) hasta su XSD.

## Salidas (por expediente)

- `modelo200_contable_<ej>.xml` — XML de datos contables (importable en Sociedades WEB).
- `estados_contables_aeat.xlsx` — Balance / PyG / ECPN en formato AEAT.
- `agrupado_4d.xlsx` / `.csv` — sumas y saldos normalizado (formato A3) = canónico contable.
- `validacion.md` (Etapa A, revisión humana) · `validacion_xml.md` (apto/no apto).
- `casillas.csv` · `lineage_casillas.csv` (cuenta→casilla) · `cuadres_builder.md` · `resumen_cuadres.md`.
- `manifest.json` · `INFORME.md`.

## Garantías y límites

- **Válido contra el XSD oficial**: el XML valida ✅ contra `mod2002024.xsd` (rama Normal) con lxml.
  El builder emite **solo casillas importables del esquema, en orden**; los subtotales/totales/resultados
  (00101, 00180, 00185, 00252, 00296, 00500…) NO se emiten porque el XSD no los admite: los recompone la AEAT.
- **Cuadre por construcción**: TOTAL ACTIVO == TOTAL PN+PASIVO (561.111.165,52 en GIP; informe interno,
  no va al XML). Verificado con GIP real y fixture sintético. **13/13 tests verdes** (incl. validez XSD).
- **Human-in-the-loop**: el motor SyS entrega un borrador (tabla de validación); la fuente de verdad es
  el canónico aprobado.
- **Pendiente**: XSD **2025** oficial (hoy `mod2002025_normal.xsd` es provisional = casillas de 2024);
  esquema completo para ramas no-Normal (Seguros/BancoEspaña); ECPN se rellena parcialmente desde el SyS
  (las CCAA aportan el detalle de movimientos); el extractor de CCAA requiere PDF con texto (o OCR).
- **Fuera de alcance**: liquidación, ajustes fiscales, casillas de liquidación (págs. 12+).
