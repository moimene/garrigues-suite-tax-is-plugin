# Harness local de replay / generación del `.200` (Modelo 200)

Herramienta **local** que reconstruye el fichero de importación de ancho fijo (`.200`, BOE) del Modelo 200
desde los documentos del expediente, para reducir al máximo el "picado" manual del abogado. Es un harness
de viabilidad, **no** el motor fiscal canónico (ese es `engine_service`/`suite-is`, ADR-001).

## Confidencialidad (regla dura 2)

El código y los tests **no contienen datos de cliente**. La identidad (NIF, razón social), las rutas de los
ficheros fuente, las cifras esperadas por los tests y los datos manuales (`overrides`) viven **solo** en
`Extractor-parseador/caso_local.json` (**gitignored**). El guard `tests/test_no_pii.py` falla si reentra PII.

## Puesta en marcha

```bash
cp Extractor-parseador/caso_local.example.json Extractor-parseador/caso_local.json
# editar caso_local.json con la identidad, las rutas locales del expediente y los overrides
python3 Extractor-parseador/scripts/gip2024_replay_builder.py
```

Salidas (en `engine_service/_local_out/...`, gitignored):
- `declaracion_mod200_2024_replay.200` — el fichero a importar en Sociedades WEB.
- `*.golden.json` — diff casilla-a-casilla contra el `.200` real (si se configuró `real_200`).
- `INFORME_CIERRE.md` — estado para el abogado: cobertura, pendientes, avisos, acción.

## Flujo (las cuatro redes de seguridad)

1. **Extracción automática** de balance/PyG, liquidación y datos formales → casillas por origen
   (separadas por página para no escribir en casillas homónimas de otro marco).
2. **Golden value-gate** (`modelo200_golden`): `correct_fields` cuenta solo las casillas con el **valor
   correcto**; `errores()` lista las que no cuadran. Una casilla con valor equivocado NO cuenta como acierto.
3. **Overrides** (`caso_local.json`): el abogado aporta lo que el harness no puede extraer (datos de grupo,
   ajustes manuales), cada uno con estado `auto`/`revisar`/`manual_requerido`/`bloqueado`. Se valida que la
   casilla exista en el DR y que el valor sea emitible. Con overrides, el replay GIP cierra a 201/201.
4. **Parsing fail-loud**: el parser de datos formales valida la forma (empleados, IBAN por checksum mod-97)
   y AVISA en vez de leer la celda equivocada en silencio; los avisos se surfacean en `INFORME_CIERRE.md`.

## Validación de formato y límites conocidos

`tests/test_golden_multi_entidad.py` valida, por cada `.200` real que configures en `caso_local.json` →
`golden_200` (paths, gitignored), que el DR del ejercicio mapea el 100% de sus registros (0 tags
desconocidos) — prueba de que el formato no es específico de GIP. Verificado localmente contra 3
entidades 2024 (no reproducible desde un checkout limpio, porque los `.200` reales no se versionan).

Límites conocidos para la **importación completa** (no afectan al replay casilla-a-casilla, sí a la
fidelidad total del fichero):
- **Bloque `<AUX>`**: el harness lo emite en blanco; los `.200` reales llevan metadatos del presentador
  (versión EEDD `F 1.05` + NIF). `dr200.construir_fichero` acepta `version_ed`/`nif_ed` para poblarlo.
- **Registros de continuación (`C`)**: entidades con muchas participadas/socios/titulares usan registros
  `<T20002000>C`/`<T20002B00>C` adicionales. El harness emite `DP200002` una vez (suficiente a nivel de
  casilla; pendiente para el detalle completo de personas/participadas).

## Campaña multi-entidad (varias sociedades / ejercicios)

`caso_local.json → casos` es una lista de casos `{id, nif, razon_social, ejercicio, paths, overrides}`.
`python3 .../gip2024_replay_builder.py --campana` los corre todos y deja, por caso,
`engine_service/_local_out/campana/<id>/declaracion.200` + `INFORME_CIERRE.md`, más un `CAMPANA.md`
resumen (cobertura / pendientes / avisos / revisión por sociedad). Un caso roto **no aborta** la campaña
(se reporta su error). Cada caso aporta SUS rutas (no cae a la config singular). Sin `casos`, `--campana`
corre la config singular como un único caso.

## Campañas 2024 y 2025

La capa DR (`dr200`/`modelo200_golden`) es **paramétrica por ejercicio** (`cargar_dr(ejercicio=...)`,
`--ejercicio` en el builder; `DR200e24`/`DR200e25` versionados). Cada caso de la campaña declara su
`ejercicio` (mezcla 2024/2025 en la misma campaña). Para 2025 basta añadir el caso con `ejercicio: "2025"`
y sus inputs; el golden valida contra el DR2025.

## Arquitectura (genérico vs específico de entidad)

- **Núcleo genérico, reutilizable tal cual** (nombres ya neutros): `dr200` (emisor DR ancho fijo),
  `modelo200_golden` (golden diff), `gip2024_replay_contract` (merge de fuentes por prioridad, sin
  criterio fiscal), `caso_local` (config), `normalizar_dr200`, y el **runner de campaña** dentro del
  builder.
- **Específico de la sociedad** (no renombrado para no aparentar generalidad que no tiene): los parsers
  `gip2024_*_parser` (leen la estructura de los workbooks de GIP) y los mapeos de página del builder
  (`LIQUIDACION_KEYS`, etc.). Otra sociedad con otra plantilla necesita su propio parser (o el extractor
  por modelo, pendiente). El runner de campaña y el contrato de parser `{source, casillas, campos_pos,
  warnings}` son la frontera estable sobre la que añadirlos.

## Compuerta humana

El harness no afirma "importable": la **validez definitiva** es el import real en Sociedades WEB. El
`INFORME_CIERRE.md` dice qué revisar antes.

## Tests

```bash
python3 -m pytest Extractor-parseador/tests/ -q     # con caso_local.json: caso real; sin él: CI-safe (skip)
```

Detalle y decisiones: `docs/memoria/2026-06-17-replay-gip2024-harness-local.md`.
