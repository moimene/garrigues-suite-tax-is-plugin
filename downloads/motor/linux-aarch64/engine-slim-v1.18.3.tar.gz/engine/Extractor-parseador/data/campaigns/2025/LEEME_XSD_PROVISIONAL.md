# Campaña 2025 — XSD PROVISIONAL (pendiente del oficial AEAT)

> **Estado [2026-06-07]:** la campaña 2025 está montada con un **XSD PROVISIONAL**
> (`mod2002025_normal.xsd` = casillas del ejercicio **2024**, root renombrado a `mod2002025`).
> **NO es el esquema OFICIAL** de la AEAT para el ejercicio 2025.

## Por qué provisional
El `mod2002025.xsd` OFICIAL aún no es obtenible automáticamente: a fecha de hoy no está publicado
como fichero suelto en el portal de desarrolladores (la ruta `static_files/.../Modelo_200/mod2002025.xsd`
devuelve 404; los XSD van empaquetados / publicados con la Orden de la campaña, normalmente junio/julio
del año de presentación — el IS 2025 se presenta en julio 2026).

## Garantía de integridad (cómo lo trata el motor)
- `campaign.resolve('2025')` marca `provisional` (no vacío).
- `engines.emitir_mod200(..., ejercicio='2025')` devuelve `xsd_provisional: true` y
  `xsd_fuente: "provisional ... pendiente XSD OFICIAL AEAT"`.
- `/expediente/paquete` propaga el flag al entregable `xml_mod200` y añade un aviso ⚠️.
- La consola muestra **"✓ XSD PROVISIONAL (no oficial 2025)"** — NUNCA se presenta como validado
  contra el oficial. (Principio: no inventar; el A3 sigue siendo la vía operativa hasta el XSD oficial.)

## Cómo clavar el XSD OFICIAL cuando la AEAT lo publique
1. Descarga el `mod2002025.xsd` oficial (portal de desarrolladores AEAT / Orden de la campaña 2025).
2. Re-onboarda la campaña:
   ```bash
   cd Extractor-parseador/scripts
   python3 -c "import campaign; campaign.onboard('2025', '/ruta/mod2002025.xsd', base='2024', dr200='/ruta/DR200e26.xls')"
   ```
   Esto regenera `xsd_campos.json` + `mod2002025_normal.xsd` desde el oficial y **vacía** `provisional`
   en `campaign.json`. A partir de ahí `xsd_provisional` pasa a `false` automáticamente (sin tocar código).
3. (Opcional) genera el catálogo/validaciones 2025 desde el `DR200` de la campaña 2025
   (`catalogo_contable_calamine.py`).

> El binario `mod2002025.xsd` y el `DR200` van **gitignored** si son pesados; los JSON derivados sí se
> versionan. El flujo de "clavar oficial" es de **un comando**, sin cambios de lógica.
