"""Adaptadores que REUTILIZAN los motores Python existentes (no reescriben lógica).

EPC contable  : motor_sys, builder, validador, pipeline, campaign.
Plugin fiscal : calcular_liquidacion, harness_estado.

Importar este módulo asume que `engine_service.__init__` ya insertó en sys.path el
repo-root y ambos `scripts/`. Se capturan SystemExit (los motores hacen `raise
SystemExit` ante input inválido) además de Exception.
"""
import base64
import hashlib
import json
import math
import os
import re
import tempfile
from decimal import Decimal, ROUND_HALF_UP

import engine_service  # noqa: F401  -- bootstrap de sys.path

import campaign            # noqa: E402  (EPC)
import builder             # noqa: E402
import reconciliador       # noqa: E402  (cuadres tol=0 + inter-documento, B3)
import validador           # noqa: E402
import pipeline            # noqa: E402
import dr200               # noqa: E402  (Diseño de Registro: declaración completa en ancho fijo, D20/5.B)
import formal200           # noqa: E402  (datos formales DP200002/DP200002B)
import normalizador_pgc    # noqa: E402  (ingesta de precisión D12)
import extractor_contable  # noqa: E402  (extracción layout + provenance D12)
import clasificador        # noqa: E402  (clasificación de documento D12)
import extractor_ccaa      # noqa: E402  (extracción PDF/cuentas anuales D12)
import extractor_markdown  # noqa: E402  (partidas desde el Markdown del OCR D14+)
import generar_sys_a3 as _gen_a3  # noqa: E402  (CASO B: CCAA->A3 determinista, T1.2.3; alias para no colisionar)
import calcular_liquidacion  # noqa: E402  (plugin fiscal)
import harness_estado        # noqa: E402
import motor_auditoria       # noqa: E402  (auditoría D11)
import motor_expediente      # noqa: E402  (orquestador canónico F3: M2→M3→M4 + lineage + traza, T1.1)
import motor_triaje_art15    # noqa: E402  (triaje art.15, T1.1)
import motor_calculo_aeat    # noqa: E402  (tipos_por_regimen para resolver el tipo, T1.1 fix)
import validacion_contable    # noqa: E402  (pre-import Fase A, Epic 3)
import estado_expediente       # noqa: E402  (lógica del recorrido del expediente, wiring W1)
import motor_servicio          # noqa: E402  (fachada motor "listo para hospedar", wiring W4)

import tablas_salida       # noqa: E402  (tablas de salida de la ingesta D14)

from engine_service import ocr_client  # noqa: E402  (Opción 1: OCR por HTTP, D14)
from engine_service.seam import contable_a_inputs_liquidacion, cent  # noqa: E402

ROOT = engine_service.ROOT


def _campaign_paths(ejercicio):
    return campaign.resolve(str(ejercicio))


_IMPORTABLES_200_CACHE = {}


def _casillas_importables_200(ejercicio):
    """Set de casillas CONTABLES que el importador AEAT ACEPTA: las del esquema XSD oficial (`xsd_campos`).
    Se usa para PODAR de la ECPN del `.200` las casillas calculadas/no-importables (00632/00645/00500/00355…)
    que Sociedades WEB rechaza con «no puede tener contenido» (confirmado en el reimport REDEVCO 2026-06-28).
    Es el MISMO criterio que ya aplica el XML contable en `builder.construir_xml`. Fail-soft: None si no se
    resuelve la campaña (no se poda → comportamiento previo). Cacheado por ejercicio."""
    ej = str(ejercicio)
    if ej in _IMPORTABLES_200_CACHE:
        return _IMPORTABLES_200_CACHE[ej]
    res = None
    try:
        imp = set()
        for _cs in json.load(open(_campaign_paths(ej)["xsd_campos"], encoding="utf-8"))["paginas"].values():
            imp |= set(_cs)
        res = imp
    except Exception:   # noqa: BLE001  sin campaña resoluble → no podar
        res = None
    _IMPORTABLES_200_CACHE[ej] = res
    return res


def extraer_texto_ccaa(path):
    """Texto del Balance de la CCAA para alimentar la APERTURA del ECPN (`ecpn_sys.componentes_desde_ccaa_texto`)
    cuando el SyS no trae saldo de apertura. Soporta DOCX, PDF-portfolio (extrae los PDF EMBEBIDOS) y PDF normal.
    Devuelve '' si no hay texto (escaneado sin OCR) -> el llamador cae al comportamiento previo. 0 PII."""
    path_s = str(path or "")
    if path_s.lower().endswith(".docx"):
        try:
            from docx import Document
            doc = Document(path_s)
            partes = []
            for t in doc.tables:
                for row in t.rows:
                    vals = [c.text.replace("\n", " ").strip() for c in row.cells]
                    if any(vals):
                        partes.append(" ".join(vals))
            partes.extend(p.text.strip() for p in doc.paragraphs if p.text.strip())
            return "\n".join(partes)
        except Exception:   # noqa: BLE001
            return ""
    try:
        import io
        from pypdf import PdfReader
    except Exception:   # noqa: BLE001
        return ""
    try:
        r = PdfReader(path)
    except Exception:   # noqa: BLE001
        return ""
    cand = []
    try:
        att = getattr(r, "attachments", None) or {}
        for nombre, blobs in att.items():
            if str(nombre).lower().endswith(".pdf"):
                blob = blobs[0] if isinstance(blobs, list) else blobs
                try:
                    rr = PdfReader(io.BytesIO(blob))
                    cand.append("\n".join((p.extract_text() or "") for p in rr.pages))
                except Exception:   # noqa: BLE001
                    pass
    except Exception:   # noqa: BLE001
        pass
    if not cand:
        try:
            cand.append("\n".join((p.extract_text() or "") for p in r.pages))
        except Exception:   # noqa: BLE001
            return ""
    # Preferir el documento que contenga el bloque de PN del balance.
    for t in cand:
        if "PATRIMONIO NETO" in (t or "").upper():
            return t
    return cand[0] if cand else ""


class ConfirmacionHitlRequerida(Exception):
    """Gate HITL server-side (Codex HIGH T1.2): se intentó emitir el XML mod200 desde un canónico
    INFERIDO de las CCAA (exportable_a_importador:false) sin confirmación humana (a3_confirmado is True).
    Centraliza el bloqueo en el chokepoint (`emitir_mod200`), así NINGUNA ruta (/emitir-mod200,
    /expediente/paquete, …) firma un número inferido de OCR sin que un humano lo asuma."""


class CaracterRegimenIncoherente(Exception):
    """Guarda fiscal (Garrigues 2026-06-22): la declaración trae un CARÁCTER de régimen especial
    (00006 pyme · 00088 · 00012 SOCIMI · 00004 IIC) pero el régimen con el que se firmaría NO es ese
    régimen especial → se bloquea, para que una pyme/SOCIMI/IIC no se firme como general al 25%.
    Complementa `tipo_disponible` (que bloquea por RÉGIMEN no soportado): aquí se caza la INCOHERENCIA
    carácter↔régimen (un carácter especial firmándose como general/ETVE)."""


# Gate fail-closed de cuadre (B3): excepción ÚNICA en reconciliador (chokepoint del cuadre); se re-exporta
# aquí para que `engines.CanonicoDescuadradoError` (endpoint + tests) siga funcionando.
CanonicoDescuadradoError = reconciliador.CanonicoDescuadradoError


# ----------------------------------------------------------------- Contable (EPC)
def proyectar_contable(canonico_csv: str, ejercicio="2024", fuente_canonico=None, a3_confirmado=False) -> dict:
    """Canónico 4d (ruta CSV) -> casillas contables (incl. 00500) + cuadre. builder.proyectar.

    GATE HITL (Codex HIGH T1.2): proyecta el **resultado contable 00500** (que puede alimentar
    facts.resultado_contable de /firmar). Si el canónico es INFERIDO de las CCAA y no hay confirmación
    humana, se levanta `ConfirmacionHitlRequerida` — así la cadena CCAA→proyección→firma no cuela un
    número de OCR sin que un humano lo asuma. (El front no usa esta ruta para el preview; usa Fase A.)
    """
    try:
        with open(canonico_csv, encoding="utf-8") as _fh:
            _contenido = _fh.read()
    except OSError:
        _contenido = ""
    if (_es_canonico_inferido(_contenido) or fuente_canonico == "ccaa_a3") and a3_confirmado is not True:
        raise ConfirmacionHitlRequerida(
            "Canónico INFERIDO de las CCAA (exportable_a_importador:false): requiere confirmación HITL "
            "del A3 (a3_confirmado) antes de proyectar el resultado 00500 — gate server-side (Codex HIGH T1.2).")
    paths = _campaign_paths(ejercicio)
    mapeo = json.load(open(paths["mapeo"], encoding="utf-8"))
    catalogo = json.load(open(paths["catalogo"], encoding="utf-8"))
    canonico = builder.cargar_canonico(canonico_csv)
    # GATE FAIL-CLOSED de cuadre (B3, Codex): /proyectar-contable devuelve el 00500 que puede alimentar
    # facts.resultado_contable de /firmar. Un canónico descuadrado (incl. 0,01) NO debe proyectar un número
    # firmable -> CanonicoDescuadradoError (endpoint -> 422). Cierra la cadena proyección→firma.
    reconciliador.exigir_cuadre(canonico)
    casillas, lineage, cuadre, _pyg, _sec = builder.proyectar(canonico, mapeo, catalogo)
    reconciliador.exigir_cuadre_proyeccion(cuadre)  # B3: no proyectar 00500 de un balance AEAT descuadrado
    return {"casillas": casillas, "cuadre": cuadre}


def emitir_mod200(canonico_csv: str, outdir: str, empresa="", ejercicio="2024",
                  fuente_canonico=None, a3_confirmado=False,
                  perfil_estados_abreviado=None, perfil_estados_pymes=None) -> dict:
    """Canónico -> XML de IMPORTACIÓN DE DATOS CONTABLES (balance/PyG/ECPN) + validación XSD.

    Es EXACTAMENTE el fichero que importa Sociedades WEB ("Importación de datos contables",
    conforme a mod2002024.xsd). **SOLO contable**: la liquidación (BI, cuota, ajustes) NO va aquí —
    la herramienta AEAT solo incorpora balance, cuenta de PyG y ECPN; el resto de la declaración se
    cumplimenta aparte. (Importante: casillas como 00552/00562/00621 en el bloque ECPN son campos de
    patrimonio neto — "Acciones propias"/"Escriturado"/"Reservas" — NO la base imponible/cuota; por eso
    NUNCA se inyecta la liquidación en este XML.)

    GATE HITL (Codex HIGH T1.2): `canonico_csv` es la RUTA del fichero; si su contenido lleva el centinela
    de inferencia CCAA (o se declara `fuente_canonico='ccaa_a3'`) y NO hay `a3_confirmado is True`, se
    levanta `ConfirmacionHitlRequerida` ANTES de construir el XML. Chokepoint: cubre todas las rutas.
    """
    try:
        with open(canonico_csv, encoding="utf-8") as _fh:
            _contenido = _fh.read()
    except OSError:
        _contenido = ""
    if (_es_canonico_inferido(_contenido) or fuente_canonico == "ccaa_a3") and a3_confirmado is not True:
        raise ConfirmacionHitlRequerida(
            "Canónico INFERIDO de las CCAA (exportable_a_importador:false): requiere confirmación HITL "
            "del A3 (a3_confirmado) antes de emitir el XML mod200 firmado — gate server-side (Codex HIGH T1.2).")
    paths = _campaign_paths(ejercicio)
    mapeo = json.load(open(paths["mapeo"], encoding="utf-8"))
    catalogo = json.load(open(paths["catalogo"], encoding="utf-8"))
    canonico = builder.cargar_canonico(canonico_csv)
    # GATE FAIL-CLOSED de cuadre (B3 / EPIC B): un canónico descuadrado NO firma el XML (Σdebe=Σhaber,
    # Σdeudor=Σacreedor, SI+debe−haber=SF). Chokepoint: cubre /emitir-mod200 y /expediente/paquete.
    _rec = reconciliador.reconciliar(canonico)
    if not _rec["ok"]:
        raise CanonicoDescuadradoError("Canónico descuadrado (no firma el XML): " + "; ".join(_rec["errores"]))
    casillas, _lin, cuadre, _pyg, _sec = builder.proyectar(canonico, mapeo, catalogo)
    reconciliador.exigir_cuadre_proyeccion(cuadre)  # B3: balance AEAT proyectado debe cuadrar (no_map/dif)
    xsd_campos = json.load(open(paths["xsd_campos"], encoding="utf-8"))
    casillas_xml = _aplicar_perfil_para_xml(casillas, str(ejercicio), perfil_estados_abreviado, perfil_estados_pymes)
    xml = builder.construir_xml(casillas_xml, xsd_campos, mapeo=mapeo)
    xml_path = os.path.join(outdir, f"modelo200_contable_{ejercicio}.xml")
    with open(xml_path, "wb") as fh:
        fh.write(xml.encode("iso-8859-1", "replace"))
    val = validador.validar(xml_path, paths["catalogo"], paths.get("xsd"))
    # XSD provisional vs oficial: si la campaña marca `provisional` (p.ej. 2025 = casillas 2024,
    # pendiente del mod2002025.xsd OFICIAL), NO se debe presentar como validado contra el oficial.
    prov = paths.get("provisional") or {}
    return {
        "xml_path": xml_path,
        "xml": xml,
        "validacion": val,
        "valido_xsd": "válido" in str(val.get("xsd", "")),
        "xsd_provisional": bool(prov),
        "xsd_fuente": "provisional (= casillas del ejercicio base; pendiente XSD OFICIAL AEAT)" if prov else "oficial",
        "cuadre": cuadre,
        "n_casillas_contables": sum(1 for c in casillas_xml if casillas_xml.get(c) is not None),
        "casillas_xml": casillas_xml,
    }


def _normalizar_contable_casillas(contable_casillas) -> dict[str, float]:
    out = {}
    for k, v in (contable_casillas or {}).items():
        cas = str(k).strip().zfill(5)
        if not cas.isdigit():
            continue
        if v in (None, ""):
            continue
        try:
            out[cas] = round(float(str(v).replace(",", ".")), 2)
        except (TypeError, ValueError):
            continue
    return out


def _checks_contable_directo(casillas: dict[str, float], tolerancia=0.01) -> list[dict]:
    def _n(c):
        try:
            return round(float(casillas.get(c, 0.0)), 2)
        except (TypeError, ValueError):
            return 0.0
    dif_bal = round(_n("00180") - _n("00252"), 2)
    dif_res = round(_n("00199") - _n("00500"), 2)
    return [
        {"regla": "balance_cuadra", "ok": abs(dif_bal) <= tolerancia,
         "detalle": f"00180 - 00252 = {dif_bal:.2f}"},
        {"regla": "resultado_balance_pyg", "ok": abs(dif_res) <= tolerancia,
         "detalle": f"00199 - 00500 = {dif_res:.2f}"},
    ]


_PAGINAS_CONTABLES_200 = ("DP200003", "DP200004", "DP200005", "DP200006", "DP200007", "DP200008")


def _casillas_contables_desde_200(path: str) -> dict[str, float]:
    """Casillas 3-8 de un `.200` ya emitido, para usar el balance N-1 como apertura del ECPN."""
    if not path or not str(path).lower().endswith(".200") or not os.path.exists(str(path)):
        return {}
    try:
        import modelo200_parser as _mp
        parsed = _mp.parse(str(path), include_fields=True)
        cpp = _mp.casillas_por_pagina(parsed, significant_only=False)
    except Exception:   # noqa: BLE001  precarga best-effort
        return {}
    out = {}
    for page in _PAGINAS_CONTABLES_200:
        for cas, entries in (cpp.get(page) or {}).items():
            if not entries:
                continue
            try:
                out[str(cas).zfill(5)] = round(float(entries[0].get("valor") or 0.0), 2)
            except (TypeError, ValueError):
                continue
    return out


def _casillas_pagina_desde_200(path: str, paginas: tuple[str, ...]) -> dict[str, dict[str, float]]:
    if not path or not str(path).lower().endswith(".200") or not os.path.exists(str(path)):
        return {}
    try:
        import modelo200_parser as _mp
        parsed = _mp.parse(str(path), include_fields=True)
        cpp = _mp.casillas_por_pagina(parsed, significant_only=True)
    except Exception:   # noqa: BLE001  precarga best-effort
        return {}
    out: dict[str, dict[str, float]] = {}
    for page in paginas:
        vals = {}
        for cas, entries in (cpp.get(page) or {}).items():
            if not entries:
                continue
            try:
                vals[str(cas).zfill(5)] = round(float(entries[0].get("valor") or 0.0), 2)
            except (TypeError, ValueError):
                continue
        if vals:
            out[page] = vals
    return out


def _foral_page26_desde_n1(precarga_n1, liq: dict, ejercicio: str):
    """Pagina 26 minima desde N-1: porcentajes/volumenes estables + importes 2025 recalculados.

    Es una ayuda de importabilidad, no una liquidacion fiscal firmada: no arrastra deducciones ni ajustes de N-1.
    """
    p26_prev = _casillas_pagina_desde_200(str(precarga_n1 or ""), ("DP200026",)).get("DP200026") or {}
    if not p26_prev:
        return {}, {}, []

    def _n(src, key):
        try:
            return float(str((src or {}).get(key) or 0).replace(",", "."))
        except (TypeError, ValueError):
            return 0.0

    pct_estado_raw = _n(p26_prev, "00625")
    pct_foral_by_admin = {
        "araba": _n(p26_prev, "00626"),
        "gipuzkoa": _n(p26_prev, "00627"),
        "bizkaia": _n(p26_prev, "00628"),
        "navarra": _n(p26_prev, "00629"),
    }
    pct_foral_raw = sum(pct_foral_by_admin.values())
    if pct_estado_raw + pct_foral_raw <= 0:
        return {}, {}, []
    pct_estado = pct_estado_raw / 100.0
    pct_foral = pct_foral_raw / 100.0
    base_cuota = _n(liq, "00592") - _n(liq, "01766") - _n(liq, "01784")
    estado = round(base_cuota * pct_estado / 100.0, 2)
    foral = round(base_cuota - estado, 2)
    pagos_estado = _n(liq, "00601") + _n(liq, "00603") + _n(liq, "00605")
    pagos_foral = _n(liq, "00602") + _n(liq, "00604") + _n(liq, "00606")
    dif_estado = round(estado - pagos_estado, 2)
    dif_foral = round(foral - pagos_foral, 2)
    detalle = {"DP200026": {}}

    def _repartir(total, pesos):
        total = round(float(total or 0.0), 2)
        activos = [(k, float(v or 0.0)) for k, v in pesos.items() if float(v or 0.0) > 0]
        if not activos:
            return {k: 0.0 for k in pesos}
        suma = sum(v for _, v in activos)
        out = {k: 0.0 for k in pesos}
        acum = 0.0
        for k, v in activos[:-1]:
            val = round(total * v / suma, 2)
            out[k] = val
            acum += val
        out[activos[-1][0]] = round(total - acum, 2)
        return out

    cuota_admin = _repartir(foral, pct_foral_by_admin)
    pagos1_admin = _repartir(_n(liq, "00602"), pct_foral_by_admin)
    pagos2_admin = _repartir(_n(liq, "00604"), pct_foral_by_admin)
    pagos3_admin = _repartir(_n(liq, "00606"), pct_foral_by_admin)
    dif_admin = {
        k: round(cuota_admin[k] - pagos1_admin[k] - pagos2_admin[k] - pagos3_admin[k], 2)
        for k in pct_foral_by_admin
    }
    for c in ("00050", "00051", "00052", "00053", "00054", "00055", "00056",
              "00625", "00626", "00627", "00628", "00629"):
        if c in p26_prev:
            detalle["DP200026"][c] = (p26_prev[c] / 100.0) if c in {"00625", "00626", "00627", "00628", "00629"} else p26_prev[c]
    provincial = {
        # Cuota del ejercicio a ingresar/devolver.
        "00420": cuota_admin["araba"], "00421": cuota_admin["gipuzkoa"],
        "00426": cuota_admin["bizkaia"], "00427": cuota_admin["navarra"],
        # Pagos fraccionados 1/2/3, si existen en la liquidacion provisional.
        "00402": pagos1_admin["araba"], "00442": pagos1_admin["gipuzkoa"],
        "00443": pagos1_admin["bizkaia"], "00444": pagos1_admin["navarra"],
        "00445": pagos2_admin["araba"], "00446": pagos2_admin["gipuzkoa"],
        "00447": pagos2_admin["bizkaia"], "00448": pagos2_admin["navarra"],
        "00449": pagos3_admin["araba"], "00450": pagos3_admin["gipuzkoa"],
        "00451": pagos3_admin["bizkaia"], "00465": pagos3_admin["navarra"],
        # Cuota diferencial, resultado de autoliquidacion y resultado final.
        "00474": dif_admin["araba"], "00475": dif_admin["gipuzkoa"],
        "00476": dif_admin["bizkaia"], "00477": dif_admin["navarra"],
        "01624": dif_admin["araba"], "01625": dif_admin["gipuzkoa"],
        "01629": dif_admin["bizkaia"], "01630": dif_admin["navarra"],
        "00494": dif_admin["araba"], "00495": dif_admin["gipuzkoa"],
        "00496": dif_admin["bizkaia"], "00497": dif_admin["navarra"],
    }
    for c, v in {**provincial, "00600": foral, "00612": dif_foral, "01587": dif_foral, "00622": dif_foral}.items():
        detalle["DP200026"][c] = v
    liq_updates = {
        "00599": estado, "00600": foral,
        "00611": dif_estado, "00612": dif_foral,
        "01586": dif_estado, "01587": dif_foral,
        "00621": dif_estado, "00622": dif_foral,
    }
    avisos = [
        "Página 26 foral generada para importabilidad: porcentajes/volúmenes arrastrados del .200 N-1 "
        f"({pct_estado:.2f}% Estado / {pct_foral:.2f}% Foral) e importes 2025 recalculados desde 00592. "
        "No arrastra deducciones ni ajustes de N-1; revisar fiscalmente en Sociedades WEB."
    ]
    return liq_updates, detalle, avisos


def _componentes_pn_desde_balance_200(casillas: dict[str, float]) -> tuple[dict[str, float], dict]:
    """Balance Modelo 200 -> componentes ECPN en convención PN-positiva.

    La fuente es el balance oficial ya formulado. Se pliegan las partidas sin columna propia robusta en el ECPN
    (resultados anteriores, acciones propias, otras aportaciones, dividendo a cuenta) dentro de reservas, igual
    que la ruta CCAA. No suma detalles ya incluidos en subtotales.
    """
    cas = _normalizar_contable_casillas(casillas)

    def n(c):
        return float(cas.get(c, 0.0) or 0.0)

    reservas_base = n("00191") if abs(n("00191")) >= 0.01 else n("00192") + n("00193")
    ajustes_pn = n("00208") if abs(n("00208")) >= 0.01 else n("00209")
    comp = {
        "capital": n("00187") if abs(n("00187")) >= 0.01 else n("00188") - n("00189"),
        "prima": n("00190"),
        "reservas": reservas_base + n("00194") + n("00195") + n("00196") + n("00197")
                    + n("00198") + n("00200") + n("00201"),
        "resultado_prev": n("00199"),
        "ajustes": n("00202") + ajustes_pn,
    }
    total_componentes = round(sum(comp.values()), 2)
    total_balance = round(n("00185"), 2)
    return {k: round(v, 2) for k, v in comp.items()}, {
        "pn_balance": total_balance,
        "pn_componentes": total_componentes,
        "dif": round(total_balance - total_componentes, 2),
    }


def _ecpn_desde_contable_directo(contable_dr: dict[str, float], precarga_n1, resultado=None):
    """ECPN normal para Balance/PyG agregado: apertura = balance del `.200` N-1; cierre = balance actual."""
    prev = _casillas_contables_desde_200(str(precarga_n1 or ""))
    if not prev:
        return None, ["ECPN normal no proyectado: no hay `.200` N-1 legible para tomar la apertura del PN."]
    ap, ctrl_ap = _componentes_pn_desde_balance_200(prev)
    ci, ctrl_ci = _componentes_pn_desde_balance_200(contable_dr)
    avisos = []
    if abs(ctrl_ap["dif"]) > 0.01 or abs(ctrl_ci["dif"]) > 0.01:
        avisos.append("ECPN normal no proyectado: los componentes de PN no reconcilian con 00185 "
                      f"(N-1 dif={ctrl_ap['dif']:.2f}; N dif={ctrl_ci['dif']:.2f}).")
        return None, avisos
    try:
        import ecpn_sys
        r = float(resultado) if resultado not in (None, "") else ci.get("resultado_prev", 0.0)
        paginas, av, _ctrl = ecpn_sys.proyectar_desde_balance(ap, ci, r)
        paginas = {pg: cas for pg, cas in (paginas or {}).items() if cas} or None
        avisos.extend(av or [])
        if paginas:
            avisos.append("ECPN normal proyectado desde Balance N y `.200` N-1: apertura=PN N-1, "
                          "cierre=PN N, sin usar movimientos inferidos.")
        return paginas, avisos
    except Exception as e:   # noqa: BLE001
        return None, [f"ECPN normal no proyectado desde balance N/N-1: {type(e).__name__}: {e}"]


def _familias_perfil_desde_pagina01b(pagina01b, perfil_estados_abreviado=None, perfil_estados_pymes=None):
    pagina01b = pagina01b or {}
    abrev = set(perfil_estados_abreviado or ())
    pymes = set(perfil_estados_pymes or ())

    def _v(num):
        return str(pagina01b.get(num, pagina01b.get(str(num), ""))).strip()

    if _v(14) == "2":
        abrev.add("balance")
    elif _v(14) == "3":
        pymes.add("balance")
    if _v(16) == "2":
        abrev.add("pyg")
    elif _v(16) == "3":
        pymes.add("pyg")
    # ECPN en abreviado/PYMES es voluntario y el .200 lo omite: no se autoactiva desde el N-1.
    return tuple(sorted(abrev)), tuple(sorted(pymes))


def _aplicar_perfil_para_xml(casillas: dict[str, float], ejercicio: str,
                             perfil_estados_abreviado=None, perfil_estados_pymes=None) -> dict[str, float]:
    out = {k: v for k, v in (casillas or {}).items()}
    if not (perfil_estados_abreviado or perfil_estados_pymes):
        return out
    import transformar_xml_abreviado as _abrev
    if perfil_estados_abreviado:
        out, _inf = _abrev.aplicar_perfil_estados_contables(
            {k: str(v) for k, v in out.items()}, familias=tuple(sorted(perfil_estados_abreviado)),
            ejercicio=str(ejercicio), perfil="abreviado", mantener_calculadas=False)
    if perfil_estados_pymes:
        out, _inf = _abrev.aplicar_perfil_estados_contables(
            {k: str(v) for k, v in out.items()}, familias=tuple(sorted(perfil_estados_pymes)),
            ejercicio=str(ejercicio), perfil="pymes", mantener_calculadas=False)
    return _normalizar_contable_casillas(out)


def emitir_mod200_desde_casillas(contable_casillas: dict, outdir: str, empresa="", ejercicio="2025",
                                 perfil_estados_abreviado=None, perfil_estados_pymes=None) -> dict:
    """Casillas contables ya agregadas -> XML mod200 contable + validación XSD.

    Ruta para expedientes que traen Balance/PyG formulado por partidas, no SyS/A3. No reemplaza el camino
    canonico; solo evita fabricar cuentas PGC artificiales cuando la fuente ya viene a nivel de casilla.
    """
    paths = _campaign_paths(ejercicio)
    mapeo = json.load(open(paths["mapeo"], encoding="utf-8"))
    catalogo = json.load(open(paths["catalogo"], encoding="utf-8"))
    casillas = _normalizar_contable_casillas(contable_casillas)
    checks = _checks_contable_directo(casillas)
    if not all(c["ok"] for c in checks):
        raise CanonicoDescuadradoError("Casillas contables directas descuadradas: "
                                       + "; ".join(c["detalle"] for c in checks if not c["ok"]))
    xsd_campos = json.load(open(paths["xsd_campos"], encoding="utf-8"))
    casillas_xml = _aplicar_perfil_para_xml(casillas, str(ejercicio), perfil_estados_abreviado, perfil_estados_pymes)
    xml = builder.construir_xml(casillas_xml, xsd_campos, mapeo=mapeo)
    xml_path = os.path.join(outdir, f"modelo200_contable_{ejercicio}.xml")
    with open(xml_path, "wb") as fh:
        fh.write(xml.encode("iso-8859-1", "replace"))
    val = validador.validar(xml_path, paths["catalogo"], paths.get("xsd"))
    prov = paths.get("provisional") or {}
    return {
        "xml_path": xml_path,
        "xml": xml,
        "validacion": val,
        "valido_xsd": "válido" in str(val.get("xsd", "")),
        "xsd_provisional": bool(prov),
        "xsd_fuente": "provisional (= casillas del ejercicio base; pendiente XSD OFICIAL AEAT)" if prov else "oficial",
        "cuadre": {"total_activo": casillas.get("00180"), "total_pnpasivo": casillas.get("00252"),
                   "dif": round(float(casillas.get("00180", 0)) - float(casillas.get("00252", 0)), 2),
                   "resultado": casillas.get("00500"), "n_casillas": len(casillas)},
        "n_casillas_contables": len(casillas_xml),
        "casillas_xml": casillas_xml,
    }


def _redactar_resultado_00500(report: dict) -> dict:
    """Oculta el VALOR del resultado contable 00500 en el informe de Fase A (Codex HIGH T1.2): se conserva
    `apto`/`semaforo` (el preview HITL los necesita) pero se redacta el número, que si no podría leerse de
    /validar-contable y colarse en facts.resultado_contable de /firmar sin confirmar el A3 inferido."""
    redact = "Resultado del ejercicio (00500)=[oculto: requiere confirmación HITL del A3 inferido de CCAA]"
    checks = [({**c, "detalle": redact} if c.get("regla") == "resultado_presente" else c)
              for c in report.get("checks", [])]
    return {**report, "checks": checks,
            "motivos": [c["detalle"] for c in checks if not c.get("ok")],
            "numero_redactado_hitl": True}


def validar_contable(canonico_csv: str, tipo_entidad="normal", ejercicio="2024",
                     fuente_canonico=None, a3_confirmado=False) -> dict:
    """Canónico -> proyección contable -> informe 'apto para importar' (Fase A, Epic 3).

    Comprueba las identidades contables (balance 00180=00252, resultado presente) y el formato DR200
    ANTES de emitir/validar el XML contra el XSD. Es el gate de la Fase A (importador de datos contables).

    GATE HITL (Codex HIGH T1.2): el front usa esta ruta para el PREVIEW del CCAA inferido, así que NO se
    bloquea (a diferencia de proyectar/emitir); pero si el canónico es inferido sin confirmar se REDACTA el
    valor del 00500 del informe (no debe poder extraerse para firmar sin que un humano asuma el A3).
    """
    paths = _campaign_paths(ejercicio)
    mapeo = json.load(open(paths["mapeo"], encoding="utf-8"))
    catalogo = json.load(open(paths["catalogo"], encoding="utf-8"))
    canonico = builder.cargar_canonico(canonico_csv)
    casillas, _lin, cuadre, _pyg, _sec = builder.proyectar(canonico, mapeo, catalogo)
    vf = None
    vf_path = os.path.join(paths.get("dir", ""), "validaciones_formato.json")
    if os.path.exists(vf_path):
        vf = json.load(open(vf_path, encoding="utf-8"))
    report = validacion_contable.validar(
        casillas, cuadre, tipo_entidad=tipo_entidad, validaciones_formato=vf, ejercicio=str(ejercicio)
    )
    # Cuadre cent-exact (B3, Codex): un canónico descuadrado NO es 'apto para importar' (consistencia con
    # los emisores AEAT, que lo bloquean). No se levanta: es el PREVIEW Fase A -> se devuelve apto=False con
    # el motivo para que el front lo muestre. GIP/SyS reales cuadran cent-exact (siguen apto).
    # Cuadre BRUTO del canónico (Σdebe=Σhaber, Σdeudor=Σacreedor) + cuadre de la PROYECCIÓN AEAT (balance
    # 00180=00252, sin no_map): cualquiera que falle => NO apto (un canónico raw-cuadrado puede proyectar un
    # balance descuadrado o dejar cuentas sin mapear — Codex B3).
    _rec = reconciliador.reconciliar(builder.cargar_canonico(canonico_csv))
    _proj_ok, _proj_err = reconciliador.cuadre_proyeccion(cuadre)
    report["reconciliacion"] = {"ok": _rec["ok"] and _proj_ok,
                                "errores": _rec["errores"] + _proj_err, "avisos": _rec.get("avisos", [])}
    if not (_rec["ok"] and _proj_ok):
        report["apto"] = False
        report["motivos"] = list(report.get("motivos", [])) + _rec["errores"] + _proj_err
        report["semaforo"] = "🔴"
    try:
        with open(canonico_csv, encoding="utf-8") as _fh:
            _contenido = _fh.read()
    except OSError:
        _contenido = ""
    # REDACTA el 00500 si NO es apto (cualquier causa: bruto/proyección descuadrados) o es inferido de CCAA
    # sin confirmar (HITL, T1.3): un preview no-apto no debe filtrar el resultado proyectable para colarlo en
    # facts.resultado_contable de /firmar. (El binding provenance→/firmar es Fase 2; aquí se cierra la fuga.)
    _hitl = (_es_canonico_inferido(_contenido) or fuente_canonico == "ccaa_a3") and a3_confirmado is not True
    if _hitl or not report["apto"]:
        report = _redactar_resultado_00500(report)
    return report


def fase_a_desde_sys(sys_path: str, tipo_entidad="normal", ejercicio="2024") -> dict:
    """SyS -> proyección contable -> informe Fase A 'apto para importar' (W6).

    Reúne el pipeline contable (run_pipeline produce `agrupado_4d.csv`) con el validador inter-casilla
    (Epic 3). Es el cuadre fuerte (balance 00180=00252) del paso 1 del expediente, además del Σdebe=Σhaber.
    """
    with tempfile.TemporaryDirectory() as td:
        man = run_pipeline([sys_path], td, ejercicio=ejercicio)
        agr = os.path.join(td, "agrupado_4d.csv")
        if not os.path.exists(agr):
            return {
                "apto": False,
                "semaforo": "🔴",
                "motivos": [f"No se pudo proyectar el SyS (pipeline: {man.get('estado')})."],
                "checks": [],
                "estado_pipeline": man.get("estado"),
                "canonico_csv": None,
            }
        res = validar_contable(agr, tipo_entidad=tipo_entidad, ejercicio=ejercicio)
        res["estado_pipeline"] = man.get("estado")
        # Canónico 4d REAL (gap#3): lo devolvemos para que el paquete (paso 5) use ESTA contabilidad,
        # no DEMO_CANONICO. Es el mismo CSV que consume emitir_mod200.
        try:
            with open(agr, encoding="utf-8") as fh:
                res["canonico_csv"] = fh.read()
        except OSError:
            res["canonico_csv"] = None
        return res


def run_pipeline(docs, outdir, empresa="", ejercicio="2024") -> dict:
    """Pipeline contable completo (motor_sys+builder+validador). Captura SystemExit."""
    try:
        return pipeline.run(list(docs), outdir, empresa=empresa, ejercicio=str(ejercicio))
    except SystemExit as e:  # los motores hacen raise SystemExit ante input inválido
        return {"estado": "error", "error": f"SystemExit: {e}"}
    except Exception as e:  # noqa: BLE001
        return {"estado": "error", "error": f"{type(e).__name__}: {e}"}


# ----------------------------------------------------------------- Fiscal (plugin)
def liquidar(facts: dict, issues: list) -> dict:
    """facts+issues -> liquidación (BI, cuota, casillas). calcular_liquidacion.calcular.

    Resuelve régimen (minúsculas) + tipo de gravamen ANTES del plugin para que /liquidar (red de
    coherencia) coincida con el orquestador (/firmar): sin esto, para régimenes no-general sin
    `tipo_gravamen` explícito el plugin caería a 0,25 (ignora el régimen) y divergiría de la firma.
    """
    facts = dict(facts or {})
    regimen = str(facts.get("regimen") or "general").strip().lower()
    facts["regimen"] = regimen
    if facts.get("tipo_gravamen") is None:
        facts["tipo_gravamen"] = _resolver_tipo(facts, regimen, facts.get("ejercicio", "2024"))
    return calcular_liquidacion.calcular(facts, issues or [])


def firma_desde_liquidacion(liq: dict) -> dict:
    """DEPRECADA (Codex HIGH): suma los importes de LÍNEA del plugin como valores de casilla, así que casillas
    como 00547 (compensación BINs) salen con el signo de la línea (-comp) en vez del valor de casilla (+comp).
    Sin llamantes: toda firma pasa por `firma_desde_orquestado`. Conservada solo por compatibilidad; NO usar."""
    # calcular_liquidacion emite varias líneas con la misma casilla (p.ej. el rango
    # "00301..00414" aparece 3 veces): agregar por suma evita pérdida de datos y hace
    # el hash determinista (un dict-comprehension dejaría solo la última línea).
    casillas: dict = {}
    for ln in liq.get("lineas", []):
        c = ln.get("casilla")
        imp = ln.get("importe")
        if not c or imp is None:
            continue
        try:
            casillas[c] = round(float(casillas.get(c, 0.0)) + float(imp), 2)
        except (TypeError, ValueError):
            casillas[c] = imp
    firma_hash = hashlib.sha256(
        json.dumps(casillas, sort_keys=True, default=str).encode()
    ).hexdigest()[:16]
    return {
        "base_imponible": liq.get("base_imponible"),
        "cuota_integra": liq.get("cuota_integra"),
        "cuota_liquida": liq.get("cuota_liquida"),
        "cuota_a_ingresar": liq.get("cuota_a_ingresar"),
        "casillas": casillas,
        "hash": firma_hash,
        "autoridad": "python (cerebro canónico ADR-001)",
    }


# --------------------------------------------------- Orquestador canónico (Fase 1, T1.1)
def _resolver_tipo(facts: dict, regimen: str, ejercicio="2024"):
    """Tipo de gravamen EXPLÍCITO: `facts.tipo_gravamen` si viene; si no, el del régimen
    (`tipos_por_regimen` del ejercicio); fallback 0,25. Unifica el tipo entre /liquidar (plugin) y el
    orquestador para que NO diverja por régimen. Los tipos POR EJERCICIO viven en
    rules/parametros/{ejercicio}.yaml (p. ej. 2024: SOCIMI 0,00 · PYMES 0,23 · general·ETVE 0,25; ERD/pymes
    2025 = 0,24 por Ley 7/2024 DT 44ª cuando se desbloquea la matriz)."""
    t = (facts or {}).get("tipo_gravamen")
    if t is not None:
        return t
    par = motor_calculo_aeat.cargar_parametros(str(ejercicio))
    return par.get("tipos_por_regimen", {}).get(str(regimen).strip().lower(), 0.25)


def tipo_disponible(regimen, ejercicio="2024") -> bool:
    """¿Hay tipo de gravamen CONOCIDO para (régimen, ejercicio)? 'general' siempre (25%); el resto exige
    matriz `tipos_por_regimen` en rules/parametros/{ejercicio}.yaml. Fail-closed: sin matriz un régimen
    especial NO debe firmarse con el 0,25 por defecto (Codex HIGH: 2025 sin params firmaba SOCIMI al 25%)."""
    reg = str(regimen or "general").strip().lower()
    if reg == "general":
        return True
    tipos = motor_calculo_aeat.cargar_parametros(str(ejercicio)).get("tipos_por_regimen", {})
    return reg in tipos


# Carácter de la declaración (Modelo 200) -> régimen especial que IMPLICA. Si el carácter aparece pero el
# régimen con el que se firma NO es ese, hay incoherencia (p.ej. una pyme firmándose como general 25%).
# 00088 = carácter de régimen especial (Garrigues 2026-06-22): mapeado a un régimen no-soportado para que
# su sola presencia bloquee mientras no esté validado.
CARACTER_REGIMEN_ESPECIAL = {
    "00006": "pymes",              # reducida dimensión (art.101)
    "00088": "regimen_especial",   # carácter de régimen especial (no soportado hasta validar)
    "00012": "socimi",
    "00004": "fondos",             # IIC
}


def _regimen_desde_caracteres(caracteres, ejercicio="2024") -> str:
    """Régimen IMPLÍCITO por los caracteres de la declaración, para fijar el TIPO de la base cosmética (00562)
    en `exportar_base` (que no recibe régimen). 00011→etve · 00012→socimi · 00006→pymes(ERD) · etc., SOLO si el
    ejercicio tiene matriz de tipos para ese régimen (si no, general; el fail-closed previo ya habría bloqueado
    los no soportados). Por defecto general. GIP/ETVE (00011) y casos sin carácter especial → SIN CAMBIO."""
    cd = caracteres or {}
    if str(cd.get("00011", "")).strip() == "1":
        return "etve"
    for _car, _reg in CARACTER_REGIMEN_ESPECIAL.items():
        if str(cd.get(_car, "")).strip() == "1" and tipo_disponible(_reg, str(ejercicio)):
            return _reg
    return "general"


def _caracteres_activos(caracteres) -> set:
    """Normaliza el contrato de caracteres (Capa 1) a un set de casillas ACTIVAS. Acepta dict
    {casilla: valor} (valor flag 1-dígito) o un iterable de casillas. Valores vacíos/0/false = inactivos."""
    if not caracteres:
        return set()
    if isinstance(caracteres, dict):
        return {str(c) for c, v in caracteres.items() if str(v).strip().lower() not in ("", "0", "false", "no")}
    return {str(c) for c in caracteres}


def coherencia_caracter_regimen(caracteres, regimen, ejercicio="2024") -> None:
    """Guarda carácter↔régimen (fiscal, Garrigues 2026-06-22). Lanza CaracterRegimenIncoherente si la
    declaración trae un carácter de régimen ESPECIAL pero el régimen resuelto NO es ese régimen — para no
    firmar una pyme/SOCIMI/IIC como general/ETVE al 25%. No-op si no hay caracteres (contrato opcional)."""
    reg = str(regimen or "general").strip().lower()
    activos = _caracteres_activos(caracteres)
    incoherentes = sorted(
        (c, CARACTER_REGIMEN_ESPECIAL[c]) for c in activos
        if c in CARACTER_REGIMEN_ESPECIAL and CARACTER_REGIMEN_ESPECIAL[c] != reg)
    if incoherentes:
        det = ", ".join(f"{c}→{r}" for c, r in incoherentes)
        raise CaracterRegimenIncoherente(
            f"Carácter de régimen especial ({det}) en la declaración pero el régimen es {reg!r} en {ejercicio}: "
            f"no se firma un régimen especial como {reg} (campaña del régimen no soportada/validada).")


def _facts_issues_a_inputs(facts: dict, issues: list, ejercicio="2024", regimen=None) -> dict:
    """facts (plugin) + issues -> kwargs de `calcular_casillas` (lo que consume el orquestador).

    Reutiliza `calcular_liquidacion.suma` para agregar los issues por dominio/signo: la conversión
    facts+issues -> agregados es la MISMA que la del plugin plano, así el número coincide POR
    CONSTRUCCIÓN. Además (fixes de la auto-revisión adversarial 2026-06-13): normaliza el régimen a
    minúsculas (evita 'SOCIMI'≠'socimi' → tipo/reglas erróneos), resuelve el tipo explícito por régimen
    (coherencia con /liquidar) y propaga la **compensación de BINs forzada** (issue dominio='compensacion')
    que el orquestador antes perdía → /firmar firmaba la base infra-declarada.

    Nota de seam: NO se usa `contable_a_inputs_liquidacion` aquí (ese mapea casillas contables del
    EPC -> B2/B3/B10, el puente *upstream* de Fase A); los `facts` del plugin ya traen lo contable.
    """
    facts = facts or {}
    iss = issues or []
    s = calcular_liquidacion.suma
    perm = float(s(iss, "diferencias_permanentes", "positivo") + s(iss, "diferencias_permanentes", "negativo"))
    temp = float(s(iss, "diferencias_temporarias", "positivo") + s(iss, "diferencias_temporarias", "negativo"))
    reservas = float(s(iss, "reduccion_bi"))     # negativos (reducción de BI)
    deducciones = float(s(iss, "deduccion"))     # negativos
    reg = str(regimen or facts.get("regimen") or "general").strip().lower()
    # Compensación de BINs forzada por el abogado (issue dominio='compensacion'): puede ser MENOR que el
    # límite (preservar BINs a futuro). Se honra topada al límite, igual que el plugin (calcular_liquidacion).
    comp_issue = next((it for it in iss if it.get("dominio") == "compensacion"), None)
    comp_forzada = comp_issue.get("importe") if comp_issue and comp_issue.get("importe") is not None else None
    return {
        "resultado_contable": facts.get("resultado_contable", 0),
        "gasto_por_is": facts.get("gasto_por_is", 0),
        "ajustes_permanentes": perm,
        "ajustes_temporarias": temp,
        "reservas": reservas,
        "bins_pendientes": facts.get("bins_pendientes", 0),
        "incn_ejercicio_anterior": facts.get("incn_ejercicio_anterior", 0),
        "deducciones": deducciones,
        "pagos_fraccionados": facts.get("pagos_fraccionados", 0),
        "retenciones": facts.get("retenciones", 0),
        "regimen": reg,
        "tipo": _resolver_tipo(facts, reg, ejercicio),   # explícito por régimen (coherencia /liquidar)
        "compensacion_forzada": comp_forzada,            # None -> calcular_casillas aplica el límite
        "ejercicio": str(ejercicio),
    }


def liquidar_orquestado(facts: dict, issues: list, ejercicio="2024", regimen=None) -> dict:
    """Liquidación por el ORQUESTADOR canónico (motor_expediente), no por el plugin plano.

    M3 (calcular_casillas) + M4 (validaciones inter-casilla) + lineage (cadena + ref normativa) +
    traza (collector en memoria; persistencia Supabase = Fase 2). Mismo número que /liquidar (red:
    test de coherencia), con trazabilidad inspección-ready y reglas activas por régimen (incl. ETVE).

    itemizados=None a propósito: los issues del plugin no traen `casilla`/`naturaleza` que exige M2
    (motor_ajustes); el juicio fiscal entra ya AGREGADO en los inputs. La verificación itemizada (M2)
    se habilita cuando los issues lleven casilla+naturaleza (bloque parseable / Fase 2).
    """
    inputs = _facts_issues_a_inputs(facts, issues, ejercicio, regimen)
    trazas: list = []
    orq = motor_expediente.liquidar_expediente(
        inputs, itemizados=None, ejercicio=str(ejercicio), on_traza=trazas.append)
    liq = orq["liquidacion"]
    return {
        "casillas": orq["casillas"],
        "base_imponible": liq["base_imponible"],
        "cuota_integra": liq["cuota_integra"],
        "cuota_liquida": liq["cuota_liquida"],
        "cuota_a_ingresar": liq["cuota_a_ingresar"],
        "tipo_gravamen": liq["tipo_gravamen"],
        "lineage": orq["lineage"],
        "validaciones": orq["validaciones"],
        "traza": (trazas[0] if trazas else orq.get("traza")),
        "reglas_activas": motor_expediente.reglas_activas(str(ejercicio), inputs["regimen"]),
        "apto_para_firma": orq["apto_para_firma"],
        "regimen": inputs["regimen"],
        "autoridad": "python (orquestador canónico ADR-001)",
    }


def firma_desde_orquestado(orq: dict) -> dict:
    """FIRMA (autoridad del número) desde la salida del orquestador. Mismo schema que
    `firma_desde_liquidacion` (base/cuotas/casillas/hash/autoridad) + traza + lineage + apto."""
    casillas = {k: v for k, v in (orq.get("casillas") or {}).items() if v is not None}
    firma_hash = hashlib.sha256(
        json.dumps(casillas, sort_keys=True, default=str).encode()
    ).hexdigest()[:16]
    return {
        "base_imponible": orq.get("base_imponible"),
        "cuota_integra": orq.get("cuota_integra"),
        "cuota_liquida": orq.get("cuota_liquida"),
        "cuota_a_ingresar": orq.get("cuota_a_ingresar"),
        "casillas": casillas,
        "hash": firma_hash,
        "autoridad": "python (cerebro canónico ADR-001)",
        "traza": orq.get("traza"),
        "lineage": orq.get("lineage"),
        "apto_para_firma": orq.get("apto_para_firma"),
    }


def gf_criterio(payload: dict) -> dict:
    """Límite de gastos financieros (art.16 LIS) por CRITERIO (leniente/estricto) para el cuestionario de la
    lanzadera. Devuelve {leniente, estricto, delta_00363}. NO firma cuota: el 00363 elegido entra como
    `diferencias_permanentes` (signo +) en `liquidar_orquestado` (el motor firma, ADR-001). Fuente ÚNICA de la
    matemática del art.16: `limitacion_gf` (consistencia con el parser GIP garantizada por test gated)."""
    import limitacion_gf  # lazy: solo carga al invocar el criterio GF
    return limitacion_gf.gf_criterio(payload or {})


_TRIAJE_CRIT = {"roja": "bloqueante", "amarilla": "a_confirmar"}


def triaje(partida: dict) -> dict:
    """Triaje art.15 de una partida (motor_triaje_art15.clasificar) con criticidad NORMALIZADA.

    El triaje emite 'roja'/'amarilla'; se normaliza al vocabulario de Harvey/auditoría
    (bloqueante/a_confirmar) para coherencia con el contrato del bloque parseable.
    """
    res = motor_triaje_art15.clasificar(partida or {})
    inc = res.get("incidencia")
    if isinstance(inc, dict) and inc.get("criticidad"):
        inc["criticidad"] = _TRIAJE_CRIT.get(
            str(inc["criticidad"]).strip().lower(), inc["criticidad"])
    return res


_CRIT_MAP = {
    "🔴": "rojo", "🟡": "amarillo", "🟢": "verde", "⚪": "blanco",
    "bloqueante": "rojo", "a_confirmar": "amarillo", "pendiente": "amarillo",
}


def normalizar_criticidad(v) -> str:
    """Normaliza criticidad (emoji o texto). Harvey emite emoji; el plugin usa texto."""
    return _CRIT_MAP.get(str(v or "").strip().lower(), str(v or "").strip().lower())


def estado_desde_issues(issues: list, validada=True) -> dict:
    """Construye el estado de gating (semáforos) a partir de los issues."""
    rojo = sum(1 for i in (issues or []) if normalizar_criticidad(i.get("criticidad")) == "rojo")
    amar = sum(
        1 for i in (issues or [])
        if normalizar_criticidad(i.get("criticidad")) == "amarillo"
        and float(i.get("importe", 0) or 0) != 0
        and str(i.get("estado", "")).lower() not in {"validado", "validada", "si", "sí"}
    )
    return {
        "H_sem_rojo": rojo,
        "H_sem_amarillo_impacto": amar,
        "H_validada": "si" if (validada and rojo == 0 and amar == 0) else "no",
    }


def combinar_estado_con_validaciones(estado: dict, validaciones_issues: list, apto=True) -> dict:
    """Funde las validaciones del ORQUESTADOR (M4) en el estado de gating.

    Codex HIGH: el validador canónico debe ser COMPUERTA, no observacional. `severidad` bloqueante->rojo,
    a_confirmar->amarillo (informativo no cuenta). Si el orquestador marcó `apto_para_firma=False`, NO exportable.
    """
    estado = dict(estado or {})
    rojo = sum(1 for v in (validaciones_issues or []) if normalizar_criticidad(v.get("severidad")) == "rojo")
    amar = sum(1 for v in (validaciones_issues or []) if normalizar_criticidad(v.get("severidad")) == "amarillo")
    estado["H_sem_rojo"] = round(float(estado.get("H_sem_rojo", 0) or 0)) + rojo
    estado["H_sem_amarillo_impacto"] = round(float(estado.get("H_sem_amarillo_impacto", 0) or 0)) + amar
    if not apto:
        estado["H_validada"] = "no"
    return estado


def gating(state: dict) -> dict:
    """Gating duro: exportable solo si rojo=0, amarillo_impacto=0, validada=sí.

    Combina la regla canónica (harness_estado.is_exportable) con una comprobación propia
    con round() — más estricta, NUNCA más permisiva: un conteo fraccional (0.9) no se cuela.
    """
    state = state or {}
    rojo = round(float(state.get("H_sem_rojo", 0) or 0))
    amar = round(float(state.get("H_sem_amarillo_impacto", 0) or 0))
    validada = str(state.get("H_validada", "no")).lower() in {"si", "sí", "true"}
    motivos = []
    if rojo > 0:
        motivos.append("Hay issues 🔴 bloqueantes sin resolver")
    if amar > 0:
        motivos.append("Hay 🟡 con impacto sin validar")
    if not validada:
        motivos.append("La liquidación no está validada (humano en el bucle)")
    exportable = bool(harness_estado.is_exportable(state)) and rojo == 0 and amar == 0 and validada
    if not exportable and not motivos:
        motivos.append("No exportable según el gating del motor")
    return {"exportable": exportable, "motivos": motivos}


# Ejercicio(s) del oráculo GIP validado (D4/ADR-002). 2025 = campaña DEFERIDA/provisional -> NO 'validado'.
_EJERCICIOS_VALIDADOS_ORACULO = {"2024"}


# ----------------------------------------------------------------- campañas (versionado por ejercicio)
def campanas_listar(data_dir=None) -> dict:
    """Lista las campañas dadas de alta (admin). Marca `validado_oraculo` por ADR-002 (sólo 2024)."""
    camps = campaign.listar(data_dir or campaign.DATA)
    for c in camps:
        c["validado_oraculo"] = c["ejercicio"] in _EJERCICIOS_VALIDADOS_ORACULO
    return {"campanas": camps}


def campana_diff(a, b, data_dir=None) -> dict:
    """Diferencias de casillas importables entre dos campañas (nuevas/eliminadas por página)."""
    try:
        return {"a": str(a), "b": str(b), "diff": campaign.diff(a, b, data_dir or campaign.DATA)}
    except (ValueError, SystemExit):
        raise
    except Exception as e:   # noqa: BLE001  campaña/JSON ilegible en disco -> entrada inválida (422), no 500
        raise ValueError(f"No se pudo comparar las campañas {a}/{b}: {e}")


def campana_onboard(ejercicio, xsd_path, base=None, data_dir=None) -> dict:
    """Da de alta una campaña desde el XSD OFICIAL (parsea casillas + subesquema + informe de diffs vs base).

    Saneo (adversarial): `ejercicio` y `base` deben ser 4 dígitos (evita traversal en el dir de campañas, y
    que `base` lea/copie mapeo de fuera de campaigns/). NO sobrescribe una campaña existente (protege el
    mapeo que firma el número GIP, p.ej. 2024 — borrarla a mano para rehacerla). Un XSD ilegible -> ValueError
    (422), nunca 500, y sin dejar el dir a medias (parse-before-write en campaign.onboard)."""
    ej = str(ejercicio).strip()
    if not re.fullmatch(r"[0-9]{4}", ej):   # ASCII 0-9 (no dígitos Unicode: \d casaría árabe-índicos/fullwidth)
        raise ValueError("Ejercicio inválido: usa 4 dígitos (p.ej. 2025).")
    b = (base or "").strip() or None
    if b is not None and not re.fullmatch(r"[0-9]{4}", b):
        raise ValueError("Base inválida: usa 4 dígitos de una campaña existente.")
    dd = data_dir or campaign.DATA
    if os.path.isdir(os.path.join(str(dd), "campaigns", ej)):
        raise ValueError(f"La campaña {ej} ya existe; no se sobrescribe (bórrala a mano para rehacerla).")
    if b is not None and not os.path.isdir(os.path.join(str(dd), "campaigns", b)):
        raise ValueError(f"La campaña base {b} no existe; da de alta primero esa campaña.")
    try:
        res = campaign.onboard(ej, xsd_path, base=b, data_dir=dd)
    except (ValueError, SystemExit):
        raise
    except Exception as e:   # noqa: BLE001  XSD malformado/ilegible -> entrada inválida (422), no 500
        raise ValueError(f"XSD no válido o ilegible: {e}")
    return {"ejercicio": ej, "dir": res["dir"], "campos": res["campos"], "informe": res["informe"], "base": b}


def reglas_espejo(ejercicio="2024", regimen="general") -> dict:
    """T1.4.5: espejo READ-ONLY de las reglas Python (catálogo YAML validado) para admin/rulesets. La fuente
    de verdad es el repo (no editable en la consola); cada regla se etiqueta `source.validadoOraculo` (ADR-002:
    el motor Python valida el número y las reglas; la consola las REFLEJA, no las reescribe en TS).

    FAIL-CLOSED por ejercicio (Codex HIGH T1.4.5): `motor_expediente.reglas_activas` filtra SOLO por régimen
    (ignora el ejercicio), así que NO se debe presentar el catálogo como 'validado en GIP' para un ejercicio
    inexistente/futuro. Se valida que la campaña exista y `validadoOraculo` solo es True para el ejercicio del
    oráculo GIP (2024); 2025 (deferido) y los no soportados -> False."""
    ejercicio = str(ejercicio)
    try:
        _campaign_paths(ejercicio)
        soportado = True
    except (Exception, SystemExit):   # campaign.resolve lanza SystemExit si la campaña no existe
        soportado = False
    regs = motor_expediente.reglas_activas(ejercicio, regimen) if soportado else []
    validado = soportado and ejercicio in _EJERCICIOS_VALIDADOS_ORACULO
    nota = ("validado en el oráculo GIP" if validado else
            ("ejercicio sin campaña: no soportado" if not soportado else
             "ejercicio soportado pero NO validado en GIP (deferido/provisional)"))
    return {
        "ejercicio": ejercicio, "regimen": regimen, "n": len(regs), "soportado": soportado,
        "source": {"origen": "python", "validadoOraculo": validado, "editable": False, "adr": "ADR-002",
                   "nota": nota},
        "reglas": regs,
    }


# ----------------------------------------------------------------- Reconciliación
def reconciliar(preview: dict, firma: dict, tol=0.01) -> dict:
    """Tabla de divergencias casilla a casilla preview(consola) vs firma(Python). Manda Python."""
    def _f(x):
        try:
            return float(x)
        except (TypeError, ValueError):
            return None

    claves = sorted(set(preview or {}) | set(firma or {}))
    filas = []
    for c in claves:
        p = (preview or {}).get(c)
        f = (firma or {}).get(c)
        pf, ff = _f(p), _f(f)
        if pf is not None and ff is not None:
            div = abs(pf - ff) > tol
        else:
            # falta uno o algún valor no es numérico -> no se puede confirmar igualdad
            div = not (p is None and f is None)
        filas.append({"casilla": c, "preview_consola": p, "firma_python": f, "divergencia": bool(div)})
    return {
        "divergencias": sum(1 for r in filas if r["divergencia"]),
        "filas": filas,
        "autoridad": "python",
    }


def auditar(canonico: list, ejercicio="2024", regimen="general") -> dict:
    """Mayor/canónico -> auditoría fiscal completa (hallazgos por criticidad). D11.

    `canonico`: lista de cuentas [{cuenta, sf, debe, haber, ...}] (la salida de la ingesta).
    """
    return motor_auditoria.auditar(canonico or [], ejercicio=str(ejercicio), regimen=regimen)


def auditar_mayores(paths, ejercicio="2024", regimen="general", umbral=0.95) -> dict:
    """Sube MAYORES (Fase 4 / EPIC C, C1) -> canónico (vía ingesta de precisión Fase 3) -> auditoría.

    RUTA SEPARADA y READ-ONLY (D11): encadena `ingesta_multi` (extrae+normaliza+reconcilia, sobre
    tempfiles, sin persistir) con `auditar` (catálogo completo). NO firma número, NO emite XML, NO toca
    gating: es análisis de la situación fiscal, no la declaración.

    Audita la mejor base disponible: libro mayor si existe, si no Sumas y Saldos/balance, y en último
    término cualquier canónico extraído. Solo bloquea cuando no hay ninguna cuenta auditable; si se audita
    con una fuente agregada se devuelve como alcance limitado, no como ausencia de análisis.
    """
    ing = ingesta_multi(paths, umbral=umbral)
    mayores = [f for f in ing["ficheros"] if f.get("clasificacion", {}).get("clase") == "libro_mayor"]
    sys_list = [f for f in ing["ficheros"] if f.get("clasificacion", {}).get("clase") == "sumas_y_saldos"]
    mayores_con_canon = [f for f in mayores if f.get("canonico")]
    sys_con_canon = [f for f in sys_list if f.get("canonico")]
    cualquier_canon = [f for f in ing["ficheros"] if f.get("canonico")]

    if mayores_con_canon:
        fuente_ficheros = mayores_con_canon
        origen = "mayores"
        alcance = "completo_mayor"
        limitaciones = []
    elif sys_con_canon:
        fuente_ficheros = sys_con_canon
        origen = "sumas_y_saldos"
        alcance = "limitado_sumas_y_saldos"
        limitaciones = [
            "No se ha aportado libro mayor procesable; la auditoria se ejecuta sobre saldos agregados "
            "(Sumas y Saldos/balance). Puede detectar riesgos por cuenta, pero no evidencia por asiento.",
        ]
    else:
        fuente_ficheros = cualquier_canon
        origen = "canonico_disponible" if cualquier_canon else "sin_base_auditable"
        alcance = "limitado_canonico" if cualquier_canon else "bloqueado_sin_base"
        limitaciones = [
            "No se ha aportado libro mayor procesable; la auditoria se ejecuta sobre el canónico disponible.",
        ] if cualquier_canon else []
    canonico = [row for f in fuente_ficheros for row in (f.get("canonico") or [])]

    # Incidencias de alcance: se reportan siempre, pero solo bloquean si no queda ninguna base auditable.
    # Un PDF auxiliar no OCR o un fichero no usado no debe impedir auditar un mayor/SyS válido; queda como
    # advertencia de provenance. En cambio, si no hay cuentas, se antepone el bloqueo de calidad de dato.
    errores = []
    for f in ing["ficheros"]:
        clase = f.get("clasificacion", {}).get("clase")
        relevante = clase in {"libro_mayor", "sumas_y_saldos", "balance_situacion", "pyg"}
        if f.get("error"):
            errores.append({"fichero": f.get("nombre"), "motivo": f["error"], "relevante": relevante})
        elif not (f.get("canonico") or []):                        # None o lista vacía -> no aportó cuentas
            motivo = ("PDF requiere OCR/HITL: no se extrajeron cuentas auditables"
                      if f.get("clasificacion", {}).get("es_pdf") else "sin canónico (no se extrajeron cuentas)")
            errores.append({"fichero": f.get("nombre"), "motivo": motivo, "relevante": relevante})

    if errores:
        limitaciones.append(
            f"{len(errores)} fichero(s) aportado(s) no se han usado como base auditable; revisar provenance."
        )
    relevante_sin_canon = any(e.get("relevante") for e in errores)
    fiable = bool(canonico) and not relevante_sin_canon

    aud = motor_auditoria.auditar(canonico, ejercicio=str(ejercicio), regimen=regimen)
    if not canonico:
        motivo = "No se extrajo ninguna cuenta auditable de los ficheros subidos."
        aud = motor_auditoria.anteponer_hallazgo(
            aud, motor_auditoria.finding_datos_insuficientes(motivo, ficheros=errores or None))

    fuente = {
        "origen": origen,
        "alcance": alcance,
        "n_ficheros": len(ing["ficheros"]),
        "cuentas_auditadas": len(canonico),
        "fiable": fiable,
        "errores": errores,
        "limitaciones": limitaciones,
    }
    aud = dict(aud)
    aud["fuente_auditoria"] = fuente

    return {
        "auditoria": aud,
        "ingesta": {
            "exportable_conjunto": ing["exportable_conjunto"],
            "resumen_conjunto": ing["resumen_conjunto"],
            "reconciliacion_inter": ing["reconciliacion_inter"],
            "reconciliacion_sys": ing["reconciliacion_sys"],
            "ficheros": [
                {
                    "nombre": f.get("nombre"),
                    "clase": f.get("clasificacion", {}).get("clase"),
                    "n": (f.get("extraccion") or {}).get("n"),
                    "error": f.get("error"),
                    "exportable": _exportable_fichero(f),
                    "mayor_identidad_ok": (f.get("mayor_identidad") or {}).get("ok"),
                }
                for f in ing["ficheros"]
            ],
        },
        "fuente": fuente,
    }


def hallazgos_a_issues(aud_resultado: dict) -> list:
    """Adaptador puro auditoria -> propuestas de ajuste para el cuestionario.

    La auditoria sigue siendo read-only: esto NO firma, NO liquida y NO mueve la BI.
    Solo transforma hallazgos elegibles en propuestas que el abogado confirma, rechaza
    o modifica en la UI. El nombre conserva el contrato interno historico de "issue";
    la superficie de producto lo muestra como "ajuste propuesto".
    """
    aud = aud_resultado or {}
    hallazgos = aud.get("hallazgos") or []
    elegibles = {
        "diferencias_permanentes",
        "diferencias_temporarias",
        "reduccion_bi",
        "deduccion",
        "compensacion",
        "exencion_doble_imposicion",
        "deterioros",
        "provisiones",
    }
    out = []
    for h in hallazgos:
        if not isinstance(h, dict):
            continue
        dominio = h.get("dominio")
        signo = h.get("signo") or "neutro"
        casillas = [str(c).strip() for c in (h.get("casillas") or []) if str(c).strip()]
        if dominio not in elegibles or not casillas or signo not in {"positivo", "negativo"}:
            continue
        try:
            importe = abs(float(h.get("importe_contable") or 0))
        except (TypeError, ValueError):
            importe = 0.0
        evidencia = []
        for d in h.get("cuentas_detalle") or []:
            if not isinstance(d, dict):
                continue
            cuenta = d.get("cuenta") or d.get("codigo") or ""
            imp = d.get("importe_contable")
            if cuenta or imp is not None:
                evidencia.append(f"{cuenta}: {imp}")
        docs = h.get("documentos_requeridos") or []
        if docs:
            evidencia.append("Documentos: " + ", ".join(str(x) for x in docs))
        out.append({
            "id": h.get("id") or f"AUD-{len(out) + 1}",
            "titulo": h.get("titulo") or h.get("id") or "Ajuste propuesto",
            "dominio": dominio,
            "signo": signo,
            "importe": importe,
            "casilla": casillas[0],
            "casillas": casillas,
            "criticidad": h.get("criticidad") or "a_confirmar",
            "fundamento": h.get("fundamento"),
            "evidencia": " | ".join(evidencia),
            "estado": "propuesto",
            "accion": "proponer_validacion",
            "origen": "auditoria",
            "requiere_confirmacion": True,
        })
    return out


def auditoria_informe(aud, nif="", ejercicio="2024") -> dict:
    """Memoria de auditoría EXPORTABLE (.docx BRANDED Garrigues) a partir del resultado de la auditoría
    (Fase 4 / C4). Reusa `puente_entregables_v3` POR SERVICIO (mismo branding). Ruta read-only: no firma
    número ni toca la declaración. Devuelve {fichero, mime, base64}."""
    import puente_entregables_v3  # lazy: solo carga python-docx cuando se exporta el informe
    docx_mime = "application/vnd.openxmlformats-officedocument.wordprocessingml.document"
    aud = aud if isinstance(aud, dict) else {}
    ej = str(aud.get("ejercicio") or ejercicio)
    # Nombre de fichero SANEADO (adversarial): nif y ejercicio solo alfanuméricos -> ni separadores ni
    # '..' pueden formar parte de la ruta (defensa en profundidad; el escape ya fallaba con FileNotFound).
    safe_nif = "".join(ch for ch in (nif or "SA") if ch.isalnum()) or "SA"
    safe_ej = "".join(ch for ch in ej if ch.isalnum()) or "ejercicio"
    with tempfile.TemporaryDirectory() as td:
        out = os.path.join(td, f"Memoria_Auditoria_{safe_nif}_{safe_ej}.docx")
        puente_entregables_v3.build_memoria_auditoria_docx(aud, out, nif=nif, ejercicio=ej)
        with open(out, "rb") as fh:
            b64 = base64.b64encode(fh.read()).decode("ascii")
    return {"fichero": os.path.basename(out), "mime": docx_mime, "base64": b64}


def auditoria_checklist() -> dict:
    """Checklist de revisión MANUAL del IS (Fase 4): los puntos del DD que el motor NO auto-detecta
    (necesitan Libro Diario, NIF, fechas/numeración o juicio jurídico). Datos estáticos del catálogo;
    read-only. Devuelve {modulos:[{modulo, nombre, puntos:[...]}], total, nota}."""
    import yaml as _yaml
    path = os.path.join(motor_auditoria.RULES_AUDITORIA_DIR, "_checklist_humano.yaml")
    try:
        with open(path, encoding="utf-8") as fh:
            modulos = _yaml.safe_load(fh) or []
    except (FileNotFoundError, OSError):
        modulos = []
    if not isinstance(modulos, list):
        modulos = []
    total = sum(len(m.get("puntos", [])) for m in modulos if isinstance(m, dict))
    return {
        "modulos": modulos,
        "total": total,
        "nota": "Puntos del DD NO auto-detectables por el motor determinista: requieren el Libro Diario, el "
                "NIF de la contraparte, fechas/numeración o juicio jurídico (simulación art. 16 LGT, motivo "
                "económico válido, DEMPE). Los recorre el abogado; la capa LLM-juez es trabajo futuro.",
    }


def juez_normativo(payload, ejercicio="2024") -> dict:
    """Capa LLM 'juez normativo' (seam SDB) — RUTA SEPARADA y READ-ONLY (D11/ADR-001/002): NO firma número,
    NO emite XML, NO toca gating ni builder. El LLM PROPONE un IracOutput sobre las zonas grises de la cola
    de revisión humana (deducibilidad, retribución de administradores, vinculadas/DEMPE, FEAC...); el
    colegiado valida y firma. En J0 el reasoner es un STUB determinista (sin proveedor LLM); el cableado del
    proveedor real es J1. Acepta {hallazgo:{...}} (un hallazgo aislado) o {auditoria:{...}} (recorre su cola
    requiere_revision_humana). Devuelve el IracOutput individual o {ejercicio, total, resultados:[...]}."""
    import juez  # lazy: la capa LLM solo se carga al invocar este endpoint
    ej = str(ejercicio)
    payload = payload if isinstance(payload, dict) else {}
    # OPT-IN al proveedor LLM: payload {"modelo":"openai"|"gpt-..."} usa OpenAI (si hay clave); por
    # defecto "stub" determinista (ni gasta tokens ni toca la red).
    modelo = payload.get("modelo") or "stub"
    if isinstance(payload.get("hallazgo"), dict):
        return juez.juzgar_hallazgo(payload["hallazgo"], ej, model=modelo)
    aud = payload.get("auditoria")
    aud = aud if isinstance(aud, dict) else {"hallazgos": []}
    resultados = juez.juzgar_cola(aud, ej, model=modelo)
    return {"ejercicio": ej, "total": len(resultados), "resultados": resultados}


def ingesta(cuentas: list, umbral=0.95) -> dict:
    """Ingesta de datos contables de MÁXIMA PRECISIÓN (EPIC B / D12).

    Normaliza al PGC oficial (escalera exacto→prefijo→fuzzy→grupo + confianza), reconcilia (cuadre
    debe=haber) y arma la cola de revisión (HITL). `exportable_a_importador` indica si los datos están
    limpios (cuadran + sin cuentas pendientes de revisar) para alimentar la **Fase A** (import AEAT).
    """
    norm = normalizador_pgc.normalizar(cuentas or [], umbral=umbral)
    sd = sum(float(c.get("debe", 0) or 0) for c in (cuentas or []))
    sh = sum(float(c.get("haber", 0) or 0) for c in (cuentas or []))
    cuadres = {
        "suma_debe": round(sd, 2),
        "suma_haber": round(sh, 2),
        "cuadra_debe_haber": abs(sd - sh) < 0.01,
    }
    return {
        **norm,
        "cuadres": cuadres,
        "tablas": tablas_salida.construir(norm["canonico"]),  # más tablas de salida (D14)
        "exportable_a_importador": cuadres["cuadra_debe_haber"] and norm["resumen"]["a_revisar"] == 0,
    }


def _borrador_desde_partidas(partidas: list, umbral=0.95) -> dict:
    """Partidas inferidas de un PDF (CCAA) -> borrador normalizado al PGC (fuzzy por denominación).

    Es INFERENCIA (no la vía cuadrada del SyS): `exportable_a_importador` SIEMPRE False y todo pasa por
    revisión humana. Reutiliza el normalizador (mapeo por denominación, sin código) y las tablas de salida.
    """
    # Omite partidas sin importe legible (None): no inventar saldo 0 ni pasar None al normalizador
    # (el parser marca como None las filas cuyo único nº era una nota — Codex HIGH T1.2).
    cuentas = [{"cuenta": "", "denom": p["etiqueta"], "sf": p["importe"], "multi": bool(p.get("multi"))}
               for p in partidas if p.get("importe") is not None]
    norm = normalizador_pgc.normalizar(cuentas, umbral=umbral)
    return {
        **norm,
        "tablas": tablas_salida.construir(norm["canonico"]),
        "borrador": True,
        "exportable_a_importador": False,
        "nota": "Borrador por inferencia (OCR/CCAA): toda partida requiere revisión (HITL). "
                "La vía cuadrada para el importador es el Sumas y Saldos.",
    }


def ingesta_fichero(path: str, umbral=0.95) -> dict:
    """Fichero (SyS/mayor/PDF) -> ingesta de precisión END-TO-END (EPIC B).

    Clasifica el documento (Stage 0) y enruta al extractor: tabular (SyS/mayor) -> extractor_contable +
    normalización PGC + cuadres; PDF (cuentas anuales/declaración) -> extractor_ccaa (texto + candidatos,
    con aviso si necesita OCR). Siempre devuelve la clasificación.
    """
    cls = clasificador.clasificar(path)
    if cls["es_pdf"]:
        texto, motor_pdf = extractor_ccaa.extraer_texto(path)
        ocr = None
        # PDF escaneado (sin texto extraíble) + servicio OCR configurado -> Docling por HTTP (Opción 1).
        if not texto and ocr_client.disponible():
            conv = ocr_client.convertir(path, filename=os.path.basename(path))
            if conv.get("disponible") and conv.get("markdown"):
                texto = conv["markdown"]
                motor_pdf = "ocr:" + str(conv.get("backend"))
                ocr = {
                    "backend": conv.get("backend"),
                    "tablas": conv.get("tablas"),
                    "paginas": conv.get("paginas"),
                    "markdown_chars": len(conv["markdown"]),
                    "warnings": conv.get("warnings", []),
                    "url": conv.get("url"),
                }
            elif conv.get("motivo"):
                ocr = {"backend": None, "intentado": True, "motivo": conv["motivo"]}
        # Si el texto viene de Markdown (OCR/Docling), aplanar las barras de tabla "| a | b |"
        # para que la heurística de candidatos (pensada para texto plano) las lea.
        cands = extractor_ccaa.candidatos(texto.replace("|", " ")) if texto else []
        # Partidas ESTRUCTURADAS desde el Markdown (tablas Docling) -> borrador normalizado (HITL).
        partidas = extractor_markdown.extraer_partidas(texto) if texto else []
        res = {
            "clasificacion": cls,
            "pdf": {
                "motor_extraccion": motor_pdf,
                "necesita_ocr": not texto,
                "n_candidatos": len(cands),
                "n_partidas": len(partidas),
                "candidatos": cands[:40],
            },
            "nota": "PDF (cuentas anuales/declaración): extracción por inferencia; requiere revisión (HITL).",
        }
        if ocr is not None:
            res["ocr"] = ocr
        if partidas:
            res["partidas"] = partidas[:200]
            res["borrador"] = _borrador_desde_partidas(partidas, umbral=umbral)
        return res
    ext = extractor_contable.extraer_cuentas(path)
    if ext.get("error"):
        return {"clasificacion": cls, "error": ext["error"], "extraccion": {"n": 0}}
    res = ingesta(ext["cuentas"], umbral=umbral)
    res["clasificacion"] = cls
    res["extraccion"] = {
        "n": ext["n"], "cabecera_fila": ext.get("cabecera_fila"), "columnas": ext.get("columnas"),
    }
    # B5: un LIBRO MAYOR sí debe cumplir la identidad por línea SI+debe−haber=SF (gate específico del mayor;
    # un SyS-resumen no la cumple y por eso es solo aviso en `reconciliar`). Se reporta por fichero.
    if cls.get("clase") == "libro_mayor":
        res["mayor_identidad"] = reconciliador.cuadre_saldo_por_linea(ext["cuentas"])
    return res


def _exportable_fichero(f) -> bool:
    """Exportabilidad POR FICHERO para el gate del lote (B5): el flag a nivel raíz si existe; si es un PDF
    su flag vive ANIDADO en 'borrador' (siempre False, HITL); un fichero en ERROR / sin canónico NO es
    exportable. Nunca inventar: lo que no se pudo procesar (o exige humano) no entra al importador AEAT."""
    if "exportable_a_importador" in f:
        return bool(f["exportable_a_importador"])
    b = f.get("borrador")
    if isinstance(b, dict) and "exportable_a_importador" in b:
        return bool(b["exportable_a_importador"])
    return False


def ingesta_multi(paths, umbral=0.95) -> dict:
    """Ingesta de VARIOS ficheros (SyS + mayores) en un lote — EPIC B / B5.

    Procesa cada fichero (clasifica + extrae + normaliza + cuadres; identidad por línea en los mayores) y
    RECONCILIA el/los mayor(es) contra el SyS por familia de cuenta (agrupación simétrica por prefijo, tol=0).
    `exportable_conjunto` exige: cada fichero exportable + todos los mayores con identidad OK + la
    reconciliación inter-documento sin deltas (nunca inventar: una incoherencia entre fuentes contables
    bloquea el conjunto)."""
    ficheros = []
    for p in paths:
        r = ingesta_fichero(p, umbral=umbral)
        r["nombre"] = os.path.basename(p)
        ficheros.append(r)
    sys_list = [f for f in ficheros if f.get("clasificacion", {}).get("clase") == "sumas_y_saldos"]
    sys_f = sys_list[0] if sys_list else None
    mayores = [f for f in ficheros if f.get("clasificacion", {}).get("clase") == "libro_mayor"]
    recon = None
    if sys_f and mayores and sys_f.get("canonico") is not None:
        mayor_canon = [row for f in mayores for row in (f.get("canonico") or [])]
        recon = reconciliador.reconciliar_inter_documento(sys_f["canonico"], mayor_canon)
    # SyS MÚLTIPLES: deben coincidir entre sí (mismo expediente); cualquier delta los hace no fiables.
    recon_sys = None
    sys_con_canon = [f for f in sys_list if f.get("canonico") is not None]
    if len(sys_con_canon) > 1:
        deltas = []
        for extra in sys_con_canon[1:]:
            deltas += reconciliador.reconciliar_inter_documento(sys_con_canon[0]["canonico"], extra["canonico"])["deltas"]
        recon_sys = {"ok": not deltas, "deltas": deltas}
    # Gate del conjunto (nunca inventar): TODO fichero exportable (un error/PDF NO lo es) + mayores con
    # identidad OK (un mayor sin identidad NO pasa) + reconciliaciones sin deltas.
    expo = bool(ficheros) and all(_exportable_fichero(f) for f in ficheros)
    expo = expo and all((m.get("mayor_identidad") or {}).get("ok", False) for m in mayores)
    if recon is not None:
        expo = expo and recon["ok"]
    if recon_sys is not None:
        expo = expo and recon_sys["ok"]
    return {
        "ficheros": ficheros,
        "reconciliacion_inter": recon,
        "reconciliacion_sys": recon_sys,
        "exportable_conjunto": bool(expo),
        "resumen_conjunto": {
            "n_ficheros": len(ficheros),
            "sys": sys_f["nombre"] if sys_f else None,
            "sys_multiples": [f["nombre"] for f in sys_list] if len(sys_list) > 1 else None,
            "mayores": [m["nombre"] for m in mayores],
            "deltas_inter": len((recon or {}).get("deltas", [])) if recon else 0,
        },
    }


def caracteres_declaracion(prior_path, ejercicio="2024") -> dict:
    """Caracteres de la declaración (flags de DP200001: ETVE 00011, grupo mercantil 00039, matriz última
    00082, etc.) del `.200` del EJERCICIO ANTERIOR → {casilla: valor} de los flags SET. Son la CONFIG ESTABLE
    de la entidad (no cambian con el ejercicio): es el 'cargar datos de la declaración anterior'. Se excluye
    el tipo de ejercicio (se deriva del período, no se arrastra). 0 PII (lee posiciones del DR)."""
    import re as _re
    dr = dr200.cargar_dr(ejercicio=str(ejercicio))
    try:
        doc = open(prior_path, encoding="latin1").read()
    except OSError:
        return {}
    m = _re.search(r"<T20001000>(.*?)</T20001000>", doc)
    if not m:
        return {}
    rec = "<T20001000>" + m.group(1)
    out = {}
    for c in dr.get("DP200001", []):
        cas = c.get("casilla")
        if not cas or (c.get("tipo") or "").strip().lower() != "num" or c.get("longitud") != 1:
            continue                                       # solo flags de 1 dígito (caracteres)
        if "tipo de ejercicio" in (c.get("descripcion") or "").lower():
            continue                                       # derivado del período, no se arrastra
        p = c["posicion"]
        v = (rec[p - 1:p] if len(rec) >= p else "").strip()
        if v and v != "0":
            out[cas] = v
    return out


def identificativos_declaracion(prior_path, ejercicio="2024") -> dict:
    """NIF + razón social del DECLARANTE del `.200` del EJERCICIO ANTERIOR (registro DP200001:
    «Identificación - NIF» pos 14 y «Identificación - Apellidos y nombre o Razón Social» pos 23). Hace que la
    precarga Nivel A traiga los identificativos para que el `.200` NO salga con NIF/razón vacíos (errores AEAT
    EMALNI1/EMALNO1). Determinista (lee posiciones del DR); 0 PII en logs (devuelve el dict, no imprime)."""
    import re as _re
    try:
        doc = open(prior_path, encoding="latin1").read()
    except OSError:
        return {}
    m = _re.search(r"<T20001000>(.*?)</T20001000>", doc)
    if not m:
        return {}
    rec = "<T20001000>" + m.group(1)
    dr = dr200.cargar_dr(ejercicio=str(ejercicio))
    out = {}
    for c in dr.get("DP200001", []):
        desc = (c.get("descripcion") or "").strip().lower()
        p, ln = c.get("posicion"), c.get("longitud")
        if not p or not ln or len(rec) < p:
            continue
        val = rec[p - 1:p - 1 + ln].strip()
        if not val:
            continue
        if desc.endswith("nif") and "nif" not in out:
            out["nif"] = val
        elif ("raz" in desc and "social" in desc) and "razon_social" not in out:
            out["razon_social"] = val
    return out


def pagina01b_declaracion(prior_path, ejercicio_prior="2024") -> dict:
    """Página DP200001B del `.200` del EJERCICIO ANTERIOR → {num_campo: valor} para reemitirla. Es CONFIG
    ESTABLE (capa 1 'config heredada'): aquí la entidad declara QUÉ modelo de estados de cuentas usa
    (Balance/ECPN/PyG = 1 normal / 2 abreviado / 3 PYMES) y los datos de la matriz última del grupo. Sin esta
    página el importador rechaza las páginas contables 3-11 (EMALP311 «debe haber cumplimentado algún estado de
    cuentas»). Se arrastra POR Nº DE CAMPO (clave estable entre años; el layout de DP200001B es idéntico
    2024↔2025), omitiendo constantes (cabecera/pie), el RESERVADO de la AEAT y los campos en blanco. El personal
    asalariado (00041/00042) se arrastra como provisional (cifra del año anterior). 0 PII en logs (no imprime,
    devuelve el dict; los NIF/razón social de la matriz son del propio expediente)."""
    import re as _re
    try:
        doc = open(prior_path, encoding="latin1").read()
    except OSError:
        return {}
    m = _re.search(r"<T20001B00>(.*?)</T20001B00>", doc)
    if not m:
        return {}
    rec = "<T20001B00>" + m.group(1)
    dr = dr200.cargar_dr(ejercicio=str(ejercicio_prior))
    out = {}
    for c in dr.get("DP200001B", []):
        num, p, ln = c.get("num"), c.get("posicion"), c.get("longitud")
        if not num or not p or not ln:
            continue
        if dr200.constante(c) is not None:                 # cabecera/pie/constantes: las pone emitir_registro
            continue
        if "reservado" in (c.get("descripcion") or "").lower():
            continue
        v = rec[p - 1:p - 1 + ln] if len(rec) >= p - 1 + ln else ""
        if v.strip() == "":                                # campo en blanco → no se arrastra
            continue
        out[num] = v
    return out


def formales_declaracion(prior_path, ejercicio="2024") -> dict:
    """Datos FORMALES del `.200` del ejercicio anterior (lector inverso) → dict que consume
    formal200.formal_page_entries para re-emitir DP200002 (apartado A administradores + B.2 socios) y DP200002B
    (F titular real + G secretario/representantes). Resuelve los errores AEAT que exigen la capa formal:
    EMALR31-34 (socios B.2), 147/146 (administrador), 2827 (titular real), 144 (secretario), 146 (representante).
    Config estable del año anterior (carga asistida: el abogado confirma/edita). Contratos espejo del emisor:
    socios {nif,fj,nombre,pais,nominal(€),porcentaje(fracción)} · administradores {nif,nombre} ·
    titulares_reales {nif,nombre,extra:[nacionalidad,residencia,fecha_nac]} · secretario {nif,nombre} ·
    representantes {nif,nombre,extra:[fecha_poder_AAAAMMDD,notaria]}. Degrada a {} si falta el registro. 0 PII en logs."""
    import re as _re
    try:
        doc = open(prior_path, encoding="latin1").read()
    except OSError:
        return {}
    dr = dr200.cargar_dr(ejercicio=str(ejercicio))

    def _lector(tag, pagina):
        """Lector de campos por num_campo del registro `tag` (o None si la página no está en el `.200`)."""
        mm = _re.search("<" + tag + ">(.*?)</" + tag + ">", doc, _re.S)
        if not mm:
            return None
        recloc = "<" + tag + ">" + mm.group(1)
        by = {c.get("num"): c for c in dr.get(pagina, []) if c.get("num")}

        def _c(num):
            cc = by.get(num)
            if not cc:
                return ""
            p, ln = cc.get("posicion"), cc.get("longitud")
            return recloc[p - 1:p - 1 + ln] if p and ln and len(recloc) >= p - 1 + ln else ""
        return _c

    def _centimos_a_euros(s):
        s = (s or "").strip()
        dig = _re.sub(r"\D", "", s)
        if not dig:
            return None
        val = int(dig) / 100.0
        return -val if "N" in s.upper() else val

    out = {}
    # --- DP200002: B.2 socios (campos 100..141, base 100+7k) + apartado A administradores (campos 6..35, base 6+6k)
    c2 = _lector("T20002000", "DP200002")
    if c2:
        socios = []
        for k in range(6):
            base = 100 + 7 * k
            nif = c2(base).strip()
            if not nif:
                continue
            pct_raw = _re.sub(r"\D", "", c2(base + 6))               # 5 díg., % × 100 (3 ent + 2 dec)
            socios.append({
                "nif": nif, "fj": c2(base + 2).strip() or None, "nombre": c2(base + 3).strip(),
                "pais": c2(base + 4).strip() or None, "nominal": _centimos_a_euros(c2(base + 5)),
                "porcentaje": (int(pct_raw) / 10000.0) if pct_raw else None,  # → FRACCIÓN (contrato _socios_campos)
            })
        if socios:
            out["socios"] = socios
        admins = []
        for k in range(5):                                          # 5 slots apartado A; base = 6 + 6k
            base = 6 + 6 * k
            nif = c2(base).strip()
            if not nif:
                continue
            admins.append({"nif": nif, "nombre": c2(base + 3).strip()})
        if admins:
            out["administradores"] = admins
    # --- DP200002B: F titular real + G secretario/representantes
    c2b = _lector("T20002B00", "DP200002B")
    if c2b:
        nif_tr = c2b(146).strip()
        if nif_tr:                                                  # F titular real: extra=[nacionalidad, residencia, fecha_nac]
            out["titulares_reales"] = [{"nif": nif_tr, "nombre": c2b(147).strip(),
                                        "extra": [c2b(151).strip(), c2b(150).strip(), c2b(149).strip()]}]
        nif_sec = c2b(153).strip()
        if nif_sec:                                                 # G secretario del Consejo
            out["secretario"] = [{"nif": nif_sec, "nombre": c2b(152).strip()}]
        reps = []
        for k in range(3):                                          # G representantes; 3 slots, base = 154 + 4k
            base = 154 + 4 * k
            nif = c2b(base + 1).strip()
            if not nif:
                continue
            reps.append({"nif": nif, "nombre": c2b(base).strip(),
                         "extra": [c2b(base + 2).strip(), c2b(base + 3).strip()]})  # [fecha_poder, notaria]
        if reps:
            out["representantes"] = reps
    # --- DP200021: grupo mercantil (00987 INCN del grupo + NIF/país de participadas) → capa formal que cierra
    # el aviso 21200 (grupo con dominante española exige 00987 + ≥1 NIF en pág 21). Se emite vía formal_page_entries.
    c21 = _lector("T20021000", "DP200021")
    if c21:
        participadas = []
        for k in range(1, 13):                                      # 12 slots; NIF=campo 7+2(k-1), país=campo 8+2(k-1)
            nif = c21(7 + 2 * (k - 1)).strip()
            if not nif:
                continue
            participadas.append({"nif": nif, "pais": c21(8 + 2 * (k - 1)).strip() or None})
        if participadas:
            out["participadas"] = participadas
        incn = _centimos_a_euros(c21(6))                            # campo 6 = casilla 00987 (INCN del grupo)
        if incn is not None:
            out["incn_grupo"] = incn
    return out


# ----------------------------------------------------- Precarga del año anterior (Capa 1+2, U2 carga asistida)
def _es_fichero_200(path) -> bool:
    """Heurística barata: ¿es un `.200` (registro DR de ancho fijo) y NO un PDF? Busca el tag de envoltorio
    DP200000 en la cabecera. Un PDF (firma %PDF) o binario sin el tag → False (se enruta a parser PDF)."""
    try:
        with open(path, "rb") as fh:
            head = fh.read(4096)
    except OSError:
        return False
    if head[:4] == b"%PDF":
        return False
    return b"<T2000" in head


def _precarga_ocr(nivel, fuente) -> dict:
    """Contrato de precarga cuando el PDF es un ESCANEO (sin texto): no se inventa nada, se enruta a OCR."""
    return {"nivel": nivel, "fuente": fuente, "necesita_ocr": True,
            "caracteres": {}, "pagina01b": {}, "formales": {}, "liquidacion_inputs": {},
            "identificativos": {}, "capa1": {}, "capa2": {}, "resumen": {},
            "perfil_estados_cuentas": None,
            "nota": "PDF sin texto (escaneado): enrutar a OCR (persona_tax/Docling) y reparsear con HITL. "
                    "Recomendación: pedir el datos-fiscales DIGITAL de la Sede AEAT."}


def _precarga_desde_parsed(parsed: dict, nivel: str, fuente: str) -> dict:
    """Mapea la salida de un parser de plantilla fija (Nivel B justificante / Nivel C datos-fiscales) al
    contrato de precarga: caracteres (Capa 1) + formales (Capa 2) + identificativos + liquidacion_inputs.
    `a_params_motor` vale para B y C (misma forma capa1/capa2). Los inputs de liquidación NO se autofirman."""
    import parser_datos_fiscales_aeat as _df
    params = _df.a_params_motor(parsed) or {}
    capa1 = parsed.get("capa1", {})
    capa2 = parsed.get("capa2", {})
    formales = params.get("formales", {}) or {}
    resumen = {
        "n_caracteres": len(params.get("caracteres", {}) or {}),
        "n_administradores": len(formales.get("administradores", []) or []),
        "n_socios": len(formales.get("socios", []) or []),
        "n_titulares": len(formales.get("titulares_reales", []) or []),
        "n_secretario": len(formales.get("secretario", []) or []),
        "n_representantes": len(formales.get("representantes", []) or []),
        "n_liquidacion_inputs": len(parsed.get("liquidacion", {}) or {}),
    }
    ident = params.get("identificativos") or {"nif": capa1.get("nif"), "razon_social": capa1.get("nombre")}
    if capa1.get("cnae_2025") and not ident.get("cnae"):
        ident = {**ident, "cnae": capa1["cnae_2025"]}   # CNAE-2025 actividad principal (datos-fiscales) → cierra aviso 196
    return {
        "nivel": nivel, "fuente": fuente, "necesita_ocr": False,
        "caracteres": params.get("caracteres", {}) or {},
        "pagina01b": {},   # Nivel B/C no reconstruye DP200001B; la selección de modelo la confirma la pág 1
        "formales": formales,
        "liquidacion_inputs": parsed.get("liquidacion", {}) or {},
        "identificativos": ident, "capa1": capa1, "capa2": capa2, "resumen": resumen,
        "perfil_estados_cuentas": capa1.get("perfil_estados_cuentas"),
        "nota": (f"Nivel {nivel} ({fuente}): CARGA ASISTIDA. Los inputs de liquidación (INCN/retenciones/BINs) "
                 "NO se autofirman — requieren confirmación profesional."),
    }


def precarga_anterior(path: str, ejercicio="2024", tipo="auto") -> dict:
    """Declaración/datos del AÑO ANTERIOR → Capa 1 (caracteres + página 1B) + Capa 2 (formales) + inputs de
    liquidación (carga asistida; NO autofirmados). Niveles, por precedencia A > B > C:
      A `.200` previo      → caracteres_declaracion + pagina01b_declaracion (determinista; reusa lo existente).
      B justificante PDF   → parser_justificante_m200 (fecha de poder de representantes; error import 153).
      C datos-fiscales PDF → parser_datos_fiscales_aeat (caracteres + socios + INCN/retenciones/BINs).
    PDF escaneado (sin texto) → necesita_ocr=True (ruta OCR + reparseo + HITL). Aditivo: NO toca el cálculo;
    sólo lee plantillas fijas autoetiquetadas. 0 PII en logs (devuelve el dict; no imprime)."""
    ej = str(ejercicio)
    # Nivel A: `.200` previo (determinista; reusa caracteres_declaracion/pagina01b_declaracion).
    if tipo == "previo_200" or (tipo == "auto" and _es_fichero_200(path)):
        caracteres = caracteres_declaracion(path, ejercicio=ej)
        pag01b = pagina01b_declaracion(path, ejercicio_prior=ej)
        formales = formales_declaracion(path, ejercicio=ej)   # B.2 socios COMPLETOS (país+nominal+%) del previo
        ident = identificativos_declaracion(path, ejercicio=ej)  # NIF + razón social del declarante (evita EMALNI1/EMALNO1)
        n = len(caracteres) + len(pag01b)
        return {
            "nivel": "A", "fuente": "previo_200", "necesita_ocr": False,
            "caracteres": caracteres, "pagina01b": pag01b, "formales": formales, "liquidacion_inputs": {},
            "identificativos": ident, "capa1": {}, "capa2": {},
            "resumen": {"n_caracteres": len(caracteres), "n_pagina01b": len(pag01b),
                        "n_socios": len(formales.get("socios", []) or [])},
            "perfil_estados_cuentas": None,
            "nota": ("Nivel A (.200 previo): caracteres (config estable) + página 1B (modelo de estados de "
                     "cuentas) + datos mercantiles/formales del N-1 (administradores, B.1, B.2, titular real, "
                     "secretario y representantes; carga asistida, confírmalos)."
                     if n else "El `.200` no contenía caracteres re-leíbles (¿formato distinto?)."),
        }
    # Nivel B/C: PDF de plantilla fija. Detección explícita por `tipo`, o auto por marcadores.
    import parser_datos_fiscales_aeat as _df
    import parser_justificante_m200 as _ju
    if tipo == "justificante":
        parsed = _ju.parse(path, ejercicio=ej)
        return _precarga_ocr("B", "justificante_m200") if parsed.get("necesita_ocr") \
            else _precarga_desde_parsed(parsed, "B", "justificante_m200")
    if tipo == "datos_fiscales":
        parsed = _df.parse(path, ejercicio=ej)
        return _precarga_ocr("C", "datos_fiscales_aeat") if parsed.get("necesita_ocr") \
            else _precarga_desde_parsed(parsed, "C", "datos_fiscales_aeat")
    # auto: probar datos-fiscales (C); si no parece C, probar justificante (B).
    parsedC = _df.parse(path, ejercicio=ej)
    if parsedC.get("necesita_ocr"):
        return _precarga_ocr("C", "datos_fiscales_aeat")
    looksC = bool(parsedC.get("capa1", {}).get("caracteres") or parsedC.get("capa2", {}).get("socios")
                  or parsedC.get("capa2", {}).get("administradores")
                  or parsedC.get("capa2", {}).get("titulares_reales")
                  or parsedC.get("capa2", {}).get("secretario")
                  or parsedC.get("capa2", {}).get("representantes")
                  or parsedC.get("liquidacion"))
    if looksC:
        return _precarga_desde_parsed(parsedC, "C", "datos_fiscales_aeat")
    parsedB = _ju.parse(path, ejercicio=ej)
    if parsedB.get("necesita_ocr"):
        return _precarga_ocr("B", "justificante_m200")
    looksB = bool(parsedB.get("capa2", {}).get("administradores") or parsedB.get("capa2", {}).get("representantes")
                  or parsedB.get("capa1", {}).get("matriz_ultima"))
    if looksB:
        return _precarga_desde_parsed(parsedB, "B", "justificante_m200")
    return _precarga_desde_parsed(parsedC, "C", "datos_fiscales_aeat")   # nada reconocido → C vacío (no inventa)


# --------------------------------------------- Resolver TB de grupo → PGC (lineage HITL, U1 carga asistida)
def resolver_contable_grupo_tb(path: str, ejercicio="2024") -> dict:
    """TB de ERP de GRUPO (plan propio ≠ PGC) → canónico que cuadra + LINEAGE HITL por cuenta (PGC resuelto,
    método código/descripción/fallback, confianza; <0,7 = revisar) + Fase A. Modo CARGA ASISTIDA: el resolver
    mapea best-effort el 100% de las cuentas (por eso cuadra el balance) y el profesional revisa el lineage.
    Pre-motor: NO toca dr200/builder → GIP 2024 byte-idéntico. Aditivo."""
    import resolver_contable_grupo as _res
    from collections import Counter
    with tempfile.TemporaryDirectory() as td:
        # El resolver emite un CSV con FORMA de SyS (cuenta resuelta + Saldo Final; Debe/Haber vacíos): se
        # ingesta por el MISMO pipeline que el SyS del abogado (motor_sys → builder), no como canónico ya 4d.
        sys_out = os.path.join(td, "tb_resuelto.csv")
        lin_out = os.path.join(td, "lineage.csv")
        lineage = _res.adaptar(path, sys_out, ejercicio=str(ejercicio), lineage_out=lin_out)
        fase_a = fase_a_desde_sys(sys_out, tipo_entidad="normal", ejercicio=str(ejercicio))
    canonico_csv = fase_a.get("canonico_csv") or ""   # canónico 4d PROYECTADO (numérico, listo para el paquete)
    lin = [{"cuenta_origen": x["orig"], "descripcion": x["desc"], "pgc_resuelto": x["pgc"],
            "metodo": x["metodo"], "confianza": x["confianza"], "revisar_hitl": x["confianza"] < 0.7}
           for x in lineage]
    return {
        "canonico_csv": canonico_csv,
        "lineage": lin,
        "resumen": {"n": len(lin), "por_metodo": dict(Counter(x["metodo"] for x in lin)),
                    "hitl": sum(1 for x in lin if x["revisar_hitl"]),
                    "confianza_media": round(sum(x["confianza"] for x in lin) / len(lin), 3) if lin else 0.0},
        "fase_a": fase_a,
    }


def _liq_detalle_paginas(liq, ej) -> dict:
    """Casillas de DETALLE de la liquidación (detalle de compensación de BINs en DP200015, detalle de
    correcciones al resultado en DP200020B, regímenes especiales DP200026x…) agrupadas por su página de
    detalle {pagina: {casilla: valor}}. SOLO incluye casillas cuyo código NO aparece en ninguna página CORE
    (contable/identificativos/liquidación-core): así se evita el problema de homónimos (un código reutilizado
    como concepto distinto en una página core se deja a su mecanismo, no se reasigna al detalle). Sin esto el
    importador exige las páginas de detalle (p.ej. EMALP20 'debe incluir la página 20')."""
    liq = {k: v for k, v in (liq or {}).items() if v not in (None, "")}
    if not liq:
        return {}
    dr = dr200.cargar_dr(ejercicio=str(ej))
    pliq = set(dr200.PAGINAS_LIQUIDACION)
    # Una casilla la EMITE el mecanismo core solo si está en una página de PAGINAS_LIQUIDACION; si además
    # aparece en una contable/ECPN (DP200009/010/011) es un HOMÓNIMO que el core NO emite, así que esa casilla
    # de detalle (p.ej. los totales de gastos financieros 00538/539/546, homónimos del ECPN) sí debe ir a su
    # página de detalle. El DESTINO nunca puede ser una página contable/identificativos/liquidación-core.
    no_destino = pliq | set(dr200.PAGINAS_CONTABLE) | {"DP200001", "DP200001B", "DP200002", "DP200002B"}
    pages_of = {}
    for pg, campos in dr.items():
        for c in campos:
            cas = c.get("casilla")
            if cas:
                pages_of.setdefault(cas, []).append(pg)
    out = {}
    for cas, val in liq.items():
        pgs = pages_of.get(cas, [])
        if not pgs or any(p in pliq for p in pgs):
            continue                                       # el core (PAGINAS_LIQUIDACION) ya la emite
        dest = [p for p in sorted(pgs) if p not in no_destino]
        if dest:
            out.setdefault(dest[0], {})[cas] = val         # primera página de DETALLE (orden estable)
    # 00417/00418 (totales de correcciones) van TAMBIÉN en la página 20BIS, PERO ahí su valor importable es el
    # de las correcciones PERMANENTES (02301/02302), no el total de la pág 13 (que incluye la diferencia
    # TEMPORARIA de GF). Las temporarias (02303/02309) están BLOQUEADAS a la importación: el formulario Sociedades
    # WEB las auto-genera al editar 00363. Si se emitiera el total con GF en la 20BIS, el importador lo rechaza
    # (E25400417 pág 20BIS), porque calcula 02301+02303(=0 en fichero)=permanente. Emitir el permanente → solo el
    # aviso 651 (que recuerda completar el cuadro en el formulario). Para 00418 no hay temporaria → 02302=00418.
    if "DP200020B" in dr:
        _bis = {"00417": liq.get("02301"), "00418": liq.get("02302")}
        for c in ("00417", "00418"):
            v = _bis[c] if _bis[c] not in (None, "") else liq.get(c)
            if v not in (None, ""):
                out.setdefault("DP200020B", {})[c] = v
    # 00547 (compensación total de BINs) va TAMBIÉN en el desglose de la página 15 (DP200015), además de su
    # página de liquidación core (DP200014) — el importador lo exige en la 15 (E25400547).
    if "DP200015" in dr and liq.get("00547") not in (None, ""):
        out.setdefault("DP200015", {})["00547"] = liq["00547"]
    # Página 20 quater (DP200020D): base de la reserva de capitalización/nivelación = resultado contable 00500
    # (00650/00653/00654/00666/01522). El routing por orden las mandaría a DP200015 (homónimo); van a su página
    # correcta (error 16200: 00650 pág 20 quater debe = 00500 pág 12).
    if "DP200020D" in dr:
        for c in ("00650", "00653", "00654", "00666", "01522"):
            if liq.get(c) not in (None, ""):
                out.setdefault("DP200020D", {})[c] = liq[c]
                # Quitar el valor de la distribución de las páginas HOMÓNIMAS donde la misma casilla es otra cosa:
                # DP200015 (detalle BINs por año) y DP200016 (01522 = reajuste de deducciones, EMR01522). Solo
                # debe vivir en DP200020D (cuadro de distribución del resultado).
                for _pg in ("DP200015", "DP200016"):
                    if c in out.get(_pg, {}):
                        del out[_pg][c]
    return out


def _entrada_declaracion_dr(ej, contable, nif="", razon_social="", liquidacion=None, formales=None,
                            caracteres=None, incn=None, ecpn=None, pagina01b=None, cnae=None,
                            perfil_estados_abreviado=None, perfil_estados_pymes=None,
                            liq_detalle_extra=None):
    """Núcleo común del registro DR (declaración de ancho fijo) = identificativos + `contable` {casilla: valor}
    + (5.B) la LIQUIDACIÓN firmada (BI/cuota). contable y liquidación se escriben SEPARADOS por origen: cada
    uno solo en SUS páginas (los códigos de casilla se reutilizan entre páginas/marcos de entidad, así que la
    liquidación NO pisa casillas contables homónimas — revisión adversarial). Devuelve la entrada de fichero
    (con el aviso de casillas dependientes de OTROS modelos) o None si no hay ni contable ni liquidación.
    PROVISIONAL: no hay XSD para la declaracion completa; valida solo importando el .200 en Sociedades WEB."""
    contable = {k: v for k, v in (contable or {}).items() if v not in (None, "")}
    liq = {str(k).strip(): v for k, v in (liquidacion or {}).items() if v not in (None, "")} if liquidacion else {}
    if not contable and not liq:
        return None

    # --- Coherencia contable→liquidación: cuadra avisos SISTEMÁTICOS del importador (valen para toda declaración) ---
    def _f(v):
        try:
            return float(str(v).replace(",", "."))
        except (ValueError, TypeError):
            return None
    # 10250: el aviso "01250 (pág 20) ≠ 00296 (pág 7)" es NO bloqueante y NO se autocuadra aquí. Cuadrarlo
    # (01250=00296) destapó que el beneficio operativo REAL de la ETVE es NEGATIVO (el importador recalcula
    # 01249 = 30%·BO = −2.707.290,08), lo que baja el límite GF al suelo de 1M (art. 16.1) y rompe el import
    # con errores 5091/22890/E25401249/E25402369. Es DECISIÓN FISCAL del abogado, no un ajuste mecánico: la
    # hoja GF trae 01250 inflado (164,8M) para forzar un BO positivo. Se deja el valor de la hoja GF y el
    # autocontrol marca INT-GF-RE para que el abogado lo resuelva (ver doc 2026-06-19, §"BO negativo").
    # 20966/20967: corrección por Impuesto sobre Sociedades. Si 00326 (impuesto, pág 8) ≥ 0, la casilla 00301
    # (pág 12) NO puede tener contenido y 00302 = 00326. El parser lo trae en 00301 (negativo); se reubica a 00302.
    _is = _f(contable.get("00326"))
    if liq and _is is not None and _is >= 0:
        liq["00302"] = contable["00326"]
        liq["00301"] = 0.0
    # Puente resultado-contable → liquidación: la casilla 00500 (resultado de la cuenta de PyG) figura en la
    # página 8 (PyG) Y en la página 12 (inicio de la liquidación) y DEBE coincidir (EMAL500_12). El contable
    # (SyS) es la fuente del resultado; se propaga a la liquidación para que ambas páginas lleven el mismo valor.
    if liq and contable.get("00500") and "00500" not in liq:
        liq["00500"] = contable["00500"]
    # Distribución del resultado (DP200020D pág 20 quater): la BASE de reparto (00650 PyG = 00653 total) y la
    # APLICACIÓN (00654 a reservas = 00666 total) son el resultado contable 00500 si es POSITIVO. El importador
    # exige (16200) 00650=00500 y (16211) 00653=00666 (todo lo repartido se aplica). Default = todo a reservas;
    # si hubo dividendos, el abogado reparte 00654/dividendos manteniendo Σaplicación=00666=00653.
    # NOTA: va DES-ANIDADO del guard "00500 not in liq" — la liquidación BASE cosmética ya pone 00500 en liq, así
    # que si se dejara dentro nunca se poblaría 00650 y la AEAT rechazaría con 16200 (DP200020D ausente).
    try:
        _r500 = liq.get("00500") if liq else None
        if _r500 not in (None, "") and float(str(_r500).replace(",", ".")) > 0:
            # 00654 (a reservas) es subtotal de 01270(capitalización)+01271(nivelación)+01522(otras): el
            # importador lo recalcula desde el detalle, así que se puebla 01522 (otras reservas) = 00500 para
            # que 00654=01522 y la aplicación cuadre. Default = todo a otras reservas (el abogado reparte si
            # hubo dividendos/dotaciones específicas, manteniendo Σaplicación=00666=00653).
            for _c in ("00650", "00653", "00654", "01522", "00666"):
                liq.setdefault(_c, _r500)
    except (ValueError, TypeError):
        pass
    dr = dr200.cargar_dr(ejercicio=ej)
    # [FIX EMALP311] Modelo de estados de cuentas por DEFECTO = NORMAL. Si se emiten páginas contables (3-11)
    # SIN declarar en DP200001B qué modelo usa la entidad (Balance/ECPN/PyG, campos 14/15/16 = 1 normal/2 abrev/
    # 3 PYMES), Sociedades WEB rechaza con EMALP311 ("para que las páginas 3-11 tengan contenido… debe haber
    # cumplimentado algún estado de cuentas"). Pasa con TODO flujo sin `.200` N-1 (lote y /is-nueva): la precarga
    # Nivel B/C deja pagina01b={} y antes el DR salía sin DP200001B. FILL-IF-MISSING: si se proyecta detalle
    # NORMAL, declarar 14/15/16 = 1 (ARIOSO R3 / ADR-001); un modelo ya indicado (abreviado/PYMES explícito) GANA
    # y no se pisa. NO marca caracteres de exención de estados (00003/00004/00024/00025/00036/00058/00061): esos
    # solo se emiten si el llamador los aporta (entidad exenta). pagina01b se normaliza a dict mutable.
    pagina01b = dict(pagina01b or {})
    _perfil_downgrade = []   # Fase 0: familias cuyo perfil sugerido (abreviado/PYMES) se degrada a normal (aviso)
    _perfil_abreviado = set(perfil_estados_abreviado or ())   # M2: familias a EMITIR en abreviado (opt-in)
    _perfil_pymes = set(perfil_estados_pymes or ())           # M2: familias a EMITIR en PYMES (opt-in)
    # M2 — emisión ABREVIADO/PYMES en el `.200` (reimport REAL NS BILBAO, 2026-06-30): se construye en DOS tiempos
    # con `aplicar_perfil_estados_contables(..., mantener_calculadas=True)`. (1) PLIEGA el detalle (N)-only en sus
    # carriers (igual que el XML certificado): el `.200` NO puede llevar casillas (N)-only (Open «la casilla NNNNN no
    # puede tener contenido»). (2) RE-AÑADE los subtotales/totales/resultados CALCULADOS a su valor NORMAL: el `.200`
    # es de ancho fijo y Open VALIDA LA HOJA ENTERA recomponiendo cada calculada desde el detalle; si quedan a 0.00
    # las RECHAZA («se ha calculado un valor X y el valor importado es 0.00»). El plegado CONSERVA los subtotales
    # (el carrier capta su detalle en el mismo subárbol) → lo que Open recompone desde los carriers == el subtotal
    # normal. La poda de calculadas vive SOLO en el XML (Open las rellena); en el `.200` es LETAL. Familias abreviado
    # y PYMES son disjuntas. OPT-IN: sin pedirlo, camino normal byte-idéntico. ECPN = EXCEPCIÓN: voluntario, se OMITE.
    import transformar_xml_abreviado as _abrev
    if _perfil_abreviado:
        contable, _abrev_inf = _abrev.aplicar_perfil_estados_contables(
            contable, familias=tuple(sorted(_perfil_abreviado)), ejercicio=str(ej), perfil="abreviado",
            mantener_calculadas=True)
    if _perfil_pymes:
        contable, _pymes_inf = _abrev.aplicar_perfil_estados_contables(
            contable, familias=tuple(sorted(_perfil_pymes)), ejercicio=str(ej), perfil="pymes",
            mantener_calculadas=True)
    if "00208" in contable and not _perfil_pymes:
        # Import real Lanzarote 2025: en el `.200` normal OpenWeb rechaza 00208 con E25400208
        # ("no puede tener contenido"). El importe importable vive en 00209; 00208 lo recompone el formulario.
        contable = {k: v for k, v in contable.items() if k != "00208"}
    # ECPN VOLUNTARIO en abreviado/PYMES: si se emite un perfil (abreviado/PYMES) y NO se pidió la familia `ecpn`,
    # el ECPN se OMITE LIMPIO — no se emiten DP200009/10/11 y DP200001B campo 15 = 0 ("no consta"). Si no se
    # podara, el contable arrastraría el ECPN NORMAL de la fuente (flags 2/1/2 + DP200009 con datos) = mismatch
    # en Open. El ECPN solo se emite cuando se pide explícitamente (vía perfil_estados_*=[..,'ecpn'], p.ej. RRE full).
    # En el `.200` abreviado/PYMES el ECPN se OMITE SIEMPRE (voluntario). No solo cuando no se pide la familia
    # `ecpn`: la proyección abreviado del ECPN (que «doblaría» 00390→00391 para casar el modelo) PONE A 0.00 los
    # subtotales calculados del ECPN columnar → letal en el `.200` (mismo problema que balance/PyG, T1); y emitir el
    # ECPN NORMAL con flag 2/3 es un mismatch que Open rechaza (00390 «no habilitada en PYMES»). El ECPN del opt-in
    # se entrega por el XML contable (proyección certificada), no por el `.200`. Por eso aquí el `.200` nunca lleva
    # ECPN en abreviado/PYMES (campo15=0). Normal (sin perfil) y opt-in del XML NO se ven afectados.
    _omitir_ecpn = bool(_perfil_abreviado or _perfil_pymes)
    if _omitir_ecpn and contable:
        import transformar_xml_abreviado as _abrev2
        _cas2pag = _abrev2._casilla_pagina(dr200.cargar_dr(ejercicio=str(ej)))
        _ecpn_pags = {"DP200009", "DP200010", "DP200011"}
        contable = {_c: _v for _c, _v in contable.items() if _cas2pag.get(_c) not in _ecpn_pags}
    if contable:
        _b01b = dr.get("DP200001B", [])

        def _nmodelo(*kw, excl=()):
            for _c in _b01b:
                _d = (_c.get("descripcion") or "").lower()
                if all(k in _d for k in kw) and not any(e in _d for e in excl):
                    return _c.get("num")
            return None

        # FASE 0 — GUARDRAIL anti-mismatch de perfil de estados (spec PERFILES_ESTADOS_CONTABLES): el motor
        # proyecta el modelo NORMAL salvo que M2 pida abreviado para esa familia. Si una fuente (N-1/CCAA) había
        # sugerido abreviado/PYMES (2/3) en pagina01b pero NO se pide emitir abreviado, NO se hereda — declarar un
        # perfil y emitir las casillas de otro provoca rechazo en Open: se FUERZA 1 (normal) y se anota para avisar.
        for _fam, _n, _key in (("Balance", _nmodelo("balance"), "balance"),
                               ("ECPN", _nmodelo("ecpn"), "ecpn"),
                               ("PyG", _nmodelo("ganancias"), "pyg")):
            if _n is None:
                continue
            if _key == "ecpn" and _omitir_ecpn:
                pagina01b[_n] = 0     # 0 = NO CONSTA: ECPN OMITIDO SIEMPRE en abreviado/PYMES (va por el XML, no el
                #                       `.200`). Va PRIMERO: aunque 'ecpn' esté en las familias del opt-in, el `.200`
                #                       no lo emite, así que su flag debe ser 0 (coherencia campo15=0 ↔ sin DP200009/10/11).
            elif _key in _perfil_abreviado:
                pagina01b[_n] = 2     # 2 = modelo ABREVIADO = lo que el motor emite tras la proyección (M2)
            elif _key in _perfil_pymes:
                pagina01b[_n] = 3     # 3 = modelo PYMES = lo que el motor emite tras la proyección PYMES (M2)
            else:
                if str(pagina01b.get(_n, "")).strip() in ("2", "3"):
                    _perfil_downgrade.append(_fam)
                pagina01b[_n] = 1     # 1 = modelo NORMAL = lo que el motor realmente emite (coherencia DP200001B)
    ident = dr200.mapear_identificativos(dr, {"nif": nif, "razon_social": razon_social, "ejercicio": ej,
                                              "cnae": cnae})
    _grupo_fiscal_dr = any(str((caracteres or {}).get(_c, "")).strip() == "1" for _c in ("00009", "00010"))
    # Miembro de grupo fiscal: el bloque de INGRESO del DID (modalidad + importe a ingresar) va VACÍO (Open
    # EMALID25). Confirmado contra el 200 N-1 REAL de un dependiente: con cuota POSITIVA el miembro MARCA «Resultado
    # cero» y NO consigna importe de ingreso (la cuota se ingresa en el Modelo 220), pero el resultado 00621 (pág
    # 14B) SÍ va positivo (la AEAT lo recalcula; E254 si fuera 0) — no se toca `liq`. resultado=0 → DID sin importe.
    did = dr200.mapear_identificativos_did(dr, {"nif": nif, "razon_social": razon_social, "ejercicio": ej,
                                                "resultado": (0 if _grupo_fiscal_dr else liq.get("00621"))})
    liq_detalle = _liq_detalle_paginas(liq, ej)
    for _pg, _cas in (liq_detalle_extra or {}).items():
        if _cas:
            liq_detalle.setdefault(_pg, {}).update(_cas)
    # Sociedad matriz última = el propio declarante cuando la entidad es matriz última del grupo (caracter
    # 00082): rellena sus datos en DP200001B si vienen vacíos (errores 10034 incompleto / 10042 no coincide con
    # el declarante). País por defecto ES (residente en territorio español).
    if pagina01b and caracteres and str(caracteres.get("00082", "")).strip() == "1":
        _b = dr.get("DP200001B", [])

        def _nb(*kw, excl=()):
            for _c in _b:
                _d = (_c.get("descripcion") or "").lower()
                if all(k in _d for k in kw) and not any(e in _d for e in excl):
                    return _c.get("num")
            return None

        for _n, _v in ((_nb("matriz", "nif"), nif), (_nb("matriz", "razón social"), razon_social),
                       (_nb("nombre de grupo"), razon_social),
                       (_nb("país de residencia", excl=("nif",)), "ES"),
                       (_nb("país de residencia", "nif"), nif)):
            if _n is not None and _v and not str(pagina01b.get(_n, "")).strip():
                pagina01b[_n] = _v
    # Tipo de declaración (campo 6, I/D/N por signo de la cuota a ingresar/devolver 00621) + tramo de INCN
    # (campos 102/103/104, ≥20M/≥60M) — el replay los pone vía _ident_campos. Sin ellos el importador no
    # contextualiza la declaración y rechaza la cuota mínima 00619 (E25400619). Mismos campos/umbrales.

    def _f(v):
        try:
            s = str(v).strip().replace(" ", "")
            s = s.replace(".", "").replace(",", ".") if ("," in s and "." in s) else s.replace(",", ".")
            return float(s)
        except (ValueError, TypeError):
            return 0.0

    cuota = _f(liq.get("00621"))
    ident.setdefault(6, "I" if cuota > 0 else ("D" if cuota < 0 else "N"))
    # INCN: propio (contable 00255) o del GRUPO (00987, para una holding cuyo INCN individual es bajo pero su
    # grupo factura ≥60M). Se acepta `incn` explícito (arrastre del bracket de la entidad).
    incn_val = _f(incn) or _f(contable.get("00255")) or _f(contable.get("00987")) or _f(liq.get("00987"))
    # R7.1 (gating subjetivo art.30bis UNIFICADO): la cuota líquida mínima 00619 solo aplica con INCN≥20M
    # (o consolidación). Por debajo NO debe emitirse (la AEAT la rechaza, E25400619, al no marcarse tramo). Esta
    # vía (exportar_aeat) ahora poda 00619 igual que el builder de replay (gip2024_replay_builder.py) → MISMA
    # regla en ambos caminos. Para GIP (INCN≥20M) no poda: 00619 se mantiene (sin cambio).
    if liq and incn_val < 20_000_000:
        liq.pop("00619", None)
    if incn_val >= 60_000_000:
        ident.setdefault(104, "1")
    elif incn_val >= 20_000_000:
        ident.setdefault(103, "1")
    else:
        ident.setdefault(102, "1")     # [A5 FIX G3] INCN < 20M: marcar el tramo (campo 102) -> cierra error 7011
    # Páginas obligatorias de liquidación: cuando hay liquidación, el `.200` debe llevar TODAS las páginas de
    # liquidación (12/13/14/14B/DID) aunque alguna salga a cero — si no, el importador rechaza con EMALOBL
    # ("faltan páginas obligatorias"). Se fuerzan SOLO con liquidación (un borrador contable-solo no las lleva).
    # Las ya emitidas (con datos) no se duplican (construir_declaracion solo fuerza las que faltan).
    # + DP200020 (página 20 PRINCIPAL, detalle de correcciones al resultado): el importador la exige por
    # estructura cuando hay liquidación (EMALP20), no basta la 20 bis (DP200020B). En modo base va a CERO (sin
    # inventar gastos financieros/correcciones); el detalle real lo aporta el abogado en Sociedades WEB.
    # Las páginas ECPN 10/11 NO se fuerzan vacías aquí: emitirlas a CERO hace que la AEAT valide la hoja entera y
    # rechace los cierres/totales computados (reimport REDEVCO 2026-06-28). Se emiten SOLO si ecpn_sys proyecta
    # contenido (vía `ecpn`); su reconciliación con la AEAT es trabajo del motor para TB no-PGC.
    # DP200020 (límite GF art.16) se fuerza por estructura SALVO en miembro de grupo fiscal: Open RECHAZA (EPAGINC)
    # cualquier página 20 en un miembro del grupo (el límite se computa en el Modelo 220). Antes se forzaba siempre
    # y luego se podaban las casillas, pero el REGISTRO de página vacío seguía emitiéndose → riesgo EPAGINC. Ahora no
    # se incluye en paginas_min para miembros de GF (la liquidación 12/13/14/14B/DID sí, esas sí son obligatorias).
    paginas_min = ((list(dr200.PAGINAS_LIQUIDACION) + ([] if _grupo_fiscal_dr else ["DP200020"])) if liq else None)
    # Suelo del límite de GF (art.16.1, casilla 02369 = max(30%·B.O.; 1.000.000 €)): la AEAT SIEMPRE lo recalcula
    # a ≥1.000.000 y rechaza el import con E25402369 si la página 20 (que aquí se fuerza por estructura) lleva
    # 02369=0. Cuando hay liquidación (DP200020 presente), garantizamos el SUELO legal de 1.000.000 si el motor no
    # calculó un valor mayor; no inventa gastos financieros (el detalle GF lo aporta el abogado), solo el suelo.
    if liq and not _grupo_fiscal_dr:   # solo con liquidación real; en grupo fiscal la página 20 GF NO se emite (EPAGINC)
        try:
            _o2369 = float(str(liq.get("02369") or 0).replace(",", "."))
        except (TypeError, ValueError):
            _o2369 = 0.0
        if _o2369 < 1_000_000.0:
            liq["02369"] = 1_000_000.0
    # [GRUPO FISCAL — miembro] El 200 INDIVIDUAL de un miembro de grupo (00009 dominante / 00010 dependiente)
    # exige, además de podar la página 20 (límite art.16 → Modelo 220): (1) «Resultado cero» = 1 en DP200DID
    # (Open: EMALID27); (2) NIF de la sociedad representante/dominante en DP200001B (Open: 10031 — en la
    # DOMINANTE coincide con el NIF del declarante; en la DEPENDIENTE es el NIF de la dominante, dato del grupo
    # que aporta el llamador en `pagina01b`, no se inventa); (3) B.I. individual a integrar en el grupo, casilla
    # 01029 de la página 13 = base imponible individual del miembro (= 00550 cuando no hay eliminaciones/
    # incorporaciones de grupo; Manual Cap.07). Gated por 00009/00010 → régimen general (GIP/ARIOSO) intacto.
    if _grupo_fiscal_dr:
        def _gf_desc(_c):
            return (_c.get("descripcion") or "").lower()
        _did_rc = next((c.get("num") for c in dr.get("DP200DID", []) if "resultado cero" in _gf_desc(c)), None)
        if _did_rc is not None and isinstance(did, dict):
            did[_did_rc] = "1"                                    # EMALID27: el miembro de grupo SIEMPRE marca «Resultado cero» (no ingresa individualmente; tributa en el 220)
        if isinstance(ident, dict):
            ident[6] = "N"                                        # tipo de declaración del miembro = N (sin ingreso/devolución individual) → cierra EMALID16
        _c7 = next((c.get("num") for c in dr.get("DP200001B", [])
                    if "representante" in _gf_desc(c) and "n.i.f" in _gf_desc(c)), None)
        if _c7 is not None and not str(pagina01b.get(_c7, "")).strip():
            if str((caracteres or {}).get("00009", "")).strip() == "1":
                pagina01b[_c7] = nif                              # 10031 dominante: campo 7 = NIF del declarante
            else:
                _nd = str((caracteres or {}).get("nif_dominante", "")).strip()
                if _nd:
                    pagina01b[_c7] = _nd                          # dependiente (00010): campo 7 = NIF de la dominante (del N-1)
        if isinstance(caracteres, dict):
            caracteres.pop("nif_dominante", None)                 # valor de DP200001B, no flag de DP200001
        _c6 = next((c.get("num") for c in dr.get("DP200001B", [])
                    if "de grupo fiscal" in _gf_desc(c) and "n.i.f" not in _gf_desc(c)), None)
        _ng = str((caracteres or {}).get("00040", "")).strip()    # nº de grupo (arrastrado del N-1 vía parse_pdf)
        if _c6 is not None and _ng and not str(pagina01b.get(_c6, "")).strip():
            pagina01b[_c6] = _ng                                  # 00040: Nº de grupo fiscal (DP200001B campo 6)
        if isinstance(caracteres, dict):
            caracteres.pop("00040", None)                         # es VALOR de DP200001B, no flag de DP200001
        if liq and str(liq.get("00550", "")).strip() != "" and not str(liq.get("01029", "")).strip():
            liq["01029"] = liq["00550"]                           # E25401029: B.I. individual a integrar (= 00550)
        if liq:
            liq.pop("00619", None)                                 # cuota minima art.30bis: se liquida en el grupo, no en el 200 individual
    # Fichero COMPLETO con envoltorio DP200000 (<T200…> + <AUX> + páginas + </T200…>), tag por ejercicio.
    doc = dr200.construir_fichero(dr, ej, identificativos=ident, contable=contable, liquidacion=liq,
                                  formales=formales or None, caracteres=caracteres or None,
                                  ecpn=ecpn or None, pagina01b=pagina01b or None,
                                  liq_detalle=liq_detalle or None, did=did or None, paginas_extra=paginas_min)
    # ECPN VOLUNTARIO (abreviado/PYMES sin opt-in 'ecpn'): omitir las PÁGINAS DP200009/10/11 ENTERAS del `.200`.
    # No basta podar las casillas ECPN-only del contable: las casillas COMPARTIDAS con otras páginas (p.ej. 00500
    # Resultado de PyG, que vive también en el A.1 del ECPN) las reemite `construir_fichero` en DP200009 → quedaba
    # campo15=0 («no consta») a la vez que DP200009 con datos = mismatch. Se borra el registro de página entero.
    if _omitir_ecpn:
        for _tag in ("T20009000", "T20010000", "T20011000"):
            doc = re.sub("<" + _tag + ">.*?</" + _tag + ">", "", doc, flags=re.S)
    dependientes = dr200.casillas_dependientes({**contable, **liq})
    pendientes = [d for d in dependientes if not d["presente"]]
    return {
        "fichero": f"declaracion_mod200_{ej}.200", "mime": "text/plain",
        "base64": base64.b64encode(doc.encode("iso-8859-1", "replace")).decode("ascii"),
        "provisional": True,
        "contiene_liquidacion": bool(liq),
        "perfil_estados_downgrade": _perfil_downgrade,   # Fase 0: familias degradadas abreviado/PYMES → normal
        "contiene_formales": bool(formales),     # socios/titular/secretario/representante (importable AEAT)
        "contiene_caracteres": bool(caracteres),  # caracteres de la declaración arrastrados (ETVE/grupo/…)
        "contiene_pagina01b": bool(pagina01b),    # DP200001B: modelo de estados de cuentas + matriz última
        "casillas_dependientes_de_otros_modelos": dependientes,
        "nota": ("Fichero BOE .200 de ancho fijo (declaración, con envoltorio DP200000). Codificación de importes "
                 "OFICIAL (DR: céntimos, 2 decimales, negativo con 'N'). PROVISIONAL solo porque la AEAT no "
                 "publica XSD para la declaración -> validar el fichero como TODO con una importación real en "
                 "Sociedades WEB. Incluye identificativos + contable"
                 + (" + liquidación firmada (BI/cuota)." if liq else "; la liquidación firmada (BI/cuota) "
                    "se añade desde el cierre del expediente.")
                 + (f" PENDIENTE de otros modelos ({len(pendientes)} casillas a cero): "
                    + ", ".join(f"{d['casilla']}←M{d['modelo']}" for d in pendientes) + "." if pendientes else "")),
    }


def _declaracion_dr(td, ej, nif="", razon_social="", liquidacion=None, formales=None, caracteres=None,
                    incn=None, ecpn=None, pagina01b=None, perfil_estados_abreviado=None,
                    perfil_estados_pymes=None):
    """Registro DR desde el contable proyectado del pipeline (casillas.csv en `td`) + identificativos +
    liquidación (5.B) + datos formales (socios/titular/secretario/representante). Delega en
    `_entrada_declaracion_dr`. None si no hay casillas.csv ni liquidación."""
    contable = {}
    casillas_csv = os.path.join(td, "casillas.csv")
    if os.path.exists(casillas_csv):
        import csv as _csv
        with open(casillas_csv, encoding="utf-8-sig") as fh:
            rd = _csv.reader(fh, delimiter=";")
            next(rd, None)
            for row in rd:
                if len(row) >= 5 and row[0].strip():
                    contable[row[0].strip()] = row[4].strip()
    return _entrada_declaracion_dr(ej, contable, nif=nif, razon_social=razon_social,
                                   liquidacion=liquidacion, formales=formales, caracteres=caracteres,
                                   incn=incn, ecpn=ecpn, pagina01b=pagina01b,
                                   perfil_estados_abreviado=perfil_estados_abreviado,
                                   perfil_estados_pymes=perfil_estados_pymes)


def datos_formales(path, sheet=None) -> dict:
    """Extrae los DATOS FORMALES (administrador/socios/titular real/secretario/representante/participadas)
    del XLS de datos formales -> dict `formales` listo para `/exportar-aeat` (que los emite en DP200002/
    DP200002B y hace el .200 importable). Para que el abogado NO pegue JSON. Hoja parametrizable (misma
    plantilla, otra sociedad). Devuelve los nombres/NIF TAL CUAL (no inventa) + avisos para revisión humana."""
    import gip2024_datos_formales_parser as _dfp
    p = _dfp.parse(path, sheet=sheet)
    formales = {k: (p.get(k) or []) for k in
                ("administradores", "socios", "titulares_reales", "secretario", "representantes", "participadas")}
    n = {k: len(v) for k, v in formales.items()}
    warnings = list(p.get("warnings") or [])
    # El parser depende de la POSICIÓN de las filas (plantilla del despacho). Si no se extrae NADA, casi
    # seguro la hoja/plantilla no es la esperada -> avisar (regla dura 5: no devolver vacío en silencio).
    if not any(formales[k] for k in ("administradores", "socios", "titulares_reales", "secretario", "representantes")):
        warnings.append("No se extrajo ningún dato formal: ¿hoja o plantilla distinta a la estándar? "
                        "Revisa el XLS y, si hace falta, indica la hoja. Los datos se rellenan/revisan a mano.")
    return {"formales": formales, "resumen": n, "warnings": warnings}


def exportar_aeat(path_sys, ejercicio="2024", nif="", razon_social="", liquidacion=None, formales=None,
                  caracteres=None, incn=None, ecpn=None, pagina01b=None, liquidacion_base=False) -> dict:
    """SyS/mayor → ficheros de IMPORTACIÓN AEAT DIRECTA (D20): XML mod200 validado contra el XSD oficial
    (entregable PRIMARIO) + XLS de estados contables + registro DR de la declaración (identificativos +
    contable, PROVISIONAL); A3 (agrupado_4d) SECUNDARIO. Listos para descargar (base64). Reusa `pipeline.run`
    (gates B3 cent-exact + validación XSD + versionado por campaña). FAIL-CLOSED: si el SyS descuadra o la
    proyección AEAT no cuadra (00180≠00252), NO se emite el XML (ok=False + motivo)."""
    ej = str(ejercicio)
    XLSX_MIME = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"

    def _b64(p):
        with open(p, "rb") as fh:
            return base64.b64encode(fh.read()).decode("ascii")

    with tempfile.TemporaryDirectory() as td:
        man = pipeline.run([path_sys], td, empresa="", ejercicio=ej)
        val = man.get("etapas", {}).get("validacion", {})
        provisional = bool((man.get("campania") or {}).get("provisional"))
        ficheros = {}
        xmlp = os.path.join(td, f"modelo200_contable_{ej}.xml")
        if os.path.exists(xmlp):
            ficheros["xml_mod200"] = {"fichero": f"modelo200_contable_{ej}.xml", "mime": "application/xml",
                                      "base64": _b64(xmlp), "valido_xsd": bool(val.get("apto")),
                                      "xsd_estado": val.get("xsd"), "xsd_provisional": provisional}
        estp = os.path.join(td, "estados_contables_aeat.xlsx")
        if os.path.exists(estp):
            ficheros["estados_contables_aeat"] = {"fichero": "estados_contables_aeat.xlsx",
                                                  "mime": XLSX_MIME, "base64": _b64(estp)}
        decl = _declaracion_dr(td, ej, nif=nif, razon_social=razon_social, liquidacion=liquidacion,
                               formales=formales, caracteres=caracteres, incn=incn, ecpn=ecpn,
                               pagina01b=pagina01b)  # +ECPN +DP200001B
        avisos = []
        dependientes = []
        # LOTE → `.200` COMPLETO e IMPORTABLE (opt-in `liquidacion_base`, default OFF = contable-solo, contrato
        # previo intacto): el `.200` contable-solo NO lleva las páginas de liquidación (12/13/14/14B) y la AEAT
        # lo rechaza con EMALOBL al importarlo como DECLARACIÓN (incidencia reimport ARIOSO 2025). Si el llamador
        # NO aporta una liquidación firmada y pide `liquidacion_base`, se REUSA `exportar_base` sobre el canónico
        # YA proyectado por el pipeline (`agrupado_4d.csv`) para que el `.200` lleve la liquidación BASE COHERENTE
        # firmada por el motor (ADR-001; EXACTAMENTE la de /is-nueva: cascada 00501→…→00621 + págs obligatorias).
        # Solo sustituye `declaracion_dr`; el XML/XLS contable del lote se mantienen. `gip2025_replay` SÍ pasa
        # liquidación (estimación GIS) → no entra aquí → oráculo intacto. Best-effort: si falla, queda el .200
        # contable-solo (comportamiento previo). NO firma un número nuevo: es la misma BASE cosmética coherente.
        if liquidacion is None and liquidacion_base:
            _canp = os.path.join(td, "agrupado_4d.csv")
            if os.path.exists(_canp):
                try:
                    with open(_canp, encoding="utf-8") as _fh:
                        _eb = exportar_base(_fh.read(), ejercicio=ej, nif=nif, razon_social=razon_social,
                                            formales=formales, caracteres=caracteres, pagina01b=pagina01b,
                                            fuente_canonico="sys", a3_confirmado=True)
                    _dr2 = (_eb.get("ficheros") or {}).get("declaracion_dr")
                    if _dr2:
                        decl = _dr2
                        for _a in (_eb.get("avisos") or []):
                            if _a not in avisos:
                                avisos.append(_a)
                except Exception:   # noqa: BLE001  best-effort: si falla, queda el `.200` contable-solo
                    pass
        if decl is not None:
            ficheros["declaracion_dr"] = decl
            dependientes = decl.get("casillas_dependientes_de_otros_modelos") or []
            pendientes = [d for d in dependientes if not d["presente"]]
            if pendientes:
                avisos.append(
                    f"{len(pendientes)} casilla(s) del 200 dependen de otros modelos y están a cero: "
                    + ", ".join(f"{d['casilla']} (M{d['modelo']})" for d in pendientes)
                    + ". Rellénalas desde el modelo origen (ver ECOSISTEMA_MODELOS_IS.md).")
            if not decl.get("contiene_liquidacion"):
                avisos.append("El DR incluye identificativos + contable; la liquidación firmada (BI/cuota) "
                              "se añade desde el cierre del expediente.")
        a3p = os.path.join(td, "agrupado_4d.xlsx")
        if os.path.exists(a3p):
            ficheros["agrupado_4d"] = {"fichero": "agrupado_4d.xlsx", "mime": XLSX_MIME,
                                       "base64": _b64(a3p), "secundario": True}
        ok = man.get("estado") == "ok" and "xml_mod200" in ficheros
        out = {"ok": ok, "estado": man.get("estado"), "ejercicio": ej,
               "validacion": {"valido_xsd": bool(val.get("apto")), "xsd": val.get("xsd"),
                              "casillas": val.get("casillas"), "errores": (val.get("errores") or [])[:10]},
               "xsd_provisional": provisional, "ficheros": ficheros,
               "casillas_dependientes_de_otros_modelos": dependientes, "avisos": avisos}
        if not ok:
            out["motivo"] = ("El fichero no es un Sumas y Saldos reconocible."
                             if man.get("estado") == "sin_sumas_y_saldos"
                             else "El SyS descuadra o la proyección AEAT no cuadra (00180≠00252); "
                                  "no se emite el XML (fail-closed).")
        return out


# ----------------------------------------------------------- Capa de PRECARGA N-1 (opt-in, aditiva, M1+M3+M4)
# Inyecta los identificativos + el bloque mercantil de la declaración del AÑO ANTERIOR (`.200` N-1) en el
# `.200` que se está generando, para cerrar los cubos 1 (identificativos) y 2 (mercantil/AML) de la validación
# de Sociedades WEB sin que el abogado pique a mano. OPT-IN: solo actúa si se pasa `precarga_n1`; por defecto
# (None) el export se comporta EXACTAMENTE como antes (golden-safe: GIP/ARIOSO/internacionales byte-idénticos).
# ADR-001: NO automatiza el cubo 3 (fiscal). D23: el flag 144 (titular real) se ARRASTRA del N-1, no se infiere.
def precarga_n1_extraer(precarga_n1, ejercicio="2024") -> dict:
    """Normaliza `precarga_n1` al dict `precarga` por AUTO-DETECCIÓN de fuente (extensión):
      · ruta `.200` -> `parser_declaracion_previa.parse_200`   (M1, fixed-width)
      · ruta `.pdf` -> `parser_declaracion_previa.parse_pdf`   (M2, fallback PDF; texto extraíble por anclas;
        PDF imagen -> dict con `requiere_vision=True`)
      · dict        -> se acepta TAL CUAL (visión del llamador o precarga ya extraída; debe traer las claves del
        contrato: identificativos/administradores/representantes/secretario/participaciones_b2/titulares_reales/
        caracteres). Esta es la vía por la que el HITL inyecta lo extraído por visión de un PDF imagen.
    None -> {} (sin efecto). Determinista; 0 PII en logs (devuelve el dict, no imprime)."""
    if precarga_n1 in (None, "", {}):
        return {}
    if isinstance(precarga_n1, dict):
        return precarga_n1
    import parser_declaracion_previa as _pdp
    ruta = str(precarga_n1)
    if ruta.lower().endswith(".pdf"):
        return _pdp.parse_pdf(ruta, ejercicio=str(ejercicio))
    return _pdp.parse_200(ruta, ejercicio=str(ejercicio))     # `.200` (y default para extensiones desconocidas)


def _aplicar_precarga_n1(precarga, ejercicio, formales, caracteres, nif, razon_social, cnae):
    """M3+M4: funde el `precarga` N-1 (dict de M1) en los inputs del `.200`. ADITIVO y FILL-IF-MISSING: lo que
    el llamador ya pasó (formales/caracteres/nif/razon_social/cnae) GANA; la precarga solo rellena huecos.
    Devuelve (formales, caracteres, nif, razon_social, cnae, avisos, manifest). TODO lo precargado se marca
    como pendiente de revisión del abogado (avisos + manifest). Reglas:
      · 144 (titular real, D23): se arrastra del N-1 SOLO si el N-1 lo traía (caracteres['00144']='1') y el N-1
        NO traía registros de titular real (no mezclar 144 con titulares). Si el N-1 trae titular real ->
        arrastrar los registros, no marcar 144. Nunca se pone 144 por defecto.
      · B.2 (validación 186): la suma de % debe ser 100%. Si no, se AVISA (HITL); no se fuerza ni se infla.
      · Titular real: si no hay titular por participación/control en N-1, el Manual considera titular real al
        administrador -> se propone como titular con marca de revisión (solo si no hay ya titular ni 144)."""
    avisos = []
    if not precarga:
        return formales, caracteres, nif, razon_social, cnae, avisos, None
    # M2 (PDF imagen sin capa de texto): parse_pdf devolvió `requiere_vision` y NINGÚN dato. No se inventa nada;
    # se AVISA para que el llamador/HITL aporte la visión (persona_tax OCR / Claude) y reinyecte como dict.
    _sin_datos = not any(precarga.get(k) for k in (
        "identificativos", "administradores", "representantes", "secretario", "participaciones_b2",
        "titulares_reales")) and not (precarga.get("caracteres") or {})
    if precarga.get("requiere_vision") and _sin_datos:
        avisos.append(
            "PRECARGA N-1 (PDF imagen sin texto): no se pudo extraer identificativos ni mercantil por texto. "
            "Aporta la visión (OCR/Claude) del PDF N-1 o el `.200` N-1, o completa estos datos a mano. "
            "El `.200` se emite SIN precarga.")
        return formales, caracteres, nif, razon_social, cnae, avisos, {
            "fuente": precarga.get("fuente") or "previo_pdf", "bloques_precargados": [],
            "requiere_vision": True, "revision_requerida": True}
    ident = precarga.get("identificativos") or {}
    car_n1 = precarga.get("caracteres") or {}
    # --- Identificativos (capa 1): fill-if-missing (el dato del expediente actual manda) ---
    if not str(nif or "").strip() and ident.get("nif"):
        nif = ident["nif"]
    if not str(razon_social or "").strip() and ident.get("razon_social"):
        razon_social = ident["razon_social"]
    # CNAE: NO arrastrar el del N-1 cuando el ejercicio destino usa CNAE-2025. El N-1 es de un ejercicio anterior
    # (clasificación CNAE-2009); arrastrar un código viejo (p.ej. 6420) → la AEAT lo rechaza al importar con
    # EMALCNAE («C.N.A.E. Actividad principal no válido»). Para 2025+ el CNAE-2025 debe venir de fuente del propio
    # ejercicio (datos fiscales, capa 1) o quedar EN BLANCO para que el abogado lo seleccione en Sociedades WEB.
    if not str(cnae or "").strip() and ident.get("cnae"):
        try:
            _ej_cnae = int(str(ejercicio)[:4])
        except (TypeError, ValueError):
            _ej_cnae = 0
        if _ej_cnae >= 2025:
            avisos.append("CNAE: no se arrastra el del año anterior (clasificación CNAE-2009) al campo CNAE-2025; "
                          "queda EN BLANCO. Selecciónalo en Sociedades WEB (la AEAT rechaza el código antiguo con "
                          "EMALCNAE).")
        else:
            cnae = ident["cnae"]
    # --- Mercantil (capa 2): poblar `formales` (contrato de formal200) SOLO en las claves que falten ---
    fmt = dict(formales or {})
    fuentes = []   # qué bloques aportó la precarga (para el aviso/manifest HITL)
    # participaciones_b2 (M1) -> socios (contrato de formal200/_socios_campos: {nif,nombre,pais,nominal,porcentaje})
    b2 = precarga.get("participaciones_b2") or []
    if b2 and not (fmt.get("socios")):
        fmt["socios"] = [{"nif": s.get("nif"), "nombre": s.get("nombre"), "pais": s.get("pais"),
                          "nominal": s.get("nominal"), "porcentaje": s.get("pct"),
                          "fj": s.get("fj")} for s in b2 if str(s.get("nif") or "").strip()]
        if fmt["socios"]:
            fuentes.append("participaciones B.2")
    # participaciones_b1 (M2) -> participadas_b1 (B.1). OpenWeb 2025 acepta B.1 simple (hasta 3 participadas) pero
    # SUN demostró que B.1 con continuaciones/totales parciales rechaza (01501/01502/01503 y E254R2C*T). Por tanto
    # se conserva siempre; formal200 solo emite el subconjunto simple y el resto queda como trabajo post-import.
    b1 = precarga.get("participaciones_b1") or []
    if b1 and not fmt.get("participadas_b1"):
        _b1_ok = [e for e in b1 if str(e.get("nif") or "").strip() and str(e.get("pais") or "").strip()]
        _b1_inc = [e for e in b1 if str(e.get("nif") or "").strip() and not str(e.get("pais") or "").strip()]
        if _b1_ok:
            fmt["participadas_b1"] = [{"nif": e.get("nif"), "nombre": e.get("nombre"), "pais": e.get("pais"),
                                       "pct": e.get("pct"), "nominal": e.get("nominal"),
                                       "valor_libros": e.get("valor_libros"), "dividendos": e.get("dividendos")}
                                      for e in _b1_ok]
            if formal200.b1_emitible_dr(fmt["participadas_b1"]):
                fuentes.append("participaciones B.1 (emitidas en DR simple)")
                avisos.append(
                    f"B.1 (sociedades en las que participa): {len(_b1_ok)} participada(s) captada(s) del N-1 "
                    "y emitida(s) en el .200 como bloque simple sin continuación. Revisar en Sociedades WEB.")
            else:
                fuentes.append("participaciones B.1 (post-import; no se emiten por DR)")
                avisos.append(
                    f"B.1 (sociedades en las que participa): {len(_b1_ok)} participada(s) captada(s) del N-1. "
                    "No se emiten en el .200 porque el bloque exige continuación o presenta riesgo de totales "
                    "01501/01502/01503; se adjuntan como JSON local para revisión/carga post-import en Sociedades WEB.")
        if _b1_inc:
            avisos.append(f"B.1 (sociedades en las que participa): {len(_b1_inc)} participada(s) del N-1 SIN código de "
                          "provincia/país. Quedan fuera del JSON post-import hasta completar el dato; si se informan "
                          "en Sociedades WEB con país/provincia ausente, la AEAT las rechazará.")
    for clave in ("administradores", "titulares_reales", "secretario", "representantes"):
        v = precarga.get(clave) or []
        if v and not (fmt.get(clave)):
            fmt[clave] = v
            fuentes.append({"administradores": "administradores", "titulares_reales": "titular real",
                            "secretario": "secretario", "representantes": "representantes"}[clave])
    # Titular real: datos fiscales 2025 puede traer mas filas que el N-1, pero con menos detalle (sin fecha).
    # Enriquecemos por NIF desde el `.200` N-1 sin sobrescribir lo que haya decidido el llamador.
    def _merge_extra_posicional(dst, src):
        dd = list(dst or [])
        ss = list(src or [])
        n = max(len(dd), len(ss))
        out = []
        for i in range(n):
            dv = dd[i] if i < len(dd) else None
            sv = ss[i] if i < len(ss) else None
            out.append(dv if str(dv or "").strip() else sv)
        return out

    _tit_src = {str(t.get("nif") or "").strip(): t for t in (precarga.get("titulares_reales") or [])
                if str(t.get("nif") or "").strip()}
    for t in (fmt.get("titulares_reales") or []):
        src = _tit_src.get(str(t.get("nif") or "").strip())
        if src and (src.get("extra") or []):
            t["extra"] = _merge_extra_posicional(t.get("extra"), src.get("extra"))
    # --- COMPLETAR socios B.2 y representante desde el N-1 (NUNCA vaciar): para una S.L. (NIF letra B) ambos
    #     bloques son OBLIGATORIOS (errores AEAT 187 socios / 146 representante), así que vaciarlos crea un error
    #     duro. El N-1 los trae por DOS vías con campos distintos: `precarga_anterior` (merge del driver → puebla
    #     `formales`) da el socio SIN país/nominal y el representante con claves `fecha_poder`/`notario`; mientras
    #     que `participaciones_b2`/`representantes` (de precarga_n1_extraer/parse_pdf, en `precarga`) los trae
    #     COMPLETOS (país+nominal+% y `extra`=[fecha,notario]). Se FUSIONAN por NIF para emitir el registro
    #     COMPLETO. Lo que siga incompleto NO se vacía: se mantiene + HITL (el abogado lo completa en Open).
    #     Opt-in (precarga_n1) → GIP/ARIOSO no pasan por aquí → golden-safe.
    def _vacio(v):
        try:
            return v in (None, "") or abs(float(v)) <= 1e-9
        except (TypeError, ValueError):
            return not str(v).strip()
    # B.2 socios: `participaciones_b2` (parse_pdf/parse_200) es el extractor COMPLETO (nif/fj/nombre/país/
    # nominal/%); `precarga_anterior` (merge del driver) puede traer el NIF con un artefacto de columna (visto en
    # RIV II: «N»+NIF en el socio mayoritario), por lo que un merge por NIF dejaría ese socio sin país/nominal →
    # EMALR31. Estrategia: b2 = FUENTE PRIMARIA; se añaden los socios de precarga_anterior que b2 NO cubra (por
    # NIF o por %, que desempata cuando el NIF viene artefactado), para no perder ninguno. Sin b2 → se conserva
    # lo de precarga_anterior tal cual.
    _b2 = [s for s in (precarga.get("participaciones_b2") or []) if str(s.get("nif") or "").strip()]
    if _b2:
        _soc = [{"nif": s.get("nif"), "nombre": s.get("nombre"), "pais": s.get("pais"),
                 "nominal": s.get("nominal"), "porcentaje": s.get("pct"), "fj": s.get("fj")} for s in _b2]
        _nifs = {str(s["nif"]).strip() for s in _soc}
        _pcts = {round(float(s["porcentaje"]), 4) for s in _soc if s.get("porcentaje") is not None}
        for soc in (fmt.get("socios") or []):
            _n = str(soc.get("nif") or "").strip()
            _p = soc.get("porcentaje")
            if _n in _nifs:
                continue
            if _p is not None and round(float(_p), 4) in _pcts:
                continue                                           # mismo socio con NIF artefactado en precarga_anterior
            _soc.append(soc)                                       # socio que b2 no trajo (b2 incompleto) → se conserva
        fmt["socios"] = _soc
    _rep_src = {str(r.get("nif")).strip(): r for r in (precarga.get("representantes") or [])
                if str(r.get("nif") or "").strip()}
    for r in (fmt.get("representantes") or []):                    # normaliza fecha_poder/notario → extra; completa desde precarga
        if not (r.get("extra") or []):
            fp, no = r.get("fecha_poder"), r.get("notario")
            if fp or no:
                r["extra"] = [fp, no]
            else:
                src = _rep_src.get(str(r.get("nif") or "").strip())
                if src and (src.get("extra") or []):
                    r["extra"] = src["extra"]
    # HITL: avisa de obligatorios que SIGAN incompletos tras la fusión (NO se vacían: bloquearían como 187/146)
    _soc_inc = sum(1 for s in (fmt.get("socios") or [])
                   if _vacio(s.get("pais")) or _vacio(s.get("nominal")) or _vacio(s.get("porcentaje")))
    if _soc_inc:
        avisos.append(f"B.2 (socios de la declarante): {_soc_inc} socio(s) del N-1 sin país/nominal/% completos. "
                      "Para una S.L. el bloque es OBLIGATORIO (error 187 al importar); complétalos en Sociedades WEB.")
    _rep_inc = sum(1 for r in (fmt.get("representantes") or [])
                   if len(r.get("extra") or []) < 2 or any(not str(x or "").strip() for x in (r.get("extra") or [None, None])[:2]))
    if _rep_inc:
        avisos.append(f"Representante legal: {_rep_inc} representante(s) del N-1 sin fecha de poder/notario completos. "
                      "Es OBLIGATORIO al menos uno (error 146 al importar); complétalo en Sociedades WEB.")
    # --- Cautela B.2: la suma de participaciones debe ser 100% (validación 186) -> avisa, no fuerza ---
    socios_pct = [s for s in (fmt.get("socios") or []) if s.get("porcentaje") is not None]
    suma_pct = round(sum(float(s.get("porcentaje") or 0.0) for s in socios_pct), 4)
    if socios_pct and abs(suma_pct - 1.0) > 1e-4:
        avisos.append(
            f"Revisar (HITL, validación 186): las participaciones B.2 precargadas del N-1 suman {suma_pct*100:.2f}% "
            "(deben sumar 100%). No se fuerza ni se infla; cuadra la titularidad en Sociedades WEB.")
    # --- Caracteres de la declaración (config. página 1: tipo de entidad/régimen) del N-1: arrastre
    #     fill-if-missing (lo que ya trae el llamador gana). 00144 (titular real) tiene su tratamiento D23 aparte
    #     (abajo). Sin esto, la pág 1 sale EN BLANCO aunque el N-1 marcara ETVE/gran empresa/grupo (REDEVCO 2024).
    car = dict(caracteres or {})
    _car_pre = []
    _CAR_VOLATIL_EJERCICIO = {
        "00027": "base imponible negativa o cero",  # depende del resultado de 2025; no es configuración estable
    }
    # COHERENCIA: 00081/00082 (filial / sociedad matriz última de grupo multinacional) EXIGEN el bloque «sociedad
    # matriz última» (DP200001B: NIF/denominación/país) que el N-1 no aporta → si se arrastra el carácter sin el
    # bloque, la AEAT rechaza con FRECH 10034. No se arrastran; se marca HITL para Sociedades WEB.
    _CAR_MATRIZ = {"00081", "00082"}
    _car_matriz_n1 = [k for k in _CAR_MATRIZ if str((car_n1 or {}).get(k, "")).strip()]
    _car_volatil_n1 = [k for k in _CAR_VOLATIL_EJERCICIO if str((car_n1 or {}).get(k, "")).strip()]
    for _k, _v in (car_n1 or {}).items():
        if _k in _CAR_MATRIZ:
            continue
        if _k in _CAR_VOLATIL_EJERCICIO:
            continue
        if _k != "00144" and _k not in car and str(_v).strip():
            car[_k] = _v
            _car_pre.append(_k)
    if _car_matriz_n1:
        avisos.append("Grupo multinacional (caracteres " + "/".join(sorted(_car_matriz_n1)) + "): el N-1 lo marcaba, "
                      "pero exige el bloque «sociedad matriz última» (NIF/denominación/país) que no consta en el N-1; "
                      "NO se arrastra para no romper la importación (FRECH 10034). Márcalo y cumpliméntalo en Sociedades WEB.")
    if _car_volatil_n1:
        avisos.append("Caracteres volátiles del ejercicio NO arrastrados del N-1 ("
                      + ", ".join(f"{k}={_CAR_VOLATIL_EJERCICIO[k]}" for k in sorted(_car_volatil_n1))
                      + "). Deben recalcularse/confirmarse con el resultado de 2025.")
    if _car_pre:
        fuentes.append("caracteres de la declaración (config pág 1)")
        avisos.append("Caracteres de la declaración (config. pág 1: tipo de entidad/régimen) ARRASTRADOS del N-1 ("
                      + ", ".join(sorted(_car_pre)) + "). Confírmalos/ajústalos en Sociedades WEB (cubo 3, juicio fiscal).")
    # --- 144 (titular real, D23): arrastre del N-1, NUNCA default ---
    tiene_titular = bool(fmt.get("titulares_reales"))
    n1_marco_144 = str(car_n1.get("00144", "")).strip() == "1"
    if "00144" in car:
        pass   # el llamador ya decidió 144 (override humano explícito) -> se respeta
    elif n1_marco_144 and not tiene_titular:
        car["00144"] = "1"                                   # N-1 declaró exención y no hay titular -> arrastrar
        avisos.append(
            "Titular real (casilla 144=1, D23): se ARRASTRA del N-1 (la entidad declaró exención de identificar "
            "titular real, art.4.2 Ley 10/2010). Confirma que la exención sigue vigente; si cambió, apórtalo.")
    elif tiene_titular:
        car.pop("00144", None)                               # hay titular real -> NO mezclar con 144
    elif not tiene_titular and not n1_marco_144:
        # N-1 sin 144 ni titular legible -> NO inventar. Titular = administrador (regla del Manual) con revisión.
        admins = fmt.get("administradores") or []
        if admins:
            fmt["titulares_reales"] = [{"nif": a.get("nif"), "nombre": a.get("nombre"),
                                        "extra": []} for a in admins[:1] if str(a.get("nif") or "").strip()]
            if fmt["titulares_reales"]:
                fuentes.append("titular real (=administrador, regla Manual)")
                avisos.append(
                    "Titular real (HITL, D23): el N-1 no traía titular real ni la casilla 144. Se PROPONE como "
                    "titular real al administrador (regla del Manual: a falta de control por participación, lo es "
                    "el administrador). REVÍSALO: si la entidad está exenta marca 144; si hay titular por control, "
                    "apórtalo.")
        else:
            avisos.append(
                "Titular real (HITL, D23): el N-1 no traía titular real ni la casilla 144 ni administrador. "
                "Resuélvelo a mano (titular por participación/control, administrador, o exención 144) antes de presentar.")
    # --- Aviso global HITL + manifest de lo precargado ---
    manifest = {
        "fuente": precarga.get("fuente") or "previo_200",
        "bloques_precargados": fuentes,
        "identificativos": {k: bool(ident.get(k)) for k in ("nif", "razon_social", "cnae", "periodo", "tipo_ejercicio")},
        "n_administradores": len(fmt.get("administradores") or []),
        "n_participadas_b1": len(fmt.get("participadas_b1") or []),
        "b1_emision_dr": ("emitida_simple_sin_continuacion"
                          if formal200.b1_emitible_dr(fmt.get("participadas_b1") or [])
                          else "omitida_compleja_post_import"),
        "n_socios_b2": len(fmt.get("socios") or []),
        "n_titulares_reales": len(fmt.get("titulares_reales") or []),
        "n_secretario": len(fmt.get("secretario") or []),
        "n_representantes": len(fmt.get("representantes") or []),
        "casilla_144": car.get("00144"),
        "suma_pct_b2": suma_pct,
        "revision_requerida": True,
    }
    if precarga.get("requiere_vision"):       # M2 (PDF): texto extraído parcialmente; el resto necesita visión
        manifest["requiere_vision"] = True
    if fuentes:
        avisos.insert(0,
            "PRECARGA N-1 (revisión del abogado OBLIGATORIA): se han precargado desde la declaración del año "
            "anterior — " + ", ".join(str(f) for f in fuentes) + ". Los datos N-1 pueden estar desactualizados "
            "(cambios de órgano, socios o %): confírmalos/edítalos antes de presentar. La liquidación fiscal "
            "(cubo 3) NO se precarga (criterio del abogado).")
    return fmt or None, car or None, nif, razon_social, cnae, avisos, manifest


def exportar_base(canonico_csv, ejercicio="2024", nif="", razon_social="", liquidacion_provisional=None,
                  formales=None, caracteres=None, pagina01b=None, fuente_canonico=None,
                  a3_confirmado=False, necesita_ocr=False, cnae=None, precarga_n1=None,
                  ecpn_ccaa_texto=None, perfil_estados_abreviado=None, perfil_estados_pymes=None,
                  contable_casillas=None) -> dict:
    """Expediente v1 sin Harvey: canónico persistido -> XML contable + `.200` provisional.

    Reusa los chokepoints existentes del motor: reconciliación `00180=00252`, `emitir_mod200`
    y el escritor DR. Si la contabilidad no cuadra o la carga asistida no está confirmada, no
    emite ningún fichero importable.

    `precarga_n1` (OPT-IN, aditiva): ruta a un `.200` N-1 o dict `precarga` ya extraído. Si se aporta,
    inyecta los identificativos (DP200001) + el bloque mercantil (DP200002/2B vía `formales`) de la
    declaración del AÑO ANTERIOR (cubos 1 y 2 de Sociedades WEB), marcándolo TODO como pendiente de revisión
    del abogado (avisos + `precarga_n1_manifest`). 144 (titular real) se ARRASTRA del N-1 (D23), nunca por
    defecto. Default None -> comportamiento EXACTAMENTE como antes (GIP/ARIOSO/internacionales byte-idénticos);
    el XML contable y la liquidación NO cambian con la precarga. ADR-001: el cubo 3 (fiscal) NO se precarga.
    """
    ej = str(ejercicio)
    if necesita_ocr:
        return {"ok": False, "estado": "bloqueado_ocr", "ejercicio": ej,
                "validacion": {"valido_xsd": False, "xsd": None, "casillas": None, "errores": []},
                "xsd_provisional": False, "ficheros": {}, "avisos": [],
                "motivo": "Hay una fuente PDF escaneada pendiente de OCR. Sube version digital o pasala por OCR."}
    contable_directo = _normalizar_contable_casillas(contable_casillas)
    if not str(canonico_csv or "").strip() and not contable_directo:
        return {"ok": False, "estado": "sin_contabilidad", "ejercicio": ej,
                "validacion": {"valido_xsd": False, "xsd": None, "casillas": None, "errores": []},
                "xsd_provisional": False, "ficheros": {}, "avisos": [],
                "motivo": "Falta contabilidad cargada y validada."}
    asistida = fuente_canonico in {"ccaa_a3", "tb_grupo"} or fuente_canonico in (None, "", "desconocido")
    if asistida and a3_confirmado is not True:
        return {"ok": False, "estado": "bloqueado_hitl", "ejercicio": ej,
                "validacion": {"valido_xsd": False, "xsd": None, "casillas": None, "errores": []},
                "xsd_provisional": False, "ficheros": {}, "avisos": [],
                "motivo": "La carga asistida no esta confirmada. Revisa el lineage y confirma antes de emitir."}

    # PRECARGA N-1 (opt-in): si se aporta, funde identificativos + mercantil del N-1 en los inputs (fill-if-
    # missing; el dato del expediente actual gana). Default None -> NO se toca nada (golden-safe). Best-effort:
    # un `.200` N-1 ilegible NO tumba el export (solo avisa); el cálculo contable/liquidación no depende de esto.
    _avisos_precarga, _precarga_manifest = [], None
    if precarga_n1 not in (None, "", {}):
        try:
            _prec = precarga_n1_extraer(precarga_n1, ejercicio=ej)
            (formales, caracteres, nif, razon_social, cnae,
             _avisos_precarga, _precarga_manifest) = _aplicar_precarga_n1(
                _prec, ej, formales, caracteres, nif, razon_social, cnae)
            # MODELO DE ESTADOS del N-1 → pagina01b 14/15/16 (fill-if-missing). La continuidad año a año es la
            # norma, así que el modelo del N-1 (Balance/ECPN/PyG = normal/abreviado/PYMES) es la mejor propuesta.
            # En Fase 0 el guardrail de _entrada_declaracion_dr lo degrada a normal + avisa (abreviado/PYMES =
            # fail-closed hasta los rollups); en Fase 1-2 se emitirá el modelo real. Golden-safe: N-1 normal → 1.
            _me = (_prec or {}).get("modelo_estados") or {}
            if _me:
                pagina01b = dict(pagina01b or {})
                for _fam, _num in (("balance", 14), ("ecpn", 15), ("pyg", 16)):
                    _cod = {"normal": 1, "abreviado": 2, "pymes": 3}.get(_me.get(_fam))
                    if _cod and not str(pagina01b.get(_num, "")).strip():
                        pagina01b[_num] = _cod
        except Exception as e:   # noqa: BLE001  precarga ilegible: avisar, no romper el export
            _avisos_precarga = [f"PRECARGA N-1 no aplicada (fuente ilegible o formato inesperado): {e}. "
                                "El `.200` se emite SIN precarga; completa identificativos/mercantil a mano."]

    # Guarda carácter↔régimen en el chokepoint que SÍ produce el entregable AEAT (.200/DR). export-base no recibe
    # el régimen, pero el CARÁCTER lo implica (00006→pyme · 00012→SOCIMI · 00004→IIC · 00088→especial). Bloquea
    # SOLO si ese régimen implícito NO tiene matriz de tipos para el ejercicio (fail-closed por ejercicio, vía
    # tipo_disponible): así 2025 sin pymes/socimi se bloquea, pero 2024 (que SÍ los soporta) NO regresiona, y GIP
    # (ETVE=00011, no especial) es byte-idéntico en cualquier ejercicio.
    no_soportados = sorted(c for c in (_caracteres_activos(caracteres) & set(CARACTER_REGIMEN_ESPECIAL))
                           if not tipo_disponible(CARACTER_REGIMEN_ESPECIAL[c], ej))
    if no_soportados:
        return {"ok": False, "estado": "bloqueado_caracter_regimen", "ejercicio": ej,
                "validacion": {"valido_xsd": False, "xsd": None, "casillas": None, "errores": []},
                "xsd_provisional": False, "ficheros": {}, "avisos": [],
                "motivo": f"Caracter de regimen especial ({no_soportados}) sin matriz de tipos en {ej}: "
                          f"campaña de ese régimen no soportada/validada; no se exporta el .200/XML."}

    perfil_estados_abreviado, perfil_estados_pymes = _familias_perfil_desde_pagina01b(
        pagina01b, perfil_estados_abreviado=perfil_estados_abreviado,
        perfil_estados_pymes=perfil_estados_pymes)

    xlsx_mime = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"

    with tempfile.TemporaryDirectory() as td:
        cpath = os.path.join(td, "canonico.csv")
        if not contable_directo:
            with open(cpath, "w", encoding="utf-8") as fh:
                fh.write(canonico_csv)

        # RESIDUO HITL explícito: cuentas SIN casilla y CON saldo material que rompen 00180=00252. Es el
        # punto de revisión del abogado (no se inventa el mapeo). Se proyecta aquí para adjuntarlo a la
        # respuesta de descuadre, tanto si falla el cuadre bruto como la proyección. Best-effort (si la
        # proyección levantara, se ignora y se sigue por el camino normal de error).
        _residuo = []
        if not contable_directo:
            try:
                _camp_r = _campaign_paths(ej)
                _can_r = builder.cargar_canonico(cpath)
                _mapeo_r = json.load(open(_camp_r["mapeo"], encoding="utf-8"))
                _cat_r = json.load(open(_camp_r["catalogo"], encoding="utf-8"))
                _, _, _cuadre_r, _, _ = builder.proyectar(_can_r, _mapeo_r, _cat_r)
                _residuo = _cuadre_r.get("no_map_detalle", []) or []
            except Exception:
                _residuo = []

            rec = reconciliador.reconciliar(builder.cargar_canonico(cpath))
            if not rec["ok"]:
                return {"ok": False, "estado": "descuadrado", "ejercicio": ej,
                        "validacion": {"valido_xsd": False, "xsd": None, "casillas": None,
                                       "errores": rec.get("errores", [])[:10]},
                        "xsd_provisional": False, "ficheros": {}, "avisos": rec.get("avisos", []),
                        "residuo_sin_mapear": _residuo,
                        "motivo": "El balance no cuadra (00180 != 00252). Revisa las cuentas antes de emitir."
                                  + (f" Cuentas sin casilla con saldo (residuo HITL): "
                                     + "; ".join(f"{r['cuenta']} {r['denom']} = {r['saldo']:,.2f}" for r in _residuo)
                                     if _residuo else "")}
        else:
            _checks_directo = _checks_contable_directo(contable_directo)
            if not all(c["ok"] for c in _checks_directo):
                return {"ok": False, "estado": "descuadrado", "ejercicio": ej,
                        "validacion": {"valido_xsd": False, "xsd": None, "casillas": None,
                                       "errores": [c["detalle"] for c in _checks_directo if not c["ok"]]},
                        "xsd_provisional": False, "ficheros": {}, "avisos": [],
                        "motivo": "Las casillas contables directas no cuadran: "
                                  + "; ".join(c["detalle"] for c in _checks_directo if not c["ok"])}

        ficheros = {}
        avisos = [
            "BORRADOR / PROVISIONAL: fichero para completar en el Programa 200. SuiteIS no presenta ni cierra la declaracion.",
        ]
        avisos.extend(_avisos_precarga)   # PRECARGA N-1 (HITL): avisos de revisión; vacío si precarga_n1=None
        b1_post_import = [p for p in ((formales or {}).get("participadas_b1") or [])
                          if str(p.get("nif") or "").strip()]
        if b1_post_import and not formal200.b1_emitible_dr(b1_post_import):
            b1_payload = {
                "tipo": "B.1_post_import",
                "ejercicio": ej,
                "regla": "No emitido en .200: B.1 complejo/con continuaciones puede rechazar en OpenWeb 2025 por totales 01501/01502/01503; completar/revisar en Sociedades WEB tras import positivo.",
                "participadas": b1_post_import,
            }
            b1_bytes = json.dumps(b1_payload, ensure_ascii=False, indent=2).encode("utf-8")
            ficheros["b1_post_import_json"] = {
                "fichero": "b1_participadas_post_import.json",
                "mime": "application/json",
                "base64": base64.b64encode(b1_bytes).decode("ascii"),
                "bytes": len(b1_bytes),
            }
            avisos.append(
                f"B.1 post-import: {len(b1_post_import)} participada(s) preparada(s) en "
                "`b1_participadas_post_import.json`. No están dentro del .200 importable.")
        elif b1_post_import:
            avisos.append(
                f"B.1 DR: {len(b1_post_import)} participada(s) emitida(s) en el .200 como bloque simple "
                "sin continuación; revisar avisos 44/45/46 en Sociedades WEB si aparecen.")
        validacion = {"valido_xsd": False, "xsd": None, "casillas": None, "errores": []}
        provisional = False
        outdir = os.path.join(td, "out")
        os.makedirs(outdir, exist_ok=True)

        try:
            if contable_directo:
                emis = emitir_mod200_desde_casillas(
                    contable_directo, outdir, empresa=nif, ejercicio=ej,
                    perfil_estados_abreviado=perfil_estados_abreviado,
                    perfil_estados_pymes=perfil_estados_pymes)
            else:
                emis = emitir_mod200(cpath, outdir, empresa=nif, ejercicio=ej,
                                     fuente_canonico=fuente_canonico, a3_confirmado=a3_confirmado,
                                     perfil_estados_abreviado=perfil_estados_abreviado,
                                     perfil_estados_pymes=perfil_estados_pymes)
            xml_bytes = emis["xml"].encode("iso-8859-1", "replace")
            ficheros["xml_mod200"] = {
                "fichero": os.path.basename(emis["xml_path"]),
                "mime": "application/xml",
                "base64": base64.b64encode(xml_bytes).decode("ascii"),
                "bytes": len(xml_bytes),
                "valido_xsd": emis["valido_xsd"],
                "xsd_estado": emis.get("validacion", {}).get("xsd"),
                "xsd_provisional": emis.get("xsd_provisional", False),
            }
            validacion = {"valido_xsd": bool(emis["valido_xsd"]),
                          "xsd": emis.get("validacion", {}).get("xsd"),
                          "casillas": emis.get("n_casillas_contables"),
                          "errores": (emis.get("validacion", {}).get("errores") or [])[:10]}
            provisional = bool(emis.get("xsd_provisional", False))
            avisos.append("XML mod200 contable: destino 'Importacion de datos contables' de Sociedades WEB.")
        except ConfirmacionHitlRequerida as e:
            return {"ok": False, "estado": "bloqueado_hitl", "ejercicio": ej,
                    "validacion": {"valido_xsd": False, "xsd": None, "casillas": None, "errores": [str(e)]},
                    "xsd_provisional": False, "ficheros": {}, "avisos": [],
                    "motivo": "La carga asistida no esta confirmada. Revisa el lineage y confirma antes de emitir."}
        except reconciliador.CanonicoDescuadradoError as e:
            return {"ok": False, "estado": "descuadrado", "ejercicio": ej,
                    "validacion": {"valido_xsd": False, "xsd": None, "casillas": None, "errores": [str(e)]},
                    "xsd_provisional": False, "ficheros": {}, "avisos": [],
                    "residuo_sin_mapear": _residuo,
                    "motivo": str(e)
                              + (" — RESIDUO HITL (cuentas sin casilla con saldo; el abogado mapea, el motor "
                                 "no inventa): "
                                 + "; ".join(f"{r['cuenta']} {r['denom']} = {r['saldo']:,.2f}" for r in _residuo)
                                 if _residuo else "")}

        if contable_directo:
            try:
                estados_path = os.path.join(outdir, "estados_contables_aeat.xlsx")
                paths_x = _campaign_paths(ej)
                catalogo_x = json.load(open(paths_x["catalogo"], encoding="utf-8"))
                casillas_x = _aplicar_perfil_para_xml(
                    contable_directo, str(ej), perfil_estados_abreviado, perfil_estados_pymes)
                builder.construir_xlsx(casillas_x, catalogo_x, estados_path, nif, str(ej))
                xlsx = {"ficheros": {"estados_contables_aeat": estados_path},
                        "avisos": ["Fuente contable directa Balance/PyG agregado: no se genera agrupado_4d.xlsx "
                                   "porque no hay cuentas A3/subcuentas reales."]}
            except Exception as e:  # noqa: BLE001
                xlsx = {"ficheros": {}, "avisos": [f"estados_contables_aeat.xlsx no generado: {type(e).__name__}: {e}"]}
        else:
            xlsx = _emitir_xlsx_aeat(cpath, outdir, empresa=nif, ejercicio=ej)
        for clave, ruta in xlsx["ficheros"].items():
            try:
                with open(ruta, "rb") as fh:
                    data = fh.read()
            except OSError:
                continue
            ficheros[clave] = {
                "fichero": os.path.basename(ruta),
                "mime": xlsx_mime,
                "base64": base64.b64encode(data).decode("ascii"),
                "bytes": len(data),
            }
        avisos.extend(xlsx["avisos"])
        # Aviso AEAT 21200 (NO bloqueante): si la entidad marca grupo mercantil (00039) pero NO se pudo arrastrar
        # la página 21 del .200 previo (sin participadas), avisar para que el abogado la complete. NO se inventa el
        # INCN del grupo ni los NIF; cuando el previo SÍ trae pág 21, formal_page_entries (DP200021) la emite.
        if str((caracteres or {}).get("00039", "")).strip() == "1" and not (formales or {}).get("participadas"):
            avisos.append(
                "Revisar (aviso AEAT 21200, NO bloqueante): la entidad marca grupo mercantil (00039) pero no hay "
                "pagina 21 que arrastrar del .200 previo. Completa 00987 (INCN del grupo) + NIF de la dominante en "
                "Sociedades WEB.")

        if contable_directo:
            contable_dr = {k: v for k, v in contable_directo.items() if v is not None}
            avisos.append("Contabilidad cargada desde Balance/PyG agregado: casillas contables directas "
                          "validadas por 00180=00252 y 00199=00500.")
        else:
            try:
                contable_dr = {
                    k: v for k, v in proyectar_contable(
                        cpath, ej, fuente_canonico=fuente_canonico, a3_confirmado=a3_confirmado
                    )["casillas"].items() if v is not None
                }
            except ConfirmacionHitlRequerida as e:
                return {"ok": False, "estado": "bloqueado_hitl", "ejercicio": ej,
                        "validacion": {"valido_xsd": False, "xsd": None, "casillas": None, "errores": [str(e)]},
                        "xsd_provisional": False, "ficheros": {}, "avisos": [],
                        "motivo": "La carga asistida no esta confirmada. Revisa el lineage y confirma antes de emitir."}
        # ECPN (DP200009/010/011): el `.200` necesita las páginas obligatorias del Estado de Cambios en el PN
        # (sin ellas: EMALOBL "faltan páginas obligatorias 10 y 11"). Se proyecta DESDE EL CANÓNICO (apertura =
        # −Saldo Inicial, cierre = −Saldo Final del PN). Page-keyed → construir_declaracion lo emite por su `ecpn`.
        # Fail-soft: si no se puede proyectar, se omite (no rompe el resto del `.200`).
        #
        # LÍMITE CONOCIDO (reimport REDEVCO 2026-06-28): NO se poda la hoja. El DR zero-rellena toda casilla no
        # provista, y la AEAT VALIDA la hoja entera (recalcula cierres/totales desde el balance) rechazando con
        # «se ha calculado un valor … y el valor que se intenta importar es: 0.00» CUALQUIER casilla computada que
        # quede a 0.00. Por eso podar (quitar casillas → 0.00) EMPEORA el import (2 → 10+ errores). Para TB PGC
        # (ARIOSO 5/5) ecpn_sys proyecta la matriz EXACTA que computa la AEAT → importa limpio. Para un TB que
        # ecpn_sys no clasifica del todo (p.ej. REDEVCO: capital/patrimonio de cierre desviados) la hoja NO
        # reconcilia y la AEAT la rechaza: ES TRABAJO PENDIENTE del motor proyectar el ECPN de ese TB, o el
        # abogado la completa en Sociedades WEB (Fase 2). Por eso aquí se emite la proyección TAL CUAL (sin poda).
        ecpn_pag = None
        try:
            import ecpn_sys
            _r500 = contable_dr.get("00500")
            try:
                _r500 = float(str(_r500).replace(",", ".")) if _r500 not in (None, "") else None
            except (TypeError, ValueError):
                _r500 = None
            if contable_directo:
                # Balance/PyG agregado no tiene canónico 4d ni saldos de apertura por cuenta. Para modelo NORMAL,
                # el ECPN se reconstruye desde estados formulados: apertura = balance del `.200` N-1; cierre =
                # balance actual. Abreviado/PYMES se podan más abajo, como antes.
                ecpn_pag, _ecpn_av = _ecpn_desde_contable_directo(contable_dr, precarga_n1, resultado=_r500)
                avisos.extend(_ecpn_av or [])
            else:
                _filas_ecpn = builder.cargar_canonico(cpath)
                _tiene_apertura = any(abs(float(f.get("si") or 0)) >= 0.01 for f in _filas_ecpn)
                # PASO DEL MOTOR (REDEVCO 2026-06-28): si el SyS NO trae saldo de apertura (export YTD: si=0 en todo)
                # el ECPN no se puede proyectar del canónico (apertura=0 → la AEAT recalcula y rechaza). Si se aporta
                # el texto del Balance de la CCAA, se toma la APERTURA de su columna N-1 (y el cierre de N) y se
                # proyecta el ECPN desde el balance → reconcilia y la AEAT lo importa (probado en RRE). Si hay apertura
                # en el SyS (TB PGC estándar, p.ej. ARIOSO) se mantiene la proyección del canónico (byte-idéntico).
                ecpn_pag = None
                if ecpn_ccaa_texto and not _tiene_apertura:
                    _cc = ecpn_sys.componentes_desde_ccaa_texto(ecpn_ccaa_texto)
                    if _cc:
                        _ap_c, _ci_c, _ctrl_c = _cc
                        _r_ecpn = _r500 if _r500 is not None else _ci_c.get("resultado_prev", 0.0)
                        ecpn_pag, _ecpn_av, _ecpn_ctrl = ecpn_sys.proyectar_desde_balance(_ap_c, _ci_c, _r_ecpn)
                        ecpn_pag = {pg: cas for pg, cas in (ecpn_pag or {}).items() if cas} or None
                        avisos.append("ECPN proyectado desde el Balance de la CCAA (apertura = columna N-1): el SyS no "
                                      "traía saldo de apertura. Revisar el cuadre del ECPN antes de presentar (Fase 2).")
                if ecpn_pag is None:
                    ecpn_pag, _ecpn_av, _ecpn_ctrl = ecpn_sys.proyectar_desde_canonico(_filas_ecpn, resultado=_r500)
                    ecpn_pag = {pg: cas for pg, cas in (ecpn_pag or {}).items() if cas} or None
                    if _ecpn_av:
                        avisos.extend(_ecpn_av)
        except Exception:   # noqa: BLE001  ECPN best-effort: nunca tumba la emisión del .200
            ecpn_pag = None
        # ECPN VOLUNTARIO (abreviado/PYMES sin opt-in 'ecpn'): NO emitir DP200009/10/11 (lo normal en esos
        # modelos es no incluir el ECPN). exportar_base proyecta el ECPN SIEMPRE (independiente del perfil);
        # sin esta poda el `.200` declaraba campo15=0 («no consta») y a la vez emitía el ECPN con datos —incluidos
        # los cierres 00632/00634/00635/00645 SIN apertura (riesgo E25400632/634/645 en Open)—. Normal (sin perfil)
        # y opt-in-ECPN (perfil con 'ecpn', p.ej. RRE full) NO se tocan: ecpn_pag se mantiene.
        # En el `.200` abreviado/PYMES el ECPN se omite SIEMPRE (voluntario; va por el XML contable, no el `.200`).
        if perfil_estados_abreviado or perfil_estados_pymes:
            ecpn_pag = None
        # Liquidación BASE COSMÉTICA (ADR-001) — SOLO en la lanzadera (export-base; el lote exportar_aeat es
        # contable-only por diseño). Si no llega una liquidación con cascada (falta 00621) pero hay resultado
        # contable, el motor la calcula para que el `.200` cuadre las identidades del importador (recálculo
        # todo-o-nada) y lleve las páginas obligatorias. Spec del equipo fiscal (informe 2026-06-24):
        #   · Página 12 — identidad 00501 = 00500 + 00301 − 00302 + 00004:
        #       OPCIÓN B (defecto): 00501 = RESULTADO ANTES DE IMPUESTOS contable (00325); 00301/00302 = corrección
        #       por el impuesto sobre beneficios CONTABILIZADO (gasto → 00301 positivo; ingreso → 00302 positivo);
        #       00004 = 0. → elimina el efecto contable del IS, sin meter ajustes extracontables (art. 11-25 LIS).
        #       FALLBACK A: si no hay 00325 fiable → 00501 = 00500, 00301/00302/00004 = 0 (placeholder).
        #   · Página 14 — identidad 00550 = 00501 + 00417 − 00418: base SIN ajustes → 00417 = 00418 = 0, 00550 = 00501.
        #   La cascada (00552/00562/.../00621) se calcula con BI base = 00501 (resultado ANTES de impuestos; el IS
        #   no es deducible). El abogado mete los ajustes reales (GF art.16, amortizaciones, BINs…) en el
        #   cuestionario o en Sociedades WEB. Régimen no soportado → fail-closed, se omite la base.
        liq_final = dict(liquidacion_provisional or {})
        liq_base_opcion = None
        _liq_firmada = False   # F2: True si el .200 lleva una liquidación FIRMADA por el motor (no la base cosmética)
        foral_detalle_extra = None
        if not liq_final.get("00621") and contable_dr.get("00500") not in (None, ""):
            try:
                _res = float(str(contable_dr["00500"]).replace(",", "."))           # 00500 resultado (tras IS)
                _rai_raw = contable_dr.get("00325")                                  # RESULTADO ANTES DE IMPUESTOS
                if _rai_raw not in (None, ""):
                    _rai = float(str(_rai_raw).replace(",", ".")); liq_base_opcion = "B"
                else:
                    _rai = _res; liq_base_opcion = "A"                               # sin RAI fiable → placeholder
                # Régimen IMPLÍCITO por carácter → fija el tipo de la base cosmética (00562). 00011→etve ·
                # 00012→socimi (0%) · 00006→pymes/ERD (24%, 2025); el fail-closed previo ya bloqueó los no
                # soportados, así que aquí el régimen detectado SIEMPRE tiene matriz. GIP/ETVE (00011) sin cambio.
                _reg = _regimen_desde_caracteres(caracteres, ej)
                # cascada coherente desde BI base = resultado ANTES de impuestos (el IS contabilizado se añade)
                _base = liquidar_orquestado({"resultado_contable": _rai, "ejercicio": int(str(ej)), "regimen": _reg},
                                            [], ejercicio=str(ej), regimen=_reg)
                _cas = dict(_base.get("casillas") or {})
                _d = round(_rai - _res, 2)
                _cas["00500"] = _res                                                 # resultado contable real
                _cas["00501"] = _rai                                                 # resultado antes de impuestos
                _cas["00301"] = _d if _d > 0 else 0.0                                # IS contabilizado = GASTO
                _cas["00302"] = (-_d) if _d < 0 else 0.0                             # IS contabilizado = INGRESO
                _cas["00004"] = 0.0
                _cas["00417"] = 0.0                                                  # base sin ajustes extracontables
                _cas["00418"] = 0.0
                _cas["00550"] = _rai                                                 # BI previa = 00501 (00417=00418=0)
                # CASCADA MÍNIMA de liquidación (págs 14/14B/DID): el importador RECALCULA y rechaza (E254) las
                # casillas que se importan a 0,00 cuando él calcula un positivo. En modo base SIN ajustes cada
                # eslabón = el anterior (catálogo §3 "cadena simple"). El motor las calcula por identidad; el
                # abogado las sobrescribe con los importes reales (BINs/deducciones/retenciones/pagos) a mano.
                _tipo = float(_base.get("tipo_gravamen") or 0.25)
                _cas["00558"] = "%.2f" % (_tipo * 100)                               # tipo % como STRING "25.00" (NO float)
                _cas.pop("00103", None)                                              # 00103 NO es el tipo en pág 14 (es DDI): no propagar
                _c552 = float(_cas.get("00552") or 0)

                def _num(_src, _k):                                                  # lectura float-safe de un dict de casillas
                    _x = _src.get(_k)
                    try:
                        return float(str(_x).replace(",", ".")) if _x not in (None, "") else 0.0
                    except (ValueError, TypeError):
                        return 0.0
                _cas["01330"] = _cas.get("00552")                                    # BI tras reserva nivelación (0 en base) = 00552
                _cas["00582"] = _cas.get("00562")                                    # cuota íntegra ajustada (sin bonif/DDI) = 00562
                _cas.setdefault("00592", _cas.get("00582"))                          # cuota líquida (sin deducciones)
                # Cadena de cuota (DP200014B): el importador RECALCULA 00599=00592−retenciones y 00611=00599−pagos
                # (motor_calculo_aeat: 00621=00592−retenciones−pagos) y rechaza (E25400599/E25400611) si se copian
                # SIN restar. En modo "Revisión asistida" el abogado inyecta retenciones (01766/01784) y pagos
                # (00601/00603/00605) por liquidacion_provisional (viven en liq_final); restamos lo PRESENTE, sin
                # inventar importes. En base puro (ret/pagos=0) coincide con la identidad anterior (00599=00592…).
                _ret = _num(liq_final, "01766") + _num(liq_final, "01784")
                _pag = _num(liq_final, "00601") + _num(liq_final, "00603") + _num(liq_final, "00605")
                _cas["00599"] = round(_num(_cas, "00592") - _ret, 2)                 # cuota del ejercicio = 00592 − retenciones
                _cas["00611"] = round(_num(_cas, "00599") - _pag, 2)                 # cuota diferencial = 00599 − pagos fraccionados
                _cas["01586"] = _cas["00611"]                                        # resultado autoliquidación (sin rectificativa) → también DID
                _cas["00621"] = _cas["01586"]                                        # resultado a ingresar (la precarga del abogado tiene prioridad en el merge)
                _cas.pop("00619", None)                                              # art.30bis: no autogenerar en liquidacion cosmetica
                # Régimen de CONSOLIDACIÓN FISCAL (art.16.4 LIS): si la entidad es dominante (carácter 00009) o
                # dependiente (00010) de un grupo fiscal, la limitación de GF se computa a NIVEL DE GRUPO (Modelo
                # 220), NO en el 200 individual del miembro. Open rechaza (EPAGINC) CUALQUIER contenido en la
                # página 20 de un miembro de grupo → se calcula igual abajo pero se PODA antes del merge, y NO se
                # acopla el GF no deducible a la base. (Decisión usuario 2026-06-29: omitir solo la página 20.)
                _grupo_fiscal = any(str((caracteres or {}).get(_c, "")).strip() == "1" for _c in ("00009", "00010"))
                # Página 20 (límite de GF, art.16): el importador RECALCULA 01249 = 30%·B.O. y 02369 y rechaza
                # (E25401249/E25402369) si se importan a 0/suelo cuando él calcula un positivo. B.O. (mapa DR
                # DP200020) = 01250−01251−01252−01253+01254−02368. Poblamos i1/i2 desde la PyG (01250=00296
                # resultado explotación, 01251=00284 amortización, mismo signo PyG) y escribimos 01249/02369 con la
                # MISMA fórmula sobre esos valores → cuadra por construcción. NO es ajuste fiscal (no toca
                # 00363/01260): es el límite que el propio formulario calcula; el GF no deducible lo mete el abogado.
                if contable_dr.get("00296") not in (None, ""): _cas.setdefault("01250", contable_dr["00296"])
                if contable_dr.get("00284") not in (None, ""): _cas.setdefault("01251", contable_dr["00284"])
                _bo = (_num(_cas, "01250") - _num(_cas, "01251") - _num(_cas, "01252")
                       - _num(_cas, "01253") + _num(_cas, "01254") - _num(_cas, "02368"))
                _cas["01249"] = round(0.30 * _bo, 2)                                  # i) 30%·B.O. (signo: BO<0 → 01249<0)
                _cas["02369"] = round(max(max(0.0, _cas["01249"]) + _num(_cas, "01255"), 1_000_000.0), 2)  # k) max(30%BO+adición; suelo 1M)
                # [A5 NÚCLEO §5] Página 20 art.16 COMPLETA: el split deducible/no deducible se DELEGA en
                # limitacion_gf() (fuente única de la matemática del art.16, cubre 16.1 general y 16.5 etve; emite
                # 01249/02369/01256/01257/01260/00363). Sobrescribe las casillas cosméticas i)/k) de arriba con los
                # valores firmados por limitacion_gf, puebla las hojas B.O. (01253 = 00287, NO 00292) + los espejos
                # (03585/03587) + la fila TOTAL (01214/01216), y ACOPLA el GF no deducible (00363, diferencia
                # permanente +) a la base: 00417 += 00363 → 00550 → recalcula la cuota aguas abajo. limitacion_gf.py
                # NO se modifica (solo se consume); GIP va por gip2024_replay_builder.py (intacto por construcción).
                import limitacion_gf as _lgf
                _e16 = abs(_num(contable_dr, "00305")); _gi16 = _num(contable_dr, "00297")   # e) gastos / g) ingresos fin.
                _h16 = round(_e16 - _gi16, 2)                                                 # h = f - g (f = e; sin 16.5)
                _re16 = _num(contable_dr, "00296"); _am16 = _num(contable_dr, "00284")
                _de16 = _num(contable_dr, "00287")                                            # i4) = 00287 (NO 00292), con signo
                _l30 = round(0.30 * round(_re16 - _am16 - _de16, 2), 2)                       # 30%·B.O. (01250-01251-01253)
                _gf16 = _lgf.limitacion_gf(_h16, criterio="leniente", regimen="general",
                                           limite_30_hoja=_l30, suelo=1_000_000.0)
                _cas.update({"01245": _e16, "01246": _e16, "01247": _gi16, "01248": _gf16["01248"],
                             "01250": _re16, "01251": _am16, "01253": _de16,
                             "01249": _gf16["01249"], "02369": _gf16["02369"],
                             "01256": _gf16["01256"], "01257": _gf16["01257"], "01260": _gf16["01260"],
                             "03585": _gf16["01256"], "03586": 0.0, "03587": _gf16["01257"],   # fila 2025
                             "01214": _gf16["01256"], "01215": 0.0, "01216": _gf16["01257"]})   # fila TOTAL = Σ fila(s) año [K1]
                # [6395] Adición por límite B.O. GENERADA EN EL PROPIO EJERCICIO (art.16.2 LIS + Manual Sociedades
                # 2025, cap.5 §3: fila «2025(**)»): si el límite del 30% (01249) supera el GF neto (01248), el EXCESO
                # de capacidad se adiciona al límite de los 5 ejercicios siguientes y SE CONSIGNA en la rejilla
                # «pendiente de adición por límite B.O. no aplicado», fila 2025(**) = generación del propio período:
                # 03588 (importe generado) + 03590 (pendiente períodos futuros) + totales 00538/00546. NO va en la
                # fila 2025(*) (02447/02972, que es para otro período <12m previo) — emitirla ahí dispara E254. Si la
                # capacidad no se declara, la AEAT rechaza con «6395 · Registro Nº 1». Solo capacidad POSITIVA
                # (B.O.≤0 → 01249≤0 → 0: RHVS/GIP sin headroom no se tocan). Cosmético; GIP va por su ruta (replay).
                _adic_bo = round(max(0.0, _num(_cas, "01249") - _num(_cas, "01248")), 2)
                if _adic_bo > 0:
                    _cas["03588"] = _adic_bo                                   # 2025(**) importe generado (a principio)
                    _cas["03589"] = 0.0                                        # 2025(**) aplicado en esta liquidación
                    _cas["03590"] = _adic_bo                                   # 2025(**) pendiente períodos futuros (= generado − aplicado)
                    _cas["00538"] = round(_num(_cas, "00538") + _adic_bo, 2)   # Total a principio (importe generado)
                    _cas["00546"] = round(_num(_cas, "00546") + _adic_bo, 2)   # Total pendiente períodos futuros
                _n363 = _gf16.get("00363") or 0.0                                             # = 01260
                if _n363 > 0 and not _grupo_fiscal:    # en grupo fiscal el GF no deducible se acopla a nivel de grupo, no aquí
                    # Acople del GF no deducible (diferencia temporaria +) a la base [J2] y RECÁLCULO de la cuota
                    # aguas abajo (este bloque va DESPUÉS de la cascada 00599/00611/00621, por eso se recomputa).
                    _cas["00363"] = _n363
                    _cas["00417"] = round(_num(_cas, "00417") + _n363, 2)                     # aumentos P&G += GF no deducible
                    _cas["00550"] = round(_num(_cas, "00501") + _num(_cas, "00417") - _num(_cas, "00418"), 2)
                    _cas["00552"] = _cas["00550"]; _cas["01330"] = _cas["00550"]
                    _ci16 = round(max(0.0, _num(_cas, "00552")) * _tipo, 2)                   # 00562 = tipo·max(0,00552)
                    _cas["00562"] = _ci16; _cas["00582"] = _ci16; _cas["00592"] = _ci16
                    _cas["00599"] = round(_ci16 - _ret, 2)                                    # 00599 = 00592 − retenciones
                    _cas["00611"] = round(_num(_cas, "00599") - _pag, 2)                      # 00611 = 00599 − pagos fracc.
                    _cas["01586"] = _cas["00611"]; _cas["00621"] = _cas["00611"]
                    _cas.pop("00619", None)                                                  # art.30bis: solo si viene firmado/HITL
                if _grupo_fiscal:
                    # Miembro de grupo fiscal: PODA de toda la página 20 (limitación de GF art.16) — se computa en
                    # el Modelo 220 del grupo, no en el 200 individual. Open la rechaza (EPAGINC) si lleva cualquier
                    # casilla con contenido. Se eliminan de _cas antes del merge a liq_final.
                    for _c in ("01240", "01241", "01242", "01243", "01244", "01245", "01246", "01247", "01248",
                               "01249", "01250", "01251", "01252", "01253", "01254", "02368", "01255", "02369",
                               "01256", "01257", "01258", "01259", "01260", "00363", "03585", "03586", "03587",
                               "01214", "01215", "01216", "03588", "03589", "03590", "00538", "00539", "00546",
                               "02447", "02465", "02972"):
                        _cas.pop(_c, None)
                # NOTA pérdidas (revisión 2026-06-30): la liquidación cosmética usa el RAI (00501, resultado ANTES de
                # impuestos) como base, vía liquidar_orquestado → para un RAI ≤ 0 ya emite 00552 ≤ 0 y cuota 00562 = 0
                # (verificado). NO se fuerza nada por el 00500 después de impuestos: una sociedad con resultado contable
                # negativo PERO RAI > 0 (p.ej. IS contabilizado alto) SÍ tiene base imponible positiva (el IS no es
                # deducible) y su cuota cosmética positiva es CORRECTA. Las identidades de Open (00501=00500+00301−00302+
                # 00004; 00550=00501+00417−00418; 00552) las satisface la cascada de arriba (NS BILBAO real, beneficio,
                # cuadra). Los rechazos «00552 calc vs importa» del reimport eran SÍNTOMA del bug T1 (subtotales podados a
                # 0.00 rompían la cascada), no pérdidas: T1 los cierra.
                for _k, _v in _cas.items():
                    if _v not in (None, "") and str(_k).strip() not in liq_final:
                        liq_final[str(_k).strip()] = _v
                avisos.append(
                    f"Liquidacion BASE provisional (opcion {liq_base_opcion}): 00501 = resultado antes de impuestos"
                    + (" (00325)" if liq_base_opcion == "B" else " = 00500 (placeholder, sin dato de RAI fiable)")
                    + "; 00301/00302 = correccion por el IS contabilizado; ajustes extracontables (00417/00418) = 0. "
                    "NO es la liquidacion fiscal definitiva: revisa y completa en el cuestionario o en Sociedades WEB.")
                # Aviso AEAT 11717 (NO bloqueante): el detalle de deterioros del art.13 LIS (DP200012:
                # 00321/00415/00325/00327/01807) va a CERO en la base cosmética; esos ajustes extracontables
                # discrecionales los consigna el abogado en Sociedades WEB (frontera: el motor no los fabrica).
                avisos.append(
                    "Informativo (aviso AEAT 11717, NO bloqueante): el detalle de deterioros del art.13 LIS "
                    "(correcciones a la PyG, casillas 00321/00415/00325/00327/01807) va a CERO en la base; "
                    "consigna los deterioros reales en Sociedades WEB.")
                # Aviso AEAT 11711 (NO bloqueante): traza los netos NEGATIVOS del bloque Existencias/Deudores del
                # activo corriente (DP200003 00138-00148, DP200004 00149-00167) para revisión humana. NO se corrige
                # el valor (abs/clamp descuadraría el balance que la AEAT recalcula): solo se señala el contable tal cual.
                _ac_neg = [c for c in ("%05d" % n for n in range(138, 168)) if _num(contable_dr, c) < 0]
                if _ac_neg:
                    avisos.append(
                        "Revisar (aviso AEAT 11711, NO bloqueante): neto NEGATIVO en Existencias/Deudores del activo "
                        "corriente (casillas " + ", ".join(_ac_neg) + "). Puede ser legitimo (deterioro > bruto) o un "
                        "signo a revisar; el .200 mantiene el valor contable tal cual.")
            except Exception:   # noqa: BLE001  régimen no soportado / gate fail-closed → sin base (resto intacto)
                pass
        elif (liq_final.get("00621") not in (None, "")
                and all(liq_final.get(_a) not in (None, "") for _a in ("00552", "00562", "00592"))):
            # F1 — LIQUIDACIÓN FIRMADA: la app mandó la cascada firmada por el motor (ADR-001; el set de anclas
            # 00552/00562/00592/00621 presente — calcular_casillas las co-emite siempre) → la cosmética NO corre
            # (guard de arriba), pero el `.200` SIGUE necesitando las IDENTIDADES de liquidación que el importador
            # RECALCULA y rechaza si van a 0 (E254/EPOR), en DOS cadenas:
            #   · BASE IMPONIBLE (págs 12/14): 00501=00500+00301−00302+00004 · 00550=00501+00417−00418.
            #   · CUOTA (págs 14/14B/DID): 00558/01330/00582/00599/00611/01586/00619.
            # Se COMPLETAN por IDENTIDAD desde las ANCLAS FIRMADAS (fill-if-missing: la precarga del abogado gana).
            # 00417/00418 = el NETO de ajuste FIRMADO (00550−00501) repartido en aumentos/disminuciones AGREGADO.
            # FRONTERA FISCAL: NO se fabrica el DESGLOSE itemizado por ajuste (DP200013) ni qué deducción aplica
            # (00571 DDI internacional, bonificaciones) — eso lo aporta el abogado (juicio fiscal); 00582 resta SOLO
            # las bonif/DDI ya CONFIRMADAS en la liquidación, no inventa ninguna.
            _liq_firmada = True   # F2: el .200 lleva la liquidación firmada por el motor (cascada coherente)
            try:
                def _numf(_k):
                    _x = liq_final.get(_k)
                    try:
                        return float(str(_x).replace(",", ".")) if _x not in (None, "") else 0.0
                    except (ValueError, TypeError):
                        return 0.0

                def _numc(_k):
                    _x = contable_dr.get(_k)
                    try:
                        return float(str(_x).replace(",", ".")) if _x not in (None, "") else 0.0
                    except (ValueError, TypeError):
                        return 0.0
                # --- Cadena de BASE IMPONIBLE (págs 12/14) por identidad
                _is = round(_numc("00325") - _numc("00500"), 2)               # IS contabilizado (gasto añadido a la RAI)
                liq_final.setdefault("00301", _is if _is > 0 else 0.0)        # corrección IS — aumentos
                liq_final.setdefault("00302", (-_is) if _is < 0 else 0.0)     # corrección IS — disminuciones
                liq_final.setdefault("00004", 0.0)
                liq_final.setdefault("00501", round(_numf("00500") + _is, 2)) # = 00500 + 00301 − 00302 + 00004 (RAI)
                _net = round(_numf("00550") - _numf("00501"), 2)             # ajuste extracontable NETO firmado
                liq_final.setdefault("00417", _net if _net > 0 else 0.0)      # aumentos al resultado (agregado)
                liq_final.setdefault("00418", (-_net) if _net < 0 else 0.0)   # disminuciones (agregado)
                # --- Cadena de CUOTA (págs 14/14B/DID) por identidad
                _tipo_f = _numf("00103") or 0.25
                liq_final.pop("00103", None)                                  # 00103 = tipo (interno del motor); en pág 14 es DDI → no emitir
                liq_final.setdefault("00558", "%.2f" % (_tipo_f * 100))       # tipo % STRING "25.00"
                liq_final.setdefault("01330", liq_final.get("00552"))         # BI tras reserva de nivelación
                _ddi = _numf("00567") + _numf("00571") + _numf("00572") + _numf("00573")   # bonif + DDI CONFIRMADAS
                liq_final.setdefault("00582", round(_numf("00562") - _ddi, 2))             # cuota íntegra ajustada
                _ret = _numf("01766") + _numf("01784")
                _pag = _numf("00601") + _numf("00603") + _numf("00605")
                liq_final.setdefault("00599", round(_numf("00592") - _ret, 2))             # cuota del ejercicio
                liq_final.setdefault("00611", round(_numf("00599") - _pag, 2))             # cuota diferencial
                liq_final.setdefault("01586", liq_final.get("00611"))                      # resultado autoliq → DID
                # art.30bis / 00619 no se completa por defecto: OpenWeb la rechaza en borradores en los que no
                # queda habilitada. Si aplica fiscalmente, debe venir como dato firmado/HITL.
                avisos.append(
                    "Liquidacion FIRMADA por el motor (ADR-001): identidades de BI (00501/00417/00418) y cuota "
                    "(00558/01330/00582/00599/00611/01586/00619) completadas desde las anclas firmadas. El DESGLOSE "
                    "itemizado por ajuste (DP200013) y la deduccion DDI (00571) los aporta el abogado (juicio fiscal).")
            except Exception:   # noqa: BLE001
                pass
        # F4 — GATING de régimen ERD (empresas de reducida dimensión). Las casillas de incentivos ERD del detalle
        # de correcciones (DP200013: 00311/00312 libertad amort. art.102, 00313/00314 amort. acelerada art.103,
        # 00323/00324 deterioro insolvencias art.104) "no pueden tener contenido" salvo que la entidad MARQUE el
        # carácter 00006 (Incentivos ERD, cap. XI tít. VII LIS): la AEAT rechaza con E25400312/00314/00324 si vienen
        # sin ese régimen. Si 00006 no está marcado se PODAN del `.200` (+ aviso). Es una regla ESTRUCTURAL del
        # importador, NO una decisión fiscal (marcar ERD es del abogado). Los homónimos contables de DP200008/033
        # NO se tocan: aquí solo se poda de `liq_final` (liquidación), que el ruteo por origen emite en DP200013.
        if str((caracteres or {}).get("00006", "")).strip() != "1" and liq_final:
            _erd = [_c for _c in ("00311", "00312", "00313", "00314", "00323", "00324")
                    if liq_final.get(_c) not in (None, "")]
            if _erd:
                for _c in _erd:
                    liq_final.pop(_c, None)
                avisos.append(
                    "Régimen ERD no marcado (carácter 00006): se omiten del .200 las casillas de incentivos de "
                    "Empresas de Reducida Dimensión (" + ", ".join(_erd) + ") que la AEAT rechaza sin ese régimen. "
                    "Si la entidad es ERD, marca el carácter y reincorpora los incentivos en Sociedades WEB.")
        # F5 — GATING FORAL (carácter 00028, tributación conjunta Estado/Foral). En régimen conjunto el resultado
        # se canaliza por las casillas forales (00600/00612/01587/00622) + el cuadro de la PÁGINA 26, NO por la
        # cascada solo-Estado; la AEAT rechaza (E254/35100, "no puede tener contenido"/"tipo incompatible") las
        # casillas 00599/00611/01586/00621 si vienen por la liquidación cosmética en foral. Si 00028 está marcado
        # se PODAN (+ aviso); el resultado foral lo completa el abogado en Sociedades WEB / pág.26. Regla
        # ESTRUCTURAL del importador (no decisión fiscal). GIP es solo-Estado → no entra → byte-idéntico intacto.
        # (Espejo del gate ERD de arriba. La PÁGINA 26 en sí es un paso aparte: arrastre del .200 previo / reparto.)
        # FORAL (carácter 00028) — REGLA DE PRODUCTO (2026-06-26, validada con AEAT en CYA): un .200 de sociedad
        # en tributación conjunta Estado/Foral CON resultado contable obliga a AEAT a recalcular la liquidación
        # COMPLETA (base→cuota→split Estado/Foral por % de la pág.26→desglose por Diputación→DID), que es JUICIO
        # FISCAL del abogado (00417/00418 = ajustes extracontables): el motor NO los fabrica. Comportamiento
        # observado: stripping rompe la estructura (EMALREG); cero-coherente no pasa (AEAT calcula cuota no nula);
        # cosmético-foral coherente = feature mayor (roadmap). → VÍA DE CIERRE: XML mod200 contable (carga
        # balance+PyG; el abogado completa liquidación+foral+pág.26 en Sociedades WEB). El .200 se emite igual
        # (estructura completa) pero se AVISA. GIP es solo-Estado → no entra → byte-idéntico intacto.
        if str((caracteres or {}).get("00028", "")).strip() in ("1", "X", "x"):
            _foral_updates, foral_detalle_extra, _foral_av = _foral_page26_desde_n1(precarga_n1, liq_final, ej)
            if _foral_updates:
                liq_final.update(_foral_updates)
            if _foral_av:
                avisos.extend(_foral_av)
            _solo_estado = [c for c in ("00599", "00611", "01586", "00621") if c in (liq_final or {})]
            if _foral_updates:
                avisos.append(
                    "RÉGIMEN CONJUNTO ESTADO/FORAL (00028): la liquidación base se reparte con los porcentajes "
                    "de la página 26 arrastrados del N-1. Se emiten tanto las casillas Estado "
                    "(00599/00611/01586/00621) como las Forales/Navarra (00600/00612/01587/00622). "
                    "Proxy de importabilidad: revisar fiscalmente en Sociedades WEB.")
            else:
                for _c in _solo_estado:
                    liq_final.pop(_c, None)
                avisos.append(
                    "RÉGIMEN CONJUNTO ESTADO/FORAL (00028): sin página 26 N-1 usable se omiten del .200 las "
                    f"casillas solo-Estado ({', '.join(_solo_estado) if _solo_estado else 'sin casillas solo-Estado con contenido'}). "
                    "El .200 NO queda importable sin página 26: aporta reparto foral o importa el XML mod200 "
                    "CONTABLE y completa la liquidación/reparto en Sociedades WEB.")
        # [A5 §3] HITL titular real: si no se aporta titular real, el DR marca DP200002B[144]="1" (entidad sin
        # obligación de identificar titular real, exención art.4.2 Ley 10/2010), que cierra el error AEAT 2830.
        # NO es un default silencioso: si la entidad SÍ debe declarar titular real, el abogado debe aportarlo.
        # INTERINO (D23): cuando NO hay precarga N-1, este 144=1 es el comportamiento heredado (HITL-flagged);
        # con precarga N-1 el 144 lo decide _aplicar_precarga_n1 por arrastre (no se duplica el aviso aquí).
        if (not _precarga_manifest) and formales and not (formales.get("titulares_reales") or []):
            avisos.append(
                "DECISIÓN DEL ABOGADO (titular real, INTERINO sin precarga N-1): no se ha aportado titular real, "
                "por lo que el .200 marca la entidad como SIN obligación de identificarlo (exención art.4.2 Ley "
                "10/2010, casilla 144=1). Confirma que la exención aplica; si la entidad debe declarar titular real, "
                "apórtalo antes de presentar. (Con la declaración N-1 disponible, este 144 se ARRASTRA — D23.)")
        # SOCIMI (carácter 00012): el .200 va a CUOTA 0 (00562 = 00520×tipo; en SOCIMI pura 00520=0, tipo 0%).
        # Los gravámenes especiales NO van en el 200 (Manual cap.10): 19% dividendos → Modelo 217; 15% beneficios
        # no distribuidos → Modelo 237. El split 00520/00521 (renta al tipo general) y el incumplimiento de
        # permanencia (00633/00642) son criterio del abogado → HITL, no se infieren del SyS.
        if str((caracteres or {}).get("00012", "")).strip() in ("1", "X", "x"):
            avisos.append(
                "RÉGIMEN SOCIMI (00012): el .200 se emite con CUOTA 0 (toda la base imponible al 0%). REVISA en "
                "Sociedades WEB: (1) si hay renta del régimen previo al tipo general, el reparto 00520/00521 y su "
                "cuota; (2) los gravámenes especiales 19% (dividendos a socios ≥5% tributados <10% → Modelo 217) y "
                "15% (beneficios no distribuidos → Modelo 237), que se autoliquidan FUERA del 200; (3) incumplimiento "
                "del plazo de permanencia (3 años) → casillas 00633/00642. El motor NO calcula estos importes.")
        # 00027 es un carácter VOLÁTIL del ejercicio ("base imponible negativa o cero"). Puede llegar ya
        # precargado desde N-1 por el wrapper de carpeta; si la liquidación 2025 que se va a emitir tiene base
        # positiva, no puede viajar activo porque OpenWeb lo contrasta contra la propia autoliquidación.
        if isinstance(caracteres, dict) and str(caracteres.get("00027", "")).strip() in ("1", "X", "x"):
            def _num027(_src, _k):
                try:
                    _x = (_src or {}).get(_k)
                    return float(str(_x).replace(",", ".")) if _x not in (None, "") else 0.0
                except (TypeError, ValueError):
                    return 0.0
            _bi027 = _num027(liq_final, "00552") or _num027(liq_final, "00550")
            if _bi027 > 0:
                caracteres = dict(caracteres)
                caracteres.pop("00027", None)
                avisos.append(
                    "Caracter 00027 desmarcado: la base imponible 2025 emitida es positiva; la marca "
                    "'base imponible negativa o cero' no se arrastra desde N-1.")
        decl = _entrada_declaracion_dr(ej, contable_dr, nif=nif, razon_social=razon_social,
                                       liquidacion=liq_final or None, formales=formales, caracteres=caracteres,
                                       pagina01b=pagina01b, ecpn=ecpn_pag, cnae=cnae,
                                       perfil_estados_abreviado=perfil_estados_abreviado,
                                       perfil_estados_pymes=perfil_estados_pymes,
                                       liq_detalle_extra=foral_detalle_extra)
        dependientes = []
        if decl is not None:
            decl["bytes"] = len(base64.b64decode(decl["base64"]))
            decl["provisional"] = True
            decl["nota"] = "BORRADOR / PROVISIONAL para completar en el Programa 200. " + str(decl.get("nota") or "")
            ficheros["declaracion_dr"] = decl
            if decl.get("perfil_estados_downgrade"):
                avisos.append(
                    "MODELO DE ESTADOS DE CUENTAS: el N-1/CCAA sugería modelo ABREVIADO/PYMES para " +
                    ", ".join(decl["perfil_estados_downgrade"]) + ", pero el .200 se presenta en modelo NORMAL "
                    "(detalle completo, válido para cualquier entidad y COHERENTE con las casillas emitidas; evita "
                    "el rechazo por declarar un modelo y emitir otro). El modelo abreviado/PYMES real se soportará "
                    "con los rollups (pendiente); si lo necesitas ya, ajústalo en Sociedades WEB.")
            dependientes = decl.get("casillas_dependientes_de_otros_modelos") or []
            pendientes = [d for d in dependientes if not d.get("presente")]
            if pendientes:
                avisos.append(
                    f"{len(pendientes)} casilla(s) dependen de otros modelos o revision manual: "
                    + ", ".join(str(d.get("casilla")) for d in pendientes[:8])
                )
            avisos.append(".200 BORRADOR: destino 'Borrador de declaracion' para completar en Programa 200.")

        completos = "xml_mod200" in ficheros and "declaracion_dr" in ficheros
        ok = completos and bool(validacion.get("valido_xsd"))
        estado = "ok" if ok else ("xml_xsd_invalido" if completos else "sin_declaracion")
        out = {"ok": ok, "estado": estado, "ejercicio": ej, "validacion": validacion,
               "xsd_provisional": provisional, "ficheros": ficheros,
               "casillas_dependientes_de_otros_modelos": dependientes, "avisos": avisos,
               "borrador_provisional": True, "liquidacion_firmada": _liq_firmada}
        if _precarga_manifest:           # PRECARGA N-1 (HITL): manifiesto de lo precargado para revisión del abogado
            out["precarga_n1_manifest"] = _precarga_manifest
        if completos and not validacion.get("valido_xsd"):
            out["motivo"] = "El XML contable no valida contra el XSD; no se marca como borrador apto."
        return out


# ----------------------------------------------------------------- CASO B: CCAA -> A3 (T1.2.3)
# Centinela de provenance: marca un canónico como INFERIDO de las CCAA (CASO B). `builder.cargar_canonico`
# lo ignora (solo lee filas cuyo r[0] es isdigit()); los 4 chokepoints (emitir_mod200, proyectar_contable,
# validar_contable, generar_paquete) lo detectan para FAIL-CLOSED: un canónico inferido no produce
# número/XML firmable sin confirmación HITL, aunque se POSTee directo saltando la UI (Codex HIGH T1.2).
# El SyS real (vía validar_contable/fase_a) NO lleva centinela -> intacto.
#
# LÍMITE CONOCIDO (Codex 6ª pasada, → backlog Fase 2): este centinela viaja IN-BAND en el CSV, que es
# texto controlado por el cliente. Un cliente directo-API DELIBERADO puede borrar esta línea y omitir
# `fuente_canonico` para volver el canónico indistinguible de un SyS real (mismas filas numéricas) y
# desactivar el gate. Es la misma clase que "/firmar firma facts del llamador": sin Auth (DEMO) no hay
# frontera de confianza. El cierre ROBUSTO = provenance LIGADO EN SERVIDOR (id de canónico opaco / envelope
# firmado emitido por /generar-sys-a3 y verificado en los 4 chokepoints + estado de confirmación
# server-side), que es maquinaria de Fase 2 (Auth + persistencia). El flujo de la consola NUNCA despoja el
# centinela. Test que codifica el requisito Fase 2: test_caso_b_a3.py::test_FASE2_sentinel_stripping_*.
_CENTINELA_CCAA_A3 = "# PROVENANCE=ccaa_a3_inferido; no_exportable_sin_confirmacion_HITL"


def _es_canonico_inferido(canonico_csv: str) -> bool:
    """True si el canónico lleva el centinela de inferencia CCAA (CASO B)."""
    return bool(canonico_csv) and _CENTINELA_CCAA_A3 in canonico_csv


def _canonico_csv_desde_filas(filas: list) -> str:
    """Filas A3 (agrupado 4d de generar_sys) -> canónico CSV que consume `builder.cargar_canonico`
    (cuenta;denom;sf;debe;haber;si, separado por ';'; la cabecera no-numérica se ignora al leer).
    Antepone el centinela de provenance (CASO B = inferido): el builder lo ignora, el paquete lo gatea."""
    out = [_CENTINELA_CCAA_A3, "Cuenta;Descripción;Saldo Final;Debe;Haber;Saldo Inicial"]
    for f in filas or []:
        out.append(";".join(str(x) for x in (
            f.get("cuenta", ""), f.get("descripcion", ""), f.get("saldo_final", 0.0),
            f.get("debe", 0.0), f.get("haber", 0.0), f.get("saldo_inicial", 0.0))))
    return "\n".join(out)


def generar_sys_a3_desde_partidas(partidas: list, nif="", nombre="") -> dict:
    """Partidas (etiqueta+importe, inferidas de las CCAA) -> SyS A3 determinista (CASO B del paso 1).

    Es INFERENCIA (no la vía cuadrada del SyS): el generador mapea cada etiqueta vía el 'PGC mínimo'
    (mapeo_partidas_sys_a3.yaml), valida contra el maestro PGC (904 oficial) y CUADRA. Si queda alguna
    partida sin mapear o no cuadra -> issue BLOQUEANTE (HITL). Sólo si `apto` emite el canónico 4d: las
    **filas A3 SON el agrupado** que consume la Fase A/paquete, así CASO B y CASO A (SyS) convergen.
    """
    # Partidas SIN importe legible (None): NO inventar fila a cero (fila fantasma). Se omiten y se flaggean
    # como a_confirmar para que el HITL las vea (auto-revisión LOW: importe ausente colapsaba a 0).
    sin_importe = [p for p in (partidas or []) if p.get("importe") is None]
    entrada = [{"partida": p.get("etiqueta"), "importe": p.get("importe")}
               for p in (partidas or []) if p.get("importe") is not None]
    try:
        a3 = _gen_a3.generar_sys(entrada, nif=nif, nombre=nombre)
    except SystemExit as e:  # los motores hacen raise SystemExit ante input inválido
        a3 = {"filas": [], "control": None, "apto": False, "tabla3": [],
              "issues": [{"codigo": "A3_ERROR", "severidad": "bloqueante", "detalle": f"SystemExit: {e}"}]}
    except Exception as e:  # noqa: BLE001
        a3 = {"filas": [], "control": None, "apto": False, "tabla3": [],
              "issues": [{"codigo": "A3_ERROR", "severidad": "bloqueante", "detalle": f"{type(e).__name__}: {e}"}]}
    issues = list(a3.get("issues", []))
    for p in sin_importe:
        issues.append({"codigo": "PARTIDA_SIN_IMPORTE", "severidad": "a_confirmar",
                       "detalle": f"Partida '{p.get('etiqueta')}' sin importe legible (OCR): omitida del A3; revísala."})
    # Columna/año ambiguo: el parser marcó varias columnas MONETARIAS (p.ej. ejercicio N y N-1) y se tomó
    # la primera; el HITL debe confirmar el ejercicio (la inversa 2023-a-la-izquierda colaba el año
    # comparativo al número firmado — auto-revisión T1.2). No bloquea (a_confirmar): el abogado decide.
    for p in (partidas or []):
        if p.get("multi") and p.get("importe") is not None:
            issues.append({"codigo": "COLUMNA_AMBIGUA", "severidad": "a_confirmar",
                           "detalle": f"Partida '{p.get('etiqueta')}' con varias columnas {p.get('importes')}: "
                                      f"se tomó {p.get('importe')} (primera monetaria); confirma el ejercicio."})
    # Cuadre forzado: generar_sys enchufa una cuenta de cuadre cuando las partidas no cuadran. En CASO B
    # (inferencia OCR) ese plug puede ENMASCARAR un importe mal leído o una partida sin mapear -> a_confirmar
    # con la magnitud, para que 'cuadra ✓' no oculte el descuadre (auto-revisión T1.2; ruta nº firmado).
    for t in a3.get("tabla3", []):
        if t.get("partida") == "cuadre del balance":
            issues.append({"codigo": "CUADRE_INSERTADO", "severidad": "a_confirmar",
                           "detalle": f"Se enchufó un cuadre de {t.get('importe')} en {t.get('cuenta')} "
                                      f"({t.get('descripcion')}): revisa que no falte/sobre una partida."})
    canonico = _canonico_csv_desde_filas(a3["filas"]) if a3.get("apto") and a3.get("filas") else None
    return {
        "apto": bool(a3.get("apto")),
        "filas": a3.get("filas", []),
        "control": a3.get("control"),
        "issues": issues,
        "tabla3": a3.get("tabla3", []),
        "canonico_csv": canonico,
        "borrador": True,
        "exportable_a_importador": False,   # inferencia: SIEMPRE HITL (como _borrador_desde_partidas)
        "nota": "A3 por inferencia desde CCAA (OCR/texto): revisa cada partida (HITL). La vía cuadrada "
                "directa para el importador es el Sumas y Saldos. El canónico se emite sólo si el A3 cuadra.",
    }


def generar_sys_a3(path: str, ejercicio="2024") -> dict:
    """Fichero CCAA (PDF/texto) -> A3 determinista (CASO B). Extrae texto (+OCR si hace falta), infiere
    partidas (extractor_markdown) y genera el A3 + canónico. `ejercicio` reservado para campañas."""
    cls = clasificador.clasificar(path)
    texto, motor_pdf, ocr = "", None, None
    if cls.get("es_pdf"):
        texto, motor_pdf = extractor_ccaa.extraer_texto(path)
        if not texto and ocr_client.disponible():
            conv = ocr_client.convertir(path, filename=os.path.basename(path))
            if conv.get("disponible") and conv.get("markdown"):
                texto, motor_pdf = conv["markdown"], "ocr:" + str(conv.get("backend"))
                ocr = {"backend": conv.get("backend"), "paginas": conv.get("paginas")}
    else:
        try:  # no PDF: mejor esfuerzo leyéndolo como texto plano
            with open(path, encoding="utf-8", errors="replace") as fh:
                texto = fh.read()
            motor_pdf = "texto"
        except OSError:
            texto = ""
    if not texto:
        return {"clasificacion": cls, "apto": False, "necesita_ocr": bool(cls.get("es_pdf")),
                "partidas": [], "canonico_csv": None,
                "nota": "No se pudo extraer texto de las CCAA (¿PDF escaneado sin OCR configurado?)."}
    # NO quitar los pipes: extractor_markdown es el parser de TABLAS del OCR (Docling/TableFormer) y los
    # NECESITA para delimitar celdas; tiene fallback de línea plana interno para texto sin tabla. Quitarlos
    # pegaba la fila entera en la etiqueta y cogía la columna del año comparativo (auto-revisión HIGH).
    partidas = extractor_markdown.extraer_partidas(texto) or []
    res = generar_sys_a3_desde_partidas(partidas)
    res["clasificacion"] = cls
    res["motor_extraccion"] = motor_pdf
    res["n_partidas"] = len(partidas)
    res["partidas"] = partidas[:200]
    if ocr is not None:
        res["ocr"] = ocr
    return res


# ----------------------------------------------------------------- Expediente (wiring W1)
def expediente_pasos() -> dict:
    """El recorrido de 7 pasos + checkpoints (para que el frontend pinte el stepper)."""
    return {
        "pasos": estado_expediente.PASOS,
        "checkpoints": estado_expediente.CHECKPOINTS,
        "max_paso": estado_expediente.MAX_PASO,
    }


def expediente_siguiente(paso_actual: int) -> dict:
    """¿Dónde estás → siguiente acción? (con marca de checkpoint humano). estado_expediente."""
    return estado_expediente.siguiente_accion(int(paso_actual))


def expediente_recomputo(paso_modificado: int) -> dict:
    """Marcha atrás/enriquecer: qué pasos rehacer + qué entregables quedan obsoletos."""
    return estado_expediente.plan_recomputo(int(paso_modificado))


# --- Carpeta-estado del expediente (persistencia real, W8) ---
# El estado = el expediente (spec §4). Se guarda un harness JSON por expediente en un dir LOCAL y
# GITIGNORED (puede contener NIF/ejercicio = datos de cliente). En Phase 2 esto será SharePoint/Dataverse.
# Overridable por entorno (tests/CI escriben en tmp; sandbox sin unlink en el mount, 2026-06-11)
EXPEDIENTES_DIR = os.environ.get("SUITE_IS_EXPEDIENTES_DIR") or os.path.join(
    ROOT, "engine_service", "_local_expedientes")


def _expediente_path(eid: str) -> str:
    safe = re.sub(r"[^A-Za-z0-9_.-]", "_", str(eid or ""))[:120] or "default"
    return os.path.join(EXPEDIENTES_DIR, safe + ".json")


def guardar_estado(eid: str, estado: dict) -> dict:
    """Persiste el harness del expediente (JSON) en la carpeta-estado local (gitignored)."""
    os.makedirs(EXPEDIENTES_DIR, exist_ok=True)
    with open(_expediente_path(eid), "w", encoding="utf-8") as fh:
        json.dump(estado or {}, fh, ensure_ascii=False)
    return {"ok": True, "id": eid}


def cargar_estado(eid: str) -> dict:
    """Lee el harness del expediente; {existe: False} si no hay."""
    path = _expediente_path(eid)
    if not os.path.exists(path):
        return {"existe": False, "estado": None}
    try:
        with open(path, encoding="utf-8") as fh:
            return {"existe": True, "estado": json.load(fh)}
    except (OSError, ValueError):
        return {"existe": False, "estado": None}


_MIME = {
    ".docx": "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
    ".xlsx": "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
    ".xml": "application/xml",
}


def _emitir_xlsx_aeat(canonico_csv_path: str, outdir: str, empresa: str, ejercicio: str) -> dict:
    """P10 (T1.3.4): desde el canónico 4d emite los DOS xlsx de la proyección AEAT descargable —
    `estados_contables_aeat.xlsx` (balance/PyG/ECPN, importación de datos contables) y `agrupado_4d.xlsx`
    (fichero de importación A3 = Sumas y Saldos). Devuelve {ficheros:{clave:ruta}, avisos:[...]}; cada
    emisor falla-cerrado por su cuenta (no escribe si descuadra). NO valida provenance: el llamador
    (generar_paquete) ya está DENTRO del gate HITL. La CONVENCIÓN A3 definitiva (4d agrupado vs subcuentas)
    es COMPUERTA DE Moi64: el agrupado_4d.xlsx se marca 'provisional' hasta su prueba de importación real."""
    import motor_sys  # lazy: el coste de import (calamine) solo al emitir el paquete
    salida = {"ficheros": {}, "avisos": []}
    paths = _campaign_paths(ejercicio)
    mapeo = json.load(open(paths["mapeo"], encoding="utf-8"))
    catalogo = json.load(open(paths["catalogo"], encoding="utf-8"))
    canonico = builder.cargar_canonico(canonico_csv_path)
    # GATE FAIL-CLOSED de cuadre (Codex B3): este emisor también es un chokepoint de xlsx AEAT (estados +
    # agrupado). Un canónico descuadrado no emite NINGÚN xlsx, aunque se llame directo (no solo vía paquete).
    reconciliador.exigir_cuadre(canonico)
    # estados_contables_aeat.xlsx (proyección a casillas AEAT, mismas que el XML)
    casillas, _lin, _cuadre, _pyg, _sec = builder.proyectar(canonico, mapeo, catalogo)
    reconciliador.exigir_cuadre_proyeccion(_cuadre)  # B3: no emitir xlsx de un balance AEAT descuadrado/no_map
    estados_path = os.path.join(outdir, "estados_contables_aeat.xlsx")
    try:
        builder.construir_xlsx(casillas, catalogo, estados_path, empresa, str(ejercicio))
        salida["ficheros"]["estados_contables_aeat"] = estados_path
    except Exception as e:  # noqa: BLE001
        salida["avisos"].append(f"estados_contables_aeat.xlsx no generado: {type(e).__name__}: {e}")
    # agrupado_4d.xlsx (fichero de importación A3). Convención A3 = compuerta humana -> 'provisional'.
    grupos = {f["cuenta"]: {"denom": f["denom"], "sf": f["sf"], "debe": f["debe"],
                            "haber": f["haber"], "si": f["si"]} for f in canonico}
    try:
        r = motor_sys.escribir_a3_xlsx(outdir, empresa, str(ejercicio), grupos, nif=empresa)
        if r.get("ok"):
            salida["ficheros"]["agrupado_4d"] = r["fichero"]
            salida["avisos"].append("agrupado_4d.xlsx (A3): CONVENCIÓN PROVISIONAL (4d agrupado); la "
                                    "definitiva (4d vs subcuentas) la decide una prueba de importación real (compuerta humana).")
        else:
            salida["avisos"].append(f"agrupado_4d.xlsx no generado: {r.get('motivo')}")
        salida["avisos"].extend(r.get("avisos", []))
    except Exception as e:  # noqa: BLE001
        salida["avisos"].append(f"agrupado_4d.xlsx no generado: {type(e).__name__}: {e}")
    return salida


def _formato_bloqueo(state: dict) -> str:
    """Parche 6 (T1.3.2) — FORMATO ÚNICO DE BLOQUEO (verbatim del WF-2 v1.2): '# BORRADOR no presentable'
    + tabla 'Lista de bloqueos' (qué falta y dónde se resuelve) + 'Nota operativa'. Cubre los casos del
    gating: H_validada ausente, 🔴 abiertos, 🟡 con impacto. Paridad con Harvey en la consola."""
    rojo = round(float(state.get("H_sem_rojo", 0) or 0))
    amar = round(float(state.get("H_sem_amarillo_impacto", 0) or 0))
    validada = str(state.get("H_validada", "no")).lower() in {"si", "sí", "true"}
    bloqueos = []
    if rojo > 0:
        bloqueos.append((f"Issues 🔴 bloqueantes sin resolver (H_sem_rojo={rojo})",
                         "Resuélvelos en el análisis (WF-1) o aporta la evidencia que los cierra."))
    if amar > 0:
        bloqueos.append((f"Issues 🟡 con impacto sin validar (H_sem_amarillo_impacto={amar})",
                         "Valida o descarta cada 🟡 con impacto en el checkpoint 1."))
    if not validada:
        bloqueos.append(("La liquidación no está validada (H_validada≠'si')",
                         "Valida el número en el checkpoint 2 (cuadro 00552/00562/00621 + evidencia)."))
    if not bloqueos:
        bloqueos.append(("No exportable según el gating del motor",
                         "Revisa el estado del expediente (semáforos + validación)."))
    lineas = ["# BORRADOR no presentable", "",
              "## Lista de bloqueos", "", "| Bloqueo | Dónde se resuelve |", "|---|---|"]
    lineas += [f"| {q} | {donde} |" for q, donde in bloqueos]
    lineas += ["", "## Nota operativa", "",
               "1. Para desbloquear, aporta/responde exactamente lo indicado en cada fila de la lista de bloqueos.",
               "2. Si SOLO falta la validación del número, NO habrá recálculo: el número ya está calculado; "
               "solo falta el visto bueno humano.",
               "3. No se inventan protocolos de consentimiento ni formalismos no definidos en este workflow."]
    return "\n".join(lineas)


def _a_centimos(x) -> Decimal:
    """Cuantiza a 2 decimales con ROUND_HALF_UP (la política de redondeo de la emisión/firma): dos importes
    que se firman/renderizan con el MISMO céntimo se consideran iguales; uno que cruza el límite, distinto."""
    return Decimal(str(x)).quantize(Decimal("0.01"), rounding=ROUND_HALF_UP)


def _coherencia_liquidacion(inputs: dict, mapping: list) -> list:
    """H11 (Codex T1.3): el modelo_200 se escribe del 05_MAPPING_M200 VERBATIM. El flag H_validada no basta:
    verifica que las casillas de LIQUIDACIÓN del mapping (00552/00562/00621) CUADRAN con la liquidación
    RECOMPUTADA desde 03_LIQUIDACION_INPUTS_V2 (la fuente de verdad: B15/B16/B17). Devuelve los descuadres
    (vacío = coherente). Un mapping stale/alterado con H_validada='si' habría firmado un número no validado."""
    try:
        import puente_entregables_v3
        liq = puente_entregables_v3.recompute_liquidacion(inputs)
    except Exception as e:  # noqa: BLE001  (inputs incompletos -> no verificable -> fail-closed)
        return [f"No se pudo recomputar la liquidación desde 03_LIQUIDACION_INPUTS_V2 ({type(e).__name__}): no verificable."]
    esperado = {"00552": liq.get("B15"), "00562": liq.get("B16"), "00621": liq.get("B17")}
    desc = []
    for casilla, val in esperado.items():
        if val is None:
            continue
        # Non-finite (Codex H14): json acepta NaN/Infinity y abs(nan-x)>0.01 es False -> evadía el descuadre.
        if not math.isfinite(float(val)):
            desc.append(f"Casilla {casilla}: valor recomputado NO finito ({val}) desde los inputs (NaN/Infinity).")
            continue
        # TODAS las filas de esa casilla (Codex H12): el Modelo_200 escribe el mapping VERBATIM, así que una
        # fila duplicada STALE se emitiría aunque otra duplicada cuadre. Un dict {casilla:row} la ocultaría.
        # Casilla NORMALIZADA (strip) (Codex H13): "00552 " (espacio) se trataría como 00552 al escribirla;
        # un match exacto la dejaba pasar como 'ausente' con su importe erróneo.
        filas = [r for r in (mapping or []) if str(r.get("casilla") or "").strip() == casilla]
        if len(filas) > 1:
            desc.append(f"Casilla {casilla}: {len(filas)} filas en el mapping (debe haber exactamente una).")
        for fila in filas:
            raw = str(fila.get("casilla") or "")
            if raw != casilla:   # etiqueta no canónica (espacios u otros) de una casilla de liquidación
                desc.append(f"Casilla {casilla}: etiqueta no canónica {raw!r} en el mapping (debe ser exactamente '{casilla}').")
            try:
                imp = float(fila.get("importe"))
            except (TypeError, ValueError):
                desc.append(f"Casilla {casilla}: importe del mapping no numérico ({fila.get('importe')!r}).")
                continue
            if not math.isfinite(imp):   # NaN/Infinity en el mapping (Codex H14)
                desc.append(f"Casilla {casilla}: importe del mapping NO finito ({fila.get('importe')!r}).")
                continue
            # CÉNTIMO EXACTO (Codex H17): el Modelo_200.xlsx guarda el importe CRUDO del mapping; un valor
            # sub-céntimo (p.ej. 100.001) firmaría un número distinto del céntimo validado aunque redondee al
            # mismo céntimo. Se exige que el importe sea ya su céntimo exacto (no sub-céntimos).
            if abs(imp - float(_a_centimos(imp))) > 1e-6:
                desc.append(f"Casilla {casilla}: importe del mapping {imp} no es un céntimo exacto "
                            f"(debe ser {_a_centimos(imp)}); el Modelo_200 guardaría el valor crudo.")
                continue
            # Comparación AL CÉNTIMO con la misma cuantización que la emisión (Codex H15): una tolerancia
            # float 'abs>0.01' dejaba pasar divergencias sub-céntimo que cruzan el redondeo (100.004 vs
            # 100.013 -> '100.00' vs '100.01'). Decimal ROUND_HALF_UP iguala el céntimo renderizado/firmado.
            if _a_centimos(imp) != _a_centimos(val):
                desc.append(f"Casilla {casilla}: mapping {imp} (={_a_centimos(imp)}) ≠ recomputado "
                            f"{_a_centimos(val)} al céntimo (descuadre).")
    # Nota: una casilla AUSENTE no es un número erróneo (el Modelo_200 no la escribe; la Liquidacion.docx la
    # emite desde los inputs recomputados). La completitud del trío 00552/00562/00621 es una verificación
    # aparte (no se fuerza aquí: rompería bloques con mapping parcial legítimo y no es ruta de número-firmado).
    return desc


def generar_paquete(nif="DEMO", ejercicio="2025", sys_tabla1=None, bloque_wf1=None,
                    bloque_wf2=None, canonico_csv=None, fuente_canonico=None, a3_confirmado=False,
                    formales=None, caracteres=None, pagina01b=None) -> dict:
    """Paso 5 (Entregables): motor_servicio.generar_paquete -> entregables en base64 (para descarga web).

    Recibe los bloques (texto) de WF-1/WF-2, la tabla SyS y, opcionalmente, el canónico 4d; el motor
    (fachada "listo para hospedar") genera A3 + carta + memoria/liquidación/Modelo 200, y si hay canónico
    también el **XML mod200 CONTABLE** (Fase A, D13: solo balance/PyG/ECPN — la liquidación va aparte).

    GATE HITL SERVER-SIDE (Codex HIGH T1.2): si el canónico es INFERIDO de las CCAA (centinela de
    provenance o `fuente_canonico='ccaa_a3'`) NO se emite el XML firmado salvo `a3_confirmado=True`.
    Fail-closed: el POST directo del canónico de /generar-sys-a3 no salta el gate de la UI.
    """
    # Parche 6 (T1.3.2): gating de PRESENTABILIDAD antes de generar nada. Si hay bloque WF-2 y el gating es
    # negativo (🔴, 🟡 con impacto o sin validar) o el bloque es ilegible, el paquete es un BORRADOR no
    # presentable con el FORMATO ÚNICO y NO se generan los entregables finales (paridad Harvey + defensa
    # server-side: nunca se entrega un número no validado, aunque el front deje pulsar 'Generar').
    mapping_wf2 = []   # 5.B: casillas de liquidación firmadas (05_MAPPING_M200), para el DR completo del cierre
    if bloque_wf2:
        descuadres = []
        try:
            import puente_entregables_v3  # parser real del bloque WF-2 (sys.path por __init__)
            parsed = puente_entregables_v3.parse_bloque(bloque_wf2)
            harness = parsed.get("harness") or {}
            mapping_wf2 = parsed.get("mapping") or []
            g = gating(harness)
            # H11 (Codex T1.3): además del flag H_validada, las casillas de liquidación del mapping deben
            # cuadrar con la liquidación recomputada desde los inputs (si no, el Modelo 200 firmaría un
            # número no validado, p.ej. mapping stale).
            descuadres = _coherencia_liquidacion(parsed.get("inputs") or {}, mapping_wf2)
        except Exception as e:  # noqa: BLE001  (bloque ilegible -> fail-closed)
            harness, g = {"H_validada": "no"}, {"exportable": False, "motivos": [f"bloque WF-2 ilegible: {e}"]}
        if descuadres:
            g = {"exportable": False, "motivos": list(g.get("motivos", [])) + descuadres}
        if not g["exportable"]:
            bloqueo = _formato_bloqueo(harness)
            if descuadres:
                bloqueo += "\n\n## Descuadre de la liquidación (05_MAPPING_M200 ≠ inputs recomputados)\n" + \
                           "\n".join(f"- {d}" for d in descuadres)
            return {"entregables": {}, "presentable": False, "bloqueo": bloqueo,
                    "avisos": ["Paquete NO presentable (gating negativo): ver 'bloqueo' "
                               "(# BORRADOR no presentable + Lista de bloqueos + Nota operativa)."]}
    with tempfile.TemporaryDirectory() as td:
        inputs = {"nif": nif, "ejercicio": str(ejercicio), "output_dir": os.path.join(td, "out")}
        for clave, texto in (("sys_tabla1", sys_tabla1), ("bloque_wf1", bloque_wf1), ("bloque_wf2", bloque_wf2)):
            if texto:
                p = os.path.join(td, clave + ".txt")
                with open(p, "w", encoding="utf-8") as fh:
                    fh.write(texto)
                inputs[clave] = p
        res = motor_servicio.generar_paquete(inputs)
        out = {"entregables": {}, "avisos": res.get("avisos", [])}
        # B3 (Codex): si el SyS legacy (sys_tabla1) está descuadrado, motor_servicio lo señala -> el paquete
        # NO es presentable (la contabilidad base no cuadra), aunque no se pase canonico_csv.
        if res.get("contabilidad_descuadrada"):
            out["canonico_descuadrado"] = True
        for clave, ruta in (res.get("entregables") or {}).items():
            # El puente añade claves internas (_liquidacion/_harness) con valor dict: no son ficheros.
            if clave.startswith("_") or not isinstance(ruta, str):
                continue
            try:
                with open(ruta, "rb") as fh:
                    data = fh.read()
            except OSError:
                continue
            ext = os.path.splitext(ruta)[1].lower()
            out["entregables"][clave] = {
                "fichero": os.path.basename(ruta),
                "mime": _MIME.get(ext, "application/octet-stream"),
                "base64": base64.b64encode(data).decode("ascii"),
                "bytes": len(data),
            }
        # XML mod200 CONTABLE (Fase A, D13: SOLO contable; NO inyecta la liquidación).
        # Gate HITL: un canónico inferido de CCAA no firma el número sin confirmación humana (fail-closed).
        # B3 inter-documento (Codex / EPIC B AC): si se aportan AMBAS fuentes contables (sys_tabla1 +
        # canonico_csv), deben CUADRAR ENTRE SÍ por cuenta al céntimo (tol=0). Un delta = contabilidad
        # incoherente -> no se emite AEAT (cada fuente puede cuadrar consigo misma pero diferir de la otra).
        if sys_tabla1 and canonico_csv and not out.get("canonico_descuadrado"):
            try:
                import exportar_sys_a3
                cchk = os.path.join(td, "canonico.csv")
                with open(cchk, "w", encoding="utf-8") as fh:
                    fh.write(canonico_csv)
                inter = reconciliador.reconciliar_inter_documento(
                    builder.cargar_canonico(cchk), exportar_sys_a3.parse_tabla1(sys_tabla1))
                if not inter["ok"]:
                    out["canonico_descuadrado"] = True
                    out["avisos"].append(
                        "Fuentes contables INCONSISTENTES (SyS≠canónico, inter-documento) — deltas: "
                        + "; ".join(f"{d['cuenta']}:{d['delta']}" for d in inter["deltas"][:5]))
            except Exception as e:  # noqa: BLE001
                out["avisos"].append(f"Reconciliación inter-documento no realizada: {type(e).__name__}: {e}")
        inferido = _es_canonico_inferido(canonico_csv) or fuente_canonico == "ccaa_a3"
        if canonico_csv and out.get("canonico_descuadrado"):
            # B3 (Codex): otra fuente contable (sys_tabla1) ya está descuadrada -> fuentes inconsistentes;
            # NO se emite AEAT del canónico aunque éste cuadre (no firmar de una contabilidad incoherente).
            out["avisos"].append("XML/xlsx AEAT NO generados: otra fuente contable (SyS) está descuadrada "
                                 "(fuentes inconsistentes).")
        elif canonico_csv and inferido and a3_confirmado is not True:   # estricto: 'false'/'0' NO confirman
            out["avisos"].append(
                "XML mod200 NO generado: el canónico es un A3 INFERIDO de las CCAA "
                "(exportable_a_importador:false). Requiere confirmación HITL del A3 (a3_confirmado) "
                "antes de firmar el número — Codex HIGH T1.2 (gate server-side).")
            out["xml_bloqueado_hitl"] = True
        elif canonico_csv:
            cpath = os.path.join(td, "canonico.csv")
            with open(cpath, "w", encoding="utf-8") as fh:
                fh.write(canonico_csv)
            # GATE FAIL-CLOSED de cuadre (B3 / EPIC B): un canónico descuadrado NO firma el XML NI emite los
            # xlsx AEAT (todos son la misma proyección del número). El XML ya lo bloquea emitir_mod200
            # (CanonicoDescuadradoError); aquí gateamos también el xlsx para no entregar un número descuadrado.
            _rec = reconciliador.reconciliar(builder.cargar_canonico(cpath))
            if not _rec["ok"]:
                out["avisos"].append("XML/xlsx AEAT NO generados: canónico descuadrado — " + "; ".join(_rec["errores"]))
                out["canonico_descuadrado"] = True
            else:
                try:
                    # El gate vive también en emitir_mod200 (chokepoint): pasamos provenance + confirmación.
                    emis = emitir_mod200(cpath, os.path.join(td, "out"), empresa=nif, ejercicio=str(ejercicio),
                                         fuente_canonico=fuente_canonico, a3_confirmado=a3_confirmado)
                    xml_bytes = emis["xml"].encode("iso-8859-1", "replace")
                    out["entregables"]["xml_mod200"] = {
                        "fichero": os.path.basename(emis["xml_path"]),
                        "mime": "application/xml",
                        "base64": base64.b64encode(xml_bytes).decode("ascii"),
                        "bytes": len(xml_bytes),
                        "valido_xsd": emis["valido_xsd"],
                        "xsd_provisional": emis.get("xsd_provisional", False),
                        "xsd_fuente": emis.get("xsd_fuente", "oficial"),
                        "contiene_liquidacion": False,
                    }
                    out["avisos"].append(
                        "XML mod200: SOLO contable (Fase A, D13); la liquidación va aparte."
                        + (" ⚠️ XSD PROVISIONAL para 2025 (= casillas 2024): pendiente del mod2002025.xsd OFICIAL de la AEAT; "
                           "NO presentar como validado contra el oficial." if emis.get("xsd_provisional") else "")
                    )
                except reconciliador.CanonicoDescuadradoError as e:
                    # Descuadre de la PROYECCIÓN AEAT (00180≠00252) con canónico raw-cuadrado (B3 Codex): ni
                    # XML ni xlsx; el número AEAT no es firmable.
                    out["avisos"].append(f"XML/xlsx AEAT NO generados: {e}")
                    out["canonico_descuadrado"] = True
                except Exception as e:  # noqa: BLE001
                    out["avisos"].append(f"XML mod200 no generado: {type(e).__name__}: {e}")
                # P10 (T1.3.4): la proyección AEAT descargable — estados_contables_aeat.xlsx + agrupado_4d.xlsx
                # (A3). Solo si la proyección cuadró (no canonico_descuadrado); _emitir_xlsx_aeat re-gatea.
                if not out.get("canonico_descuadrado"):
                    xlsx = _emitir_xlsx_aeat(cpath, os.path.join(td, "out"), empresa=nif, ejercicio=str(ejercicio))
                    for clave, ruta in xlsx["ficheros"].items():
                        try:
                            with open(ruta, "rb") as fh:
                                data = fh.read()
                        except OSError:
                            continue
                        out["entregables"][clave] = {
                            "fichero": os.path.basename(ruta),
                            "mime": _MIME.get(".xlsx", "application/octet-stream"),
                            "base64": base64.b64encode(data).decode("ascii"),
                            "bytes": len(data),
                        }
                    out["avisos"].extend(xlsx["avisos"])
                    # 5.B: registro DR de la declaración COMPLETA (identificativos + contable + LIQUIDACIÓN
                    # firmada del cierre = 05_MAPPING_M200). El contable cuadró (rama de éxito); la liquidación
                    # viene del bloque WF-2 ya validado (mapping_wf2, coherente con la recomputada). Guardado:
                    # NUNCA rompe el cierre (try/except); entregable ADITIVO PROVISIONAL (sin XSD; valida import real).
                    try:
                        liq = {str(r.get("casilla") or "").strip(): r.get("importe")
                               for r in mapping_wf2 if str(r.get("casilla") or "").strip()}
                        contable_dr = {k: v for k, v in proyectar_contable(cpath, str(ejercicio))["casillas"].items()
                                       if v is not None}
                        # U2/U4: la precarga del año anterior (formales Capa 2 + caracteres/página 1B Capa 1)
                        # alimenta el `.200` del cierre. Aditivo (None por defecto → cierre demo/GIP intacto).
                        decl = _entrada_declaracion_dr(str(ejercicio), contable_dr, nif=nif,
                                                       razon_social="", liquidacion=liq or None,
                                                       formales=formales, caracteres=caracteres,
                                                       pagina01b=pagina01b)
                        if decl is not None:
                            decl["bytes"] = len(base64.b64decode(decl["base64"]))
                            out["entregables"]["declaracion_dr"] = decl
                    except Exception as e:  # noqa: BLE001  (aditivo: su fallo no bloquea el cierre)
                        out["avisos"].append(f"Registro DR de la declaración no generado: {type(e).__name__}: {e}")
        # Presentabilidad (parche 6 + H10 Codex T1.3): es un CIERRE presentable SOLO con bloque WF-2
        # exportable. Si llegamos aquí CON WF-2, su gating fue positivo -> presentable=True. Si NO hay WF-2,
        # el paquete es PARCIAL (carta WF-1 + contable Fase A, permitidos por diseño:
        # test_expediente_paquete_incluye_xml_contable / ..._parcial_solo_wf1): se marca presentable=False
        # para que NUNCA se descargue como cierre validado sin checkpoint 2. El número de LIQUIDACIÓN no se
        # filtra: memoria/liquidacion/modelo_200 vienen de WF-2 (ausente -> no se emiten); el XML/xlsx son
        # CONTABLES (Fase A, validados por el cuadre del canónico), no el número del checkpoint 2.
        if bloque_wf2 and out.get("canonico_descuadrado"):
            # B3 (Codex): WF-2 exportable PERO la contabilidad base (canónico) NO cuadra -> el cierre NO es
            # presentable; se OMITEN los entregables finales de WF-2 (Modelo 200/Liquidación/Memoria), que se
            # apoyan en una contabilidad rota. El paquete entero pasa a BORRADOR.
            for _k in ("modelo_200", "liquidacion", "memoria", "xml_mod200", "estados_contables_aeat",
                       "agrupado_4d", "a3", "declaracion_dr"):
                out["entregables"].pop(_k, None)
            out["presentable"] = False
            out["bloqueo"] = (_formato_bloqueo({"H_validada": "no"}) +
                              "\n\n## Contabilidad base descuadrada\n- El canónico (SyS/Fase A) no cuadra: "
                              "no se presenta el cierre. Sube una contabilidad que cuadre.")
            out["avisos"].append("Paquete NO presentable: la contabilidad base (canónico) está descuadrada.")
        elif bloque_wf2:
            out["presentable"] = True
        else:
            out["presentable"] = False
            out["avisos"].append("Paquete PARCIAL: falta el bloque WF-2 (cierre / checkpoint 2). Solo "
                                 "artefactos de análisis (carta) / contable (Fase A); NO es un cierre presentable.")
        return out


def explicar(casilla: str, ejercicio="2024", regimen="general") -> dict:
    """Lineage de una casilla: (a) mapeo PGC->casilla del EPC y (b) cadena fiscal + FUNDAMENTO
    normativo (ref LIS/RIS) desde el orquestador/catálogo. T1.1.5 (antes solo daba el PGC)."""
    paths = _campaign_paths(ejercicio)
    mapeo = json.load(open(paths["mapeo"], encoding="utf-8"))
    reglas = [r for r in mapeo.get("reglas", []) if r.get("casilla") == casilla]
    res = mapeo.get("resultado_casillas", {})
    # (b) cadena fiscal (concepto/formula/ref por casilla) + reglas del catálogo que tocan la casilla
    cadena = motor_expediente.construir_lineage({}, ejercicio=str(ejercicio)).get(casilla)
    reglas_fiscales = [
        {"id": r["id"], "titulo": r.get("titulo"), "ref": r.get("ref"),
         "criticidad_default": r.get("criticidad_default"), "dominio": r.get("dominio")}
        for r in motor_expediente.reglas_activas(str(ejercicio), regimen)
        if casilla in (r.get("casillas") or [])
    ]
    return {
        "casilla": casilla,
        "es_resultado": casilla in set(res.values()),
        "reglas": reglas,
        "fuente": "mapeo PGC->casilla (EPC builder)",
        "cadena_fiscal": cadena,                 # concepto/formula/ref/valor (ref = art. LIS/RIS)
        "fundamento": (cadena or {}).get("ref"),
        "reglas_fiscales": reglas_fiscales,      # catálogo: ref normativa de cada regla que toca la casilla
    }


# ----------------------------------------------------------------- Caso GIP 2024 (solo local)
def caso_gip2024(sys_path: str, vector: dict, outdir: str, ejercicio="2024") -> dict:
    """Pipeline completo del caso real: SyS -> contable (anclas) -> firma fiscal -> reconciliación.

    `vector` = {"facts": {...}, "issues": [...]} con los inputs de juicio fiscal validados
    (vive fuera de git: cifras de cliente). Reproduce las anclas §6 sin inventar nada.
    """
    man = run_pipeline([sys_path], outdir, empresa="GIP", ejercicio=ejercicio)
    b = man.get("etapas", {}).get("builder", {})
    v = man.get("etapas", {}).get("validacion", {})
    contable = {
        "00500": b.get("resultado"),
        "activo_total": b.get("total_activo"),
        "pnpasivo_total": b.get("total_pnpasivo"),
        "cuadra": b.get("cuadra"),
        "xsd_estado": v.get("xsd"),
        "xml_valido_xsd": bool(v.get("apto")) and ("válido" in str(v.get("xsd", ""))),
    }
    seam = contable_a_inputs_liquidacion({"casillas": {"00500": contable["00500"], "00301": 0.0, "00595": 0.0}}) \
        if contable["00500"] is not None else {"B2_resultado_contable": None}
    # Firma por el ORQUESTADOR canónico (no la ruta plugin): casillas con SIGNO correcto — p.ej. 00547
    # (compensación BINs) POSITIVA, no el importe de línea -comp que firmaba firma_desde_liquidacion (Codex HIGH).
    orq = liquidar_orquestado(vector["facts"], vector["issues"], ejercicio, vector["facts"].get("regimen"))
    firma = firma_desde_orquestado(orq)
    # Reconciliación con claves COINCIDENTES (mismo ejercicio cuadra -> 0 divergencias;
    # cruzar ejercicios distintos -> divergencia, que es justo lo que debe surfacearse).
    recon = reconciliar(
        {"00500": cent(contable["00500"]) if contable["00500"] is not None else None,
         "B2": seam.get("B2_resultado_contable")},
        {"00500": firma["casillas"].get("00500"),
         "B2": cent(vector["facts"].get("resultado_contable", 0))},
    )
    # FASE A — Importación de datos contables (Sociedades WEB): XML CONTABLE válido vs XSD, SIN liquidación.
    agr = os.path.join(outdir, "agrupado_4d.csv")
    importacion_contable = None
    if os.path.exists(agr):
        try:
            # Fase A — gate PRE-XML: ¿apto para importar? (identidades contables + formato)
            validacion_fase_a = validar_contable(agr, tipo_entidad="normal", ejercicio=ejercicio)
            emis = emitir_mod200(agr, outdir, empresa="GIP", ejercicio=ejercicio)
            importacion_contable = {
                "apto": validacion_fase_a["apto"],
                "validacion": validacion_fase_a,
                "valido_xsd": emis["valido_xsd"],
                "xsd_estado": emis["validacion"].get("xsd"),
                "n_casillas_contables": emis["n_casillas_contables"],
                "contiene_liquidacion": False,
                "fichero": os.path.basename(emis["xml_path"]),
                "xml": emis["xml"],  # para descarga desde la consola (solo se ship­ea si valido_xsd)
            }
        except Exception as e:  # noqa: BLE001
            importacion_contable = {"error": f"{type(e).__name__}: {e}"}
    return {
        "contable": contable,
        "seam": seam,
        "firma": firma,
        "reconciliacion": recon,
        "importacion_contable": importacion_contable,
        "estado_pipeline": man.get("estado"),
    }
