"""Cliente HTTP del servicio de conversión/OCR (parser IRPF persona_tax) — Opción 1 (D14).

El parser IRPF ya despliega **Docling** (Layout Heron RT-DETR + TableFormer + EasyOCR es/en/…) en
Railway y expone `POST /convert-document` (PDF → Markdown estructurado con tablas y OCR). En lugar de
cargar torch + modelos (~700 MB) en este servicio, lo **LLAMAMOS por HTTP** para el OCR de cuentas
anuales en PDF escaneado (el "fleco" pendiente de D12).

Diseño:
  - Configurable vía env `OCR_SERVICE_URL` (p.ej. `http://localhost:8081` o la URL Railway del parser).
  - **Degrada con gracia**: si no está configurado o el servicio no responde, devuelve
    `disponible=False` y la ingesta sigue con el aviso `necesita_ocr` (no rompe el flujo determinista
    SyS/mayor, que NO necesita OCR). NUNCA lanza: un fallo de OCR no debe tumbar la ingesta.
  - Sin dependencias nuevas: `urllib` de la stdlib.

Contrato del endpoint (persona_tax/app/docling_converter.py):
  req  {document_id, filename, content_base64, output_format="markdown"}
  resp {document_id, markdown, tables_count, pages_count, backend, entity_hint, warnings[]}
"""
from __future__ import annotations

import base64
import json
import os
import urllib.error
import urllib.request

OCR_ENV = "OCR_SERVICE_URL"


def service_url() -> str | None:
    """URL base del servicio de OCR (env `OCR_SERVICE_URL`), o None si no está configurado."""
    url = (os.environ.get(OCR_ENV) or "").strip().rstrip("/")
    return url or None


def disponible() -> bool:
    """¿Hay un servicio de OCR configurado? (no comprueba conectividad — eso lo hace `convertir`)."""
    return service_url() is not None


def _timeout() -> float:
    try:
        return float(os.environ.get("OCR_TIMEOUT", "120"))
    except ValueError:
        return 120.0


def _post(url: str, payload: dict, timeout: float) -> dict:
    """POST JSON -> JSON (urllib). Aislado para poder monkeypatchearlo en tests."""
    data = json.dumps(payload).encode("utf-8")
    req = urllib.request.Request(
        url, data=data, headers={"Content-Type": "application/json"}, method="POST"
    )
    with urllib.request.urlopen(req, timeout=timeout) as resp:  # noqa: S310 (URL interna controlada)
        return json.loads(resp.read().decode("utf-8"))


def convertir(
    path: str | None = None,
    *,
    contenido: bytes | None = None,
    filename: str | None = None,
    document_id: str = "is200-ingesta",
    url: str | None = None,
    timeout: float | None = None,
) -> dict:
    """PDF (path o bytes) -> {disponible, markdown, tablas, paginas, backend, warnings, url}.

    NUNCA lanza: ante cualquier fallo (sin URL, timeout, 5xx, JSON inválido) devuelve
    `disponible=False` con el motivo, para que la ingesta degrade con gracia.
    """
    base = url or service_url()
    if not base:
        return {"disponible": False, "motivo": f"{OCR_ENV} no configurado", "markdown": "", "tablas": 0}
    if contenido is None:
        if not path:
            return {"disponible": False, "motivo": "sin contenido ni path", "markdown": "", "tablas": 0}
        try:
            with open(path, "rb") as fh:
                contenido = fh.read()
        except OSError as e:
            return {"disponible": False, "motivo": f"lectura: {e}", "markdown": "", "tablas": 0}
    fname = filename or (os.path.basename(path) if path else "documento.pdf")
    payload = {
        "document_id": document_id,
        "filename": fname,
        "content_base64": base64.b64encode(contenido).decode("ascii"),
        "output_format": "markdown",
    }
    try:
        body = _post(f"{base}/convert-document", payload, timeout or _timeout())
    except Exception as e:  # noqa: BLE001 — el OCR jamás debe tumbar la ingesta
        return {"disponible": False, "motivo": f"{type(e).__name__}: {e}", "markdown": "", "tablas": 0}
    if not isinstance(body, dict):
        return {"disponible": False, "motivo": "respuesta no-JSON", "markdown": "", "tablas": 0}
    md = body.get("markdown") or ""
    backend = body.get("backend") or "desconocido"
    if backend == "error":
        return {"disponible": False, "motivo": "; ".join(body.get("warnings") or ["error remoto"]),
                "markdown": "", "tablas": 0}
    resultado = {
        "disponible": True,
        "markdown": md,
        "tablas": int(body.get("tables_count") or 0),
        "paginas": int(body.get("pages_count") or 0),
        "backend": backend,
        "warnings": list(body.get("warnings") or []),
        "url": base,
    }
    # Representación común de la suite fiscal (parser-core): documento estructurado neutro.
    try:
        from parser_core.structured_document import from_convert_response
        resultado["documento"] = from_convert_response(resultado).to_dict()
    except Exception:  # noqa: BLE001 — el documento estructurado es un extra, no crítico
        pass
    return resultado
