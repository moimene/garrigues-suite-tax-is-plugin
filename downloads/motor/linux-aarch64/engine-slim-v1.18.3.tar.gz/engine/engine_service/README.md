# engine_service — el motor Python (cerebro canónico ADR-001) por servicio

Expone por REST/JSON los dos motores Python **reutilizando su código** (no reescribe la
lógica fiscal): el contable `Extractor-parseador/` (extracción SyS → casillas → mod200 XML
+ validación XSD) y el fiscal `suite-is/` (liquidación determinista). **El número que va al
XML y al gating lo FIRMA este servicio** (validado al céntimo en GIP 2024).

## Arranque

```bash
# 1) Instalar deps (incluye lectura .xls BIFF: python-calamine + xlrd)
python3 -m pip install -r engine_service/requirements.txt

# 2) Levantar el servicio (desde la raíz del repo)
uvicorn engine_service.app:app --reload --port 8000
#  -> http://localhost:8000/salud   y   /docs (OpenAPI)
```

## Endpoints

| Método | Ruta | Qué hace |
|---|---|---|
| GET  | `/salud`, `/version` | health / metadatos |
| POST | `/normalizar-sys` | SyS (multipart) → canónico 4d + cuadres (pipeline EPC) |
| POST | `/proyectar-contable` | canónico CSV → casillas contables + `00500` |
| POST | `/liquidar` | `facts`+`issues` → liquidación (BI, cuota) |
| POST | `/firmar` | `facts`+`issues` → **número firmado** + gating |
| POST | `/gating` | estado/issues → `exportable?` (rojo=0, amarillo_impacto=0, validada=sí) |
| POST | `/emitir-mod200` | canónico CSV → `mod200` XML + validación XSD (lxml) |
| POST | `/reconciliar` | preview(consola) vs firma(Python) → divergencias (**manda Python**) |
| GET  | `/explicar/{casilla}` | lineage cuenta→casilla→regla |
| POST | `/auditoria` | mayor/canónico → auditoría fiscal por criticidad (D11) |
| POST | `/ingesta` | cuentas → normalización PGC + cuadres + **tablas de salida** + revisión (D12/D14) |
| POST | `/ingesta-fichero` | fichero (SyS/mayor/**PDF**) → ingesta E2E; PDF escaneado → **OCR por HTTP** (D14) |

### OCR por servicio (Opción 1, D14)

`POST /ingesta-fichero` con un **PDF escaneado** (sin texto extraíble) llama por HTTP al parser IRPF
(`persona_tax`, Docling en Railway) vía `engine_service/ocr_client.py` → `POST /convert-document`. Se
configura con la env del **backend** `OCR_SERVICE_URL` (+ `OCR_TIMEOUT`, def. 120s). Sin servicio
configurado o ante fallo de red **degrada con gracia** (`pdf.necesita_ocr=true`); nunca tumba la ingesta.
La respuesta añade un bloque `ocr` (backend, tablas, páginas) y `tablas` (balance/PyG/agregado/cobertura).

## Oráculo de no-regresión (solo local)

El oráculo de no-regresión vive como **test local** (`test_service_anclas.py`), que lee datos reales
gitignored (**cifras de cliente, no se commitean**) y verifica que el contable y la firma siguen
byte-idénticos. No es un endpoint del API: corre solo en local y se salta en CI/clon limpio.

## Pruebas

```bash
python3 -m pytest engine_service/tests -q
# CI (sin datos reales): salud/version/seam/firmar/gating/reconciliar/liquidar.
# Local (datos reales presentes): oráculo de no-regresión §6 (2024).
```

## Despliegue en Railway (D2)

El servicio se empaqueta con el `Dockerfile` de la raíz del repo (incluye ambos motores; el
`.dockerignore` deja FUERA todos los datos de cliente). `railway.json` configura build (DOCKERFILE) +
healthcheck (`/salud`).

```bash
# Verificación local (requiere el daemon de Docker arrancado):
docker build -t suite-is-engine .
docker run --rm -p 8000:8000 suite-is-engine     # -> http://localhost:8000/salud
```

**Pasos del humano (externo):**
1. Crear proyecto en Railway y conectar el repo. Railway detecta `railway.json` → build con `Dockerfile`.
2. `PORT` lo inyecta Railway; CORS hoy es `*` (dev) — restringir al dominio de la web en prod.
3. La web (Vercel) → `VITE_ENGINE_URL` = URL pública del servicio en Railway.

**Confidencialidad:** la imagen NO contiene datos de cliente (`.dockerignore` excluye `GIP 2025/`,
`CLIENTES/`, `_local/`, `salidas/`, `**/tests/`, `*.xls`, `*.xlsx`, `*.msg`). El caso real corre solo en
local; en Railway el servicio recibe uploads efímeros (ingesta) sin persistir datos de cliente.
