"""Seam (Nivel 1, ADR-001): el resultado contable 00500 del EPC ES el input B2 de la liquidación.

Handoff determinista, SIN tecleo manual: la proyección contable del motor EPC
(`builder`) produce la casilla 00500 (resultado contable); aquí se mapea 1:1 al
input B2 del plugin de liquidación. El juicio fiscal (B4 ajustes, B5 art.21,
B7 BINs, B8 reserva, B9 DDI) NO es derivable del SyS: llega como issues validados.
"""
from decimal import Decimal, ROUND_HALF_UP


def cent(x) -> float:
    """Redondeo a 2 decimales (ROUND_HALF_UP), formato casilla."""
    return float(Decimal(str(x)).quantize(Decimal("0.01"), rounding=ROUND_HALF_UP))


def contable_a_inputs_liquidacion(proyeccion_contable: dict) -> dict:
    """EPC (casillas contables) -> inputs deterministas de liquidación.

    Args:
        proyeccion_contable: dict con clave "casillas" -> {"00500": float, ...}.

    Returns:
        dict con los inputs B* derivables del contable. B2 == casilla 00500.
    """
    casillas = proyeccion_contable["casillas"]
    return {
        "B2_resultado_contable": cent(casillas["00500"]),          # == 00500 (Art. 10 LIS)
        "B3_correccion_is_6300": cent(casillas.get("00301", 0.0)),  # informativa, no se suma
        "B10_retenciones_pagos": cent(casillas.get("00595", 0.0)),
        "_fuente": "EPC.builder->00500",
    }
