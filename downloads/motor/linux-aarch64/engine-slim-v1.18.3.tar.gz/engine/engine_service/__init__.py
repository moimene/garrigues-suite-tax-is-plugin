"""engine_service — el motor Python (cerebro canónico, ADR-001) expuesto por servicio.

Importar este paquete inserta en sys.path el repo-root y los `scripts/` de ambos
motores (contable `Extractor-parseador` y fiscal `suite-is`), de modo que los
adaptadores puedan REUTILIZAR el código existente sin reescribir la lógica fiscal.
"""
import os
import sys

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
_PATHS = [
    ROOT,
    os.path.join(ROOT, "Extractor-parseador", "scripts"),
    os.path.join(ROOT, "suite-is", "scripts"),
]
for _p in _PATHS:
    if _p not in sys.path:
        sys.path.insert(0, _p)

__all__ = ["ROOT"]
