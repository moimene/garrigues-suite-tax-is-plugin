"""Servicio FastAPI — el motor Python (cerebro canónico ADR-001) expuesto por REST/JSON.

Reutiliza el código de Extractor-parseador (contable) y suite-is (fiscal); no
reescribe la lógica. CORS abierto a la web (la consola consume vía VITE_ENGINE_URL).
El número que va al XML y al gating lo FIRMA este servicio (validado contra el oráculo de no-regresión).

Endpoints:
  GET  /salud /version
  POST /normalizar-sys        (multipart SyS) -> canónico + cuadres
  POST /proyectar-contable    (canónico CSV) -> casillas contables + 00500
  POST /liquidar              (facts+issues) -> liquidación
  POST /firmar                (facts+issues[+estado]) -> número firmado + gating
  POST /gating                (estado) -> exportable?
  POST /emitir-mod200         (canónico CSV) -> XML mod200 + validación XSD
  POST /reconciliar           (preview+firma) -> divergencias (manda Python)
  GET  /explicar/{casilla}    -> lineage cuenta->casilla->regla
"""
import json
import os
import tempfile

import engine_service  # noqa: F401  -- bootstrap de sys.path
from fastapi import Body, Depends, FastAPI, File, Form, Header, HTTPException, UploadFile
from fastapi.middleware.cors import CORSMiddleware

from engine_service import engines
from engine_service.seam import contable_a_inputs_liquidacion

app = FastAPI(title="Suite IS - Motor (cerebro Python canónico)", version="1.18.3")

# CORS restringido por env (gap#2): default = orígenes locales de dev. En deploy, fijar CORS_ORIGINS
# al dominio de la web (p.ej. https://suite-tax-is.vercel.app). '*' explícito solo si CORS_ORIGINS='*'.
_default_cors_origins = ",".join([
    "http://127.0.0.1:5173",
    "http://localhost:5173",
    "http://127.0.0.1:3000",
    "http://localhost:3000",
])
_origins = [
    o.strip()
    for o in os.environ.get("CORS_ORIGINS", _default_cors_origins).split(",")
    if o.strip()
]
app.add_middleware(
    CORSMiddleware,
    allow_origins=_origins,
    allow_credentials=False,
    allow_methods=["*"],
    allow_headers=["*"],
)


def _check_state_token(authorization: str = Header(default="")):
    """Gate de los endpoints de estado del expediente (gap#2). Si `ENGINE_STATE_TOKEN` está fijado
    (deploy), exige `Authorization: Bearer <token>`; si no está fijado (local/dev), se permite."""
    tok = os.environ.get("ENGINE_STATE_TOKEN", "").strip()
    if tok:
        provided = authorization.strip()
        if provided.lower().startswith("bearer "):
            provided = provided[7:].strip()
        if provided != tok:
            raise HTTPException(401, "Token de estado del expediente requerido o incorrecto.")


@app.get("/salud")
def salud():
    return {"ok": True, "servicio": "engine_service", "version": app.version}


@app.get("/version")
def version():
    return {
        "servicio": "engine_service",
        "version": app.version,
        "adr": "ADR-001",
        "ejercicio_foco": "2024",
    }


@app.post("/normalizar-sys")
async def normalizar_sys(ejercicio: str = "2024", fichero: UploadFile = File(...)):
    """SyS bruto -> canónico 4d + cuadres (pipeline EPC en dir temporal)."""
    suffix = os.path.splitext(fichero.filename or "")[1].lower()
    if suffix not in {".xls", ".xlsx", ".csv"}:
        raise HTTPException(422, "Extensión no permitida (use .xls / .xlsx / .csv).")
    with tempfile.TemporaryDirectory() as td:
        src = os.path.join(td, "sys" + suffix)
        with open(src, "wb") as fh:
            fh.write(await fichero.read())
        man = engines.run_pipeline([src], td, empresa="", ejercicio=ejercicio)
        etapa = man.get("etapas", {}).get("motor_sys", {})
        return {
            "estado": man.get("estado"),
            "motor_sys": etapa,
            "builder": man.get("etapas", {}).get("builder", {}),
        }


@app.post("/proyectar-contable")
def proyectar_contable(payload: dict = Body(...)):
    """Canónico 4d (texto CSV en 'canonico_csv') -> casillas contables + resultado 00500."""
    csv_text = payload.get("canonico_csv")
    ejercicio = str(payload.get("ejercicio", "2024"))
    if not csv_text:
        raise HTTPException(422, "Falta 'canonico_csv' (texto CSV del canónico 4d).")
    # Gate HITL server-side (Codex HIGH T1.2): el resultado 00500 puede alimentar /firmar; un canónico
    # inferido de CCAA sin confirmar (is True estricto) -> 422 (no se devuelve número proyectable).
    with tempfile.TemporaryDirectory() as td:
        path = os.path.join(td, "canonico.csv")
        with open(path, "w", encoding="utf-8") as fh:
            fh.write(csv_text)
        try:
            res = engines.proyectar_contable(
                path, ejercicio,
                fuente_canonico=payload.get("fuente_canonico"),
                a3_confirmado=payload.get("a3_confirmado") is True)
        except engines.ConfirmacionHitlRequerida as e:
            raise HTTPException(422, str(e))
        except engines.CanonicoDescuadradoError as e:   # B3: descuadre no proyecta 00500 firmable
            raise HTTPException(422, str(e))
    return {"casillas": res["casillas"], "cuadre": res["cuadre"], "resultado_00500": res["casillas"].get("00500")}


def _resolver_envelope(payload: dict):
    """Normalización ÚNICA del envelope (regimen/ejercicio) para /liquidar, /liquidar-orquestado y
    /firmar (Codex HIGH: las 3 rutas deben coincidir). El envelope tiene PRECEDENCIA sobre facts; un
    conflicto envelope≠facts -> 422 FAIL-CLOSED. Los valores vacíos/blancos se tratan como AUSENTES y el
    ejercicio canónico (no vacío) se ESCRIBE en facts para que /liquidar (que sólo consume facts) no
    diverja de /firmar ante un `ejercicio` en blanco (formulario vacío)."""
    def _limpio(v):
        return v if (v is not None and str(v).strip() != "") else None
    facts = dict(payload.get("facts") or {})
    for clave in ("regimen", "ejercicio"):
        env = _limpio(payload.get(clave))
        dato = _limpio(facts.get(clave))
        if env is not None and dato is not None and str(env).strip().lower() != str(dato).strip().lower():
            raise HTTPException(
                422, f"Conflicto en '{clave}': envelope={env!r} vs facts={dato!r}. Envía un único valor coherente.")
        val = env if env is not None else dato
        if val is not None:
            facts[clave] = val
        else:
            facts.pop(clave, None)   # ausente/vacío -> que el motor use su default (regimen->general)
    facts["ejercicio"] = str(facts.get("ejercicio") or "2024")   # canónico NO vacío, escrito en facts
    # Fail-closed (Codex HIGH): régimen especial SIN tipo explícito y SIN matriz de tipos para el
    # ejercicio -> no se firma/liquida (no inventar 0,25). p.ej. SOCIMI 2025 sin rules/parametros/2025.yaml.
    reg = facts.get("regimen")
    if reg and not engines.tipo_disponible(reg, facts["ejercicio"]):
        # Aunque venga tipo EXPLÍCITO (incl. 0): sin matriz de tipos del ejercicio no se puede VALIDAR
        # (M4 = SIN_DATOS) -> no se firma (Codex HIGH: SOCIMI/PYMES 2025 con tipo 0 firmaban cuota 0 exportable).
        raise HTTPException(
            422, f"No hay matriz de tipos para régimen {reg!r} en {facts['ejercicio']} "
                 f"(falta rules/parametros/{facts['ejercicio']}.yaml): campaña no soportada, no se firma.")
    # Guarda carácter↔régimen (fiscal, Garrigues 2026-06-22): si la declaración trae un carácter de régimen
    # especial (00006/00088/00012/00004) pero el régimen no es ese, no se firma como general/ETVE. `caracteres`
    # es OPCIONAL en el envelope: las rutas que no lo envían (p.ej. la preview de B1) no se ven afectadas.
    caracteres = payload.get("caracteres")
    if caracteres:
        try:
            engines.coherencia_caracter_regimen(caracteres, facts.get("regimen"), facts["ejercicio"])
        except engines.CaracterRegimenIncoherente as e:
            raise HTTPException(422, str(e))
    return facts, facts.get("regimen"), facts["ejercicio"]


@app.post("/liquidar")
def liquidar(payload: dict = Body(...)):
    """facts + issues validados -> casillas de liquidación + BI + cuota. Envelope normalizado (Codex)."""
    facts, _regimen, _ejercicio = _resolver_envelope(payload)
    return engines.liquidar(facts, payload.get("issues", []))


@app.post("/firmar")
def firmar(payload: dict = Body(...)):
    """El motor Python FIRMA: liquidación + gating. Es la autoridad del número.

    Seam T1.1.3: firma por el ORQUESTADOR canónico (no el plugin plano). /liquidar conserva la ruta
    plugin como red de coherencia (test calcular↔calcular_casillas). La firma incluye traza + lineage.
    """
    facts, regimen, ejercicio = _resolver_envelope(payload)
    issues = payload.get("issues", [])
    orq = engines.liquidar_orquestado(facts, issues, ejercicio, regimen)
    firma = engines.firma_desde_orquestado(orq)
    estado = payload.get("estado") or engines.estado_desde_issues(issues, validada=payload.get("validada", True))
    # Codex HIGH: las validaciones del orquestador (M4) deben GATEAR la firma, no sólo observarse.
    estado = engines.combinar_estado_con_validaciones(
        estado, (orq.get("validaciones") or {}).get("issues", []), apto=orq.get("apto_para_firma", True))
    return {"firma": firma, "gating": engines.gating(estado), "estado": estado}


@app.post("/liquidar-orquestado")
def liquidar_orquestado(payload: dict = Body(...)):
    """facts + issues -> liquidación por el ORQUESTADOR canónico: casillas + lineage (cadena + ref
    normativa) + traza + reglas activas por régimen (incl. ETVE) + apto_para_firma. Seam T1.1: no
    duplica /liquidar (que conserva la ruta plugin como red)."""
    facts, regimen, ejercicio = _resolver_envelope(payload)
    return engines.liquidar_orquestado(facts, payload.get("issues", []), ejercicio, regimen)


@app.post("/triaje")
def triaje(payload: dict = Body(...)):
    """Triaje art.15 de una partida: letra/nivel/casilla (autopoblar/proponer) o incidencia
    estructurada (criticidad normalizada bloqueante/a_confirmar + motivo_duda + opciones_resolucion)."""
    return engines.triaje(payload.get("partida", payload))


@app.post("/gating")
def gating(payload: dict = Body(...)):
    """Gating duro a partir del estado (semáforos) o de los issues."""
    estado = payload.get("estado")
    if estado is None and "issues" in payload:
        estado = engines.estado_desde_issues(payload["issues"], validada=payload.get("validada", True))
    return engines.gating(estado or {})


@app.post("/emitir-mod200")
def emitir_mod200(payload: dict = Body(...)):
    """Canónico CSV -> mod200 XML + validación XSD (lxml). Solo se ship­ea si valido_xsd."""
    csv_text = payload.get("canonico_csv")
    ejercicio = str(payload.get("ejercicio", "2024"))
    empresa = payload.get("empresa", "")
    if not csv_text:
        raise HTTPException(422, "Falta 'canonico_csv'.")
    # Gate HITL server-side (Codex HIGH T1.2): provenance + confirmación ESTRICTA (is True; 'false'/'0' no
    # confirman). Si el canónico es inferido de CCAA sin confirmar -> 422 (no se devuelve XML).
    with tempfile.TemporaryDirectory() as td:
        path = os.path.join(td, "canonico.csv")
        with open(path, "w", encoding="utf-8") as fh:
            fh.write(csv_text)
        try:
            res = engines.emitir_mod200(
                path, td, empresa=empresa, ejercicio=ejercicio,
                fuente_canonico=payload.get("fuente_canonico"),
                a3_confirmado=payload.get("a3_confirmado") is True,
                perfil_estados_abreviado=payload.get("perfil_estados_abreviado") or None,
                perfil_estados_pymes=payload.get("perfil_estados_pymes") or None)
        except engines.ConfirmacionHitlRequerida as e:
            raise HTTPException(422, str(e))
        except engines.CanonicoDescuadradoError as e:   # B3: canónico descuadrado no firma el XML
            raise HTTPException(422, str(e))
    return {
        "valido_xsd": res["valido_xsd"],
        "xsd_estado": res["validacion"].get("xsd"),
        "n_casillas": res["validacion"].get("n"),
        "n_casillas_contables": res["n_casillas_contables"],
        "xml": res["xml"],
    }


@app.post("/validar-contable")
def validar_contable(payload: dict = Body(...)):
    """Fase A (Epic 3): canónico CSV -> informe 'apto para importar' (identidades + formato DR200).

    Es el gate PREVIO al XSD del importador de datos contables (D13): valida el balance
    (00180=00252), que el resultado exista y el formato de las casillas. NO emite la liquidación.
    """
    csv_text = payload.get("canonico_csv")
    if not csv_text:
        raise HTTPException(422, "Falta 'canonico_csv' (texto CSV del canónico 4d).")
    with tempfile.TemporaryDirectory() as td:
        path = os.path.join(td, "canonico.csv")
        with open(path, "w", encoding="utf-8") as fh:
            fh.write(csv_text)
        return engines.validar_contable(
            path, tipo_entidad=payload.get("tipo_entidad", "normal"),
            ejercicio=str(payload.get("ejercicio", "2024")),
            # Gate HITL (Codex HIGH T1.2): redacta el 00500 si el canónico es inferido y no se confirma
            # (is True estricto). No bloquea: el front usa esta ruta para el preview del CCAA.
            fuente_canonico=payload.get("fuente_canonico"),
            a3_confirmado=payload.get("a3_confirmado") is True,
        )


@app.post("/fase-a-sys")
async def fase_a_sys(ejercicio: str = "2024", tipo_entidad: str = "normal", fichero: UploadFile = File(...)):
    """SyS (multipart) -> Fase A 'apto para importar' (W6): proyecta el SyS y valida el balance
    (00180=00252) + formato. Es el cuadre FUERTE del paso 1 del expediente (además del Σdebe=Σhaber)."""
    suffix = os.path.splitext(fichero.filename or "")[1].lower()
    if suffix not in {".xls", ".xlsx", ".csv"}:
        raise HTTPException(422, "Extensión no permitida (use .xls / .xlsx / .csv).")
    with tempfile.TemporaryDirectory() as td:
        src = os.path.join(td, "sys" + suffix)
        with open(src, "wb") as fh:
            fh.write(await fichero.read())
        return engines.fase_a_desde_sys(src, tipo_entidad=tipo_entidad, ejercicio=ejercicio)


@app.post("/generar-sys-a3")
async def generar_sys_a3(ejercicio: str = "2024", fichero: UploadFile = File(...)):
    """CCAA (PDF/texto, multipart) -> SyS A3 determinista (CASO B del paso 1). Inferencia con HITL: mapea
    las partidas al PGC mínimo, cuadra y SÓLO si apto emite el canónico 4d (que alimenta la Fase A igual
    que el SyS). No persiste el fichero (temp dir; puede contener datos de cliente)."""
    suffix = os.path.splitext(fichero.filename or "")[1].lower()
    with tempfile.TemporaryDirectory() as td:
        src = os.path.join(td, "ccaa" + (suffix or ".pdf"))
        with open(src, "wb") as fh:
            fh.write(await fichero.read())
        return engines.generar_sys_a3(src, ejercicio=ejercicio)


@app.post("/reconciliar")
def reconciliar(payload: dict = Body(...)):
    """preview (consola) vs firma (Python) -> divergencias casilla a casilla. Manda Python."""
    return engines.reconciliar(payload.get("preview", {}), payload.get("firma", {}))


@app.get("/explicar/{casilla}")
def explicar(casilla: str, ejercicio: str = "2024", regimen: str = "general"):
    """Lineage cuenta->casilla->regla (PGC) + cadena fiscal con FUNDAMENTO normativo (ref LIS/RIS)."""
    return engines.explicar(casilla, ejercicio, regimen)


@app.get("/reglas-activas")
def reglas_activas(ejercicio: str = "2024", regimen: str = "general"):
    """Espejo READ-ONLY de las reglas Python (catálogo validado) para admin/rulesets (T1.4.5, ADR-002)."""
    return engines.reglas_espejo(ejercicio, regimen)


@app.get("/expediente/pasos")
def expediente_pasos():
    """El recorrido de 7 pasos (1 declaración = 1 expediente) + checkpoints humanos.

    Es el plano del stepper de la consola (spec §3). Lógica pura, sin datos de cliente.
    """
    return engines.expediente_pasos()


@app.post("/expediente/siguiente")
def expediente_siguiente(payload: dict = Body(...)):
    """paso_actual -> siguiente acción del recorrido (marca los 2 checkpoints humanos)."""
    return engines.expediente_siguiente(payload.get("paso_actual", 0))


@app.post("/expediente/recomputo")
def expediente_recomputo(payload: dict = Body(...)):
    """Marcha atrás/enriquecer (spec §3): al modificar un paso, qué rehacer + entregables obsoletos."""
    return engines.expediente_recomputo(payload.get("paso_modificado", 0))


@app.get("/expediente/estado/{eid}")
def expediente_estado_get(eid: str, _=Depends(_check_state_token)):
    """Lee el estado persistido del expediente (carpeta-estado, W8). {existe:false} si no hay.

    Protegido por token si `ENGINE_STATE_TOKEN` está fijado (gap#2). Es el almacén DEMO/local; en
    producción la persistencia real va por Supabase con sesión autenticada (no por esta ruta).
    """
    return engines.cargar_estado(eid)


@app.put("/expediente/estado/{eid}")
def expediente_estado_put(eid: str, payload: dict = Body(...), _=Depends(_check_state_token)):
    """Persiste el estado del expediente (harness JSON) en la carpeta-estado local (gitignored)."""
    estado = payload.get("estado", payload)
    return engines.guardar_estado(eid, estado)


@app.post("/expediente/paquete")
def expediente_paquete(payload: dict = Body(...)):
    """Paso 5 (Entregables): genera el paquete (A3 + carta + memoria/liquidación/Modelo 200) y lo
    devuelve en base64. Acepta los bloques WF-1/WF-2 y la tabla SyS como TEXTO (mismo contrato que el
    copiloto/Power App: JSON-in/JSON-out). El motor 'se construye una vez'."""
    return engines.generar_paquete(
        nif=payload.get("nif", "DEMO"),
        ejercicio=str(payload.get("ejercicio", "2025")),
        sys_tabla1=payload.get("sys_tabla1"),
        bloque_wf1=payload.get("bloque_wf1"),
        bloque_wf2=payload.get("bloque_wf2"),
        canonico_csv=payload.get("canonico_csv"),
        # Gate HITL server-side (Codex HIGH T1.2): provenance del canónico + confirmación ESTRICTA del A3
        # inferido (is True; 'false'/'0'/strings NO confirman — bool('false') sería True en Python).
        fuente_canonico=payload.get("fuente_canonico"),
        a3_confirmado=payload.get("a3_confirmado") is True,
        # Precarga del año anterior (U2/U4): formales (Capa 2) + caracteres/página 1B (Capa 1) → `.200` del
        # cierre. Aditivo (None por defecto): un cierre sin precarga emite igual que antes (GIP/demo intacto).
        formales=payload.get("formales") or None,
        caracteres=payload.get("caracteres") or None,
        pagina01b=payload.get("pagina01b") or None,
    )


@app.post("/auditoria")
def auditoria(payload: dict = Body(...)):
    """Ruta de análisis SEPARADA (D11): un mayor/canónico -> auditoría de la situación fiscal.

    El motor avanzado de reglas detecta (determinista, por patrón de cuenta PGC) las situaciones que
    disparan revisión fiscal y devuelve hallazgos por criticidad (🔴🟡🟢⚪) con cuenta(s), importe y
    fundamento LIS. NO es la declaración: es la auditoría de toda la situación.
    """
    canonico = payload.get("canonico")
    if not canonico:
        raise HTTPException(422, "Falta 'canonico' (lista de cuentas {cuenta, sf, debe, haber}).")
    return engines.auditar(
        canonico, ejercicio=str(payload.get("ejercicio", "2024")), regimen=payload.get("regimen", "general")
    )


@app.post("/auditoria-mayores")
async def auditoria_mayores(
    umbral: float = 0.95,
    ejercicio: str = "2024",
    regimen: str = "general",
    ficheros: list[UploadFile] = File(...),
):
    """Sube MAYORES (.xls/.xlsx/.csv) -> canónico (ingesta de precisión Fase 3) -> AUDITORÍA del catálogo
    completo (Fase 4 / C1). Ruta SEPARADA y read-only (D11): NO firma número, NO emite XML, NO toca gating.
    Devuelve {auditoria, ingesta, fuente}: hallazgos por criticidad (🔴🟡🟢⚪) con cuenta/importe/fundamento
    (art. LIS)/acción + un resumen de calidad/provenance de la ingesta."""
    if not ficheros:
        raise HTTPException(422, "Adjunta al menos un mayor.")
    with tempfile.TemporaryDirectory() as td:
        paths = []
        for i, f in enumerate(ficheros):
            suffix = _suffix_ingesta(f.filename)
            sub = os.path.join(td, str(i))
            os.makedirs(sub, exist_ok=True)
            src = os.path.join(sub, _nombre_seguro(f.filename, suffix))
            with open(src, "wb") as fh:
                fh.write(await f.read())
            paths.append(src)
        return engines.auditar_mayores(paths, ejercicio=str(ejercicio), regimen=regimen, umbral=umbral)


@app.post("/auditoria-propuestas")
def auditoria_propuestas(payload: dict = Body(...)):
    """Auditoria -> propuestas de ajuste para el cuestionario. No firma ni liquida."""
    aud = payload.get("auditoria", payload)
    return {"propuestas": engines.hallazgos_a_issues(aud)}


@app.post("/gf-criterio")
def gf_criterio(payload: dict = Body(...)):
    """Criterio de gastos financieros (art.16 LIS) por opcion leniente/estricto + delta del 00363, para que
    el cuestionario pinte ambas cuotas. No firma: el 00363 elegido entra como diferencias_permanentes (+) en
    /liquidar-orquestado (el motor firma, ADR-001)."""
    return engines.gf_criterio(payload)


@app.post("/auditoria-informe")
def auditoria_informe(payload: dict = Body(...)):
    """Memoria de auditoría EXPORTABLE (.docx branded Garrigues) — Fase 4 / C4, ruta read-only. Acepta el
    resultado de la auditoría en `auditoria` (lo que devuelve /auditoria o /auditoria-mayores.auditoria), o
    un `canonico` para auditar al vuelo. Devuelve {fichero, mime, base64} del documento Word."""
    aud = payload.get("auditoria")
    if aud is None:
        canonico = payload.get("canonico")
        if not canonico:
            raise HTTPException(422, "Falta 'auditoria' (resultado) o 'canonico' (lista de cuentas).")
        aud = engines.auditar(
            canonico, ejercicio=str(payload.get("ejercicio", "2024")), regimen=payload.get("regimen", "general"))
    return engines.auditoria_informe(aud, nif=payload.get("nif", ""), ejercicio=str(payload.get("ejercicio", "2024")))


@app.get("/auditoria-checklist")
def auditoria_checklist():
    """Checklist de revisión MANUAL del IS (Fase 4): los puntos del DD que el motor NO auto-detecta
    (necesitan Diario/NIF/fechas/juicio) — para que el abogado los recorra. Read-only, datos estáticos."""
    return engines.auditoria_checklist()


@app.post("/juez-normativo")
def juez_normativo(payload: dict = Body(...)):
    """Capa LLM 'juez normativo' (seam SDB) — RUTA SEPARADA y READ-ONLY (D11/ADR-001/002): NO firma número,
    NO emite XML, NO toca gating/builder. El LLM PROPONE un IracOutput (Issue/Rule/Application/Conclusion +
    Confidence + Citation con gate de 4 estados) sobre la cola de revisión humana; el colegiado valida y
    firma. Acepta {hallazgo:{...}} (un hallazgo) o {auditoria:{...}} (resultado de /auditoria; recorre su
    cola requiere_revision_humana). En J0 el reasoner es un stub determinista (sin proveedor LLM real)."""
    tiene_hallazgo = isinstance(payload.get("hallazgo"), dict)
    tiene_aud = isinstance(payload.get("auditoria"), dict)
    if not (tiene_hallazgo or tiene_aud):
        raise HTTPException(422, "Falta 'hallazgo' (un hallazgo) o 'auditoria' (resultado de /auditoria con su cola).")
    try:
        return engines.juez_normativo(payload, ejercicio=str(payload.get("ejercicio", "2024")))
    except HTTPException:
        raise
    except Exception as e:  # noqa: BLE001 — entrada basura no debe tumbar el servicio (defensa en profundidad)
        raise HTTPException(422, f"juez-normativo: {type(e).__name__}: {e}")


@app.post("/ingesta")
def ingesta(payload: dict = Body(...)):
    """Ingesta de datos contables de MÁXIMA PRECISIÓN (EPIC B / D12).

    Normaliza las cuentas al PGC oficial (exacto→prefijo→fuzzy→grupo + confianza), reconcilia (cuadre
    debe=haber) y arma la cola de revisión (HITL). Es el harness que alimenta la **Fase A** (importador
    de datos contables) con datos limpios; `exportable_a_importador` indica si están listos.
    """
    cuentas = payload.get("cuentas")
    if not cuentas:
        raise HTTPException(422, "Falta 'cuentas' (lista {cuenta, denom, debe, haber}).")
    return engines.ingesta(cuentas, umbral=float(payload.get("umbral", 0.95)))


def _json_dict_opt(raw: str, nombre: str):
    """Parsea un parámetro JSON OPCIONAL que debe ser un objeto {clave: valor}; None si viene vacío.
    422 controlado si el JSON es inválido o no es un objeto (no romper con un 500)."""
    if not (raw or "").strip():
        return None
    try:
        val = json.loads(raw)
        if not isinstance(val, dict):
            raise ValueError(f"{nombre} debe ser un objeto JSON")
        return val
    except (ValueError, TypeError) as e:
        raise HTTPException(422, f"Parámetro '{nombre}' inválido (JSON): {e}")


_SUFIJOS_INGESTA = {".xls", ".xlsx", ".csv", ".pdf"}


def _suffix_ingesta(filename: str):
    suffix = os.path.splitext(filename or "")[1].lower()
    if suffix not in _SUFIJOS_INGESTA:
        raise HTTPException(422, "Extensión no permitida (use .xls / .xlsx / .csv / .pdf).")
    return suffix


def _nombre_seguro(filename: str, suffix: str) -> str:
    """Nombre de fichero seguro para el provenance: conserva el NOMBRE ORIGINAL (la cola HITL traza a
    `fichero:fila`, no a un 'in.csv' interno) pero saneado: normaliza separadores '\\'->'/', toma el
    basename (sin traversal), exige el suffix validado y CAPA la longitud (un basename > NAME_MAX reventaba
    open() con OSError -> 500). Fallback seguro 'in'+suffix."""
    raw = os.path.basename((filename or "").replace("\\", "/"))
    nombre = raw if (raw and raw not in (".", "..") and raw.lower().endswith(suffix)) else ("in" + suffix)
    if len(nombre) > 120:                              # cap < NAME_MAX(255); conserva el sufijo legible
        nombre = nombre[: 120 - len(suffix)] + suffix
    return nombre


@app.post("/ingesta-fichero")
async def ingesta_fichero(umbral: float = 0.95, fichero: UploadFile = File(...)):
    """Sube un SyS/mayor (.xls/.xlsx/.csv) -> ingesta de precisión END-TO-END: extraer (provenance) +
    normalizar al PGC (confianza) + cuadres + cola de revisión. Alimenta la Fase A del importador."""
    suffix = _suffix_ingesta(fichero.filename)
    with tempfile.TemporaryDirectory() as td:
        src = os.path.join(td, _nombre_seguro(fichero.filename, suffix))
        with open(src, "wb") as fh:
            fh.write(await fichero.read())
        return engines.ingesta_fichero(src, umbral=umbral)


@app.post("/ingesta-multi")
async def ingesta_multi(umbral: float = 0.95, ficheros: list[UploadFile] = File(...)):
    """Sube VARIOS ficheros (SyS + mayores) -> ingesta de lote (EPIC B / B5): cada uno se extrae+normaliza,
    los mayores se validan por su identidad por línea (SI+debe−haber=SF) y se RECONCILIAN contra el SyS por
    familia de cuenta (agrupación simétrica por prefijo, tol=0). `exportable_conjunto` exige todo limpio + sin deltas."""
    if not ficheros:
        raise HTTPException(422, "Adjunta al menos un fichero.")
    with tempfile.TemporaryDirectory() as td:
        paths = []
        for i, f in enumerate(ficheros):
            suffix = _suffix_ingesta(f.filename)
            # Cada fichero en su propio subdir: nombres duplicados no se pisan y el provenance conserva el real.
            sub = os.path.join(td, str(i))
            os.makedirs(sub, exist_ok=True)
            src = os.path.join(sub, _nombre_seguro(f.filename, suffix))
            with open(src, "wb") as fh:
                fh.write(await f.read())
            paths.append(src)
        return engines.ingesta_multi(paths, umbral=umbral)


@app.post("/precarga-anterior")
async def precarga_anterior(ejercicio: str = "2024", tipo: str = "auto", fichero: UploadFile = File(...)):
    """Sube la declaración/datos del AÑO ANTERIOR → precarga Capa 1 (caracteres + página 1B) + Capa 2
    (formales) + inputs de liquidación (carga asistida; NO autofirmados). Auto-detecta el nivel (A `.200`
    previo · B justificante PDF · C datos-fiscales PDF), o fuérzalo con `tipo`. PDF escaneado → `necesita_ocr`.
    Aditivo (U2): NO toca el cálculo; el resultado lo PINTA la consola y alimenta el `.200` tras revisión."""
    suffix = os.path.splitext(fichero.filename or "")[1].lower()
    if suffix not in {".200", ".txt", ".md", ".pdf"}:
        raise HTTPException(422, "Sube el `.200` previo, el justificante PDF o el datos-fiscales PDF/texto.")
    with tempfile.TemporaryDirectory() as td:
        src = os.path.join(td, _nombre_seguro(fichero.filename, suffix))
        with open(src, "wb") as fh:
            fh.write(await fichero.read())
        try:
            return engines.precarga_anterior(src, ejercicio=str(ejercicio), tipo=tipo)
        except Exception as e:   # noqa: BLE001  fichero ilegible/plantilla distinta -> 422 controlado
            raise HTTPException(422, f"No se pudo precargar la declaración anterior: {e}")


@app.post("/resolver-contable")
async def resolver_contable(ejercicio: str = "2024", fichero: UploadFile = File(...)):
    """Sube un TB de ERP de GRUPO (plan de cuentas propio ≠ PGC) → canónico que cuadra + LINEAGE HITL por
    cuenta (PGC resuelto · método · confianza; <0,7 = revisar) + Fase A. Modo CARGA ASISTIDA (U1): el resolver
    mapea best-effort el 100% y el profesional revisa el lineage. Pre-motor (no toca dr200/builder; GIP intacto)."""
    suffix = os.path.splitext(fichero.filename or "")[1].lower()
    if suffix not in {".xls", ".xlsx", ".csv"}:
        raise HTTPException(422, "Sube el TB de grupo (.xls / .xlsx / .csv).")
    with tempfile.TemporaryDirectory() as td:
        src = os.path.join(td, _nombre_seguro(fichero.filename, suffix))
        with open(src, "wb") as fh:
            fh.write(await fichero.read())
        try:
            return engines.resolver_contable_grupo_tb(src, ejercicio=str(ejercicio))
        except Exception as e:   # noqa: BLE001  TB ilegible/cabecera no detectada -> 422 controlado
            raise HTTPException(422, f"No se pudo resolver el TB de grupo: {e}")


@app.post("/datos-formales")
async def datos_formales(sheet: str = "", fichero: UploadFile = File(...)):
    """Sube el XLS de DATOS FORMALES → extrae {administradores, socios, titulares_reales, secretario,
    representantes, participadas} listos para `formales` de /exportar-aeat (para que el abogado no pegue
    JSON). `sheet` opcional (por defecto 'GIP' si existe, si no la primera hoja). Devuelve también avisos
    de revisión. Los datos son del cliente: se devuelven al navegador del abogado, no se persisten."""
    suffix = os.path.splitext(fichero.filename or "")[1].lower()
    if suffix not in {".xls", ".xlsx"}:
        raise HTTPException(422, "Sube el XLS de datos formales (.xls/.xlsx)")
    with tempfile.TemporaryDirectory() as td:
        src = os.path.join(td, _nombre_seguro(fichero.filename, suffix))
        with open(src, "wb") as fh:
            fh.write(await fichero.read())
        try:
            return engines.datos_formales(src, sheet=sheet or None)
        except Exception as e:   # noqa: BLE001  XLS ilegible/plantilla distinta -> 422 controlado
            raise HTTPException(422, f"No se pudieron extraer los datos formales: {e}")


@app.post("/exportar-aeat")
async def exportar_aeat(ejercicio: str = "2024", nif: str = "", razon_social: str = "",
                        liquidacion: str = "", formales: str = "", caracteres: str = "",
                        pagina01b: str = "", liquidacion_base: bool = False,
                        ejercicio_form: str = Form(default="", alias="ejercicio"),
                        fichero: UploadFile = File(...)):
    """Sube un SyS/mayor → ficheros de IMPORTACIÓN AEAT DIRECTA (D20): XML mod200 validado contra el XSD
    oficial (primario) + XLS de estados contables + registro DR de la declaración (identificativos +
    contable [+ liquidación si se aporta], PROVISIONAL: sin XSD, validar con import real) + A3 (agrupado_4d)
    secundario, en base64. `nif`/`razon_social` rellenan los identificativos del DR; `liquidacion` (JSON
    {casilla: importe} del cierre firmado, opcional) completa el DR con BI/cuota (5.B). Fail-closed (gates
    B3): un SyS descuadrado / sin balance AEAT válido NO emite el XML (ok=False). El resultado avisa de las
    casillas que dependen de otros modelos (202/242/216) y están a cero."""
    # DEFENSA: `ejercicio` es un QUERY param. Si un cliente lo manda como campo de FORMULARIO (multipart) y NO
    # por query, antes se ignoraba en silencio -> default 2024 (un SyS 2025 descuadraba). Si llega por form y la
    # query sigue en el default, respétalo. La query manda siempre que se aporte explícitamente.
    if ejercicio_form.strip() and ejercicio == "2024":
        ejercicio = ejercicio_form.strip()
    suffix = _suffix_ingesta(fichero.filename)
    liq = None
    if liquidacion.strip():
        try:
            liq = json.loads(liquidacion)
            if not isinstance(liq, dict):
                raise ValueError("liquidacion debe ser un objeto {casilla: importe}")
        except (ValueError, TypeError) as e:
            raise HTTPException(422, f"Parámetro 'liquidacion' inválido (JSON {{casilla: importe}}): {e}")
    fmt = None
    if formales.strip():
        try:
            fmt = json.loads(formales)
            if not isinstance(fmt, dict):
                raise ValueError("formales debe ser un objeto (administradores/socios/titulares_reales/…)")
        except (ValueError, TypeError) as e:
            raise HTTPException(422, f"Parámetro 'formales' inválido (JSON): {e}")
    # Capa 1 de la precarga (U2): caracteres (DP200001) + página 1B (DP200001B). Opcionales (JSON dict).
    car = _json_dict_opt(caracteres, "caracteres")
    p01b = _json_dict_opt(pagina01b, "pagina01b")
    with tempfile.TemporaryDirectory() as td:
        src = os.path.join(td, _nombre_seguro(fichero.filename, suffix))
        with open(src, "wb") as fh:
            fh.write(await fichero.read())
        try:
            return engines.exportar_aeat(src, ejercicio=ejercicio, nif=nif, razon_social=razon_social,
                                         liquidacion=liq, formales=fmt, caracteres=car, pagina01b=p01b,
                                         liquidacion_base=liquidacion_base)
        except engines.CanonicoDescuadradoError as e:   # B3 (defensa; pipeline ya lo captura a 'revisar')
            raise HTTPException(422, str(e))
        except Exception as e:   # noqa: BLE001  fichero ilegible/corrupto -> 422 controlado, nunca 500
            raise HTTPException(422, f"No se pudo exportar a AEAT: {e}")


@app.post("/expediente/export-base")
def expediente_export_base(payload: dict = Body(...)):
    """Expediente v1 sin Harvey: estado persistido/canonico -> XML contable + .200 provisional.

    `precarga_n1` (OPT-IN): dict `precarga` N-1 ya extraído (de /precarga-anterior Nivel A) o None. Aditiva;
    None = comportamiento idéntico (golden-safe). Inyecta identificativos + mercantil del N-1, marcado HITL."""
    return engines.exportar_base(
        canonico_csv=payload.get("canonico_csv"),
        ejercicio=str(payload.get("ejercicio", "2025")),
        nif=payload.get("nif", ""),
        razon_social=payload.get("razon_social", ""),
        liquidacion_provisional=payload.get("liquidacion_provisional") or None,
        formales=payload.get("formales") or None,
        caracteres=payload.get("caracteres") or None,
        pagina01b=payload.get("pagina01b") or None,
        fuente_canonico=payload.get("fuente_canonico"),
        a3_confirmado=payload.get("a3_confirmado") is True,
        necesita_ocr=payload.get("necesita_ocr") is True,
        cnae=payload.get("cnae") or None,
        precarga_n1=payload.get("precarga_n1") or None,
        ecpn_ccaa_texto=payload.get("ecpn_ccaa_texto") or None,   # texto del Balance de la CCAA → apertura ECPN
        perfil_estados_abreviado=payload.get("perfil_estados_abreviado") or None,
        perfil_estados_pymes=payload.get("perfil_estados_pymes") or None,
        contable_casillas=payload.get("contable_casillas") or None,
    )


@app.get("/campaigns")
def campaigns_list():
    """Lista las campañas (ejercicios) dadas de alta — admin/versionado por ejercicio."""
    return engines.campanas_listar()


@app.get("/campaigns/diff")
def campaigns_diff(a: str, b: str):
    """Diferencias de casillas importables entre dos campañas (nuevas/eliminadas por página)."""
    try:
        return engines.campana_diff(a, b)
    except (ValueError, SystemExit) as e:
        raise HTTPException(422, str(e))


@app.post("/campaigns/onboard")
async def campaigns_onboard(ejercicio: str, base: str = "", xsd: UploadFile = File(...)):
    """Da de alta una campaña desde el XSD OFICIAL AEAT del ejercicio: parsea casillas + subesquema, copia
    el mapeo de la campaña base y emite el informe de diffs (casillas nuevas / reglas huérfanas)."""
    if os.path.splitext(xsd.filename or "")[1].lower() != ".xsd":
        raise HTTPException(422, "Sube el XSD oficial (.xsd) del ejercicio.")
    with tempfile.TemporaryDirectory() as td:
        src = os.path.join(td, _nombre_seguro(xsd.filename, ".xsd"))
        with open(src, "wb") as fh:
            fh.write(await xsd.read())
        try:
            return engines.campana_onboard(ejercicio, src, base=base or None)
        except (ValueError, SystemExit) as e:
            raise HTTPException(422, str(e))
