#!/usr/bin/env python3
"""Extrae la SyS de cierre 31/12/2024 a engine_service/_local/ para el caso 2024 depurado (D8).

La SyS 2024 está EMBEBIDA en la Liquidación IS 2024 (hoja `SyS (31.12.24)`). Este script la
copia a `engine_service/_local/gip_2024_sys.xlsx` (gitignored) para que `/caso/gip2024` la use.
NO commitea datos: lee y escribe SOLO rutas gitignored (los datos reales quedan fuera de git).

Uso:  python3 engine_service/scripts/extraer_sys_2024.py
"""
import glob
import os
import sys

import openpyxl

ROOT = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))


def main():
    cands = glob.glob(os.path.join(ROOT, "GIP 2025", "*Liquidaci*IS 2024*.xlsx"))
    if not cands:
        sys.exit("No se encontró 'GIP 2025/*Liquidación IS 2024*.xlsx' (solo local, gitignored).")
    wb = openpyxl.load_workbook(cands[0], data_only=True)
    hoja = next((s for s in wb.sheetnames if "31.12.24" in s or ("SyS" in s and "24" in s)), None)
    if not hoja:
        sys.exit(f"No hay hoja SyS 2024 en {os.path.basename(cands[0])}. Hojas: {wb.sheetnames}")
    ws = wb[hoja]
    out_dir = os.path.join(ROOT, "engine_service", "_local")
    os.makedirs(out_dir, exist_ok=True)
    nwb = openpyxl.Workbook()
    nws = nwb.active
    nws.title = "Sumas y Saldos"
    for row in ws.iter_rows(values_only=True):
        nws.append(row)
    out = os.path.join(out_dir, "gip_2024_sys.xlsx")
    nwb.save(out)
    print(f"OK: hoja '{hoja}' ({ws.max_row} filas) -> {out}")


if __name__ == "__main__":
    main()
