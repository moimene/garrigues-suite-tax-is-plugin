# Solicitud de información — IS {{ejercicio}}

Estimados,

Para completar la preparación del Impuesto sobre Sociedades del ejercicio {{ejercicio}} necesitaríamos
que nos ayudarais con la siguiente información. Cada punto corresponde a un tema que tiene efecto en el
cálculo del impuesto y que requiere vuestra confirmación.

## 1. {{título de la solicitud}}
**Qué necesitamos:** {{descripción en lenguaje claro}}
**Por qué:** {{motivo — p. ej. cuantificar la exención por dividendos del art. 21}}

| Fecha | Asiento | Descripción | Importe divisa | Tipo de cambio medio | Contravalor EUR | Ajuste de valor |
|---|---|---|---|---|---|---|
| | | | | | | |
| | | | | | | |
| **Total** | | | | | | |

## 2. {{siguiente solicitud}}
**Qué necesitamos:** ...
**Por qué:** ...

---
Cualquier duda, quedamos a vuestra disposición.
Un saludo.
