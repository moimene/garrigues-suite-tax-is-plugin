# Estructura del vault del cliente (referencia)

```
/CLIENTES/{NIF}_{RazonSocial}/
├── _perfil_cliente.md
└── ejercicios/{año}/
    ├── 00_intake/            (sumas y saldos, CCAA, auditoría, otros_soportes, checklist_intake.md)
    ├── 01_analisis/          (balance_normalizado.xlsx, facts.json, issues.json, liquidacion.json)
    ├── 02_revision/          (lista_issues.md, solicitudes_cliente.md, respuestas_cliente/)
    ├── 03_export/            (Liquidacion_IS.xlsx, Modelo200.xlsx, memoria_tecnica.md, checklist_presentacion.md)
    ├── pagos_fraccionados/   (Modelo202/222 + memos)
    └── _bitacora.md
```

La carpeta ES el estado del expediente. Cada fase del plugin escribe sus artefactos aquí.
Crea esta estructura con `scripts/crear_vault.py`.
