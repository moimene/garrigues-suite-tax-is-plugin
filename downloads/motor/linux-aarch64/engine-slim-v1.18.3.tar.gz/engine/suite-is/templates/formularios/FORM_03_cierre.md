---
documento: FORM_03_cierre
expediente: { cliente: "{{NIF}} — {{RAZON SOCIAL}}", ejercicio: {{AÑO}}, regimen: {{regimen}}, tipologia: [{{...}}] }
harness:
  fase_actual: "4 · Cierre y export"
  fase_anterior: "3→4 · Respuestas  → 02_revision/respuestas_cliente/FORM_02b_respuestas.md"
  fase_siguiente: "— (cerrado) · complementaria/rectificativa si procede"
  estado: {{completa|bloqueada}}
  semaforo: { bloqueante: 0, a_confirmar: 0, verde: 0, informativo: 0 }
  pendientes_para_siguiente: []
contratos_datos: [facts.json, issues.json, liquidacion.json]
trazabilidad: { version: "v1", fecha: "{{YYYY-MM-DD}}", autor: "{{...}}" }
---
> 🧭 HARNESS · Fase 4/4 — Cierre · ← 3→4 Respuestas · → cerrado
> Estado: {{estado}} · 🔴0 🟡0 (gating superado)
> Pendientes: ninguno

# Cierre — IS {{AÑO}}
## Liquidación definitiva
| Concepto | Importe | Casilla |
|---|---|---|
| Base imponible | | 00552 |
| Cuota íntegra | | 00562 |
| Cuota a ingresar | | 00621 |

## Entregables
- Export: `03_export/Modelo200_{{AÑO}}.xlsx`
- Memoria técnica: `03_export/memoria_tecnica.md`
- Checklist de presentación (Sociedades WEB).
