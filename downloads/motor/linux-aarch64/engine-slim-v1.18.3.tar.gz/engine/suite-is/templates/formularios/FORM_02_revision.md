---
documento: FORM_02_revision
expediente: { cliente: "{{NIF}} — {{RAZON SOCIAL}}", ejercicio: {{AÑO}}, regimen: {{regimen}}, tipologia: [{{...}}] }
harness:
  fase_actual: "3 · Revisión y solicitudes"
  fase_anterior: "2 · Análisis  → 01_analisis/FORM_01_analisis.md"
  fase_siguiente: "4 · Cierre y export  → 03_export/FORM_03_cierre.md (tras respuestas)"
  estado: {{en_curso|completa|bloqueada}}
  semaforo: { bloqueante: 0, a_confirmar: 0, verde: 0, informativo: 0 }
  pendientes_para_siguiente: ["{{respuestas del cliente requeridas}}"]
contratos_datos: [issues.json]
trazabilidad: { version: "v1", fecha: "{{YYYY-MM-DD}}", autor: "{{...}}" }
---
> 🧭 HARNESS · Fase 3/4 — Revisión · ← 2 Análisis · → 4 Cierre (tras respuestas)
> Estado: {{estado}} · 🔴{{n}} 🟡{{n}} 🟢{{n}} ⚪{{n}}
> Pendientes que tocará resolver: {{respuestas del cliente}}

# Revisión — vista abogado
| # | Criticidad | Issue | Efecto en cuota | Acción |
|---|---|---|---|---|
| | | | | |

## Gating
{{condiciones que bloquean el export}}

# Solicitudes al cliente — vista cliente
{{tablas a rellenar: dividendos con tipo de cambio, transmisión de participaciones, etc.}}
