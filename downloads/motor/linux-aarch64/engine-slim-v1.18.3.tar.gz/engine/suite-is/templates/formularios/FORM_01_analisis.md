---
documento: FORM_01_analisis
expediente: { cliente: "{{NIF}} — {{RAZON SOCIAL}}", ejercicio: {{AÑO}}, regimen: {{regimen}}, tipologia: [{{...}}] }
harness:
  fase_actual: "2 · Análisis y motor de issues"
  fase_anterior: "1 · Intake  → 00_intake/FORM_00_intake.md"
  fase_siguiente: "3 · Revisión y solicitudes  → 02_revision/FORM_02_revision.md"
  estado: {{en_curso|completa|bloqueada}}
  semaforo: { bloqueante: 0, a_confirmar: 0, verde: 0, informativo: 0 }
  pendientes_para_siguiente: ["{{issues 'a confirmar' que pasan a la solicitud al cliente}}"]
contratos_datos: [facts.json, issues.json, liquidacion_provisional.json]
trazabilidad: { version: "v1", fecha: "{{YYYY-MM-DD}}", autor: "{{...}}" }
---
> 🧭 HARNESS · Fase 2/4 — Análisis · ← 1 Intake · → 3 Revisión
> Estado: {{estado}} · 🔴{{n}} 🟡{{n}} 🟢{{n}} ⚪{{n}}
> Pendientes que tocará resolver: {{...}}

# Análisis y motor de issues — IS {{AÑO}}

## Issues detectados
| # | Criticidad | Issue | Importe | Casilla | Estado | Acción |
|---|---|---|---|---|---|---|
| | | | | | | |

## Liquidación provisional
| Concepto | Importe | Casilla |
|---|---|---|
| Base imponible | | 00552 |
| Cuota íntegra | | 00562 |
| Cuota a ingresar (provisional) | | 00621 |

## Pendientes que pasan a Fase 3 (solicitudes al cliente)
{{lista de 🟡}}
