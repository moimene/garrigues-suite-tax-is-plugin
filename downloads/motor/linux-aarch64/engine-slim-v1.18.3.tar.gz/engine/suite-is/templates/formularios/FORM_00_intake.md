---
documento: FORM_00_intake
expediente: { cliente: "{{NIF}} — {{RAZON SOCIAL}}", ejercicio: {{AÑO}}, regimen: {{regimen}}, tipologia: [{{...}}] }
harness:
  fase_actual: "1 · Intake (gestión de información)"
  fase_anterior: "— (inicio)"
  fase_siguiente: "2 · Análisis y motor de issues  → 01_analisis/FORM_01_analisis.md"
  estado: {{en_curso|completa|bloqueada}}
  semaforo: { bloqueante: 0, a_confirmar: 0, verde: 0, informativo: 0 }
  pendientes_para_siguiente: ["{{lo que la Fase 2 debe atender}}"]
contratos_datos: [balance_normalizado.xlsx]
trazabilidad: { version: "v1", fecha: "{{YYYY-MM-DD}}", autor: "{{...}}" }
---
> 🧭 HARNESS · Fase 1/4 — Intake · ← inicio · → 2 Análisis
> Estado: {{estado}} · 🔴{{n}} 🟡{{n}} 🟢{{n}} ⚪{{n}}
> Pendientes que tocará resolver: {{...}}

# Intake — IS {{AÑO}} — {{RAZON SOCIAL}}

## Documentación recibida
| Documento | Estado | Notas |
|---|---|---|
| Balance de sumas y saldos | {{✅/⚠️/⛔}} | |
| Cuentas anuales (balance+PyG+memoria) | {{}} | |
| Declaración IS ejercicio anterior | {{}} | arrastres |

## Resultado contable reconciliado (del balance)
- Resultado contable (00500): {{importe}}
- (+) Gasto por IS (6300): {{importe}}
- Resultado contable corregido: {{importe}}

## Contexto fiscal
Régimen / tipología / tipo de gravamen / grupo.

## Saldos de arrastre
| Concepto | Importe | Origen |
|---|---|---|
| BINs pendientes | | |
| GF neto pendiente (art.16) | | |
| Deducciones pendientes | | |

## Bloqueantes
{{ninguno / lista}}
