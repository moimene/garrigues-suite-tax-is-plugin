---
documento: FORM_02b_respuestas
expediente: { cliente: "{{NIF}} — {{RAZON SOCIAL}}", ejercicio: {{AÑO}}, regimen: {{regimen}} }
harness:
  fase_actual: "3→4 · Respuestas del cliente"
  fase_anterior: "3 · Revisión  → 02_revision/FORM_02_revision.md"
  fase_siguiente: "4 · Cierre y export  → 03_export/FORM_03_cierre.md"
  estado: {{en_curso|completa}}
  semaforo: { bloqueante: 0, a_confirmar: 0, verde: 0, informativo: 0 }
  pendientes_para_siguiente: ["{{lo que aún falte por confirmar, si algo}}"]
contratos_datos: [issues.json]
trazabilidad: { version: "v1", fecha: "{{YYYY-MM-DD}}", autor: "Cliente / Abogado" }
---
> 🧭 HARNESS · Fase 3→4 — Respuestas · ← 3 Revisión · → 4 Cierre
> Estado: {{estado}} · pendientes: {{...}}

# Respuestas del cliente — IS {{AÑO}}
Para cada solicitud de la Fase 3: dato confirmado + evidencia.
1. {{Dividendos}}: ...
2. {{Transmisión de participaciones}}: ...
3. {{...}}
