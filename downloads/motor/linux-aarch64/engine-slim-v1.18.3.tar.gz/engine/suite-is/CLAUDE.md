# Suite IS — Memoria del plugin (continuidad)

> Lee este archivo al iniciar cualquier trabajo con el plugin Suite IS. Resume el propósito,
> las convenciones y el estado para que una conversación nueva pueda continuar sin contexto previo.

## Qué es
Plugin de skills/workflows que prepara el Impuesto sobre Sociedades (Modelos 200/202/222) trabajando
**sobre la carpeta del cliente**. La carpeta es el estado; cada fase escribe artefactos.

## Las 4 fases y sus artefactos
1. Intake → `00_intake/` + `checklist_intake.md`
2. Motor de issues + liquidación → `01_analisis/{facts.json, issues.json, liquidacion.json}`
3. Lista por criticidad → `02_revision/{lista_issues.md, solicitudes_cliente.md}`
4. Export → `03_export/{Liquidacion_IS.xlsx, Modelo200.xlsx, memoria_tecnica.md, checklist_presentacion.md}`

## Estructura del vault del cliente
```
/CLIENTES/{NIF}_{RazonSocial}/
  _perfil_cliente.md
  ejercicios/{año}/{00_intake,01_analisis,02_revision,03_export,pagos_fraccionados}
  ejercicios/{año}/_bitacora.md
```

## Convenciones
- **Determinismo**: ningún importe a casilla sin regla del catálogo (`rules/`). Claude detecta y
  fundamenta; NO inventa cálculos.
- **Criticidad**: 🔴 bloqueante · 🟡 a confirmar · 🟢 verde · ⚪ informativo. Los 🟡 nunca se
  auto-resuelven: los valida el abogado/cliente.
- **Gating**: con 🔴 activo o 🟡 con impacto sin resolver, NO se genera el export final.
- **Contratos JSON** entre fases: `facts.json`, `issues.json`, `liquidacion.json` (ver skills).
- **Trazabilidad**: cada acción se anota en `_bitacora.md`.
- **Branding**: documentos al cliente con identidad Garrigues (skill garrigues-presentations si aplica).

## Reglas y casillas
- `rules/catalogo/*.yaml` — dominios de ajustes/deducciones + capa de criterio (playbook):
  `posicion_estandar`, `desviaciones_aceptables`, `desviaciones_inaceptables`, `criticidad`, `ref`.
- `rules/regimenes/*.yaml` — deltas por régimen/tipología (general, etve, pymes, socimi, fondos).
- `rules/casillas/modelo200_2024.yaml` — mapa concepto→casilla por ejercicio.
- `rules/playbook/` — CSV fuente del playbook + nota de correcciones aplicadas.

## Parámetros que cambian por ejercicio (Ley 7/2024 — verificar siempre)
- **Compensación BINs** (correcto, no el del CSV): 70% mín. 1M€ (INCN<20M); 50% (20-60M); 25% (≥60M).
- **Reserva de capitalización**: ≤2023 10%/5a · 2024 **15%**/3a (RDL 4/2024) · ≥2025 20% (hasta 30% con plantilla)/3a.
- **Tipos**: general 25%; PYME INCN<1M = 23% (2024) y escala 21/22%→17/20% (2025+); ERD<10M 25%→20%.

## Caso de referencia (validado)
GIP 2024 (ETVE, régimen general). Liquidación reproducida cuadra con el Modelo 200 presentado:
- Base imponible (00552) = 11.068.602,43
- Cuota íntegra (00562) = 2.767.150,61
- Cuota a ingresar = 2.486.355,42

## Estado
v0.3.0 — Pipeline Harvey end-to-end (WF-1 v3 + Puente Excel + WF-2 v3) operativo. **Paquete de
distribución para abogados listo** en `suite-is/distribucion_abogados/` (guía Word + plantilla +
prompts + puente determinista + caso GIP de referencia; ZIP en `~/Downloads/Suite-IS-Distribucion-Abogados.zip`).
**Puente de entregables v3** (`scripts/puente_entregables_v3.py`): bloque parseable WF-2 → 3 ficheros
(Modelo 200 .xlsx + Liquidación .docx + Memoria .docx), determinista, **38 tests verdes** (incl. `test_puente_v3.py` con **ancla GIP 2025 REAL**
validada al céntimo contra la Nota 10.1 de las CCAA: 00552=3.208.497,87 · 00562=00621=802.124,47).
> ⚠️ **CORRECCIÓN FISCAL (2026-06-19): ese número de GIP 2025 está INCOMPLETO.** Al importar el `.200` real en
> AEAT Sociedades WEB se descubrió, confirmado por el abogado, que GIP es **ETVE** y sus gastos financieros van
> por el **art. 16.5 LIS** (deuda de adquisición de participaciones): el exceso sobre el 30% B.O. (6.973.462,24)
> NO es deducible este año → **ajuste positivo obligatorio 00363** que la Estimación/Nota 10.1 NO traía. El número
> fiscal **CORRECTO es BI 00552 = 6.695.228,99 · cuota 00562/00621 = 1.673.807,25** (no 3.208.497,87 / 802.124,47).
> El ancla vieja sigue siendo válida como NO-REGRESIÓN del comportamiento ACTUAL de Harvey/puente (que aún no
> aplica el art. 16.5), pero el motor de Harvey/plugin **debe incorporar la regla** para producir el número
> correcto. Detalle y mecanismo: `docs/memoria/2026-06-19-mod200-aeat-import-limpio-art16-etve.md`.
> 🔴 **3ª CORRECCIÓN (2026-06-19, noche) — el número FIRME es cuota 2.092.210,34 (criterio estricto art.16.5).**
> El veredicto del juez + la decisión del abogado fijaron que, con el B.O. del art.16 NEGATIVO, el límite del
> art.16.5 es 0 (sin suelo — el suelo de 1M es exclusivo del art.16.1) → TODO el GF de adquisición es no
> deducible (00363=10.320.686,98), no solo el exceso (6.973.462,24). **BI 00552=8.368.841,36 · cuota
> 00562/00621=2.092.210,34.** Implementado en el motor `.200` (Extractor-parseador, Pasos 1/2/3/8). El
> plugin/Harvey y `puente_entregables_v3`/`test_puente_v3` siguen con el viejo (3.208.497,87) — pendiente de
> propagar. Detalle: `docs/memoria/2026-06-19-implementacion-correcciones-motor-IS.md`.
**Fix B3 aplicado** (recompute `B12 = B2 + B4 + B5`; B3/00301 es informativa y NO se suma — B2 es el
resultado *antes* de impuestos). **Retest end-to-end con GIP real (jun-2026)**: WF-1 (Fase A) + WF-2
(reconfigurado para **ingerir el bloque parseable** directamente, sin puente Excel) funcionan; el
**gating bloquea correctamente** ante 🟡 sin resolver; la **generación nativa de Word de WF-2 NO es
fiable** (probabilística → sale en blanco), por lo que **la vía de producción de los entregables es el
puente** (ejemplo generado en `~/Downloads/GIP_2025_entregables/`). v0.2.0 previo: MVP + playbook (18 reglas, tramos BIN/reserva/tipos por ejercicio).
Pendiente: golden cases por régimen.

## Formularios documentales + harness (estándar de sistema sin tablas)
No hay base de datos: el estado vive en la cadena de documentos. Todo documento de fase abre con una
cabecera **harness** (frontmatter YAML + banner visible) que indica: `fase_actual`, `fase_anterior`,
`fase_siguiente`, `estado`, `semaforo` (🔴🟡🟢⚪) y `pendientes_para_siguiente`. El `pendientes_para_siguiente`
de un documento es la agenda de entrada del siguiente. Plantillas en `templates/formularios/`:
FORM_00_intake → FORM_01_analisis → FORM_02_revision → FORM_02b_respuestas → FORM_03_cierre.
Capa forma (Markdown+harness, humano) + capa dato (facts/issues/liquidacion.json, máquina). Mismo
estándar aplica en Harvey: cada output de Workflow Agent abre con el banner harness.

## v0.4.0 — Plugin por delante de la réplica Harvey + flujo Cowork fluido
- **Orquestador conversacional** (`skills/is-orquestador`): lleva al abogado paso a paso en una conversación
  Cowork; lee el estado del Excel-estado (00_Harness), dice dónde está (semáforos/pendientes) y ejecuta el
  siguiente paso, una acción por turno, con validación humana en los puntos clave.
- **El plugin CALCULA el número** (determinista) y lo deja en el Excel-estado con fórmulas vivas
  (`scripts/rellenar_estado.py` + `construir_plantilla.py`); Harvey solo infiere. Diferenciador.
- **Motor corregido**: fórmulas con ROUND a 2 decimales; compensación BINs topada en base−reserva y
  protegida contra base negativa; **tipo de gravamen por régimen** (`PAR_TIPO_APLICABLE`); `05_Mapping_M200`
  poblada por fórmula. Validado con LibreOffice: GIP = 11.068.602,43 / 2.767.150,61 / 2.486.355,42.
- **Fuente única de parámetros** `rules/parametros/{ejercicio}.yaml` (la lee la plantilla; Harvey sincroniza
  desde aquí). Reserva capitalización 2024 = 15% (RDL 4/2024).
- **Gating duro** vía `harness_estado.is_exportable` (rojo=0, amarillo_impacto=0, validada=sí).

## v0.5.0 — Conversor PGC autónomo (Fase 0) + cierre del upstream
- **Fase 0** (`skills/is-conversor-pgc` + `scripts/conversor_pgc.py`): convierte el SyS bruto del cliente
  en la "Tabla 1" agrupada a 4 dígitos PGC (3d → 4d+0), formato español, con cuadre y tabla de validación
  humana (reglas de reasignación: 280/281 amort. vs 290/291 deterioro, 480/485, 572/573, 630/639). Hace al
  plugin **autónomo**: ya no depende del conversor externo. Validado con el SyS real de GIP (60 cuentas,
  cuadra Debe/Haber y Deudor/Acreedor) → encadena con `exportar_sys_a3.py` (fichero A3) y `sys_a_inputs.py`
  (B2/B3 + hooks de issues) → `is-intake`.
- **Maestro PGC** `rules/pgc/maestro_pgc.csv` (SEED parcial; sustituir por el cuadro oficial RD 1514/2007
  o usar "Spain Legal" en Harvey). El conversor NO inventa códigos: marca para revisión los no presentes.
- Flujo completo Cowork: Fase 0 (conversor) → 1 (intake) → 2 (issues+liquidación) → 3 (criticidad+solicitudes)
  → 4 (cierre+export), conducido por `is-orquestador`, con el Excel-estado como estado y el número determinista.

## v0.5.1 — Maestro PGC oficial completo
`rules/pgc/maestro_pgc.csv` ya es el **cuadro de cuentas oficial completo** (RD 1514/2007, Texto refundido
2021): **904 cuentas** (9 grupos, 77 subgrupos, 421 de 3 díg., 397 de 4 díg.), extraído de la normativa
vigente. El conversor PGC (Fase 0) asigna denominaciones oficiales y valida códigos reales. Cubre también
PYMES (subconjunto con la misma numeración).
