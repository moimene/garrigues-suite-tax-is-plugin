---
name: is-export-modelo200
description: >
  Fase 4 del IS: cierre y export. Debe usarse cuando el usuario diga "genera el modelo 200", "cierra el
  impuesto", "genera los entregables", "exporta la declaración", "memoria técnica". Incorpora respuestas
  del cliente, recalcula en firme en el Excel-estado, aplica el gating duro y genera los entregables
  (Modelo 200 + memoria técnica) con identidad Garrigues.
metadata:
  version: "0.4.0"
  fase: "4 - cierre y export"
---

# Fase 4 — Cierre y export (Excel-estado → entregables)

## Procedimiento
1. **Ingesta de respuestas** de `02_revision/respuestas_cliente/`: actualiza los issues 🟡 → 🟢 (o reábrelos).
2. **Recalcular en firme**: `rellenar_estado.py` con los issues definitivos → `03_export/EXP_estado_{año}.xlsx`.
3. **Validación del número por el abogado**: marca `H_validada = sí` en el Excel-estado solo cuando el
   abogado confirme el número contra su criterio/papel de trabajo.
4. **Gating duro**: `python3 ${CLAUDE_PLUGIN_ROOT}/scripts/harness_estado.py <EXP_estado.xlsx>` →
   `is_exportable` exige `H_sem_rojo==0`, `H_sem_amarillo_impacto==0` y `H_validada` en {sí}. Si no, NO
   generes entregables; informa qué falta y vuelve a Fase 3.
5. **Entregables** (con identidad Garrigues): `python3 ${CLAUDE_PLUGIN_ROOT}/scripts/puente_entregables_v3.py …`
   produce Modelo 200 (.xlsx, casilla|importe), Liquidación (.docx) y Memoria técnica (.docx). El propio
   Excel-estado ya contiene `05_Mapping_M200` con las casillas calculadas por fórmula.
6. **Checklist de presentación** (`03_export/checklist_presentacion.md`): pasos manuales en Sociedades WEB,
   caracteres de la declaración a marcar según tipología (ETVE 00011, PYMES 00006, SOCIMI 00012, fondos
   00004, matriz de grupo 00082) y el tipo de gravamen en su casilla (no la 00562).
7. **Registrar** el cierre en `_bitacora.md`.

> El número es determinista (fórmulas del Excel-estado); aun así el cierre requiere validación humana y
> el gating. Sin integración AEAT: se generan ficheros + checklist de presentación manual.
