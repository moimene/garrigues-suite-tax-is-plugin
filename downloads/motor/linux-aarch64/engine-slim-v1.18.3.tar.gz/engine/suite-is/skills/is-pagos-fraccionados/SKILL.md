---
name: is-pagos-fraccionados
description: >
  Modelos 202 y 222 (pagos fraccionados del Impuesto sobre Sociedades). Debe usarse cuando el usuario
  diga "calcula el pago fraccionado", "prepara el modelo 202", "modelo 222 del grupo", "estimación del
  pago a cuenta", o "cuánto toca pagar en octubre". Calcula y documenta los pagos fraccionados a partir
  de la liquidación del ejercicio y/o una estimación, con el calendario abril/octubre/diciembre.
metadata:
  version: "0.1.0"
  fase: "transversal - pagos fraccionados"
---

# Pagos fraccionados (Modelos 202 / 222)

Objetivo: calcular y documentar los pagos fraccionados del IS.

## Modalidades
- **Cuota** (art. 40.2 LIS): % sobre la cuota del último Modelo 200 presentado, menos deducciones,
  bonificaciones y retenciones.
- **Base** (art. 40.3 LIS): % sobre la base imponible del periodo corrido del ejercicio en curso
  (obligatoria para grandes empresas, INCN ≥ 6M). El % depende del tipo de gravamen.

## Procedimiento

1. **Determinar modalidad** según el perfil (obligados a modalidad base si INCN ≥ 6M) y el régimen.
2. **Calendario**: 1P (abril), 2P (octubre), 3P (diciembre) sobre el periodo correspondiente.
3. **Modalidad base**: usa la estimación del ejercicio en curso (replica el patrón del fichero
   "Estimación GIS" de la carpeta de referencia: sumas y saldos del periodo, GF, BINs, dividendos).
4. **Modalidad cuota**: parte de la cuota del último Modelo 200 (`03_export/`).
5. **Generar** `ejercicios/{año}/pagos_fraccionados/Modelo{202|222}_{periodo}.xlsx` con el cálculo y
   las casillas, y un breve memo de soporte.
6. **222 (grupos)**: estructura por entidad del grupo de consolidación fiscal y agrega.

## Salida
`pagos_fraccionados/Modelo202_{periodo}.xlsx` (o 222) + memo. Registra en `_bitacora.md`.
