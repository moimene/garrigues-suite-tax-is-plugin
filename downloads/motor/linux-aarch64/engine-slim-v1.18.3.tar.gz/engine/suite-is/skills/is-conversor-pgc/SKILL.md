---
name: is-conversor-pgc
description: >
  Fase 0 del IS: convierte un balance de sumas y saldos en bruto en la "Tabla 1" agrupada a 4 dígitos
  PGC, lista para A3 y para el motor del IS. Debe usarse cuando el usuario diga "convierte el balance a
  PGC", "normaliza el sumas y saldos", "agrupa a 4 dígitos", "prepara la tabla 1", "conversor PGC",
  "deja el balance listo para A3", o cuando aporte un SyS bruto antes de empezar la declaración. Hace una
  pasada determinista + reasignación por descripción/signo y una tabla de validación para el abogado.
metadata:
  version: "0.5.0"
  fase: "0 - conversión PGC (upstream)"
---

# Fase 0 — Conversor PGC (Sumas y Saldos → Tabla 1 a 4 dígitos)

Convierte el SyS bruto del cliente (cualquier formato) en la **"Tabla 1 — Sumas y Saldos A3"** agrupada a
4 dígitos PGC, que alimenta `exportar_sys_a3.py` (fichero de importación A3) y `sys_a_inputs.py`
(inputs B2/B3/B10 + hooks de issues). Hace al plugin **autónomo** en el upstream (sin depender de un
conversor externo). Dos fases con validación humana (estándar harness).

## Principios
- **Determinista lo mecánico, razonado lo dudoso, humano lo que requiere criterio.**
- **No inventar códigos**: usar solo el maestro PGC (`rules/pgc/maestro_pgc.csv`; en producción, el cuadro
  oficial RD 1514/2007 / conocimiento "Spain Legal"). Si un código no está, marcar para revisión, no forzar.
- **Formato español** en los números (1.234.567,89).

## Fase 0a — Propuesta (determinista + razonada)
1. **Pasada determinista**:
   `python3 ${CLAUDE_PLUGIN_ROOT}/scripts/conversor_pgc.py --input <SyS> --output 00_intake/tabla1.md --validacion 00_intake/tabla1_validacion.md`.
   Detecta columnas, trunca a 4d/3d, agrupa a 4 dígitos (3d → 4d añadiendo '0'), comprueba el **cuadre**
   (Σ Debe=Σ Haber; Σ deudor=Σ acreedor) y emite las **anomalías** (código vacío/no numérico, posible
   signo equivocado, código < 3 dígitos).
2. **Reasignación razonada por descripción** (revisor contable), solo sobre filas dudosas, con estas reglas:
   - Amort. acumulada inmovilizado intangible/material → **280x / 281x** (no confundir con deterioros).
   - Deterioros → **290x / 291x** (no son amortización).
   - "Gastos anticipados" → **480**; "Ingresos anticipados"/"previsión de ingresos" → **485**.
   - Bancos/tesorería en euros → **572**; en moneda extranjera → **573**.
   - Impuesto sobre beneficios (incl. extranjero) → **630**; ajustes positivos en imposición indirecta → **639**.
   - Si la descripción contradice claramente la familia del código → "inconsistencia código-descripción":
     propón la cuenta más adecuada (la más específica del PGC), documenta original→propuesta en Notas.
3. **Validación del signo**: naturaleza esperada (deudora/acreedora/mixta) vs signo observado. Si
   incoherente → "posible signo equivocado": **no** reasignes solo por el signo; mantén la cuenta por
   descripción y marca para revisar el signo (salvo que la descripción permita una alternativa de
   naturaleza compatible).

## Tabla de validación interactiva (entrega intermedia — espera al abogado)
Muestra el banner harness y una tabla con EXACTAMENTE estas columnas: `Código original | Descripción |
Importe/Saldo observado | Cuenta detectada | Naturaleza esperada | Signo observado | Cuenta PGC propuesta
| Denominación PGC propuesta | Tipo de resolución | Motivo | Alternativas consideradas | Notas |
✅ Validar | ✏️ Corregir (codigo cuenta = <código>)`. Incluye solo filas reasignadas, con código
vacío/no numérico, "no identificada", "inconsistencia código-descripción", "posible signo equivocado",
con alternativa propuesta o que requieran validación humana. **No** continúes sin la respuesta del abogado.

## Fase 0b — Cierre (tras validación)
- Aplica las correcciones: "Validado" → mantener; "codigo cuenta = X" → sustituir, **verificando que X
  existe en el PGC**; si no existe, mantener la mejor asignación y anotarlo en Notas.
- Reagrupa a 4 dígitos y emite la **Tabla 1 limpia** definitiva (`00_intake/tabla1.md`).
- Encadena: `python3 ${CLAUDE_PLUGIN_ROOT}/scripts/sys_a_inputs.py --tabla1 00_intake/tabla1.md`
  para derivar B2 (resultado contable = −Σ saldos grupos 6 y 7), B3 (6300) y los hooks de issues; y
  `exportar_sys_a3.py` si se quiere el fichero de importación A3. Después, sigue con `is-intake`.

## Salida
`00_intake/tabla1.md` (Tabla 1 a 4 dígitos, cuadrada) + `tabla1_validacion.md`. Reporta el cuadre y el
nº de cuentas. Esta Tabla 1 es el input contable del resto del flujo.
