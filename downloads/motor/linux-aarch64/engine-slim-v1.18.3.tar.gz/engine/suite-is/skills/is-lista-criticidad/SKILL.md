---
name: is-lista-criticidad
description: >
  Fase 3 del Impuesto sobre Sociedades: lista de temas priorizada por criticidad. Debe usarse cuando
  el usuario diga "genera la lista de issues", "prioriza los temas del IS", "qué hay que confirmar con
  el cliente", "prepara las solicitudes al cliente", "lista para el abogado", o "qué bloquea el cierre
  del impuesto". Convierte issues.json en una lista ordenada y graduada para el abogado y en
  solicitudes de información en lenguaje claro para el cliente.
metadata:
  version: "0.1.0"
  fase: "3 - lista por criticidad"
---

# Fase 3 — Lista priorizada por criticidad

Objetivo: dos vistas a partir de `issues.json` — una técnica para el abogado y una para contrastar
con el cliente.

## Graduación de criticidad

| Nivel | Significado | Efecto |
|---|---|---|
| 🔴 Bloqueante | Falta dato esencial o hay incoherencia que impide cerrar | Bloquea export |
| 🟡 A confirmar | Criterio o dato que requiere validación de cliente/socio | Genera solicitud |
| 🟢 Verde | Ajuste claro y soportado, listo para incorporar | Entra en liquidación |
| ⚪ Informativo | Sin efecto en cuota, a documentar | Solo memoria técnica |

## Procedimiento

1. **Ordenar** los issues por (a) criticidad y (b) impacto absoluto en cuota. Para cada uno computa
   el efecto aproximado en cuota (importe del ajuste × tipo de gravamen).

2. **Escribir `02_revision/lista_issues.md` (vista abogado)** con una tabla:
   `id | título | importe | efecto en cuota | casilla(s) | criticidad | fundamento | acción requerida`.
   Agrupa por criticidad (🔴 primero). Incluye un resumen ejecutivo con la cuota preliminar y el
   rango si hay 🟡 abiertos.

3. **Escribir `02_revision/solicitudes_cliente.md` (vista cliente)** solo con los 🟡 "a confirmar",
   redactados en lenguaje claro y sin jerga interna. Para cada solicitud:
   - qué se necesita y por qué (en términos comprensibles),
   - una **tabla a rellenar** cuando aplique (p. ej. detalle de dividendos por participada con fecha,
     importe en divisa, tipo de cambio medio y contravalor en euros — como en el caso real).
   Usa la plantilla `${CLAUDE_PLUGIN_ROOT}/templates/solicitud_informacion.md`.

4. **No publicar contenido interno**: la vista cliente nunca incluye notas internas, criterios en
   discusión ni importes no validados que puedan confundir.

5. **Registrar** en `_bitacora.md` la generación de la lista y de las solicitudes, con fecha.

## Salida
`02_revision/lista_issues.md`, `02_revision/solicitudes_cliente.md`. Cuando lleguen respuestas a
`02_revision/respuestas_cliente/`, vuelve a `is-motor-issues`/`is-liquidacion` para recalcular y luego
a `is-export-modelo200`.
