---
name: is-memoria-tecnica
description: >
  Genera la memoria técnica auditable del Impuesto sobre Sociedades. Debe usarse cuando el usuario
  diga "genera la memoria técnica", "documenta las decisiones del IS", "prepara el soporte de la
  declaración", "justifica los ajustes", o al cierre del expediente. Compila decisiones fiscales,
  criterios, evidencias y warnings aceptados en un documento trazable.
metadata:
  version: "0.1.0"
  fase: "4 - documentación auditable"
---

# Memoria técnica del IS

Objetivo: dejar por escrito el "porqué" de cada decisión, con su evidencia, para auditoría interna y
soporte ante una eventual comprobación.

## Procedimiento

1. **Recopilar** de la carpeta: `liquidacion.json`, `issues.json`, `_bitacora.md`, y las evidencias
   de `00_intake/` y `02_revision/respuestas_cliente/`.

2. **Estructurar `03_export/memoria_tecnica.md`**:
   - **Identificación**: cliente, NIF, ejercicio, régimen, tipología, tipo de gravamen.
   - **Resumen de la liquidación**: base imponible, cuota íntegra, cuota líquida, cuota a ingresar,
     con sus casillas.
   - **Decisiones fiscales**: por cada issue 🟢 incorporado, su importe, casilla, **fundamento
     normativo** (artículo LIS) y la evidencia que lo soporta.
   - **Criterios y warnings aceptados**: issues 🟡 resueltos, con la respuesta del cliente que los
     soporta y quién/ cuándo los validó.
   - **Cuadros de arrastre**: BINs aplicadas y pendientes, gasto financiero deducido y pendiente,
     deducciones aplicadas y pendientes (saldos a futuro).
   - **Anexo de evidencias**: índice de los documentos soporte.

3. **Trazabilidad**: cada cifra material enlaza a su regla (`id`) y a su evidencia. Evita afirmaciones
   sin soporte.

4. **Branding**: si se entrega al cliente, aplica identidad Garrigues (usa la skill
   `garrigues-presentations` para versión presentable si lo piden).

## Salida
`03_export/memoria_tecnica.md` (y versión presentable si se solicita).
