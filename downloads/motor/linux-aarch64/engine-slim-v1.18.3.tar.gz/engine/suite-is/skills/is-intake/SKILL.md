---
name: is-intake
description: >
  Fase 1 del Impuesto sobre Sociedades: gestión de información. Debe usarse cuando el usuario diga
  "crea el expediente IS", "recoge la información del impuesto", "qué documentación falta para el IS",
  "prepara el intake de sociedades", "monta la carpeta del cliente para el IS", o cuando aporte
  cuentas anuales, balance de sumas y saldos o documentación contable para preparar el IS. Crea la
  estructura de carpeta del cliente, inventaría y normaliza la información mínima y deja explícito qué
  falta para arrancar.
metadata:
  version: "0.1.0"
  fase: "1 - gestión de información"
---

# Fase 1 — Gestión de información (intake)

Objetivo: arrancar con el **mínimo imprescindible** y dejar registrado, sin ambigüedad, qué falta.

## Documentación mínima para arrancar

- **Balance de sumas y saldos** a fecha de cierre (nivel cuenta).
- **Cuentas anuales** (balance + PyG + memoria) y, si existe, **informe de auditoría**.
- **Identificación**: NIF, CNAE, ejercicio, régimen, tipología (ETVE/PYMES/SOCIMI/fondos/general),
  pertenencia a grupo.
- **Saldos de arrastre del ejercicio anterior**: declaración IS previa, cuadro de **BINs**, **gasto
  financiero pendiente**, **deducciones pendientes**.

## Procedimiento

1. **Crear el vault** si no existe: ejecuta
   `python3 ${CLAUDE_PLUGIN_ROOT}/scripts/crear_vault.py --base <ruta> --nif <NIF> --razon "<Razón Social>" --ejercicio <año>`.
   Copia ahí la documentación aportada bajo `00_intake/`.

2. **Inventariar y clasificar** cada documento de `00_intake/` (sumas y saldos, CCAA, auditoría,
   correos, otros soportes). Para PDFs escaneados, usa el subagente `analista-contable` (OCR).

3. **Normalizar el balance**: ejecuta
   `python3 ${CLAUDE_PLUGIN_ROOT}/scripts/normalizar_balance.py --input <sumas_y_saldos> --output 01_analisis/balance_normalizado.xlsx`.
   El script detecta columnas (Cuenta, Descripción, Saldos), normaliza signos y agrupa por subcuentas.

4. **Reconciliar el resultado contable**: confirma que el resultado de la cuenta de PyG (cuenta 129 /
   resultado del ejercicio) casa con las CCAA. Anota cualquier diferencia.

5. **Fijar el contexto fiscal** en `_perfil_cliente.md`: ejercicio, régimen, tipología, tipo de
   gravamen aplicable, grupo. Estos campos determinan qué reglas (`rules/regimenes/`) se activan.

6. **Escribir `00_intake/checklist_intake.md`** con tres estados por ítem:
   - ✅ disponible · ⚠️ incompleto · ⛔ falta (bloqueante).
   Incluye una tabla de saldos de arrastre (BINs, GF, deducciones) con su origen.

7. **Gate de fase**: si hay ⛔ bloqueantes, NO avances a Fase 2. Genera la primera tanda de
   solicitudes al cliente (plantilla `${CLAUDE_PLUGIN_ROOT}/templates/solicitud_informacion.md`) y
   anótalo en `_bitacora.md`.

## Salida
`00_intake/` poblado, `01_analisis/balance_normalizado.xlsx`, `_perfil_cliente.md`,
`00_intake/checklist_intake.md`. Cuando no haya bloqueantes, ofrece pasar a `is-motor-issues`.

## v0.4 — Excel-estado
Al montar el vault, crea el Excel-estado del ejercicio:
`python3 ${CLAUDE_PLUGIN_ROOT}/scripts/construir_plantilla.py --output 03_export/EXP_estado_{año}.xlsx --ejercicio {año}`.
El intake pre-rellena la hoja `01_Datos` (con columna procedencia: inferida_IA / input_humano) y deja el
resultado contable reconciliado listo como input B2 de `03_Liquidacion`.
