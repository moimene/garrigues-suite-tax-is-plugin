---
name: is-motor-issues
description: >
  Fase 2 del Impuesto sobre Sociedades: verificación y motor de reglas que levanta los issues
  fiscales. Debe usarse cuando el usuario diga "levanta los issues del IS", "analiza los ajustes
  fiscales", "corre las reglas del impuesto", "qué ajustes a base imponible hay", "revisa
  deducciones y exenciones", o "verifica la información del IS". Valida los datos y aplica el catálogo
  de reglas (determinista) combinado con lectura razonada de la documentación para detectar todos los
  temas con tratamiento en el impuesto.
metadata:
  version: "0.1.0"
  fase: "2 - verificación + motor de issues"
---

# Fase 2 — Verificación + motor de issues

Objetivo: levantar **todos** los issues con efecto en el impuesto y construir `facts.json` + `issues.json`.

## Procedimiento

1. **Verificar datos** (usa el subagente `qa-fiscal`):
   - El balance cuadra (Σ debe = Σ haber).
   - El resultado contable casa con las CCAA.
   - Los saldos de arrastre (BINs, GF, deducciones) concuerdan con la declaración anterior.
   Si algo no cuadra, levanta un issue 🔴 bloqueante y detente.

2. **Construir `01_analisis/facts.json`** con los datos base normalizados: resultado contable,
   resultado contable corregido por IS (suma cuenta 6300), partidas relevantes del balance
   (dividendos cuentas 760x, gastos financieros, multas/sanciones, deterioros, etc.), saldos de
   arrastre y contexto (ejercicio, régimen, tipología, tipo de gravamen). Marca `origen` de cada fact
   (import/usuario/sistema).

3. **Ejecutar el catálogo determinista** (`${CLAUDE_PLUGIN_ROOT}/rules/`):
   - Carga las reglas de `rules/catalogo/*.yaml` activas según el régimen/tipología
     (`rules/regimenes/*.yaml`).
   - Para cada regla cuyo `aplica_si` se cumpla sobre `facts.json`, instancia un issue con su
     `importe` (vía `formula`), `casillas`, `fundamento` y `criticidad_default`.

4. **Detección asistida** (usa el subagente `revisor-fiscal`): lee la **memoria de las CCAA** y el
   balance buscando señales que no salen de una fórmula:
   - Ingresos por dividendos / juros → exención art. 21 (`AJN-EXEN-ART21-DIV`).
   - Transmisión de participaciones → exención plusvalías art. 21 (`AJN-EXEN-ART21-PV`).
   - Multas, sanciones, donativos, IS extranjero → gastos no deducibles (ajustes positivos).
   - Deterioros, provisiones no deducibles, libertad de amortización → diferencias temporarias.
   - Operaciones vinculadas → obligación de documentación (issue informativo).
   Cada hallazgo se convierte en issue con su fundamento normativo.

5. **Calcular liquidación preliminar**: invoca la skill `is-liquidacion` con `facts.json` + `issues.json`.
   Los issues 🟡 "a confirmar" entran como pendientes (rango o nota), no como importe cerrado.

6. **Escribir `01_analisis/issues.json`** siguiendo el contrato (ver `is-liquidacion`). Anota en
   `_bitacora.md` qué reglas dispararon.

## Reglas de oro
- Todo importe que llegue a una casilla procede de una regla del catálogo, nunca de una estimación libre.
- Si dudas entre incluir o no un ajuste, créalo como 🟡 "a confirmar" en vez de omitirlo.
- No cierres importes que dependan de datos que el cliente aún no ha confirmado.

## Salida
`01_analisis/facts.json`, `01_analisis/issues.json`, `01_analisis/liquidacion.json` (preliminar).
Ofrece pasar a `is-lista-criticidad`.

## v0.4 — Excel-estado
Tras levantar los issues, vuélcalos al Excel-estado y calcula la liquidación preliminar de forma
determinista: `python3 ${CLAUDE_PLUGIN_ROOT}/scripts/rellenar_estado.py --facts 01_analisis/facts.json
--issues 01_analisis/issues.json --regimen {regimen} --ejercicio {año} --output 03_export/EXP_estado_{año}.xlsx`.
Esto escribe la hoja `02_Issues`, actualiza los semáforos de `00_Harness` y rellena los inputs B2:B10;
las fórmulas calculan el número. Los 🟡 dejan la liquidación como preliminar (gating).
