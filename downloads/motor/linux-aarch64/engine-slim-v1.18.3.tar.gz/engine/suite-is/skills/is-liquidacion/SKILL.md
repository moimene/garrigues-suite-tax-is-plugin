---
name: is-liquidacion
description: >
  Cálculo determinista de la liquidación del IS y volcado al Excel-estado. Debe usarse cuando el usuario
  diga "calcula la liquidación", "recalcula la cuota", "cuánto sale a ingresar", "rellena el excel de
  liquidación", o cuando otra skill lo necesite. El plugin CALCULA el número (no lo infiere) y lo deja en
  el Excel-estado con fórmulas vivas, listo para que el abogado lo valide.
metadata:
  version: "0.4.0"
  fase: "2/4 - cálculo determinista"
---

# Liquidación determinista (Excel-estado)

El número lo calcula el plugin y queda en el Excel-estado (`03_Liquidacion`, celdas-input B2:B10 +
fórmulas vivas B12:B17 que referencian `04_Parametros`). Reproducible y trazable.

## Procedimiento
1. **Rellenar y calcular**:
   `python3 ${CLAUDE_PLUGIN_ROOT}/scripts/rellenar_estado.py --facts 01_analisis/facts.json --issues 01_analisis/issues.json --regimen {regimen} --ejercicio {año} --output 03_export/EXP_estado_{año}.xlsx`
   Escribe los inputs B2:B10, fija `PAR_TIPO_APLICABLE` por régimen, actualiza `00_Harness` y reporta
   Base imponible (00552), Cuota íntegra (00562) y Cuota a ingresar (00621).
2. **Esquema** (lo computan las fórmulas): resultado contable (+IS) → BI previa → (−reserva) → límite y
   compensación de BINs por tramo de INCN (70/50/25% con mínimo 1M€) → BI → cuota íntegra (tipo por
   régimen) → (−DDI/retenciones/pagos) → cuota a ingresar. Todo con ROUND a 2 decimales.
3. **Pendientes**: los issues 🟡 marcan la liquidación como preliminar; no es definitiva hasta resolverlos.
4. **Validación**: el número es determinista pero **debe validarlo el abogado**; el harness lleva `H_validada`.

## Parámetros
Fuente única `rules/parametros/{ejercicio}.yaml` (tramos BINs, tipos por régimen, reserva, GF). No
hardcodear: actualizar ahí cada ejercicio (la plantilla y el cálculo lo leen).

## Caso de referencia
GIP 2024 (ETVE): 00552 = 11.068.602,43 · 00562 = 2.767.150,61 · 00621 = 2.486.355,42 (cuadra por fórmula).
