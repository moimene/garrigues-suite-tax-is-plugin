#!/usr/bin/env python3
"""Rellena la plantilla Garrigues `SyS_A3.xlsx` (Vault) con el canónico agrupado 4d.

Cierra la vía "xlsx sobre plantilla" (valoración 2026-06-12): la copia BRANDED de archivo
del expediente se genera rellenando la plantilla del Vault; el fichero de IMPORTACIÓN de A3
es OTRO (puro, sin marca: `agrupado_4d.xlsx`, lo emite EPC `motor_sys.escribir_a3_xlsx` —
A3 advierte que no se altere su estructura, por eso no se rellena sobre plantilla).

Entrada: `agrupado_4d.csv` del pipeline EPC (delimitador `;`, cabecera A3) o cualquier CSV
con esas 6 columnas. Sustituye el hueco «▶ PEGAR AQUI EL TEXTO DE HARVEY ◀» por las filas
y añade la línea de Comprobación (Σ Debe=Σ Haber · Σ deudor=Σ acreedor · nº cuentas).

Uso:
  python3 rellenar_plantilla_sys_a3.py --canonico agrupado_4d.csv \
      --plantilla ../distribucion_abogados/vault_release_v1/SyS_A3.xlsx \
      --output SyS_A3_GIP_2025.xlsx [--nif GIP --ejercicio 2025]
"""
from __future__ import annotations

import argparse
import csv

HUECO = "▶ PEGAR AQUI EL TEXTO DE HARVEY ◀"
TOL = 0.01


def leer_canonico(path: str) -> list:
    """Lee el agrupado 4d (CSV `;` con cabecera A3) → lista de filas tipadas."""
    filas = []
    with open(path, encoding="utf-8-sig") as fh:
        rd = csv.reader(fh, delimiter=";")
        for i, row in enumerate(rd):
            if i == 0 or len(row) < 6 or not row[0].strip().isdigit():
                continue
            num = lambda s: float(s) if str(s).strip() not in ("", "None") else None
            filas.append([row[0].strip(), row[1], num(row[2]), num(row[3]) or 0.0,
                          num(row[4]) or 0.0, num(row[5])])
    if not filas:
        raise ValueError(f"Sin filas de cuenta en {path}")
    return filas


def rellenar(plantilla: str, canonico: str, output: str, nif: str = "", ejercicio: str = "") -> dict:
    import openpyxl

    filas = leer_canonico(canonico)
    wb = openpyxl.load_workbook(plantilla)
    ws = wb.active

    hueco_row = next((r for r in range(1, ws.max_row + 1)
                      if str(ws.cell(row=r, column=1).value or "").strip() == HUECO), None)
    if hueco_row is None:
        raise ValueError(f"La plantilla no contiene el hueco «{HUECO}»")

    if nif or ejercicio:  # línea de identificación de la plantilla (fila 3)
        for r in range(1, hueco_row):
            v = str(ws.cell(row=r, column=1).value or "")
            if "NIF:" in v:
                ws.cell(row=r, column=1).value = (
                    f"NIF: {nif or '________'}    ·    Ejercicio: {ejercicio or '______'}"
                    "    ·    Suite Tax IS")

    # sustituir hueco + nota por las filas de datos
    n_borrar = 2 if "pegar aqui" in str(ws.cell(row=hueco_row + 1, column=1).value or "").lower() else 1
    ws.delete_rows(hueco_row, n_borrar)
    ws.insert_rows(hueco_row, len(filas) + 1)
    for i, f in enumerate(filas):
        for j, v in enumerate(f, start=1):
            cell = ws.cell(row=hueco_row + i, column=j)
            cell.value = v
            if j == 1:
                cell.number_format = "@"
            elif j >= 3 and isinstance(v, (int, float)):
                cell.number_format = "#,##0.00"

    td = sum(f[3] for f in filas)
    th = sum(f[4] for f in filas)
    sd = sum(f[2] for f in filas if f[2] is not None and f[2] > 0)
    sa = sum(-f[2] for f in filas if f[2] is not None and f[2] < 0)
    comp = ws.cell(row=hueco_row + len(filas), column=1)
    comp.value = (f"Comprobación: Σ Debe = Σ Haber = {td:,.2f} "
                  f"({'✅' if abs(td-th) <= TOL else '🔴 ' + format(td-th, ',.2f')}) · "
                  f"Σ deudor = {sd:,.2f} / Σ acreedor = {sa:,.2f} "
                  f"({'✅' if abs(sd-sa) <= TOL else '🔴'}) · {len(filas)} cuentas")

    wb.save(output)
    return dict(fichero=output, n_cuentas=len(filas), total_debe=round(td, 2),
                total_haber=round(th, 2), saldo_deudor=round(sd, 2), saldo_acreedor=round(sa, 2),
                cuadra=abs(td - th) <= TOL and abs(sd - sa) <= TOL)


def main():
    ap = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    ap.add_argument("--canonico", required=True, help="agrupado_4d.csv del pipeline EPC")
    ap.add_argument("--plantilla", required=True, help="SyS_A3.xlsx del Vault (branded)")
    ap.add_argument("--output", required=True)
    ap.add_argument("--nif", default="")
    ap.add_argument("--ejercicio", default="")
    a = ap.parse_args()
    r = rellenar(a.plantilla, a.canonico, a.output, a.nif, a.ejercicio)
    print(f"OK -> {r['fichero']} · {r['n_cuentas']} cuentas · cuadra={r['cuadra']}")


if __name__ == "__main__":
    main()
