#!/usr/bin/env python3
"""Motor de triaje del art. 15 LIS — clasificación por letra con scoring 0-100 (criterio del
abogado, 2026-06-11). Configuración data-driven en `rules/triaje/art15_triaje.yaml`.

Funciona como detector hijo del paraguas AJN-PERM-ART15 (que ya no asigna casillas):
  - clasificar(partida) -> letra ganadora, nivel (alta/media/baja), casilla, acción
    (autopoblar | proponer_validacion | incidencia) e incidencia estructurada si no hay letra.
  - evaluar_00413(...) -> controles del fallback "otras correcciones": términos prohibidos,
    bloqueo por específica probable (score >= 70 exige override senior), motivos codificados
    M1-M7 con condiciones de habilitación y materialidad.

Principios: prioridad de especialidad (15.c antes que 15.f, etc.), penalización por conflicto
(dos letras >= 65 con diferencia < 15 no autopueblan), caps por condiciones mínimas (sin país no
hay 15.g; sin soporte no hay 15.f en alta), y 00413 como salida residual trazada — nunca cómoda.

`partida` (dict): concepto (str), cuenta (str PGC), importe (float), contraparte (str|None),
pais_contraparte (ISO-2|None), soporte {tipo, emisor}|None, hechos {bool/str por hecho}.
"""
import os
import unicodedata

try:
    import yaml
except ImportError:  # pragma: no cover
    yaml = None

_TRIAJE = os.path.join(
    os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "rules", "triaje",
    "art15_triaje.yaml")


def _norm(s):
    return unicodedata.normalize("NFKD", str(s or "").lower()).encode("ascii", "ignore").decode()


def cargar_triaje(path=_TRIAJE) -> dict:
    if yaml is None or not os.path.exists(path):
        return {}
    with open(path, encoding="utf-8") as fh:
        return yaml.safe_load(fh) or {}


# --------------------------------------------------------------------------- hechos derivados
def _hechos(partida, cfg) -> dict:
    h = dict(partida.get("hechos") or {})
    soporte = partida.get("soporte") or {}
    pais = _norm(partida.get("pais_contraparte"))
    h.setdefault("autoridad_publica", soporte.get("emisor") == "autoridad_publica")
    h["pais_no_cooperativo"] = bool(h.get("pais_no_cooperativo")) or (
        partida.get("pais_contraparte") in (cfg.get("paises_no_cooperativos") or []))
    h["formalidad_sancionadora"] = bool(
        h.get("autoridad_publica")
        or soporte.get("tipo") in ("resolucion_sancionadora", "carta_pago", "providencia_apremio")
        or any(k in _norm(partida.get("concepto"))
               for k in ("multa", "sancion", "recargo ejecutivo", "recargo de apremio",
                          "recargo extemporanea")))
    h["soporte_o_validacion"] = bool(soporte.get("tipo")) or bool(h.get("validacion_humana"))
    h["grupo_y_finalidad"] = bool(h.get("grupo")) and bool(
        h.get("finalidad_adquisicion_participaciones"))
    h["subcategoria_15e_identificada"] = bool(h.get("subcategoria_15e"))
    h["prueba_operacion_analizada"] = h.get("prueba_operacion_analizada", False)
    return h


# --------------------------------------------------------------------------- scoring por letra
def puntuar_letra(partida, letra, cfg) -> dict:
    lc = cfg["letras"][letra]
    pesos = lc.get("pesos", {})
    concepto = _norm(partida.get("concepto"))
    cuenta = str(partida.get("cuenta") or "")
    soporte = partida.get("soporte") or {}
    hechos = _hechos(partida, cfg)

    score = 0.0
    fuerte = any(_norm(k) in concepto for k in lc.get("keywords", []))
    debil = any(_norm(k) in concepto for k in lc.get("keywords_debiles", []))
    if fuerte:
        score += pesos.get("concepto", 0)
    elif debil:
        score += pesos.get("concepto", 0) * 0.5
    if any(cuenta.startswith(str(c)) for c in lc.get("cuentas", [])):
        score += pesos.get("cuenta", 0)
    if soporte.get("tipo") in (lc.get("soporte_tipos") or []):
        score += pesos.get("soporte", 0)
    hp = lc.get("hechos_puntuan") or []
    if hp:
        presentes = sum(1 for x in hp if hechos.get(x))
        score += pesos.get("hechos", 0) * presentes / len(hp)

    # Caps por condiciones mínimas (la confianza se capa aunque el número sea alto)
    cap = None
    for regla_cap in lc.get("caps", []):
        if "si_falta" in regla_cap and not hechos.get(regla_cap["si_falta"]):
            cap = _peor_cap(cap, regla_cap["cap"])
        if regla_cap.get("si_solo_keyword_debil") and debil and not fuerte:
            cap = _peor_cap(cap, regla_cap["cap"])
    umb = cfg["umbrales"]
    if cap == "media":
        score = min(score, umb["alta"] - 1)
    elif cap == "baja":
        score = min(score, umb["media"] - 1)

    return {"letra": letra, "score": round(score, 1), "cap": cap,
            "keyword_fuerte": fuerte, "keyword_debil": debil}


def _peor_cap(actual, nuevo):
    orden = {None: 0, "media": 1, "baja": 2}
    return nuevo if orden[nuevo] > orden[actual] else actual


def _nivel(score, umb):
    if score >= umb["alta"]:
        return "alta"
    if score >= umb["media"]:
        return "media"
    return "baja"


# --------------------------------------------------------------------------- clasificación
def clasificar(partida, cfg=None) -> dict:
    """Devuelve letra/nivel/casilla/acción + incidencia estructurada cuando no hay letra fiable."""
    cfg = cfg or cargar_triaje()
    umb = cfg["umbrales"]
    hechos = _hechos(partida, cfg)
    res = sorted((puntuar_letra(partida, l, cfg) for l in cfg["letras"]),
                 key=lambda r: r["score"], reverse=True)
    top, segundo = res[0], (res[1] if len(res) > 1 else {"score": 0, "letra": None})

    # Bonus sin_conflicto: solo si la segunda no compite. El cap por condiciones mínimas
    # prevalece SIEMPRE sobre el bonus (la confianza capada no se recupera por falta de rivales).
    if segundo["score"] < umb["media"]:
        top["score"] = round(top["score"] +
                             cfg["letras"][top["letra"]]["pesos"].get("sin_conflicto", 0), 1)
        if top["cap"] == "media":
            top["score"] = min(top["score"], umb["alta"] - 1)
        elif top["cap"] == "baja":
            top["score"] = min(top["score"], umb["media"] - 1)

    conflicto = (top["score"] >= umb["conflicto_score_min"]
                 and segundo["score"] >= umb["conflicto_score_min"]
                 and (top["score"] - segundo["score"]) < umb["conflicto_diferencia_min"])

    # Desempate por especialidad: la letra preferente gana SI su condición de formalidad se da
    if conflicto:
        for a, b in ((top, segundo), (segundo, top)):
            prevalece = cfg["letras"][a["letra"]].get("prevalece_sobre") or []
            if b["letra"] in prevalece and a["cap"] is None:
                top, segundo, conflicto = a, b, False
                break

    nivel = _nivel(top["score"], umb)
    if conflicto:
        nivel = "media" if nivel == "alta" else nivel  # nunca autopoblar en conflicto

    lc = cfg["letras"][top["letra"]]
    out = {"scores": {r["letra"]: r["score"] for r in res}, "letra": None, "nivel": nivel,
           "casilla": None, "regla": None, "accion": "incidencia", "conflicto": conflicto,
           "conflicto_con": segundo["letra"] if conflicto else None}

    if nivel == "alta":
        out.update(letra=top["letra"], casilla=lc.get("casilla"), regla=lc.get("regla"),
                   accion="autopoblar")
    elif nivel == "media":
        out.update(letra=top["letra"], casilla=lc.get("casilla"), regla=lc.get("regla"),
                   accion="proponer_validacion")
    else:
        out["incidencia"] = {
            "regla_origen": "AJN-PERM-ART15",
            "estado": "pendiente_de_clasificacion",
            "criticidad": "roja" if abs(partida.get("importe") or 0) > 0 else "amarilla",
            "importe": partida.get("importe"),
            "cuenta": partida.get("cuenta"),
            "concepto": partida.get("concepto"),
            "motivo_duda": ("posible art. 15 sin letra identificable; "
                            f"mejores candidatas: {top['letra']} ({top['score']}), "
                            f"{segundo['letra']} ({segundo['score']})"),
            "opciones_resolucion": ["seleccionar_letra", "reclasificar_fuera_art15",
                                     "fallback_00413_validado", "marcar_deducible",
                                     "solicitar_soporte"],
            "casilla_propuesta": None,
        }
    return out


# --------------------------------------------------------------------------- fallback 00413
def evaluar_00413(partida, clasificacion, motivo, *, override_senior=False, validado_por=None,
                  bi_previa=None, cfg=None) -> dict:
    """Controles del fallback 00413: nunca sustituye a una letra específica acreditable."""
    cfg = cfg or cargar_triaje()
    fb = cfg["fallback_00413"]
    concepto = _norm(partida.get("concepto"))
    hechos = dict(partida.get("hechos") or {})
    scores = clasificacion.get("scores", {})
    top_score = max(scores.values()) if scores else 0
    controles, bloqueos = [], []

    if motivo not in fb["motivos"]:
        bloqueos.append(f"Motivo '{motivo}' no codificado (M1-M7 obligatorio).")

    # Control 2: términos prohibidos sin override
    for term, letra in (fb.get("terminos_prohibidos") or {}).items():
        if _norm(term) in concepto and not override_senior:
            bloqueos.append(f"Término '{term}' exige letra {letra} o revisión; 00413 directo "
                            "bloqueado sin override senior.")
            break

    # Control 1: especificidad obligatoria
    if top_score >= fb["bloqueo_si_especifica_score"]:
        if not override_senior or motivo == "M1":
            bloqueos.append(f"Existe específica probable (score {top_score}); 00413 requiere "
                            "override senior y motivo distinto de M1.")
        else:
            controles.append("override_senior_documentado")

    # Condiciones de habilitación por motivo
    cond = {
        "M1": top_score < 50,
        "M2": top_score < 65 or clasificacion.get("conflicto", False),
        "M3": bool(hechos.get("desglose_no_disponible")),
        "M4": bool(hechos.get("fundamento_alternativo")),
        "M5": bool(validado_por),
        "M6": bool(hechos.get("tratamiento_historico_validado")),
        "M7": bool(hechos.get("soporte_pendiente")),
    }
    if motivo in cond and not cond[motivo]:
        bloqueos.append(f"Condición mínima de {motivo} no acreditada.")

    # Control 5: materialidad
    importe = abs(partida.get("importe") or 0)
    pct = (importe / bi_previa) if bi_previa else None
    control_mat = "validacion_ordinaria"
    for tramo in fb["materialidad"]:
        tope, tope_pct = tramo.get("hasta"), tramo.get("pct_bi_hasta")
        dentro_importe = tope is None or importe <= tope
        dentro_pct = tope_pct is None or pct is None or pct <= tope_pct
        if dentro_importe and dentro_pct:
            control_mat = tramo["control"]
            break
    controles.append(control_mat)
    if control_mat == "revision_senior_o_bloqueo" and not (override_senior or validado_por):
        bloqueos.append("Importe material: requiere revisión senior / segunda validación.")

    permitido = not bloqueos
    memoria = None
    if permitido:
        memoria = ("Se registra en 00413 (otras correcciones) por no identificarse casilla "
                   f"específica aplicable [{motivo}: {fb['motivos'][motivo]}]. "
                   "Tratamiento validado manualmente." +
                   (f" Letra candidata descartada: {clasificacion.get('letra')} "
                    f"(score {top_score})." if clasificacion.get("letra") else ""))
    return {"permitido": permitido, "casilla": "00413" if permitido else None, "motivo": motivo,
            "controles": controles, "bloqueos": bloqueos, "memoria": memoria}


def metricas_abuso_00413(partidas_00413, total_ajustes_positivos, cfg=None) -> list:
    """Alertas de uso sistemático de 00413 (Control 6)."""
    cfg = cfg or cargar_triaje()
    fb = cfg["fallback_00413"]
    alertas = []
    importe_00413 = sum(abs(p.get("importe") or 0) for p in partidas_00413)
    if total_ajustes_positivos and importe_00413 / total_ajustes_positivos > \
            fb["metricas_abuso"]["pct_max_importe_ajustes"]:
        alertas.append({"codigo": "ABUSO-00413-IMPORTE", "severidad": "a_confirmar",
                        "detalle": f"{importe_00413:.2f} EUR en 00413 supera el "
                                   f"{fb['metricas_abuso']['pct_max_importe_ajustes']:.0%} "
                                   "de los ajustes positivos."})
    prohibidos = fb.get("terminos_prohibidos") or {}
    con_kw = [p for p in partidas_00413
              if any(_norm(t) in _norm(p.get("concepto")) for t in prohibidos)]
    if len(con_kw) > fb["metricas_abuso"]["max_partidas_con_keywords"]:
        alertas.append({"codigo": "ABUSO-00413-KEYWORDS", "severidad": "a_confirmar",
                        "detalle": f"{len(con_kw)} partidas en 00413 contienen términos de "
                                   "letras específicas del art. 15."})
    return alertas


if __name__ == "__main__":
    import json
    import sys
    if "--self-test" in sys.argv:
        c = clasificar({"concepto": "Sanción AEAT modelo 200", "cuenta": "678", "importe": 1000,
                        "soporte": {"tipo": "resolucion_sancionadora",
                                    "emisor": "autoridad_publica"}})
        print(json.dumps(c, ensure_ascii=False, indent=1)[:400])
        raise SystemExit(0 if c["accion"] == "autopoblar" and c["casilla"] == "01815" else 1)
    print("Uso: python3 motor_triaje_art15.py --self-test")
