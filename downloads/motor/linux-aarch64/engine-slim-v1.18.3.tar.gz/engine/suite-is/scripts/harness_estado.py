"""harness_estado.py — helpers to read the 00_Harness sheet and gate exports.

Functions
---------
read_harness_state(xlsx_path) -> dict
    Opens the workbook at xlsx_path, reads the sheet '00_Harness',
    and returns {colA: colB} for every row where colA is non-empty.

is_exportable(state: dict) -> bool
    Returns True only when:
      - H_sem_rojo           == 0  (no blocking semaphores)
      - H_sem_amarillo_impacto == 0  (no impactful amber issues)
      - H_validada           in {"sí", "si", "true"}  (lawyer has signed off)
    Values may arrive as strings or numbers; the function handles both.
"""

from __future__ import annotations

from typing import Any


def read_harness_state(xlsx_path: str) -> dict:
    """Read the '00_Harness' sheet and return a {key: value} dict."""
    import openpyxl  # local import keeps the module importable without openpyxl at top-level check

    wb = openpyxl.load_workbook(xlsx_path, data_only=True)
    ws = wb["00_Harness"]

    state: dict[str, Any] = {}
    for row in ws.iter_rows(min_row=1, values_only=True):
        key = row[0]
        if key is None or str(key).strip() == "":
            continue
        value = row[1] if len(row) > 1 else None
        state[str(key).strip()] = value

    return state


def is_exportable(state: dict) -> bool:
    """Return True only if the state passes all gating conditions."""
    rojo = int(state.get("H_sem_rojo", 0) or 0)
    amarillo = int(state.get("H_sem_amarillo_impacto", 0) or 0)
    validada_raw = str(state.get("H_validada", "no") or "no").strip().lower()

    if rojo != 0:
        return False
    if amarillo != 0:
        return False
    if validada_raw not in ("sí", "si", "true"):
        return False
    return True
