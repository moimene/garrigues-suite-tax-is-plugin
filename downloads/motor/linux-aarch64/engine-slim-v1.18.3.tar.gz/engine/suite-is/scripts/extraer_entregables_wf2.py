#!/usr/bin/env python3
"""extraer_entregables_wf2.py — Plan B: del Word del Workflow WF-2 a 3 entregables limpios.

Causa raíz que motiva este script
─────────────────────────────────
Los Workflow Agents de Harvey emiten TEXTO en el response, no archivos .docx/.xlsx
separados. Frases tipo "El documento Memoria_Tecnica_IS_2025_GIP.docx es descargable"
en el response del workflow son prosa alucinada — no existe tal fichero. Lo que sí
existe es el Word del workflow completo (Export desde Harvey) con TODO el contenido
embebido: mapping, memoria, gating, observaciones.

Este script extrae de ese Word ÚNICO las 3 piezas independientes que el abogado
necesita para entregar al cliente:

  1. Modelo_200_{NIF}_{ejercicio}.xlsx
       · Hoja "Modelo_200_Casilla_Importe" → vista limpia casilla|concepto|importe
       · Hoja "Mapping_Detallado_Normativa" → con origen del dato y referencia normativa

  2. Liquidacion_{NIF}_{ejercicio}.docx
       · Conciliación resultado contable → base imponible (14 pasos)
       · Tabla de inputs B2:B10 actualizados
       · Tabla de fórmulas B12:B17 recalculadas

  3. Memoria_Tecnica_{NIF}_{ejercicio}.docx
       · Las 8 sub-secciones de la memoria técnica (Banner Harness, Resumen ajustes,
         Fundamentación jurídica, Tabla de conciliación, Detalle BINs, Deducciones,
         Recomendaciones, Espacio firma) + anexo

El script es 100% determinista: solo depende del .docx de entrada y de las anclas
de headings que el prompt de WF-2 garantiza.

Uso (CLI)
─────────
    python3 extraer_entregables_wf2.py \
        --input "WF2-Output-completo_425292789.docx" \
        --output-dir entregables/ \
        --nif B00000000 --ejercicio 2025

Uso (programático)
──────────────────
    from extraer_entregables_wf2 import extraer_todo
    extraer_todo("WF2.docx", "entregables/", nif="B00000000", ejercicio=2025)

Dependencias: python-docx, openpyxl (ya instaladas en el entorno).
"""

import argparse
import re
import sys
from pathlib import Path

from docx import Document
from docx.shared import Cm
import openpyxl
from openpyxl.styles import Font, PatternFill, Alignment


# ── helpers ──────────────────────────────────────────────────────────────────

CITATION_MARK = re.compile(r"\s*\[\d+\]")
"""Marcadores de citas inline que Harvey inserta en el Word exportado (ej. ' [42]')."""


def clean_text(s):
    """Quita marcadores de citas '[N]' del texto y normaliza espacios."""
    if not isinstance(s, str):
        return s
    return CITATION_MARK.sub("", s).strip()


def _find_table_by_header(tables, expected_headers, min_match=2):
    """Localiza una tabla cuya primera fila contiene los encabezados esperados.

    expected_headers: lista de strings que deben aparecer en la fila 0 (case-insensitive,
                      contains-match, no exact).
    min_match: mínimo nº de headers que deben encontrarse para que la tabla cuente.
    """
    for ti, table in enumerate(tables):
        if not table.rows:
            continue
        headers = [c.text.strip().lower() for c in table.rows[0].cells]
        joined = " | ".join(headers)
        matches = sum(1 for h in expected_headers if h.lower() in joined)
        if matches >= min_match:
            return ti, table
    return None, None


def _copy_table_to_docx(src_table, doc, max_cols=None, style="Light Grid Accent 1"):
    """Copia una tabla del docx fuente al docx destino, limpiando citas."""
    rows = list(src_table.rows)
    if not rows:
        return
    n_cols = len(rows[0].cells) if max_cols is None else max_cols
    out = doc.add_table(rows=len(rows), cols=n_cols)
    out.style = style
    for ri, row in enumerate(rows):
        cells = [clean_text(c.text) for c in row.cells]
        for ci, val in enumerate(cells[:n_cols]):
            out.cell(ri, ci).text = val or ""
            if ri == 0:
                for run in out.cell(ri, ci).paragraphs[0].runs:
                    run.bold = True
    return out


def _set_margins(doc, cm=2.0):
    sec = doc.sections[0]
    sec.left_margin = Cm(cm)
    sec.right_margin = Cm(cm)
    sec.top_margin = Cm(cm)
    sec.bottom_margin = Cm(cm)


def _parse_amount(s):
    """Intenta convertir un importe en string ('146.095.463,47' o '−1.650.000,00')
    a float; si no es posible (ej. '25%' o vacío), devuelve el string original."""
    if not isinstance(s, str):
        return s
    raw = s.replace("−", "-").replace("€", "").replace("%", "").strip()
    raw = raw.replace(".", "").replace(",", ".")
    try:
        return float(raw)
    except (ValueError, AttributeError):
        return s.strip()


# ── extractores por entregable ───────────────────────────────────────────────

def build_modelo_200_xlsx(src, output_path, nif="", ejercicio=""):
    """Entregable 1: Modelo_200_{NIF}_{ejercicio}.xlsx con 2 hojas."""
    tables = list(src.tables)
    wb = openpyxl.Workbook()

    header_font = Font(bold=True, color="FFFFFF", size=11)
    header_fill = PatternFill("solid", fgColor="2F5496")
    hdr_align = Alignment(horizontal="center", vertical="center", wrap_text=True)
    cell_align = Alignment(vertical="center", wrap_text=True)
    bold = Font(bold=True, size=11)

    # ── Hoja 1: vista casilla|concepto|importe ─────────────────────────────
    ws1 = wb.active
    ws1.title = "Modelo_200_Casilla_Importe"
    for col, text in enumerate(["Casilla", "Concepto", "Importe (€)"], 1):
        c = ws1.cell(row=1, column=col, value=text)
        c.font = header_font
        c.fill = header_fill
        c.alignment = hdr_align
    ws1.column_dimensions["A"].width = 12
    ws1.column_dimensions["B"].width = 55
    ws1.column_dimensions["C"].width = 20

    # La tabla buena es la que tiene SOLO 3 cols: casilla, concepto, importe
    ti, table_vista = _find_table_by_header(
        tables, ["casilla", "concepto", "importe"], min_match=3
    )
    # Si hay varias, prefiere la más corta (la vista limpia es más sintética que
    # el mapping detallado de 5 columnas).
    candidates = [
        (i, t) for i, t in enumerate(tables)
        if t.rows
        and len(t.rows[0].cells) == 3
        and "casilla" in t.rows[0].cells[0].text.strip().lower()
    ]
    if candidates:
        ti, table_vista = candidates[0]

    if table_vista is None:
        raise RuntimeError("No se encontró la tabla 'Casilla|Concepto|Importe' en el Word.")

    out_row = 2
    for ri, row in enumerate(table_vista.rows):
        if ri == 0:
            continue
        cells = [clean_text(c.text) for c in row.cells]
        if len(cells) < 3 or not cells[0]:
            continue
        casilla, concepto, importe = cells[0], cells[1], cells[2]
        ws1.cell(row=out_row, column=1, value=casilla)
        ws1.cell(row=out_row, column=2, value=concepto).alignment = cell_align
        num = _parse_amount(importe)
        cell_imp = ws1.cell(row=out_row, column=3, value=num)
        if isinstance(num, float):
            cell_imp.number_format = "#,##0.00"
        # Negritas para las casillas clave del Modelo 200
        if casilla in ("00552", "00562", "00621"):
            for col in range(1, 4):
                ws1.cell(row=out_row, column=col).font = bold
        out_row += 1

    # ── Hoja 2: mapping detallado con normativa ────────────────────────────
    ws2 = wb.create_sheet("Mapping_Detallado_Normativa")
    headers = ["Casilla", "Concepto", "Importe", "Origen_dato", "Referencia_normativa"]
    for col, text in enumerate(headers, 1):
        c = ws2.cell(row=1, column=col, value=text)
        c.font = header_font
        c.fill = header_fill
        c.alignment = hdr_align
    for col, width in enumerate([12, 40, 18, 30, 35], 1):
        ws2.column_dimensions[openpyxl.utils.get_column_letter(col)].width = width

    ti, table_map = _find_table_by_header(
        tables, ["casilla", "concepto", "importe", "origen", "normativa"], min_match=4
    )
    if table_map is not None:
        for ri, row in enumerate(table_map.rows):
            if ri == 0:
                continue
            cells = [clean_text(c.text) for c in row.cells][:5]
            if not cells or not cells[0]:
                continue
            for ci, val in enumerate(cells, 1):
                c = ws2.cell(row=ri + 1, column=ci, value=val)
                c.alignment = cell_align

    wb.save(output_path)
    return output_path


def build_liquidacion_docx(src, output_path, nif="", ejercicio=""):
    """Entregable 2: Liquidacion_{NIF}_{ejercicio}.docx con la conciliación + B2:B17."""
    tables = list(src.tables)
    doc = Document()
    _set_margins(doc)

    title = "Liquidación definitiva IS"
    if ejercicio:
        title += f" {ejercicio}"
    if nif:
        title += f" — NIF {nif}"
    doc.add_heading(title, level=0)

    # Conciliación RC → BI (15 filas: header + 14 pasos)
    ti, t_conc = _find_table_by_header(
        tables, ["paso", "concepto", "referencia", "importe"], min_match=3
    )
    if t_conc is not None:
        doc.add_heading("Conciliación resultado contable → base imponible", level=1)
        _copy_table_to_docx(t_conc, doc, max_cols=4)

    # Inputs B2:B10 (header: celda, concepto, valor anterior, valor nuevo, fuente)
    ti, t_inputs = _find_table_by_header(
        tables, ["celda", "concepto", "valor anterior", "valor nuevo"], min_match=3
    )
    if t_inputs is not None:
        doc.add_heading("Inputs B2:B10 actualizados (03_Liquidación)", level=1)
        _copy_table_to_docx(t_inputs, doc, max_cols=5)

    # Fórmulas B12:B17 (header: celda, concepto, valor anterior, valor recalculado, fórmula)
    ti, t_form = _find_table_by_header(
        tables, ["celda", "valor recalculado", "fórmula"], min_match=2
    )
    if t_form is not None:
        doc.add_heading("Fórmulas B12:B17 recalculadas (03_Liquidación)", level=1)
        _copy_table_to_docx(t_form, doc, max_cols=5)

    doc.save(output_path)
    return output_path


# Headings que delimitan la sección de memoria técnica (definidos en el prompt de WF-2)
MEMORIA_START = "1. Banner Harness"
MEMORIA_END_CANDIDATES = ("1. EXCEL-ESTADO v2", "References", "Citations")


def build_memoria_docx(src, output_path, nif="", ejercicio=""):
    """Entregable 3: Memoria_Tecnica_{NIF}_{ejercicio}.docx con las 8 sub-secciones."""
    paras = list(src.paragraphs)
    tables = list(src.tables)
    doc = Document()
    _set_margins(doc)

    title = "Memoria Técnica Fiscal — Impuesto sobre Sociedades"
    if ejercicio:
        title += f" {ejercicio}"
    doc.add_heading(title, level=0)
    if nif:
        doc.add_paragraph(f"NIF {nif} · Régimen General").italic = True
    doc.add_paragraph(
        "Elaborada con base en el Excel-estado y respuestas del cliente del expediente."
    ).italic = True

    # Localizar anclas
    start = next(
        (i for i, p in enumerate(paras) if MEMORIA_START in p.text), None
    )
    end = next(
        (
            i
            for i, p in enumerate(paras)
            if any(anchor in p.text for anchor in MEMORIA_END_CANDIDATES)
        ),
        None,
    )

    if start is None:
        raise RuntimeError(
            f"No se encontró el ancla de inicio '{MEMORIA_START}' en el Word."
        )
    if end is None or end <= start:
        end = len(paras)

    # Copiar paragraphs en el rango
    for i in range(start, end):
        p = paras[i]
        text = clean_text(p.text)
        if not text:
            continue
        if p.style.name.startswith("Heading"):
            try:
                level = int(p.style.name[-1])
            except ValueError:
                level = 2
            doc.add_heading(text, level=level)
        else:
            doc.add_paragraph(text)

    # Anexo: tabla de conciliación (útil para sustentar la memoria)
    ti, t_conc = _find_table_by_header(
        tables, ["paso", "concepto", "referencia", "importe"], min_match=3
    )
    if t_conc is not None:
        doc.add_page_break()
        doc.add_heading(
            "Anexo: Tabla de conciliación resultado contable → base imponible", level=1
        )
        _copy_table_to_docx(t_conc, doc, max_cols=4)

    doc.save(output_path)
    return output_path


# ── orquestación + CLI ───────────────────────────────────────────────────────

def extraer_todo(input_docx, output_dir, nif="", ejercicio=""):
    """Ejecuta la extracción de los 3 entregables.

    Args:
        input_docx: ruta al Word exportado de WF-2.
        output_dir: directorio donde escribir los 3 entregables.
        nif: NIF del cliente (se usa en los nombres y dentro de los documentos).
        ejercicio: año fiscal (ej. 2025).

    Returns:
        dict con las 3 rutas generadas.
    """
    input_path = Path(input_docx)
    if not input_path.exists():
        raise FileNotFoundError(input_docx)

    output_dir = Path(output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)

    src = Document(str(input_path))
    suffix = "_".join(filter(None, [nif, str(ejercicio) if ejercicio else ""]))
    suffix = f"_{suffix}" if suffix else ""

    out = {
        "modelo_200": output_dir / f"Modelo_200{suffix}.xlsx",
        "liquidacion": output_dir / f"Liquidacion{suffix}.docx",
        "memoria": output_dir / f"Memoria_Tecnica{suffix}.docx",
    }

    build_modelo_200_xlsx(src, out["modelo_200"], nif=nif, ejercicio=ejercicio)
    build_liquidacion_docx(src, out["liquidacion"], nif=nif, ejercicio=ejercicio)
    build_memoria_docx(src, out["memoria"], nif=nif, ejercicio=ejercicio)

    return out


def _cli():
    ap = argparse.ArgumentParser(
        description="Extrae 3 entregables independientes del Word de WF-2 (Plan B)."
    )
    ap.add_argument(
        "--input",
        "-i",
        required=True,
        help="Ruta al Word exportado de WF-2 (TAX-ESP IS Fase 4 ... .docx).",
    )
    ap.add_argument(
        "--output-dir",
        "-o",
        default=".",
        help="Directorio donde escribir los 3 entregables (default: cwd).",
    )
    ap.add_argument("--nif", default="", help="NIF del cliente (ej. B00000000).")
    ap.add_argument(
        "--ejercicio", default="", help="Año fiscal (ej. 2025)."
    )
    args = ap.parse_args()

    try:
        out = extraer_todo(args.input, args.output_dir, nif=args.nif, ejercicio=args.ejercicio)
    except Exception as e:
        print(f"❌ Error: {e}", file=sys.stderr)
        sys.exit(1)

    print("✅ Entregables generados:")
    for key, path in out.items():
        size = Path(path).stat().st_size
        print(f"  · {path} ({size:,} bytes)")


if __name__ == "__main__":
    _cli()
