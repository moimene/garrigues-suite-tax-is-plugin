#!/usr/bin/env python3
"""DEPRECADO — no usar. El Excel-estado lo genera `construir_plantilla.py`
(defined names PAR_*/H_* + librería `formulas`). Este archivo se dejó como stub
para evitar duplicar la fuente de la verdad del cálculo."""
import sys
if __name__ == "__main__":
    sys.exit("DEPRECADO: usa construir_plantilla.py")
