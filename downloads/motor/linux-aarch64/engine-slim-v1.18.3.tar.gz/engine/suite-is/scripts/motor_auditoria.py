#!/usr/bin/env python3
"""Motor de auditoría fiscal (D11): recorre un mayor/canónico y detecta, de forma DETERMINISTA,
situaciones que disparan revisión fiscal según el catálogo de reglas (`suite-is/rules/catalogo`).

No inventa cifras: cada hallazgo cita la(s) cuenta(s) origen y su importe contable. La `condicion` de
cada regla (prosa, la evalúa el abogado) se APROXIMA aquí por PATRONES DE CUENTA PGC (capa máquina);
el criterio fino y la confirmación con el cliente siguen siendo del abogado (criticidad del catálogo).

Uso (CLI):  python3 motor_auditoria.py --self-test
"""
import glob
import os
from decimal import Decimal, ROUND_HALF_UP

try:
    import yaml
except ImportError:  # pragma: no cover
    yaml = None

RULES_DIR_DEFAULT = os.path.join(
    os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "rules", "catalogo"
)
# Catálogo de reglas de AUDITORÍA (Fase 4 / EPIC C): reglas con bloque `deteccion` + `accion`.
# Se carga JUNTO al catálogo de la declaración; la capa data-driven (paso 4) las recorre todas.
RULES_AUDITORIA_DIR = os.path.join(
    os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "rules", "auditoria"
)

CRIT_EMOJI = {"bloqueante": "🔴", "a_confirmar": "🟡", "verde": "🟢", "informativo": "⚪"}

# Detectores por patrón de cuenta PGC -> id de regla del catálogo.
DETECTORES = [
    ("RC-IS-6300", ("630",)),               # Impuesto sobre beneficios (corrección 00301, no deducible)
    ("AJN-PERM-ART15", ("678",)),           # gastos excepcionales -> revisar no deducibles art.15
    ("AJN-EXEN-ART21-DIV", ("760", "761")), # ingresos de participaciones -> posible exención art.21
    ("BIN-COMP", ("121",)),                 # resultados negativos ej. anteriores -> compensación BINs
]
# Detectores agregados (suma de un grupo supera un umbral).
DETECTORES_GRUPO = [
    ("GF-ART16", ("66",), 1_000_000.0),     # gastos financieros del grupo 66 > 1M -> limitación art.16
]

# Ids ya cubiertos por los detectores hardcoded: la capa data-driven NO los re-emite (dedup por id),
# de modo que añadir un bloque `deteccion` a una de estas reglas nunca produce hallazgos duplicados.
_HARDCODED_IDS = {"CUADRE-BAL"} | {rid for rid, _ in DETECTORES} | {rid for rid, _, _ in DETECTORES_GRUPO}


def cargar_catalogo(rules_dir=RULES_DIR_DEFAULT, extra_dirs=None) -> dict:
    """Indexa por `id` las reglas YAML de `rules_dir` y de cada carpeta de `extra_dirs`
    (p. ej. el catálogo de auditoría). Carpetas inexistentes se ignoran (glob vacío)."""
    if yaml is None:
        return {}
    reglas = {}
    for d in [rules_dir, *(extra_dirs or [])]:
        for f in sorted(glob.glob(os.path.join(d, "*.yaml"))):
            with open(f, encoding="utf-8") as fh:
                data = yaml.safe_load(fh) or []
            for r in data if isinstance(data, list) else []:
                if isinstance(r, dict) and r.get("id"):
                    reglas[r["id"]] = r
    return reglas


def _num(x) -> float:
    """Importe -> float con la MISMA convención que la ingesta (motor_sys.num): formato español
    (coma o punto decimal; el último separador manda). Robusto y FAIL-SAFE: None/''/no-numérico -> 0.0,
    nunca lanza. Así la auditoría es consistente con el canónico y un saldo mal tecleado no rompe la ruta
    ni inventa un número por un `float()` crudo (que reventaría con '1.000.000,50')."""
    if x is None or x == "":
        return 0.0
    if isinstance(x, (int, float)):
        return float(x)
    t = str(x).strip().replace("€", "").replace(" ", "").replace("\xa0", "")
    if t in ("", "-", "--"):
        return 0.0
    if "," in t and "." in t:                       # ambos: el último separador es el decimal
        t = t.replace(".", "").replace(",", ".") if t.rfind(",") > t.rfind(".") else t.replace(",", "")
    elif "," in t:                                   # solo coma -> decimal
        t = t.replace(",", ".")
    try:
        return float(t)
    except ValueError:
        return 0.0


def _cent(x) -> float:
    return float(Decimal(str(_num(x))).quantize(Decimal("0.01"), rounding=ROUND_HALF_UP))


def _saldo(c) -> float:
    return _num(c.get("sf", c.get("saldo", 0)))


def _detalle_cuentas(cuentas) -> list:
    """Trazabilidad por cuenta de un hallazgo: cuenta + importe + provenance (_fuente), si la hay.
    Garantiza 'nunca inventar': la suma de `importe_contable` del desglose es EXACTAMENTE el
    `importe_contable` (de cabecera) del hallazgo, porque ambos usan |saldo| por cuenta. Se conserva
    además el `saldo` con signo (deudor>0 / acreedor<0) como información para el abogado."""
    return [
        {"cuenta": str(c.get("cuenta")), "importe_contable": _cent(abs(_saldo(c))),
         "saldo": _cent(_saldo(c)), "_fuente": c.get("_fuente")}
        for c in cuentas
    ]


# Módulos del checklist DD que CONCENTRAN las actas de inspección (~80% de la materialidad, según la
# síntesis del model council): gastos no deducibles (03), gastos financieros (06), operaciones vinculadas
# (07), BINs/reservas (10) y deducciones (11). Sus hallazgos pesan más en la priorización.
MODULOS_ALTA_MATERIALIDAD = {"03", "06", "07", "10", "11"}
_PROB_W = {"alta": 1.0, "media": 0.6, "baja": 0.3}


def _prioridad(criticidad, modulo, probabilidad, importe):
    """Prioridad DETERMINISTA del hallazgo (0-100) = probabilidad de regularización × (materialidad del
    módulo + banda de importe). Permite ordenar la matriz de riesgos. Los bloqueos estructurales
    (criticidad bloqueante: cuadre / datos insuficientes) van siempre primero."""
    if criticidad == "bloqueante":
        return "alta", 100.0
    prob_w = _PROB_W.get(probabilidad or "media", 0.6)
    mat_w = 1.0 if (modulo in MODULOS_ALTA_MATERIALIDAD) else 0.7
    imp = abs(importe or 0)
    imp_w = 1.0 if imp >= 1_000_000 else (0.7 if imp >= 100_000 else 0.4)
    score = round(100 * prob_w * (0.5 * mat_w + 0.5 * imp_w), 1)
    label = "alta" if score >= 70 else ("media" if score >= 45 else "baja")
    return label, score


def _peso_prob(f) -> float:
    """Peso de probabilidad para la exposición estimada; un bloqueante sin probabilidad pesa como alta."""
    prob = f.get("probabilidad_regularizacion") or ("alta" if f.get("criticidad") == "bloqueante" else "media")
    return _PROB_W.get(prob, 0.6)


def _resumen_ejecutivo(findings, top_n=5) -> dict:
    """Cabecera del informe (matriz de riesgos): EXPOSICIÓN ESTIMADA = Σ importe × peso de probabilidad
    (magnitud de PRIORIZACIÓN, no una cuota: el importe de un aviso es volumen a revisar), conteos por
    prioridad/tipo y el top-N de hallazgos por prioridad."""
    exposicion = _cent(sum(f["importe_contable"] * _peso_prob(f) for f in findings))
    top = sorted(
        findings,
        key=lambda f: (f.get("criticidad") != "bloqueante", -f.get("prioridad_score", 0.0), f.get("id", "")),
    )[:top_n]
    return {
        "exposicion_estimada": exposicion,
        "por_prioridad": {p: sum(1 for f in findings if f.get("prioridad") == p) for p in ("alta", "media", "baja")},
        "por_tipo": {t: sum(1 for f in findings if f.get("tipo") == t) for t in ("ajuste", "aviso")},
        "top": [
            {"id": f["id"], "titulo": f["titulo"], "prioridad": f.get("prioridad"), "tipo": f.get("tipo"),
             "semaforo": f.get("semaforo"), "importe_contable": f["importe_contable"]}
            for f in top
        ],
        "nota": "Exposición estimada = Σ importe × peso de probabilidad (alta 1,0 · media 0,6 · baja 0,3). "
                "Es una magnitud de PRIORIZACIÓN, no una cuota; los importes de avisos son volumen a revisar.",
    }


def _finding(rule_id, regla, cuentas, importe, detalle=None, cuentas_detalle=None) -> dict:
    crit = (regla or {}).get("criticidad_default", "a_confirmar")
    detalle_cuentas = cuentas_detalle or []
    # Identidad por CONSTRUCCIÓN (adversarial MED): con desglose por cuenta, la cabecera es la SUMA de los
    # céntimos YA redondeados por cuenta, NO el redondeo de la suma cruda — así importe_contable ==
    # Σ cuentas_detalle.importe_contable incluso con saldos sub-céntimo (p. ej. '1.000,005' -> 1000.01).
    importe_cab = (
        _cent(sum(d["importe_contable"] for d in detalle_cuentas)) if detalle_cuentas else _cent(importe)
    )
    out = {
        "id": rule_id,
        "titulo": (regla or {}).get("titulo", rule_id),
        "dominio": (regla or {}).get("dominio"),
        "signo": (regla or {}).get("signo", "neutro"),
        "casillas": (regla or {}).get("casillas", []),
        "criticidad": crit,
        "semaforo": CRIT_EMOJI.get(crit, "🟡"),
        "fundamento": (regla or {}).get("fundamento") or (regla or {}).get("ref"),
        "accion": (regla or {}).get("accion"),                      # Fase 4 / C2: qué hacer con el hallazgo
        "cuentas": cuentas,
        "cuentas_detalle": detalle_cuentas,                        # Fase 4 / C1: traza cuenta->importe->fichero
        # Contrato de trazabilidad (Fase 4): True => importe_contable == Σ cuentas_detalle.importe_contable
        # (hallazgo por patrón de cuenta). False => hallazgo ESTRUCTURAL/de calidad de dato (cuadre, datos
        # insuficientes): su importe es una métrica agregada, no la suma de saldos de cuentas; va en `detalle`.
        "traza_cuenta": bool(detalle_cuentas),
        "importe_contable": importe_cab,
        "requiere_confirmacion": (regla or {}).get("requiere_confirmacion", []),
        "posicion_estandar": (regla or {}).get("posicion_estandar"),
        # --- Capa de REVISIÓN (checklist DD + model council): el motor no solo emite AJUSTES con importe,
        #     también AVISOS/ALERTAS de lógica de revisión. `tipo`: ajuste = importe es un ajuste real;
        #     aviso = alerta de revisión (importe = volumen a revisar, NO un ajuste afirmado); control =
        #     verificación estructural (cuadre/datos). Campos adicionales aditivos (opcionales). ---
        "tipo": (regla or {}).get("tipo", "ajuste"),
        "modulo": (regla or {}).get("modulo"),
        "objetivo": (regla or {}).get("objetivo"),
        "procedimiento": (regla or {}).get("procedimiento"),
        "red_flags": (regla or {}).get("red_flags", []),
        "documentos_requeridos": (regla or {}).get("documentos_requeridos", []),
        "probabilidad_regularizacion": (regla or {}).get("probabilidad_regularizacion"),
        "requiere_revision_humana": bool((regla or {}).get("requiere_revision_humana", False)),
        # Doctrina/jurisprudencia CURADA del checklist (nunca generada por el motor): se cita literal y se
        # marca para verificar contra fuente oficial (CENDOJ/TEAC) — barrera anti-alucinación del council.
        "referencias": (regla or {}).get("referencias", []),
    }
    out["prioridad"], out["prioridad_score"] = _prioridad(
        crit, out["modulo"], out["probabilidad_regularizacion"], out["importe_contable"])
    if detalle:
        out["detalle"] = detalle
    return out


def finding_datos_insuficientes(motivo, ficheros=None) -> dict:
    """Hallazgo BLOQUEANTE (🔴) de CALIDAD DE DATO: la auditoría no es fiable (sin filas auditables o con
    ficheros que no se pudieron procesar). FAIL-CLOSED: evita que un análisis sobre datos vacíos/corruptos
    se presente como una auditoría limpia (0 hallazgos). Es estructural -> traza_cuenta False."""
    f = _finding(
        "AUD-DATOS-INSUFICIENTES",
        {"titulo": "Datos insuficientes o no procesables para auditar",
         "dominio": "datos", "criticidad_default": "bloqueante",
         "fundamento": "Control de calidad de dato (previo a cualquier conclusión fiscal)",
         "accion": "Revisar los mayores subidos (formato/errores) y reejecutar la auditoría. Un análisis "
                   "sobre datos vacíos o corruptos NO equivale a ausencia de contingencias."},
        [], 0, detalle=motivo,
    )
    if ficheros:
        f["ficheros_con_error"] = ficheros
    return f


def anteponer_hallazgo(aud, finding) -> dict:
    """Antepone un hallazgo y RECOMPUTA resumen/total/resumen_ejecutivo.

    Se usa para inyectar un bloqueo de datos sin perder coherencia en la matriz de riesgos. Devuelve un
    dict nuevo (no muta el original).
    """
    aud = dict(aud)
    aud["hallazgos"] = [finding, *aud.get("hallazgos", [])]
    resumen = {e: 0 for e in CRIT_EMOJI.values()}
    for h in aud["hallazgos"]:
        resumen[h["semaforo"]] = resumen.get(h["semaforo"], 0) + 1
    aud["resumen"] = resumen
    aud["total"] = len(aud["hallazgos"])
    aud["resumen_ejecutivo"] = _resumen_ejecutivo(aud["hallazgos"])
    return aud


def _aplica(regla, regimen) -> bool:
    if not regla:
        return True
    regimenes = regla.get("aplica_si", {}).get("regimenes")
    return (not regimenes) or (regimen in regimenes)


def _signo_ok(c, signo) -> bool:
    """Filtro opcional por signo del saldo (deudor>0 / acreedor<0); sin `signo` no filtra."""
    if not signo:
        return True
    s = _saldo(c)
    if signo == "deudor":
        return s > 0
    if signo == "acreedor":
        return s < 0
    return True


def _detectar_reglas_datos(canonico, catalogo, regimen) -> list:
    """Capa DATA-DRIVEN del catálogo completo (Fase 4 / C1): recorre TODAS las reglas que llevan un
    bloque `deteccion` (patrón de cuenta PGC) y emite un hallazgo por cada una que case sobre el
    canónico. Dedup: omite los ids ya cubiertos por los detectores hardcoded. Determinista (orden por id).

    Bloque `deteccion`: {tipo: prefijo|prefijo_umbral, prefijos: [..], umbral?: N, signo?: deudor|acreedor}.
    """
    findings = []
    for rid, regla in sorted(catalogo.items()):
        if rid in _HARDCODED_IDS:
            continue
        det = (regla or {}).get("deteccion")
        if not isinstance(det, dict) or not _aplica(regla, regimen):
            continue
        prefijos = tuple(str(p) for p in det.get("prefijos", []) if str(p))
        if not prefijos:
            continue
        signo = det.get("signo")
        cuentas = [c for c in canonico if str(c.get("cuenta", "")).startswith(prefijos) and _signo_ok(c, signo)]
        if not cuentas:
            continue
        total = sum(abs(_saldo(c)) for c in cuentas)
        if det.get("tipo") == "prefijo_umbral" and total <= float(det.get("umbral", 0) or 0):
            continue
        findings.append(_finding(
            rid, regla, [str(c.get("cuenta")) for c in cuentas], total,
            cuentas_detalle=_detalle_cuentas(cuentas),
        ))
    return findings


def auditar(canonico, ejercicio="2024", regimen="general", rules_dir=RULES_DIR_DEFAULT) -> dict:
    """canónico [{cuenta, sf/saldo, debe, haber, ...}] -> hallazgos de auditoría por criticidad."""
    catalogo = cargar_catalogo(rules_dir, extra_dirs=[RULES_AUDITORIA_DIR])
    # Robustez (ruta read-only): descarta filas no-dict (None/str/números sueltos) en vez de reventar
    # la ruta con un 500; el análisis sigue sobre las cuentas bien formadas.
    canonico = [c for c in (canonico or []) if isinstance(c, dict)]
    findings = []

    # 1) Cuadre del balance (bloqueante) — requisito previo
    sd = sum(_num(c.get("debe", 0)) for c in canonico)
    sh = sum(_num(c.get("haber", 0)) for c in canonico)
    if abs(sd - sh) >= 1.0:
        findings.append(_finding(
            "CUADRE-BAL", catalogo.get("CUADRE-BAL"), [], abs(sd - sh),
            detalle=f"Σdebe={_cent(sd)} ≠ Σhaber={_cent(sh)}",
        ))

    # 2) Detectores por patrón de cuenta
    for rule_id, prefijos in DETECTORES:
        regla = catalogo.get(rule_id)
        if not _aplica(regla, regimen):
            continue
        cuentas = [c for c in canonico if str(c.get("cuenta", "")).startswith(prefijos)]
        if cuentas:
            importe = sum(abs(_saldo(c)) for c in cuentas)
            findings.append(_finding(rule_id, regla, [str(c.get("cuenta")) for c in cuentas], importe,
                                     cuentas_detalle=_detalle_cuentas(cuentas)))

    # 3) Detectores agregados por grupo
    for rule_id, prefijos, umbral in DETECTORES_GRUPO:
        regla = catalogo.get(rule_id)
        if not _aplica(regla, regimen):
            continue
        cuentas = [c for c in canonico if str(c.get("cuenta", "")).startswith(prefijos)]
        total = sum(abs(_saldo(c)) for c in cuentas)
        if total > umbral:
            findings.append(_finding(rule_id, regla, [str(c.get("cuenta")) for c in cuentas], total,
                                     cuentas_detalle=_detalle_cuentas(cuentas)))

    # 4) Catálogo COMPLETO data-driven (Fase 4 / C1): reglas con bloque `deteccion` (rules/auditoria + catálogo)
    findings.extend(_detectar_reglas_datos(canonico, catalogo, regimen))

    # Orden de MATRIZ DE RIESGOS: mayor prioridad primero (bloqueos estructurales, luego materialidad ×
    # probabilidad × importe). Determinista: desempate estable por id.
    findings.sort(key=lambda f: (f.get("criticidad") != "bloqueante", -f.get("prioridad_score", 0.0), f.get("id", "")))

    resumen = {e: 0 for e in CRIT_EMOJI.values()}
    for f in findings:
        resumen[f["semaforo"]] = resumen.get(f["semaforo"], 0) + 1
    return {
        "ejercicio": ejercicio,
        "regimen": regimen,
        "hallazgos": findings,
        "resumen": resumen,
        "resumen_ejecutivo": _resumen_ejecutivo(findings),
        "total": len(findings),
        "nota": "Detección determinista por patrón de cuenta PGC; el criterio fino y la confirmación "
                "del soporte son del abogado (humano en el bucle).",
    }


def _self_test() -> int:
    canonico = [
        {"cuenta": "6300", "sf": 5_000_000.0, "debe": 5_000_000.0, "haber": 0.0},
        {"cuenta": "6780", "sf": 80_000.0, "debe": 80_000.0, "haber": 0.0},
        {"cuenta": "7600", "sf": -25_000_000.0, "debe": 0.0, "haber": 25_000_000.0},
        {"cuenta": "1210", "sf": -3_000_000.0, "debe": 0.0, "haber": 3_000_000.0},
        {"cuenta": "6620", "sf": 1_500_000.0, "debe": 1_500_000.0, "haber": 0.0},
        {"cuenta": "5720", "sf": 21_420_000.0, "debe": 21_420_000.0, "haber": 0.0},
    ]
    r = auditar(canonico)
    ids = {f["id"] for f in r["hallazgos"]}
    esperado = {"RC-IS-6300", "AJN-PERM-ART15", "AJN-EXEN-ART21-DIV", "BIN-COMP", "GF-ART16"}
    ok = esperado.issubset(ids)
    print("[OK]" if ok else "[FAIL]", "hallazgos:", sorted(ids), "| resumen:", r["resumen"])
    return 0 if ok else 1


if __name__ == "__main__":
    import sys
    if "--self-test" in sys.argv:
        raise SystemExit(_self_test())
    print("Uso: python3 motor_auditoria.py --self-test")
