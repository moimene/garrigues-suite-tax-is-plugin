#!/usr/bin/env python3
"""Motor de ajustes del Modelo 200 — descomposición itemizada a casillas (F1 del motor de reglas IS).

Capa M2 del motor de reglas (docs/memoria/2026-06-11-motor-reglas-is-plan.md): recibe los ajustes
ITEMIZADOS del expediente (cada uno con regla del catálogo, casilla, importe, signo y naturaleza),
los agrega por casilla de correcciones (aumentos/disminuciones), aplica coherencias FAIL-CLOSED
contra el mapa `rules/casillas/ajustes_modelo200_{ejercicio}.yaml` y garantiza la IDENTIDAD DE SUMA
con los agregados que consume la cadena de liquidación (`motor_calculo_aeat.calcular_casillas`).

Principios (ADR-001, D8, reglas duras de CLAUDE.md):
- El código no contiene casillas ni importes: todo dato vive en YAML por ejercicio.
- Fail-closed: ajuste sin casilla, casilla fuera de mapa, casilla no itemizable (lado neutro o
  reducción) o signo/lado incoherente -> issue BLOQUEANTE (apto_para_firma=False).
- Lo no verificado se marca, no se oculta: casilla con estado distinto de verificado_gip /
  oficial_dr_* -> issue a_confirmar (🟡, no bloquea).
- Identidad de suma con tolerancia 1 EUR (coherente con rules/catalogo/verificacion.yaml).
"""
import os
from decimal import Decimal, ROUND_HALF_UP

try:
    import yaml
except ImportError:  # pragma: no cover
    yaml = None

CASILLAS_DIR = os.path.join(
    os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "rules", "casillas"
)
Q = Decimal("0.01")
TOLERANCIA_IDENTIDAD = Decimal("1.00")  # EUR, como los cuadres bloqueantes de verificacion.yaml
ESTADOS_VERIFICADOS = ("verificado_gip", "verificado_caso_real")
PREFIJO_ESTADO_OFICIAL = "oficial_dr_"


def d(x):
    return Decimal(str(x if x is not None else 0))


def r(x):
    return d(x).quantize(Q, rounding=ROUND_HALF_UP)


def cargar_mapa_ajustes(ejercicio="2024", casillas_dir=CASILLAS_DIR) -> dict:
    """Carga el mapa de casillas de correcciones del ejercicio. {} si no existe (fail-closed)."""
    p = os.path.join(casillas_dir, f"ajustes_modelo200_{ejercicio}.yaml")
    if yaml is None or not os.path.exists(p):
        return {}
    with open(p, encoding="utf-8") as fh:
        return yaml.safe_load(fh) or {}


def _issue(codigo, severidad, detalle, ajuste=None):
    out = {"codigo": codigo, "severidad": severidad, "detalle": detalle}
    if ajuste is not None:
        out["ajuste"] = ajuste
    return out


def liquidar_ajustes(itemizados, ejercicio="2024", mapa=None) -> dict:
    """Agrega los ajustes itemizados por casilla y devuelve totales + issues + apto_para_firma.

    itemizados: lista de dicts con claves:
      id (regla del catálogo), casilla (str "NNNNN"), importe (float; >0 aumenta BI, <0 disminuye),
      signo ("positivo"|"negativo"), naturaleza ("permanente"|"temporaria"; default permanente).
    """
    mapa = mapa if mapa is not None else cargar_mapa_ajustes(ejercicio)
    casillas_mapa = (mapa or {}).get("casillas", {}) or {}
    reducciones_mapa = (mapa or {}).get("reducciones", {}) or {}

    issues = []
    por_casilla = {}
    tot_aumentos = Decimal("0")
    tot_disminuciones = Decimal("0")
    netos = {"permanente": Decimal("0"), "temporaria": Decimal("0")}

    if not casillas_mapa:
        issues.append(_issue(
            "MAPA_AUSENTE", "bloqueante",
            f"No hay mapa de ajustes para el ejercicio {ejercicio} "
            f"(rules/casillas/ajustes_modelo200_{ejercicio}.yaml)."))

    for it in itemizados or []:
        rid = it.get("id", "?")
        casilla = it.get("casilla")
        importe = d(it.get("importe", 0))
        signo = it.get("signo")
        naturaleza = it.get("naturaleza") or "permanente"

        if naturaleza not in ("permanente", "temporaria"):
            issues.append(_issue("NATURALEZA_INVALIDA", "bloqueante",
                                 f"Naturaleza '{naturaleza}' no reconocida.", rid))
            continue
        if it.get("naturaleza") is None:
            issues.append(_issue("NATURALEZA_AUSENTE", "informativo",
                                 "Sin naturaleza explícita; se asume 'permanente'.", rid))

        if not casilla:
            issues.append(_issue("AJUSTE_SIN_CASILLA", "bloqueante",
                                 "El itemizado no declara casilla del Modelo 200.", rid))
            continue
        if casilla in reducciones_mapa:
            issues.append(_issue(
                "CASILLA_ES_REDUCCION", "bloqueante",
                f"La casilla {casilla} es una reducción post-BI previa (input `reservas` de la "
                "cadena), no una corrección itemizable.", rid))
            continue
        if casilla not in casillas_mapa:
            issues.append(_issue(
                "CASILLA_FUERA_DE_MAPA", "bloqueante",
                f"Casilla {casilla} no está en el mapa del ejercicio {ejercicio}; añadirla solo "
                "con fuente oficial (XLS/diseño del modelo).", rid))
            continue

        meta = casillas_mapa[casilla] or {}
        lado = meta.get("lado", "neutro")
        if lado not in ("aumento", "disminucion"):
            issues.append(_issue(
                "CASILLA_NO_ITEMIZABLE", "bloqueante",
                f"Casilla {casilla} tiene lado '{lado}' (resultado/total): no admite itemizados.",
                rid))
            continue

        # Coherencia signo declarado <-> importe <-> lado de la casilla
        if signo == "positivo" and importe < 0 or signo == "negativo" and importe > 0:
            issues.append(_issue("SIGNO_INCOHERENTE", "bloqueante",
                                 f"Signo '{signo}' incoherente con importe {importe}.", rid))
            continue
        if importe > 0 and lado == "disminucion" or importe < 0 and lado == "aumento":
            issues.append(_issue(
                "LADO_INCOHERENTE", "bloqueante",
                f"Importe {importe} no encaja en casilla {casilla} (lado {lado}).", rid))
            continue

        estado = meta.get("estado", "")
        if estado not in ESTADOS_VERIFICADOS and not estado.startswith(PREFIJO_ESTADO_OFICIAL):
            issues.append(_issue(
                "CASILLA_NO_VERIFICADA", "a_confirmar",
                f"Casilla {casilla} con estado '{estado or 'desconocido'}': confirmar contra el "
                "diseño oficial del ejercicio antes de presentar.", rid))

        acc = por_casilla.setdefault(casilla, {"importe": Decimal("0"), "lado": lado, "n_ajustes": 0})
        acc["importe"] += importe
        acc["n_ajustes"] += 1
        if importe >= 0:
            tot_aumentos += importe
        else:
            tot_disminuciones += importe
        netos[naturaleza] += importe

    bloqueantes = [i for i in issues if i["severidad"] == "bloqueante"]
    return {
        "ejercicio": str(ejercicio),
        "por_casilla": {c: {"importe": float(r(v["importe"])), "lado": v["lado"],
                            "n_ajustes": v["n_ajustes"]} for c, v in sorted(por_casilla.items())},
        "totales": {
            "aumentos": float(r(tot_aumentos)),
            "disminuciones": float(r(tot_disminuciones)),
            "neto": float(r(tot_aumentos + tot_disminuciones)),
            "neto_permanentes": float(r(netos["permanente"])),
            "neto_temporarias": float(r(netos["temporaria"])),
        },
        "issues": issues,
        "apto_para_firma": not bloqueantes,
    }


def verificar_identidad(resultado, ajustes_permanentes, ajustes_temporarias=0,
                        tolerancia=TOLERANCIA_IDENTIDAD) -> list:
    """Identidad de suma: los netos itemizados deben cuadrar con los agregados de la cadena.

    Devuelve la lista de issues (vacía si cuadra). Cualquier divergencia > tolerancia es
    BLOQUEANTE: se surfacea (D8), nunca se reconcilia en silencio.
    """
    issues = []
    pares = [
        ("permanentes", d(resultado["totales"]["neto_permanentes"]), d(ajustes_permanentes)),
        ("temporarias", d(resultado["totales"]["neto_temporarias"]), d(ajustes_temporarias)),
    ]
    for nombre, itemizado, agregado in pares:
        delta = abs(itemizado - agregado)
        if delta > d(tolerancia):
            issues.append(_issue(
                "IDENTIDAD_ROTA", "bloqueante",
                f"Ajustes {nombre}: itemizado {itemizado} != agregado de la cadena {agregado} "
                f"(delta {r(delta)} > {r(tolerancia)} EUR)."))
    return issues


def liquidar_y_verificar(itemizados, ajustes_permanentes, ajustes_temporarias=0,
                         ejercicio="2024", mapa=None) -> dict:
    """liquidar_ajustes + verificar_identidad en un paso; recalcula apto_para_firma."""
    out = liquidar_ajustes(itemizados, ejercicio=ejercicio, mapa=mapa)
    out["issues"].extend(verificar_identidad(out, ajustes_permanentes, ajustes_temporarias))
    out["apto_para_firma"] = not [i for i in out["issues"] if i["severidad"] == "bloqueante"]
    return out


def _self_test() -> int:
    """Reproduce los ajustes itemizados GIP 2024 (importes ya versionados en el repo) y verifica
    la identidad con el agregado de la cadena y las anclas de no-regresión."""
    from motor_calculo_aeat import GIP_2024_AGREGADO, ANCLAS_2024, calcular_casillas

    itemizados = [
        {"id": "AJP-IS-EXTRANJERO", "casilla": "00340", "importe": 124951.06,
         "signo": "positivo", "naturaleza": "permanente"},
        {"id": "AJP-TRIBUTOS-NO-DEDUCIBLES", "casilla": "00340", "importe": 1086682.38,
         "signo": "positivo", "naturaleza": "permanente"},
        {"id": "AJN-EXEN-ART21-DIV", "casilla": "00386", "importe": -25790082.60,
         "signo": "negativo", "naturaleza": "permanente"},
        {"id": "AJN-EXEN-ART21-DIV", "casilla": "00386", "importe": -825986.47,
         "signo": "negativo", "naturaleza": "permanente"},
        {"id": "AJN-EXEN-ART21-PV", "casilla": "00386", "importe": -11950581.23,
         "signo": "negativo", "naturaleza": "permanente"},
    ]
    out = liquidar_y_verificar(itemizados, GIP_2024_AGREGADO["ajustes_permanentes"])
    args = dict(GIP_2024_AGREGADO)
    args["ajustes_permanentes"] = out["totales"]["neto_permanentes"]
    cas = calcular_casillas(**args)["casillas"]
    ok = out["apto_para_firma"] and all(abs(cas[k] - v) < 0.005 for k, v in ANCLAS_2024.items())
    print("[OK]" if ok else "[FAIL]", "neto:", out["totales"]["neto"],
          "| 00552:", cas["00552"], "| issues:",
          [(i["codigo"], i["severidad"]) for i in out["issues"]])
    return 0 if ok else 1


if __name__ == "__main__":
    import sys
    if "--self-test" in sys.argv:
        raise SystemExit(_self_test())
    print("Uso: python3 motor_ajustes.py --self-test")
