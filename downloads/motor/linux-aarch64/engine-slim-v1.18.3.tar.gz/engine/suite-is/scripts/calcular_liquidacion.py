#!/usr/bin/env python3
"""Cálculo determinista de la liquidación del Impuesto sobre Sociedades.

Lee facts.json e issues.json y produce liquidacion.json con el esquema:
  resultado contable -> (+IS) -> resultado corregido -> diferencias permanentes/temporarias
  -> BI previa -> (reservas) -> (compensación BINs) -> BI -> cuota íntegra
  -> (deducciones) -> cuota líquida -> (pagos/retenciones) -> cuota a ingresar/devolver

Todos los importes se calculan con Decimal y redondeo HALF_UP a 2 decimales.
Uso:
  python3 calcular_liquidacion.py --facts facts.json --issues issues.json --output liquidacion.json
  python3 calcular_liquidacion.py --self-test
"""
import argparse, json, sys
from decimal import Decimal, ROUND_HALF_UP, getcontext

getcontext().prec = 28
Q = Decimal("0.01")


def d(x):
    return Decimal(str(x if x is not None else 0))


def r(x):
    return d(x).quantize(Q, rounding=ROUND_HALF_UP)


def limite_bins(incn_anterior):
    """Límite de compensación de BINs sobre BI previa según INCN del ejercicio anterior."""
    incn = d(incn_anterior)
    if incn >= 60_000_000:
        return Decimal("0.25")
    if incn >= 20_000_000:
        return Decimal("0.50")
    return Decimal("0.70")


def suma(issues, dominio, signo=None):
    total = Decimal("0")
    for it in issues:
        if it.get("dominio") != dominio:
            continue
        if signo is not None and it.get("signo") != signo:
            continue
        total += d(it.get("importe", 0))
    return total


def calcular(facts, issues):
    tipo = d(facts.get("tipo_gravamen", 0.25))
    rc = d(facts.get("resultado_contable", 0))
    is6300 = d(facts.get("gasto_por_is", 0))
    resultado_corregido = rc + is6300

    # Diferencias permanentes (positivos suman, negativos restan; el importe negativo ya lleva signo)
    perm_pos = suma(issues, "diferencias_permanentes", "positivo")
    perm_neg = suma(issues, "diferencias_permanentes", "negativo")  # importes negativos
    temp_pos = suma(issues, "diferencias_temporarias", "positivo")
    temp_neg = suma(issues, "diferencias_temporarias", "negativo")

    bi_previa = resultado_corregido + perm_pos + perm_neg + temp_pos + temp_neg

    # Reservas (reducción de BI): importes negativos
    reservas = suma(issues, "reduccion_bi")
    base_pre_comp = bi_previa + reservas

    # Compensación de BINs: usa issue explícito si lo hay; si no, calcula por límite.
    comp_issue = next((it for it in issues if it.get("dominio") == "compensacion"), None)
    bins_pend = d(facts.get("bins_pendientes", 0))
    pct = limite_bins(facts.get("incn_ejercicio_anterior", 0))
    minimo = Decimal("1000000")
    limite = max(minimo, (base_pre_comp * pct)) if base_pre_comp > 0 else Decimal("0")
    limite = min(limite, bins_pend, base_pre_comp if base_pre_comp > 0 else Decimal("0"))
    if comp_issue and comp_issue.get("importe") is not None:
        # Tope SIEMPRE al límite (incl. límite 0): no se puede compensar más BINs de los disponibles ni
        # con base no positiva. Antes el `else` aplicaba el importe forzado aunque el límite fuera 0 (Codex HIGH).
        comp = min(abs(d(comp_issue["importe"])), limite)
    else:
        comp = limite
    comp = r(comp)
    base_imponible = r(base_pre_comp - comp)

    # BI negativa -> cuota íntegra 0 (caso real AFG 2024, ver motor_calculo_aeat)
    cuota_integra = r(max(Decimal("0"), base_imponible) * tipo)

    deducciones = suma(issues, "deduccion")  # negativos
    cuota_integra_ajustada = r(cuota_integra + deducciones)
    if cuota_integra_ajustada < 0:
        cuota_integra_ajustada = Decimal("0.00")
    cuota_liquida = cuota_integra_ajustada

    pagos = d(facts.get("pagos_fraccionados", 0))
    retenciones = d(facts.get("retenciones", 0))
    cuota_a_ingresar = r(cuota_liquida - pagos - retenciones)

    pendientes = [it["id"] for it in issues if it.get("criticidad") == "a_confirmar" or it.get("estado") in ("pendiente", "pendiente_cliente")]

    lineas = [
        {"concepto": "Resultado contable del ejercicio", "importe": float(r(rc)), "casilla": "00500"},
        {"concepto": "Corrección por gasto por IS (6300)", "importe": float(r(is6300)), "casilla": "00501"},
        {"concepto": "Resultado contable corregido por IS", "importe": float(r(resultado_corregido)), "casilla": None},
        {"concepto": "Diferencias permanentes (aumentos)", "importe": float(r(perm_pos)), "casilla": "00301..00414"},
        {"concepto": "Diferencias permanentes (disminuciones)", "importe": float(r(perm_neg)), "casilla": "00301..00414"},
        {"concepto": "Diferencias temporarias (netas)", "importe": float(r(temp_pos + temp_neg)), "casilla": "00301..00414"},
        {"concepto": "Base imponible previa", "importe": float(r(bi_previa)), "casilla": "00550"},
        {"concepto": "Reservas (capitalización/nivelación)", "importe": float(r(reservas)), "casilla": "01032/01033"},
        {"concepto": "Compensación de BINs", "importe": float(-comp), "casilla": "00547"},
        {"concepto": "Base imponible", "importe": float(base_imponible), "casilla": "00552"},
        {"concepto": "Tipo de gravamen", "importe": float(tipo), "casilla": "00103"},
        {"concepto": "Cuota íntegra", "importe": float(cuota_integra), "casilla": "00562"},
        {"concepto": "Deducciones doble imposición / otras", "importe": float(r(deducciones)), "casilla": "00573"},
        {"concepto": "Cuota líquida", "importe": float(cuota_liquida), "casilla": "00592"},
        {"concepto": "Pagos fraccionados y retenciones", "importe": float(-(pagos + retenciones)), "casilla": "00595..00599"},
        {"concepto": "Cuota a ingresar / devolver", "importe": float(cuota_a_ingresar), "casilla": "00621"},
    ]
    return {
        "ejercicio": facts.get("ejercicio"),
        "regimen": facts.get("regimen"),
        "tipo_gravamen": float(tipo),
        "lineas": lineas,
        "base_imponible": float(base_imponible),
        "cuota_integra": float(cuota_integra),
        "cuota_liquida": float(cuota_liquida),
        "cuota_a_ingresar": float(cuota_a_ingresar),
        "compensacion_bins_aplicada": float(comp),
        "pendientes": pendientes,
    }


def self_test():
    """Reproduce la liquidación GIP 2024 y verifica los cuadres clave."""
    facts = {
        "ejercicio": 2024, "regimen": "etve", "tipo_gravamen": 0.25,
        "incn_ejercicio_anterior": 200_000_000,  # > 60M -> límite 25%
        "resultado_contable": 47105268.85,
        "gasto_por_is": 5007884.59,
        "bins_pendientes": 98955084.10,
        "pagos_fraccionados": 0, "retenciones": 0,
    }
    issues = [
        {"id": "AJP-IS-EXTRANJERO-001", "dominio": "diferencias_permanentes", "signo": "positivo", "importe": 124951.06, "criticidad": "verde"},
        {"id": "AJP-TRIBUTOS-001", "dominio": "diferencias_permanentes", "signo": "positivo", "importe": 1086682.38, "criticidad": "verde"},
        {"id": "AJN-EXEN-ART21-DIV-SUR", "dominio": "diferencias_permanentes", "signo": "negativo", "importe": -25790082.60, "criticidad": "verde"},
        {"id": "AJN-EXEN-ART21-DIV-JUROS", "dominio": "diferencias_permanentes", "signo": "negativo", "importe": -825986.47, "criticidad": "verde"},
        {"id": "AJN-EXEN-ART21-PV-NORTE", "dominio": "diferencias_permanentes", "signo": "negativo", "importe": -11950581.23, "criticidad": "verde"},
        {"id": "DED-DDI-INT-2020", "dominio": "deduccion", "signo": "negativo", "importe": -280795.19, "criticidad": "verde"},
    ]
    out = calcular(facts, issues)
    checks = [
        ("Base imponible (00552)", out["base_imponible"], 11068602.43),
        ("Cuota íntegra (00562)", out["cuota_integra"], 2767150.61),
        ("Compensación BINs aplicada", out["compensacion_bins_aplicada"], 3689534.15),
        ("Cuota a ingresar", out["cuota_a_ingresar"], 2486355.42),
    ]
    ok = True
    for label, got, exp in checks:
        passed = abs(got - exp) <= 0.01
        ok = ok and passed
        print(f"  [{'OK' if passed else 'XX'}] {label}: calc={got:,.2f} esperado={exp:,.2f}")
    print("RESULTADO:", "TODOS OK" if ok else "FALLOS")
    return 0 if ok else 1


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--facts")
    ap.add_argument("--issues")
    ap.add_argument("--output")
    ap.add_argument("--self-test", action="store_true")
    a = ap.parse_args()
    if a.self_test:
        sys.exit(self_test())
    if not (a.facts and a.issues and a.output):
        ap.error("se requieren --facts, --issues y --output (o --self-test)")
    with open(a.facts, encoding="utf-8") as f:
        facts = json.load(f)
    with open(a.issues, encoding="utf-8") as f:
        issues_doc = json.load(f)
    issues = issues_doc.get("issues", issues_doc) if isinstance(issues_doc, dict) else issues_doc
    out = calcular(facts, issues)
    with open(a.output, "w", encoding="utf-8") as f:
        json.dump(out, f, ensure_ascii=False, indent=2)
    print(f"liquidacion.json escrito en {a.output}")
    print(f"  Base imponible: {out['base_imponible']:,.2f} | Cuota íntegra: {out['cuota_integra']:,.2f} | A ingresar: {out['cuota_a_ingresar']:,.2f}")
    if out["pendientes"]:
        print(f"  Pendientes (a confirmar): {', '.join(out['pendientes'])}")


if __name__ == "__main__":
    main()
