#!/usr/bin/env python3
"""Orquestador de expediente IS — F3 del motor de reglas (M2→M3→M4 + lineage + registry + traza).

Une las capas en una liquidación de expediente con trazabilidad inspección-ready:
  1. M2 motor_ajustes: itemizados → casillas + identidad de suma.
  2. M3 motor_calculo_aeat: agregados → cadena 00500→00621 (ancla GIP 2024).
  3. M4 motor_validaciones: identidades inter-casilla.
  4. LINEAGE por casilla (explicar-casilla, P1): fórmula declarativa + ref normativa + valor +
     reglas del catálogo que contribuyen (correcciones).
  5. REGISTRY file-based (F3): reglas activas por ejercicio/régimen desde rules/catalogo/ —
     el YAML del repo es la fuente de verdad; la activación en DB queda para cuando se apruebe
     la migración (supabase/drafts/, regla dura 1).
  6. TRAZA de ejecución con callback `on_traza` (patrón fire-and-forget del 720): el orquestador
     es puro; persistir es responsabilidad del llamador (engine_service → Supabase en el futuro).
     Opcional JSONL local si SUITE_IS_TRAZAS_DIR está definida (para auditoría en desarrollo).
"""
import glob
import json
import os
import time
import uuid

try:
    import yaml
except ImportError:  # pragma: no cover
    yaml = None

from motor_ajustes import liquidar_y_verificar
from motor_calculo_aeat import calcular_casillas, cargar_parametros
from motor_validaciones import cargar_registro, validar

_RULES = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "rules")


# --------------------------------------------------------------------------- registry (F3)
def reglas_activas(ejercicio="2024", regimen="general") -> list:
    """Registro de reglas activas: catálogo YAML filtrado por régimen. Fuente de verdad = repo."""
    out = []
    if yaml is None:
        return out
    for f in sorted(glob.glob(os.path.join(_RULES, "catalogo", "*.yaml"))):
        data = yaml.safe_load(open(f, encoding="utf-8"))
        if not isinstance(data, list):
            continue
        for regla in data:
            regs = ((regla.get("aplica_si") or {}).get("regimenes")) or []
            if regimen in regs:
                out.append({
                    "id": regla["id"], "dominio": regla.get("dominio"),
                    "titulo": regla.get("titulo"), "casillas": regla.get("casillas", []),
                    "criticidad_default": regla.get("criticidad_default"),
                    "ref": regla.get("ref") or regla.get("fundamento", ""),
                    "fichero": os.path.basename(f),
                })
    return out


# --------------------------------------------------------------------------- lineage (P1)
def _cargar_cadena(ejercicio="2024"):
    p = os.path.join(_RULES, "aeat", f"modelo200_{ejercicio}_calculo.yaml")
    if yaml is None or not os.path.exists(p):
        return []
    return (yaml.safe_load(open(p, encoding="utf-8")) or {}).get("cadena", [])


def construir_lineage(casillas, ajustes=None, itemizados=None, ejercicio="2024") -> dict:
    """Por casilla de la cadena: fórmula declarativa, ref normativa y valor calculado.
    Para las correcciones: reglas del catálogo que contribuyen y sus importes."""
    lineage = {}
    for paso in _cargar_cadena(ejercicio):
        c = paso.get("casilla")
        lineage[c] = {
            "concepto": paso.get("concepto"), "formula": paso.get("formula"),
            "ref": paso.get("ref"), "valor": casillas.get(c),
        }
    if ajustes:
        contrib = {}
        for it in itemizados or []:
            contrib.setdefault(it.get("casilla"), []).append(
                {"regla": it.get("id"), "importe": it.get("importe")})
        for c, datos in ajustes.get("por_casilla", {}).items():
            lineage[f"correccion:{c}"] = {
                "concepto": f"Corrección al resultado (casilla {c}, lado {datos['lado']})",
                "valor": datos["importe"], "reglas": contrib.get(c, []),
            }
    return lineage


# --------------------------------------------------------------------------- orquestador
def liquidar_expediente(inputs, itemizados=None, ejercicio="2024", on_traza=None) -> dict:
    """Liquidación completa de expediente. `inputs` = kwargs de calcular_casillas.

    Devuelve casillas + ajustes + validaciones + lineage + traza + apto_para_firma global.
    Gate fail-closed: cualquier issue bloqueante en M2 o M4 tumba el apto global (D8: las
    divergencias se muestran y bloquean, no se reconcilian en silencio).
    """
    inputs = dict(inputs)
    inputs.setdefault("ejercicio", ejercicio)
    regimen = inputs.get("regimen", "general")
    t0 = time.time()

    # M2 — ajustes itemizados (si los hay) con identidad contra los agregados de entrada
    ajustes = None
    if itemizados is not None:
        ajustes = liquidar_y_verificar(
            itemizados, inputs.get("ajustes_permanentes", 0),
            inputs.get("ajustes_temporarias", 0), ejercicio=ejercicio)

    # M3 — cadena de liquidación (el número que firma, ADR-001)
    liquidacion = calcular_casillas(**inputs)
    casillas = liquidacion["casillas"]

    # M4 — validaciones inter-casilla
    ctx = {"casillas": casillas, "inputs": inputs, "ajustes": ajustes,
           "params": cargar_parametros(str(ejercicio))}
    validaciones = validar(ctx, cargar_registro())

    # Lineage + apto global
    lineage = construir_lineage(casillas, ajustes, itemizados, ejercicio)
    apto = validaciones["apto_para_firma"] and (ajustes is None or ajustes["apto_para_firma"])

    traza = {
        "traza_id": str(uuid.uuid4()),
        "ts_epoch": round(t0, 3),
        "duracion_ms": round((time.time() - t0) * 1000, 1),
        "ejercicio": str(ejercicio),
        "regimen": regimen,
        "reglas_itemizadas": sorted({it.get("id") for it in itemizados or [] if it.get("id")}),
        "n_reglas_activas_registro": len(reglas_activas(str(ejercicio), regimen)),
        "casillas": casillas,
        "issues": ([] if ajustes is None else ajustes["issues"]) + validaciones["issues"],
        "apto_para_firma": apto,
    }
    # Persistencia: callback del llamador (fire-and-forget) y/o JSONL local opcional.
    if on_traza is not None:
        try:
            on_traza(traza)
        except Exception:  # noqa: BLE001 — la traza nunca tumba la liquidación
            pass
    tdir = os.environ.get("SUITE_IS_TRAZAS_DIR")
    if tdir:
        try:
            os.makedirs(tdir, exist_ok=True)
            with open(os.path.join(tdir, f"trazas_{ejercicio}.jsonl"), "a", encoding="utf-8") as fh:
                fh.write(json.dumps(traza, ensure_ascii=False) + "\n")
        except OSError:
            pass

    return {"casillas": casillas, "liquidacion": liquidacion, "ajustes": ajustes,
            "validaciones": validaciones, "lineage": lineage, "traza": traza,
            "apto_para_firma": apto}


def _self_test() -> int:
    from motor_calculo_aeat import ANCLAS_2024, GIP_2024_AGREGADO
    itemizados = [
        {"id": "AJP-IS-EXTRANJERO", "casilla": "00340", "importe": 124951.06,
         "signo": "positivo", "naturaleza": "permanente"},
        {"id": "AJP-TRIBUTOS-NO-DEDUCIBLES", "casilla": "00340", "importe": 1086682.38,
         "signo": "positivo", "naturaleza": "permanente"},
        {"id": "AJN-EXEN-ART21-DIV", "casilla": "00386", "importe": -25790082.60,
         "signo": "negativo", "naturaleza": "permanente"},
        {"id": "AJN-EXEN-ART21-DIV", "casilla": "00386", "importe": -825986.47,
         "signo": "negativo", "naturaleza": "permanente"},
        {"id": "AJN-EXEN-ART21-PV", "casilla": "00386", "importe": -11950581.23,
         "signo": "negativo", "naturaleza": "permanente"},
    ]
    capturadas = []
    out = liquidar_expediente(GIP_2024_AGREGADO, itemizados, on_traza=capturadas.append)
    ok = (out["apto_para_firma"]
          and all(abs(out["casillas"][k] - v) < 0.005 for k, v in ANCLAS_2024.items())
          and len(capturadas) == 1
          and out["lineage"]["00552"]["valor"] == out["casillas"]["00552"])
    print("[OK]" if ok else "[FAIL]",
          f"apto={out['apto_para_firma']} reglas_activas={out['traza']['n_reglas_activas_registro']}",
          f"lineage casillas={len(out['lineage'])}",
          "issues:", [(i['codigo'], i['severidad']) for i in out['traza']['issues']])
    return 0 if ok else 1


if __name__ == "__main__":
    import sys
    if "--self-test" in sys.argv:
        raise SystemExit(_self_test())
    print("Uso: python3 motor_expediente.py --self-test")
