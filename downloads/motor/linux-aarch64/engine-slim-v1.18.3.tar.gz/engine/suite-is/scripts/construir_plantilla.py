#!/usr/bin/env python3
"""construir_plantilla.py — genera el workbook Excel-estado del IS (Modelo 200).

v0.4 — Mejoras (vs réplica Harvey):
  * Parámetros desde FUENTE ÚNICA `rules/parametros/{ejercicio}.yaml` (no hardcodeados).
  * Fórmulas con ROUND a 2 decimales (las casillas son a 2 decimales).
  * Compensación de BINs topada en la base disponible (B12-B8) y protegida contra base negativa.
  * Límite de BINs calculado sobre la base TRAS reserva de capitalización.
  * Tipo de gravamen por régimen vía defined name PAR_TIPO_APLICABLE (multi-régimen).
  * 05_Mapping_M200 pre-cableada por fórmula a los defined names de salida.

Función principal: construir_plantilla(path, ejercicio=2024, params_path=None) -> Path
Hojas: 00_Harness · 01_Datos · 02_Issues · 03_Liquidacion · 04_Parametros_YYYY · 05_Mapping_M200
"""
import re
from pathlib import Path
from openpyxl import Workbook
from openpyxl.workbook.defined_name import DefinedName
from openpyxl.styles import Font, PatternFill, Alignment
from openpyxl.utils import get_column_letter

# Defaults de respaldo (solo si falta el YAML de parámetros)
_DEFAULT_DN = {
    "PAR_BIN_20":0.70,"PAR_BIN_2060":0.50,"PAR_BIN_60":0.25,"PAR_BIN_MIN":1000000,
    "PAR_UMBRAL_MEDIO":20000000,"PAR_UMBRAL_ALTO":60000000,
    "PAR_TIPO_APLICABLE":0.25,"PAR_TIPO_GENERAL":0.25,"PAR_TIPO_MICRO_1M":0.23,
    "PAR_RESERVA_CAP_PCT":0.15,"PAR_RESERVA_MANT_ANIOS":3,"PAR_GF_LIMITE_BO":0.30,"PAR_GF_MINIMO":1000000,
}

def _load_params(ejercicio, params_path):
    if params_path is None:
        params_path = Path(__file__).resolve().parent.parent / "rules" / "parametros" / f"{ejercicio}.yaml"
    try:
        import yaml
        P = yaml.safe_load(open(params_path, encoding="utf-8"))
        if P and P.get("defined_names"):
            return P
    except Exception:
        pass
    return {"ejercicio":ejercicio,"defined_names":dict(_DEFAULT_DN)}

def _add_defined_name(wb, name, sheet_title, cell_ref):
    m = re.match(r"^([A-Za-z]+)(\d+)$", cell_ref)
    if not m: raise ValueError(f"cell_ref invalido: {cell_ref!r}")
    col,row = m.group(1),m.group(2)
    wb.defined_names[name] = DefinedName(name, attr_text=f"'{sheet_title}'!${col}${row}")

def _hs(): return Font(bold=True, color="FFFFFF"), PatternFill("solid", fgColor="2F5496")
def _hdr(ws, headers, row=1):
    f,fill=_hs()
    for c,t in enumerate(headers,1):
        cell=ws.cell(row=row,column=c,value=t); cell.font=f; cell.fill=fill
        cell.alignment=Alignment(horizontal="center",wrap_text=True)

def _build_00_harness(wb):
    ws=wb.create_sheet("00_Harness")
    rows=[("H_fase","1 Intake"),("H_estado","en_curso"),("H_sem_rojo",0),
          ("H_sem_amarillo_impacto",0),("H_sem_verde",0),("H_validada","no"),
          ("pendientes_para_siguiente",""),("bitacora","")]
    ws.column_dimensions["A"].width=30; ws.column_dimensions["B"].width=60
    _hdr(ws,["variable","valor"])
    for i,(n,v) in enumerate(rows,2): ws.cell(row=i,column=1,value=n); ws.cell(row=i,column=2,value=v)
    for n,c in [("H_fase","B2"),("H_estado","B3"),("H_sem_rojo","B4"),
                ("H_sem_amarillo_impacto","B5"),("H_sem_verde","B6"),("H_validada","B7")]:
        _add_defined_name(wb,n,"00_Harness",c)
    return ws

def _build_01_datos(wb):
    ws=wb.create_sheet("01_Datos"); _hdr(ws,["campo","valor","origen/evidencia","procedencia"])
    for i in range(1,5): ws.column_dimensions[get_column_letter(i)].width=26
    return ws

def _build_02_issues(wb):
    ws=wb.create_sheet("02_Issues")
    _hdr(ws,["id","titulo","importe","signo","casilla","criticidad","fundamento","evidencia","estado","accion"])
    for i in range(1,11): ws.column_dimensions[get_column_letter(i)].width=20
    return ws

def _build_03_liquidacion(wb):
    ws=wb.create_sheet("03_Liquidacion")
    ws.column_dimensions["A"].width=44; ws.column_dimensions["B"].width=22; ws.column_dimensions["C"].width=12
    f,fill=_hs()
    for c,t in enumerate(["Concepto","Importe","Casilla"],1):
        cell=ws.cell(row=1,column=c,value=t); cell.font=f; cell.fill=fill
    inputs=[(2,"Resultado contable del ejercicio",0,"00500"),
            (3,"Corrección IS (gasto cta. 6300)",0,"00301"),
            (4,"Ajustes positivos (dif. perm./temp.)",0,"00417"),
            (5,"Exenciones art.21 LIS (negativo)",0,"00386"),
            (6,"INCN ejercicio anterior",0,"—"),
            (7,"BINs pendientes de compensar",0,"—"),
            (8,"Reserva de capitalización aplicada",0,"01032"),
            (9,"DDI y otras deducciones de cuota",0,"00573"),
            (10,"Retenciones y pagos fraccionados",0,"00595")]
    inf=PatternFill("solid",fgColor="EBF3FF")
    for r,c,d,cas in inputs:
        ws.cell(row=r,column=1,value=c); v=ws.cell(row=r,column=2,value=d); v.fill=inf; ws.cell(row=r,column=3,value=cas)
    ws.cell(row=11,column=1,value="")
    ff=PatternFill("solid",fgColor="F2F2F2"); fb=Font(bold=True)
    formulas=[(12,"BASE IMPONIBLE PREVIA","=B2+B3+B4+B5","00550"),
              (13,"Límite compensación BINs","=IF(B6>=PAR_UMBRAL_ALTO,PAR_BIN_60*(B12-B8),IF(B6>=PAR_UMBRAL_MEDIO,PAR_BIN_2060*(B12-B8),PAR_BIN_20*(B12-B8)))","—"),
              (14,"Compensación BINs","=ROUND(MAX(0,MIN(B7,B12-B8,MAX(PAR_BIN_MIN,B13))),2)","00547"),
              (15,"BASE IMPONIBLE","=ROUND(B12-B8-B14,2)","00552"),
              (16,"Cuota íntegra","=ROUND(B15*PAR_TIPO_APLICABLE,2)","00562"),
              (17,"Cuota a ingresar/devolver","=ROUND(B16-B9-B10,2)","00621")]
    for r,c,frm,cas in formulas:
        cc=ws.cell(row=r,column=1,value=c); cc.font=fb
        cf=ws.cell(row=r,column=2,value=frm); cf.fill=ff; cf.font=fb
        ws.cell(row=r,column=3,value=cas)
    for n,c in [("RESULTADO","B2"),("INCN","B6"),("BI_PREVIA","B12"),("COMP_BINS","B14"),
                ("BI","B15"),("CUOTA_INTEGRA","B16"),("CUOTA_INGRESAR","B17")]:
        _add_defined_name(wb,n,"03_Liquidacion",c)
    return ws

def _build_04_parametros(wb, ejercicio, defined):
    sn=f"04_Parametros_{ejercicio}"; ws=wb.create_sheet(sn)
    ws.column_dimensions["A"].width=30; ws.column_dimensions["B"].width=20
    _hdr(ws,["parametro","valor (BLOQUEADA)"])
    for i,(name,value) in enumerate(defined.items(),2):
        ws.cell(row=i,column=1,value=name); ws.cell(row=i,column=2,value=value)
        _add_defined_name(wb,name,sn,f"B{i}")
    ws.protection.sheet=True
    return ws

def _build_05_mapping_m200(wb):
    ws=wb.create_sheet("05_Mapping_M200")
    _hdr(ws,["casilla","concepto","importe","origen_dato","ref_normativa"])
    rows=[("00500","Resultado contable","=RESULTADO","03_Liquidacion!B2","Art.10 LIS"),
          ("00547","Compensación BINs","=COMP_BINS","03_Liquidacion!B14","Art.26 LIS / DA15"),
          ("00552","Base imponible","=BI","03_Liquidacion!B15","Art.10 LIS"),
          ("00562","Cuota íntegra","=CUOTA_INTEGRA","03_Liquidacion!B16","Art.29 LIS"),
          ("00621","Cuota a ingresar/devolver","=CUOTA_INGRESAR","03_Liquidacion!B17","Art.41 LIS")]
    for r in rows: ws.append(list(r))
    for i in range(1,6): ws.column_dimensions[get_column_letter(i)].width=24
    return ws

def construir_plantilla(path, ejercicio=2024, params_path=None):
    path=Path(path); path.parent.mkdir(parents=True,exist_ok=True)
    P=_load_params(ejercicio, params_path); defined=P.get("defined_names") or dict(_DEFAULT_DN)
    wb=Workbook(); wb.remove(wb.active)
    _build_00_harness(wb); _build_01_datos(wb); _build_02_issues(wb)
    _build_03_liquidacion(wb); _build_04_parametros(wb,ejercicio,defined); _build_05_mapping_m200(wb)
    wb.save(str(path)); return path

if __name__=="__main__":
    import argparse
    ap=argparse.ArgumentParser(description="Genera la plantilla Excel-estado IS Modelo 200")
    ap.add_argument("--output",default="EXP_plantilla_2024.xlsx")
    ap.add_argument("--ejercicio",type=int,default=2024)
    ap.add_argument("--params",default=None)
    a=ap.parse_args()
    print(f"Plantilla generada: {construir_plantilla(a.output,a.ejercicio,a.params)}")
