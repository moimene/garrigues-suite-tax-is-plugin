#!/usr/bin/env python3
"""Puente determinista WF-2 v3 -> 3 entregables BRANDED (identidad Garrigues).

Fallback robusto y de CALIDAD de la generacion documental de WF-2 v3 (cuyos pasos
DocumentDraftingAgentic son probabilisticos: 2/3 en el ultimo retest). Parte del
BLOQUE PARSEABLE final que WF-2 v3 SI emite limpio:

    (banner harness)
    ESTADO_HARNESS_V2        {json}
    03_LIQUIDACION_INPUTS_V2 {json}
    05_MAPPING_M200          [json array]

Produce 3 ficheros 100% deterministas, bien nombrados y con identidad Garrigues:
  1. Modelo_200_{NIF}_{ejercicio}.xlsx  (2 hojas, branding verde Garrigues)
  2. Liquidacion_{NIF}_{ejercicio}.docx (conciliacion + inputs + formulas)
  3. Memoria_Tecnica_{NIF}_{ejercicio}.docx (8 secciones, citas, branding)

Marca (manual Garrigues): solo Arial; verde oscuro #004438 + verde brillante
#009A77 (nunca naranja/amarillo); titulos sin negrita; wordmark GARRIGUES; pie legal.

Uso:
  python3 puente_entregables_v3.py --bloque BLOQUE.txt --output-dir OUT/ \
      --nif GIP --ejercicio 2025
  # --bloque acepta .txt (bloque pegado) o .docx (export del response de WF-2)
"""
from __future__ import annotations
import argparse
import json
import os
import re
from datetime import date

# ----------------------------------------------------------------------------
# Parametros del ejercicio (fuente unica: igual que 04_Parametros / rules)
# ----------------------------------------------------------------------------
TIPO_GENERAL = 0.25
BIN_MIN = 1_000_000.0          # suelo de compensacion BINs (art.26 LIS)
BIN_TRAMO_60 = 0.25            # INCN >= 60M
BIN_TRAMO_2060 = 0.50         # 20M <= INCN < 60M
BIN_TRAMO_20 = 0.70           # INCN < 20M

# ----------------------------------------------------------------------------
# Identidad de marca Garrigues (manual de marca / skill garrigues-presentations)
# ----------------------------------------------------------------------------
G_VERDE = "004438"            # verde oscuro primario
G_VERDE_BR = "009A77"        # verde brillante (acentos)
G_VERDE_TENUE = "E8F0ED"     # verde muy tenue (filas alternas)
G_GRIS = "6B6B6B"
G_FONT = "Arial"
G_WORDMARK_FONT = "Cambria"  # aprox. de la serif del wordmark Garrigues
G_LEGAL = ("J&A Garrigues, S.L.P.   ·   Hermosilla 3, 28001 Madrid"
           "   ·   garrigues.com")
G_CONFID = ("Documento de trabajo — uso interno / cliente. "
            "Generado por Suite Tax IS.")


# ============================================================================
# Parsing del bloque
# ============================================================================
SECCIONES = ("ESTADO_HARNESS_V2", "03_LIQUIDACION_INPUTS_V2", "05_MAPPING_M200")


def _leer_fuente(path: str) -> str:
    if path.lower().endswith(".docx"):
        from docx import Document
        doc = Document(path)
        return "\n".join(p.text for p in doc.paragraphs)
    with open(path, "r", encoding="utf-8") as fh:
        return fh.read()


def _extraer_json(texto: str, etiqueta: str):
    m = re.search(re.escape(etiqueta), texto)
    if not m:
        raise ValueError(f"No se encontro la seccion '{etiqueta}' en el bloque.")
    i = m.end()
    while i < len(texto) and texto[i] not in "{[":
        i += 1
    if i >= len(texto):
        raise ValueError(f"No hay JSON tras la seccion '{etiqueta}'.")
    apertura = texto[i]
    cierre = "}" if apertura == "{" else "]"
    profundidad = 0
    en_cadena = escape = False
    for j in range(i, len(texto)):
        c = texto[j]
        if en_cadena:
            if escape:
                escape = False
            elif c == "\\":
                escape = True
            elif c == '"':
                en_cadena = False
            continue
        if c == '"':
            en_cadena = True
        elif c == apertura:
            profundidad += 1
        elif c == cierre:
            profundidad -= 1
            if profundidad == 0:
                return json.loads(texto[i:j + 1])
    raise ValueError(f"JSON sin cerrar en la seccion '{etiqueta}'.")


def parse_bloque(texto: str) -> dict:
    return {
        "harness": _extraer_json(texto, "ESTADO_HARNESS_V2"),
        "inputs": _extraer_json(texto, "03_LIQUIDACION_INPUTS_V2"),
        "mapping": _extraer_json(texto, "05_MAPPING_M200"),
    }


# ============================================================================
# Recalculo de la liquidacion (cadena B12:B17) desde inputs B2:B10
# ============================================================================
def _tramo_bin(incn: float) -> float:
    if incn >= 60_000_000:
        return BIN_TRAMO_60
    if incn >= 20_000_000:
        return BIN_TRAMO_2060
    return BIN_TRAMO_20


def recompute_liquidacion(inp: dict) -> dict:
    B2 = float(inp["B2_resultado_contable"])
    B3 = float(inp["B3_correccion_is_6300"])
    B4 = float(inp["B4_ajustes_positivos"])
    B5 = float(inp["B5_exenciones_art21_negativo"])
    B6 = float(inp["B6_incn_ejercicio_anterior"])
    B7 = float(inp["B7_bins_pendientes"])
    B8 = float(inp["B8_reserva_capitalizacion"])
    B9 = float(inp["B9_ddi_internacional"])
    B10 = float(inp["B10_retenciones_pagos"])
    pct = _tramo_bin(B6)
    # B2 = resultado ANTES de impuestos (convencion WF-1/WF-2). B3 (00301) es la
    # correccion por IS contabilizado: INFORMATIVA, NO se suma a la base previa.
    # (Sumarla inflaria la base; verificado en el retest GIP 2025 real: con B2
    # pre-impuestos, base previa = B2 + B4 + B5 = 6.416.995,74 == Nota 10.1 CCAA.)
    B12 = B2 + B4 + B5
    B13 = pct * B12
    B14 = min(B7, max(BIN_MIN, B13))
    B15 = B12 - B14 - B8
    B16 = B15 * TIPO_GENERAL
    B17 = B16 - B9 - B10
    return {"B12": B12, "B13": B13, "B14": B14, "B15": B15, "B16": B16,
            "B17": B17, "pct_bin": pct, "bins_saldo": B7 - B14,
            "inputs": dict(B2=B2, B3=B3, B4=B4, B5=B5, B6=B6, B7=B7, B8=B8,
                           B9=B9, B10=B10)}


def eur(x: float) -> str:
    # Redondeo al céntimo con ROUND_HALF_UP (convención fiscal ES) — MISMA política que la validación de
    # coherencia del servicio (engines._a_centimos). `f"{x:,.2f}"` usaba el redondeo de float de Python
    # (p.ej. 25.005 -> '25,00'), que divergía al MEDIO CÉNTIMO del Modelo_200 (que firma el valor del
    # mapping validado HALF_UP) — Codex H16. Con HALF_UP, Liquidacion y Modelo_200 rinden el mismo céntimo.
    from decimal import Decimal, ROUND_HALF_UP
    q = Decimal(str(x)).quantize(Decimal("0.01"), rounding=ROUND_HALF_UP)
    s = f"{q:,.2f}"
    return s.replace(",", "X").replace(".", ",").replace("X", ".") + " €"


# ============================================================================
# Branding Garrigues — Word (.docx) como post-proceso determinista
# ============================================================================
def _shade_cell(cell, hexcolor):
    from docx.oxml.ns import qn
    from docx.oxml import OxmlElement
    tcPr = cell._tc.get_or_add_tcPr()
    shd = OxmlElement("w:shd")
    shd.set(qn("w:val"), "clear")
    shd.set(qn("w:fill"), hexcolor)
    tcPr.append(shd)


def brandear_docx(path: str, subtitulo: str = "Suite Tax IS · Impuesto sobre Sociedades"):
    """Aplica identidad Garrigues a un .docx ya generado (idempotente)."""
    from docx import Document
    from docx.shared import Pt, RGBColor
    from docx.enum.text import WD_ALIGN_PARAGRAPH
    verde = RGBColor(0x00, 0x44, 0x38)
    verde_br = RGBColor(0x00, 0x9A, 0x77)
    gris = RGBColor(0x6B, 0x6B, 0x6B)
    blanco = RGBColor(0xFF, 0xFF, 0xFF)
    doc = Document(path)

    # Fuente por defecto Arial
    normal = doc.styles["Normal"]
    normal.font.name = G_FONT
    normal.font.size = Pt(10)

    # Cabecera de marca: wordmark + subtitulo + filete verde, antes de todo
    first = doc.paragraphs[0]
    band = first.insert_paragraph_before()
    rw = band.add_run("GARRIGUES")
    rw.font.name = G_WORDMARK_FONT
    rw.font.size = Pt(15)
    rw.font.color.rgb = verde
    rw.font.bold = False
    sub = first.insert_paragraph_before()
    rs = sub.add_run(subtitulo)
    rs.font.name = G_FONT
    rs.font.size = Pt(8)
    rs.font.color.rgb = verde_br

    # Titulos: verde, Arial, SIN negrita (sobriedad de marca)
    for p in doc.paragraphs:
        sn = p.style.name
        if sn.startswith("Heading") or sn == "Title":
            for run in p.runs:
                run.font.name = G_FONT
                run.font.color.rgb = verde
                run.font.bold = False
        else:
            for run in p.runs:
                run.font.name = G_FONT

    # Tablas: cabecera verde + texto blanco; cuerpo Arial; filas alternas tenues
    for t in doc.tables:
        for cell in t.rows[0].cells:
            _shade_cell(cell, G_VERDE)
            for p in cell.paragraphs:
                for run in p.runs:
                    run.font.color.rgb = blanco
                    run.font.name = G_FONT
                    run.font.bold = False
        for ri, row in enumerate(t.rows[1:]):
            for cell in row.cells:
                if ri % 2 == 1:
                    _shade_cell(cell, G_VERDE_TENUE)
                for p in cell.paragraphs:
                    for run in p.runs:
                        run.font.name = G_FONT

    # Pie: linea legal + confidencialidad
    foot = doc.sections[0].footer.paragraphs[0]
    foot.alignment = WD_ALIGN_PARAGRAPH.CENTER
    fr = foot.add_run(G_LEGAL)
    fr.font.name = G_FONT
    fr.font.size = Pt(7)
    fr.font.color.rgb = gris
    doc.save(path)


# ============================================================================
# Branding Garrigues — Excel (.xlsx)
# ============================================================================
def _xlsx_brand_sheet(ws, titulo, nif, ejercicio, headers, n_cols):
    import openpyxl
    from openpyxl.styles import Font, PatternFill, Alignment, Border, Side
    from openpyxl.utils import get_column_letter
    verde_fill = PatternFill("solid", fgColor=G_VERDE)
    verde_font = Font(name=G_FONT, bold=True, color="FFFFFF", size=10)
    last_col = get_column_letter(n_cols)

    # Bloque de marca (filas 1-3)
    ws.merge_cells(f"A1:{last_col}1")
    c = ws["A1"]
    c.value = "GARRIGUES"
    c.font = Font(name=G_WORDMARK_FONT, size=16, color=G_VERDE, bold=False)
    ws.merge_cells(f"A2:{last_col}2")
    c2 = ws["A2"]
    c2.value = titulo
    c2.font = Font(name=G_FONT, size=12, color=G_VERDE, bold=False)
    ws.merge_cells(f"A3:{last_col}3")
    c3 = ws["A3"]
    c3.value = f"NIF: {nif}    ·    Ejercicio: {ejercicio}    ·    Suite Tax IS"
    c3.font = Font(name=G_FONT, size=9, color=G_GRIS)
    HDR = 5  # fila de cabecera de la tabla
    for j, h in enumerate(headers, 1):
        cell = ws.cell(row=HDR, column=j, value=h)
        cell.fill = verde_fill
        cell.font = verde_font
        cell.alignment = Alignment(vertical="center", wrap_text=True)
    ws.freeze_panes = f"A{HDR + 1}"
    # cabecera/pie de impresion
    ws.oddHeader.left.text = "&\"Arial\"&KFFFFFF GARRIGUES"
    ws.oddFooter.center.text = ("&\"Arial,Regular\"&8&K6B6B6B "
                                "J&A Garrigues, S.L.P.  -  garrigues.com  -  &P")
    return HDR


def _xlsx_body_font(ws, first_row, n_cols):
    from openpyxl.styles import Font
    for r in range(first_row, ws.max_row + 1):
        for cidx in range(1, n_cols + 1):
            cell = ws.cell(row=r, column=cidx)
            if cell.font is None or cell.font.name != G_FONT:
                cell.font = Font(name=G_FONT, size=10)


# ============================================================================
# Entregable 1: Modelo 200 .xlsx (2 hojas, branded)
# ============================================================================
def build_modelo200_xlsx(mapping, out_path, nif, ejercicio):
    import openpyxl
    from openpyxl.styles import Alignment

    wb = openpyxl.Workbook()
    # Hoja A: vista limpia
    wa = wb.active
    wa.title = "Modelo_200_Casilla_Importe"
    hdrA = _xlsx_brand_sheet(wa, "Modelo 200 — Vista limpia (AEAT)", nif,
                             ejercicio, ["Casilla", "Concepto", "Importe (€)"], 3)
    r = hdrA + 1
    for row in mapping:
        wa.cell(row=r, column=1, value=row.get("casilla", ""))
        wa.cell(row=r, column=2, value=row.get("concepto", ""))
        imp = row.get("importe", "")
        cimp = wa.cell(row=r, column=3, value=imp)
        if isinstance(imp, (int, float)):
            cimp.number_format = "#,##0.00"
        r += 1
    wa.column_dimensions["A"].width = 12
    wa.column_dimensions["B"].width = 54
    wa.column_dimensions["C"].width = 20
    _xlsx_body_font(wa, hdrA + 1, 3)

    # Hoja B: mapping detallado con normativa
    wb2 = wb.create_sheet("Mapping_Detallado_Normativa")
    hdrB = _xlsx_brand_sheet(
        wb2, "Modelo 200 — Mapping con fundamento normativo", nif, ejercicio,
        ["Casilla", "Concepto", "Importe (€)", "Origen del dato",
         "Referencia normativa"], 5)
    r = hdrB + 1
    for row in mapping:
        wb2.cell(row=r, column=1, value=row.get("casilla", ""))
        wb2.cell(row=r, column=2, value=row.get("concepto", ""))
        imp = row.get("importe", "")
        cimp = wb2.cell(row=r, column=3, value=imp)
        if isinstance(imp, (int, float)):
            cimp.number_format = "#,##0.00"
        wb2.cell(row=r, column=4, value=row.get("origen_dato", "")).alignment = \
            Alignment(wrap_text=True, vertical="top")
        wb2.cell(row=r, column=5, value=row.get("referencia_normativa", "")).alignment = \
            Alignment(wrap_text=True, vertical="top")
        r += 1
    for col, w in {"A": 12, "B": 46, "C": 18, "D": 48, "E": 48}.items():
        wb2.column_dimensions[col].width = w
    _xlsx_body_font(wb2, hdrB + 1, 5)

    wb.save(out_path)
    return out_path


# ============================================================================
# Entregable 2: Liquidacion .docx
# ============================================================================
def _hdr(table, headers):
    for j, h in enumerate(headers):
        table.rows[0].cells[j].text = h


def build_liquidacion_docx(inp, liq, harness, out_path, nif, ejercicio):
    from docx import Document
    doc = Document()
    doc.add_paragraph("\U0001F9ED HARNESS | IS Modelo 200 | Fase 4/4 | "
                      f"Estado: {harness.get('H_estado', 'cerrado')} | "
                      f"Validada: {harness.get('H_validada', 'si')}")
    doc.add_heading(f"Liquidación definitiva del Impuesto sobre Sociedades "
                    f"{ejercicio}", level=0)
    doc.add_paragraph(f"NIF: {nif}    ·    Ejercicio: {ejercicio}")

    doc.add_heading("Inputs B2:B10 (post-ingesta de respuestas)", level=1)
    t = doc.add_table(rows=1, cols=3)
    t.style = "Table Grid"
    _hdr(t, ["Celda", "Concepto", "Valor"])
    for celda, concepto in [
        ("B2", "Resultado contable (00500)"), ("B3", "Corrección IS cta.6300 (00301)"),
        ("B4", "Ajustes positivos (00417)"), ("B5", "Exenciones art.21 LIS (00386)"),
        ("B6", "INCN ejercicio anterior"), ("B7", "BINs pendientes"),
        ("B8", "Reserva capitalización (01032)"), ("B9", "DDI internacional (00573)"),
        ("B10", "Retenciones y pagos (00595)")]:
        row = t.add_row().cells
        row[0].text = celda
        row[1].text = concepto
        row[2].text = eur(liq["inputs"][celda])

    doc.add_heading("Fórmulas vivas B12:B17 (recalculadas)", level=1)
    t2 = doc.add_table(rows=1, cols=4)
    t2.style = "Table Grid"
    _hdr(t2, ["Celda", "Concepto (casilla)", "Importe", "Fórmula aplicada"])
    pctxt = f"{int(liq['pct_bin'] * 100)}%"
    for celda, concepto, val, formula in [
        ("B12", "Base imponible previa (00550)", liq["B12"], "B2+B3+B4+B5"),
        ("B13", "Límite compensación BINs", liq["B13"],
         f"{pctxt} x B12 (INCN art.26 LIS)"),
        ("B14", "Compensación BINs (00547)", liq["B14"],
         "mín(B7, máx(1.000.000, B13))"),
        ("B15", "BASE IMPONIBLE (00552)", liq["B15"], "B12 - B14 - B8"),
        ("B16", "Cuota íntegra (00562)", liq["B16"], "B15 x 25%"),
        ("B17", "Cuota a ingresar (00621)", liq["B17"], "B16 - B9 - B10")]:
        row = t2.add_row().cells
        row[0].text = celda
        row[1].text = concepto
        row[2].text = eur(val)
        row[3].text = formula

    doc.add_heading("Saldo de BINs para ejercicios futuros", level=1)
    doc.add_paragraph(
        f"BINs pendientes iniciales: {eur(liq['inputs']['B7'])}. "
        f"Compensadas en el ejercicio: {eur(liq['B14'])}. "
        f"Saldo pendiente para futuros: {eur(liq['bins_saldo'])}.")
    doc.save(out_path)
    brandear_docx(out_path, "Suite Tax IS · Liquidación del Impuesto sobre Sociedades")
    return out_path


# ============================================================================
# Entregable 3: Memoria tecnica .docx (8 secciones, citas desde el mapping)
# ============================================================================
def build_memoria_docx(harness, inp, liq, mapping, out_path, nif, ejercicio):
    from docx import Document
    doc = Document()
    exportable = ("Sí" if harness.get("H_validada") == "si"
                  and harness.get("H_sem_rojo") == 0
                  and harness.get("H_sem_amarillo_impacto") == 0 else "No")
    doc.add_paragraph("\U0001F9ED HARNESS | IS Modelo 200 | Fase 4/4 | "
                      f"Estado: {harness.get('H_estado', 'cerrado')} | "
                      f"Exportable: {exportable}")
    doc.add_heading("Memoria técnica fiscal — Impuesto sobre Sociedades", level=0)
    doc.add_paragraph(f"NIF: {nif}    ·    Ejercicio: {ejercicio}    ·    "
                      f"Fecha de emisión: {date.today().isoformat()}")
    by = {r.get("casilla"): r for r in mapping}

    doc.add_heading("1. Resumen ejecutivo", level=1)
    t = doc.add_table(rows=1, cols=2)
    t.style = "Table Grid"
    _hdr(t, ["Magnitud", "Importe"])
    for concepto, val in [
        ("Resultado contable (00500)", liq["inputs"]["B2"]),
        ("Base imponible previa (00550)", liq["B12"]),
        ("Compensación BINs (00547)", liq["B14"]),
        ("Reserva de capitalización (01032)", liq["inputs"]["B8"]),
        ("Base imponible (00552)", liq["B15"]),
        ("Cuota íntegra (00562)", liq["B16"]),
        ("DDI internacional (00573)", liq["inputs"]["B9"]),
        ("Cuota a ingresar (00621)", liq["B17"])]:
        row = t.add_row().cells
        row[0].text = concepto
        row[1].text = eur(val)

    doc.add_heading("2. Fundamentación jurídica", level=1)
    for row in mapping:
        imp = row.get("importe", "")
        imp_txt = eur(imp) if isinstance(imp, (int, float)) else str(imp)
        p = doc.add_paragraph(style="List Bullet")
        p.add_run(f"{row.get('casilla', '')} {row.get('concepto', '')}: ").bold = True
        p.add_run(f"{imp_txt}. Origen: {row.get('origen_dato', '')}. "
                  f"Fundamento: {row.get('referencia_normativa', '')}.")

    doc.add_heading("3. Conciliación resultado contable → base imponible", level=1)
    t2 = doc.add_table(rows=1, cols=3)
    t2.style = "Table Grid"
    _hdr(t2, ["Paso", "Concepto", "Importe"])
    pasos = [
        ("Resultado contable", liq["inputs"]["B2"]),
        ("(+) Corrección IS cta.6300", liq["inputs"]["B3"]),
        ("(+) Ajustes positivos", liq["inputs"]["B4"]),
        ("(+/-) Exenciones art.21 LIS", liq["inputs"]["B5"]),
        ("(=) Base imponible previa (00550)", liq["B12"]),
        ("(-) Reserva de capitalización (01032)", liq["inputs"]["B8"]),
        ("(-) Compensación BINs (00547)", liq["B14"]),
        ("(=) Base imponible (00552)", liq["B15"])]
    for i, (concepto, val) in enumerate(pasos, 1):
        row = t2.add_row().cells
        row[0].text = str(i)
        row[1].text = concepto
        row[2].text = eur(val)

    doc.add_heading("4. Detalle de BINs compensadas", level=1)
    doc.add_paragraph(
        f"Stock inicial de BINs: {eur(liq['inputs']['B7'])}. "
        f"Límite art.26 LIS ({int(liq['pct_bin'] * 100)}% de la BI previa): "
        f"{eur(liq['B13'])}. Compensado en el ejercicio: {eur(liq['B14'])}. "
        f"Saldo pendiente para ejercicios futuros: {eur(liq['bins_saldo'])}.")

    doc.add_heading("5. Deducciones aplicadas", level=1)
    ddi = by.get("00573", {})
    doc.add_paragraph(
        f"Deducción por doble imposición internacional (casilla 00573): "
        f"{eur(liq['inputs']['B9'])}. "
        f"{ddi.get('referencia_normativa', 'LIS arts. 31-32')}.")

    doc.add_heading("6. Recomendaciones para ejercicios futuros", level=1)
    for rec in [
        f"Planificación de BINs: queda saldo de {eur(liq['bins_saldo'])} "
        "pendiente de compensar, sujeto al límite del art.26 LIS.",
        "Reserva de capitalización (art.25 LIS): mantener la indisponibilidad "
        "durante el plazo legal y vigilar el límite del 10% de la BI previa.",
        "Gestión de GFN (art.16 LIS): revisar el beneficio operativo para "
        "optimizar la aplicación de gastos financieros netos pendientes.",
        "DDI (arts.31-32 LIS): controlar la trazabilidad de créditos pendientes "
        "y su compatibilidad con la exención del art.21."]:
        doc.add_paragraph(rec, style="List Bullet")

    doc.add_heading("7. Validación y firma del responsable fiscal", level=1)
    doc.add_paragraph(
        "El abogado responsable ha cuadrado las casillas 00552 / 00562 / 00621 "
        "contra el Excel-estado y marca H_validada = sí.")
    for linea in ["Nombre: ______________________________",
                  "Cargo:  ______________________________",
                  "Fecha:  ______________________________",
                  "Firma:  ______________________________"]:
        doc.add_paragraph(linea)

    doc.save(out_path)
    brandear_docx(out_path, "Suite Tax IS · Memoria técnica fiscal")
    return out_path


# ============================================================================
# Entregable de AUDITORIA (Fase 4 / EPIC C, C4): Memoria de auditoria fiscal (.docx branded)
# ============================================================================
def build_memoria_auditoria_docx(aud, out_path, nif="", ejercicio="2024"):
    """Informe EXPORTABLE de la auditoria fiscal (ruta SEPARADA, read-only): los hallazgos por criticidad
    (cuenta / importe / fundamento art. LIS / accion) en una memoria branded Garrigues. NO es la
    declaracion: no firma numero ni recoge casillas-firma. Reusa `brandear_docx` (mismo branding del puente).

    `aud`: el dict que devuelve el motor (`auditar`/`auditoria`): {ejercicio, regimen, hallazgos, resumen,
    total, nota}. Determinista; cada importe cita su(s) cuenta(s) reales.
    """
    from docx import Document
    doc = Document()
    # Robustez (adversarial): la entrada `aud` puede venir malformada del cuerpo HTTP -> coercionar a
    # tipos seguros para no reventar la generación del .docx (nunca un 500 por un payload raro).
    aud = aud if isinstance(aud, dict) else {}
    ej = str(aud.get("ejercicio") or ejercicio)
    reg = aud.get("regimen", "general")
    hallazgos = [h for h in (aud.get("hallazgos") or []) if isinstance(h, dict)]
    resumen = aud.get("resumen") if isinstance(aud.get("resumen"), dict) else {}

    doc.add_paragraph(
        "\U0001F9ED MEMORIA DE AUDITORIA FISCAL | Ruta de analisis SEPARADA (no es la declaracion) | "
        "read-only: no firma numero, no emite XML, no toca el gating")
    doc.add_heading("Memoria de auditoria fiscal — Impuesto sobre Sociedades", level=0)
    doc.add_paragraph(
        f"NIF: {nif or '—'}    ·    Ejercicio: {ej}    ·    Regimen: {reg}    ·    "
        f"Fecha de emision: {date.today().isoformat()}")

    # Aviso de fiabilidad si hay bloqueo de calidad de dato (fail-closed)
    bloqueo = next((h for h in hallazgos if h.get("id") == "AUD-DATOS-INSUFICIENTES"), None)
    if bloqueo:
        p = doc.add_paragraph()
        p.add_run("AVISO: ").bold = True
        p.add_run(bloqueo.get("detalle") or "Datos insuficientes: la auditoria NO es fiable y NO equivale "
                  "a ausencia de contingencias.")

    fuente = aud.get("fuente_auditoria") if isinstance(aud.get("fuente_auditoria"), dict) else None
    if fuente and fuente.get("limitaciones"):
        p = doc.add_paragraph()
        p.add_run("ALCANCE DE LA AUDITORIA: ").bold = True
        p.add_run(
            f"Base utilizada: {fuente.get('origen', 'no indicada')} "
            f"({fuente.get('cuentas_auditadas', 0)} cuentas auditadas). "
        )
        p.add_run(" ".join(str(x) for x in (fuente.get("limitaciones") or [])))

    # 0. Resumen ejecutivo (matriz de riesgos): exposición estimada + top-N por prioridad
    re_ej = aud.get("resumen_ejecutivo") or {}
    if re_ej:
        doc.add_heading("0. Resumen ejecutivo", level=1)
        exp = re_ej.get("exposicion_estimada", 0)
        doc.add_paragraph(
            f"Exposición estimada (ponderada por probabilidad): {eur(exp) if isinstance(exp, (int, float)) else exp}.")
        pp = re_ej.get("por_prioridad", {})
        doc.add_paragraph(
            f"Prioridad — alta: {pp.get('alta', 0)} · media: {pp.get('media', 0)} · baja: {pp.get('baja', 0)}.")
        top = re_ej.get("top") or []
        if top:
            tt0 = doc.add_table(rows=1, cols=4)
            tt0.style = "Table Grid"
            _hdr(tt0, ["Prioridad", "Hallazgo", "Tipo", "Importe"])
            for f in top:
                r = tt0.add_row().cells
                r[0].text = f"{f.get('semaforo', '')} {str(f.get('prioridad', '')).upper()}".strip()
                r[1].text = str(f.get("titulo", ""))
                r[2].text = "Aviso" if f.get("tipo") == "aviso" else "Ajuste"
                imp = f.get("importe_contable", 0)
                r[3].text = eur(imp) if isinstance(imp, (int, float)) else str(imp)
        if re_ej.get("nota"):
            doc.add_paragraph(re_ej["nota"])

    doc.add_heading("1. Resumen por criticidad", level=1)
    t = doc.add_table(rows=1, cols=2)
    t.style = "Table Grid"
    _hdr(t, ["Criticidad", "Nº de hallazgos"])
    etiquetas = {"\U0001F534": "Bloqueante", "\U0001F7E1": "A confirmar", "\U0001F7E2": "Verde", "⚪": "Informativo"}
    for sem, n in resumen.items():
        row = t.add_row().cells
        row[0].text = f"{sem} {etiquetas.get(sem, '')}".strip()
        row[1].text = str(n)
    doc.add_paragraph(f"Total: {aud.get('total', len(hallazgos))} hallazgo(s).")

    doc.add_heading("2. Hallazgos detallados", level=1)
    if not hallazgos:
        doc.add_paragraph("No se han detectado hallazgos sobre el canonico aportado.")
    for i, h in enumerate(hallazgos, 1):
        doc.add_heading(f"{i}. {h.get('semaforo', '')} {h.get('titulo', h.get('id', ''))}".strip(), level=2)
        tt = doc.add_table(rows=0, cols=2)
        tt.style = "Table Grid"
        cuentas = ", ".join(h.get("cuentas") or []) or "—"
        casillas = ", ".join(h.get("casillas") or []) or "—"
        imp = h.get("importe_contable", 0)
        es_aviso = h.get("tipo") == "aviso"
        importe_lbl = "Volumen a revisar" if es_aviso else "Importe contable"
        filas = [("Tipo", "Aviso de revisión" if es_aviso else "Ajuste")]
        if h.get("prioridad"):
            filas.append(("Prioridad", str(h["prioridad"])))
        if h.get("modulo"):
            filas.append(("Módulo DD", str(h["modulo"])))
        filas += [
            ("Fundamento (art. LIS)", h.get("fundamento") or "—"),
            ("Cuentas", cuentas),
        ]
        if (h.get("casillas") or []):
            filas.append(("Casillas Modelo 200", casillas))
        filas.append((importe_lbl, eur(imp) if isinstance(imp, (int, float)) else str(imp)))
        if h.get("probabilidad_regularizacion"):
            filas.append(("Probabilidad de regularización", str(h["probabilidad_regularizacion"])))
        if h.get("objetivo"):
            filas.append(("Objetivo de revisión", h["objetivo"]))
        if h.get("procedimiento"):
            filas.append(("Procedimiento", h["procedimiento"]))
        if h.get("accion"):
            filas.append(("Acción requerida", h["accion"]))
        if (h.get("red_flags") or []):
            filas.append(("Indicios de alerta", " · ".join(h["red_flags"])))
        if (h.get("documentos_requeridos") or []):
            filas.append(("Documentos a solicitar", " · ".join(h["documentos_requeridos"])))
        if (h.get("referencias") or []):
            filas.append(("Doctrina (curada, verificar)", " · ".join(h["referencias"])))
        if h.get("detalle"):
            filas.append(("Detalle", h["detalle"]))
        for k, v in filas:
            r = tt.add_row().cells
            r[0].text = k
            r[1].text = str(v)

    doc.add_heading("3. Nota metodologica", level=1)
    doc.add_paragraph(
        aud.get("nota") or "Deteccion determinista por patron de cuenta PGC; el criterio fino y la "
        "confirmacion del soporte son del abogado (humano en el bucle).")
    doc.add_paragraph(
        "Esta memoria es una RUTA DE ANALISIS SEPARADA de la declaracion (read-only): no firma el numero "
        "que va al XML/AEAT, no recalcula la liquidacion ni toca el gating. Los hallazgos marcados como 'a "
        "confirmar' requieren la validacion del abogado antes de practicar cualquier ajuste.")

    doc.save(out_path)
    brandear_docx(out_path, "Suite Tax IS · Memoria de auditoria fiscal")
    return out_path


# ============================================================================
# Orquestacion
# ============================================================================
def generar_entregables(bloque_path, output_dir, nif, ejercicio):
    texto = _leer_fuente(bloque_path)
    data = parse_bloque(texto)
    liq = recompute_liquidacion(data["inputs"])
    os.makedirs(output_dir, exist_ok=True)
    base = f"{nif}_{ejercicio}"
    out = {
        "modelo_200": build_modelo200_xlsx(
            data["mapping"], os.path.join(output_dir, f"Modelo_200_{base}.xlsx"),
            nif, ejercicio),
        "liquidacion": build_liquidacion_docx(
            data["inputs"], liq, data["harness"],
            os.path.join(output_dir, f"Liquidacion_{base}.docx"), nif, ejercicio),
        "memoria": build_memoria_docx(
            data["harness"], data["inputs"], liq, data["mapping"],
            os.path.join(output_dir, f"Memoria_Tecnica_{base}.docx"), nif, ejercicio),
    }
    out["_liquidacion"] = liq
    out["_harness"] = data["harness"]
    return out


def main():
    ap = argparse.ArgumentParser(
        description="Puente WF-2 v3 (branded Garrigues): bloque parseable -> 3 entregables")
    ap.add_argument("--bloque", required=True, help="Ruta al bloque (.txt) o export (.docx)")
    ap.add_argument("--output-dir", required=True)
    ap.add_argument("--nif", default="GIP")
    ap.add_argument("--ejercicio", default="2025")
    args = ap.parse_args()
    out = generar_entregables(args.bloque, args.output_dir, args.nif, args.ejercicio)
    liq = out["_liquidacion"]
    print("ENTREGABLES BRANDED GENERADOS:")
    for k in ("modelo_200", "liquidacion", "memoria"):
        print(f"  {k}: {out[k]}")
    print("\nVERIFICACION liquidacion (cadena recalculada):")
    print(f"  00552 Base imponible   = {eur(liq['B15'])}")
    print(f"  00562 Cuota integra    = {eur(liq['B16'])}")
    print(f"  00621 Cuota a ingresar = {eur(liq['B17'])}")


if __name__ == "__main__":
    main()
