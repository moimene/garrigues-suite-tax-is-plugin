#!/usr/bin/env python3
"""Genera el XLS de export del Modelo 200 a partir de liquidacion.json.

Dos hojas: 'Liquidación' (papel de trabajo legible) y 'Casillas' (casilla|descripción|importe),
adaptado por tipología (solo marca las casillas de carácter aplicables).
Uso:
  python3 generar_export_modelo200.py --liquidacion 01_analisis/liquidacion.json \
      --output 03_export/Modelo200_2024.xlsx \
      [--casillas rules/casillas/modelo200_2024.yaml] \
      [--regimen etve] [--caracteres 00011,00082]
"""
import argparse, json, os

# Mapa por defecto régimen/tipología -> casilla(s) de carácter de la declaración
REGIMEN_CARACTER = {
    "general": [],
    "etve": ["00011"],
    "pymes": ["00006"],
    "socimi": ["00012"],
    "fondos": ["00004"],
}


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--liquidacion", required=True)
    ap.add_argument("--output", required=True)
    ap.add_argument("--casillas")
    ap.add_argument("--regimen")
    ap.add_argument("--caracteres", help="CSV de códigos de carácter a marcar (p. ej. 00011,00082)")
    a = ap.parse_args()

    with open(a.liquidacion, encoding="utf-8") as f:
        liq = json.load(f)

    regimen = (a.regimen or liq.get("regimen") or "").strip().lower()

    # determinar qué casillas de carácter marcar
    codigos = []
    if a.caracteres:
        codigos = [c.strip() for c in a.caracteres.split(",") if c.strip()]
    elif regimen in REGIMEN_CARACTER:
        codigos = list(REGIMEN_CARACTER[regimen])

    # descripciones desde el yaml de casillas (si está)
    desc_caracter = {}
    if a.casillas and os.path.exists(a.casillas):
        try:
            import yaml
            with open(a.casillas, encoding="utf-8") as f:
                mapa = yaml.safe_load(f) or {}
            for nombre, cod in (mapa.get("caracteres") or {}).items():
                desc_caracter[str(cod)] = nombre
        except Exception:
            pass

    import openpyxl
    from openpyxl.styles import Font, PatternFill
    wb = openpyxl.Workbook()
    head = PatternFill("solid", fgColor="14342B")  # verde Garrigues oscuro
    hf = Font(color="FFFFFF", bold=True)

    # Hoja 1: Liquidación
    ws = wb.active
    ws.title = "Liquidación"
    ws.append([f"Liquidación IS {liq.get('ejercicio','')} — régimen {liq.get('regimen','')}"])
    ws["A1"].font = Font(bold=True, size=13)
    ws.append(["Concepto", "Casilla", "Importe (EUR)"])
    for c in ws[2]:
        c.fill = head; c.font = hf
    for ln in liq.get("lineas", []):
        ws.append([ln["concepto"], ln.get("casilla") or "", ln.get("importe")])
    for row in ws.iter_rows(min_row=3, min_col=3, max_col=3):
        for c in row:
            if isinstance(c.value, (int, float)):
                c.number_format = '#,##0.00'
    ws.column_dimensions["A"].width = 48
    ws.column_dimensions["B"].width = 16
    ws.column_dimensions["C"].width = 20

    # Hoja 2: Casillas
    ws2 = wb.create_sheet("Casillas")
    ws2.append([f"Modelo 200 — Casillas — ejercicio {liq.get('ejercicio','')} — régimen {regimen}"])
    ws2["A1"].font = Font(bold=True, size=13)
    ws2.append(["Casilla", "Descripción", "Importe / Marca"])
    for c in ws2[2]:
        c.fill = head; c.font = hf
    for cod in codigos:
        ws2.append([cod, f"[carácter] {desc_caracter.get(cod, cod)}", "X"])
    for ln in liq.get("lineas", []):
        cas = ln.get("casilla")
        if cas and str(cas).isdigit():
            ws2.append([cas, ln["concepto"], ln.get("importe")])
    for row in ws2.iter_rows(min_row=3, min_col=3, max_col=3):
        for c in row:
            if isinstance(c.value, (int, float)):
                c.number_format = '#,##0.00'
    ws2.column_dimensions["A"].width = 12
    ws2.column_dimensions["B"].width = 48
    ws2.column_dimensions["C"].width = 20

    os.makedirs(os.path.dirname(a.output) or ".", exist_ok=True)
    wb.save(a.output)
    print(f"Export Modelo 200 generado: {a.output}")
    print(f"  Régimen: {regimen} | Caracteres marcados: {', '.join(codigos) or '(ninguno)'}")
    print(f"  Base imponible (00552): {liq.get('base_imponible'):,.2f} | Cuota íntegra (00562): {liq.get('cuota_integra'):,.2f}")


if __name__ == "__main__":
    main()
