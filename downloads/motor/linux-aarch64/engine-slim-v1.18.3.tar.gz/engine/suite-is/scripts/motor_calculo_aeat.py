#!/usr/bin/env python3
"""Motor de cálculo del Modelo 200 — cadena AEAT PARAMETRIZADA por ejercicio (D10).

Coherente con las casillas del XSD AEAT y con una sola fuente de parámetros
(`suite-is/rules/parametros/{ejercicio}.yaml`): tipos por régimen, tramos de compensación de BINs,
mínimos y umbrales. Reproduce el número validado en GIP 2024 y coincide con `calcular_liquidacion`
(dos implementaciones, un mismo número -> coherencia).

Cadena (casillas Modelo 200):
  00500 resultado contable -> (+ gasto IS) -> 00550 BI previa (+ ajustes perm/temp)
  -> (- reservas) -> 00547 compensación BINs -> 00552 BI -> 00562 cuota íntegra (x tipo)
  -> (+ deducciones, suelo 0) -> 00592 cuota líquida -> (- pagos/retenciones) -> 00621 a ingresar/devolver

NOTA (D10): la descomposición casilla a casilla de los ajustes (rango 00301..00414) y el conjunto
COMPLETO de reglas de VALIDACIÓN inter-casilla de la AEAT requieren el XLS oficial de diseño del
Modelo 200 2024 (no presente en el repo). Esta capa cubre la CADENA DE CÁLCULO validada al céntimo.
"""
import os
from decimal import Decimal, ROUND_HALF_UP

try:
    import yaml
except ImportError:  # pragma: no cover
    yaml = None

PARAMS_DIR = os.path.join(
    os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "rules", "parametros"
)
Q = Decimal("0.01")


def d(x):
    return Decimal(str(x if x is not None else 0))


def r(x):
    return d(x).quantize(Q, rounding=ROUND_HALF_UP)


def cargar_parametros(ejercicio, params_dir=PARAMS_DIR) -> dict:
    p = os.path.join(params_dir, f"{ejercicio}.yaml")
    if yaml is None or not os.path.exists(p):
        return {}
    with open(p, encoding="utf-8") as fh:
        return yaml.safe_load(fh) or {}


def _pct_bin(incn, par) -> Decimal:
    dn = par.get("defined_names", {})
    medio = d(dn.get("PAR_UMBRAL_MEDIO", 20_000_000))
    alto = d(dn.get("PAR_UMBRAL_ALTO", 60_000_000))
    incn = d(incn)
    if incn >= alto:
        return d(dn.get("PAR_BIN_60", 0.25))
    if incn >= medio:
        return d(dn.get("PAR_BIN_2060", 0.50))
    return d(dn.get("PAR_BIN_20", 0.70))


def calcular_casillas(*, resultado_contable, gasto_por_is=0, ajustes_permanentes=0,
                      ajustes_temporarias=0, reservas=0, bins_pendientes=0,
                      incn_ejercicio_anterior=0, deducciones=0, pagos_fraccionados=0,
                      retenciones=0, regimen="general", tipo=None, ejercicio="2024",
                      compensacion_forzada=None, params=None) -> dict:
    """Inputs agregados -> casillas del Modelo 200, parametrizado por ejercicio."""
    par = params if params is not None else cargar_parametros(ejercicio)
    dn = par.get("defined_names", {})
    if tipo is None:
        tipo = par.get("tipos_por_regimen", {}).get(regimen, dn.get("PAR_TIPO_APLICABLE", 0.25))
    tipo = d(tipo)

    c00500 = d(resultado_contable)
    corregido = c00500 + d(gasto_por_is)
    c00550 = corregido + d(ajustes_permanentes) + d(ajustes_temporarias)
    base_pre = c00550 + d(reservas)  # reservas es reducción (negativa)

    pct = _pct_bin(incn_ejercicio_anterior, par)
    minimo = d(dn.get("PAR_BIN_MIN", 1_000_000))
    if base_pre > 0:
        # Veredicto R5.1/C15: la BASE del % del límite art.26 es 00550 (BI previa, ANTES de la reserva de
        # capitalización), NO base_pre (=00550+reservas). Se sigue topando por la base real disponible (base_pre)
        # y por los BINs pendientes. Para GIP reservas=0 → c00550=base_pre → sin cambio.
        limite = max(minimo, c00550 * pct)
        limite = min(limite, d(bins_pendientes), base_pre)
    else:
        limite = Decimal("0")
    # Compensación de BINs forzada por el abogado (puede ser MENOR que el límite, p.ej. preservar BINs a
    # ejercicios futuros): se topa SIEMPRE al límite, incl. límite 0 (Codex HIGH). La compensación forzada
    # sólo puede REDUCIR por debajo del límite, nunca exceder los BINs/base disponibles. None -> el límite.
    if compensacion_forzada is not None:
        comp = min(abs(d(compensacion_forzada)), limite)
    else:
        comp = limite
    c00547 = r(comp)
    c00552 = r(base_pre - c00547)
    # BI negativa -> cuota íntegra 0 (verificado contra M200 2024 presentado, caso AFG
    # 2026-06-11: 00552=-115.887,00 con 00562 vacía/0; el modelo no consigna cuota negativa)
    c00562 = r(max(Decimal("0"), c00552) * tipo)
    cuota_aj = r(c00562 + d(deducciones))
    c00592 = cuota_aj if cuota_aj > 0 else Decimal("0.00")
    c00621 = r(c00592 - d(pagos_fraccionados) - d(retenciones))

    return {
        "casillas": {
            "00500": float(r(c00500)), "00550": float(r(c00550)), "00547": float(c00547),
            "00552": float(c00552), "00103": float(tipo), "00562": float(c00562),
            "00592": float(c00592), "00621": float(c00621),
        },
        "base_imponible": float(c00552),
        "cuota_integra": float(c00562),
        "cuota_liquida": float(c00592),
        "cuota_a_ingresar": float(c00621),
        "tipo_gravamen": float(tipo),
        "ejercicio": str(ejercicio),
    }


def tramos_micropyme(ejercicio="2025", params=None):
    """Escala de microempresa (INCN<1M, Ley 7/2024) por tramos de base imponible, leída del yaml del
    ejercicio. Lista vacía si el ejercicio no la define (p. ej. 2024) -> el llamador trata el fail-closed."""
    par = params if params is not None else cargar_parametros(str(ejercicio))
    return par.get("tramos_micropyme") or []


def cuota_micropyme(base_01330, ejercicio="2025", dias_periodo=365, params=None) -> float:
    """Cuota íntegra (00562) de una MICROEMPRESA por TRAMOS de base imponible (art.29 LIS, Ley 7/2024).

    Patrón del Manual 2025 (cap.6, «Especialidades en el cálculo del tipo de gravamen»): en los regímenes de
    DOS tipos el 00562 se consigna directamente como suma por tramos (idéntico a las entidades de nueva
    creación: `00562 = umbral×t1 + (BI−umbral)×t2`). El umbral se prorratea por días del período (como el
    300.000 de nueva creación). 2025: 21% hasta 50.000 € de BI, 22% el resto (Manual pág.373).

    FAIL-CLOSED en la emisión: 'micropyme' NO está en `tipos_por_regimen` -> `engines.tipo_disponible` lo
    mantiene sin firmar hasta verificar en un import real de Sociedades WEB/Open cómo se representan los dos
    tipos en 00558/00562. Esta función es PURA y está lista para cablear cuando se valide ese encoding.
    """
    tramos = tramos_micropyme(ejercicio, params)
    if not tramos:
        raise ValueError(f"sin escala tramos_micropyme para el ejercicio {ejercicio} (fail-closed)")
    base = d(base_01330)
    if base <= 0:
        return 0.0
    cuota = Decimal("0")
    prev = Decimal("0")
    for tr in tramos:
        tipo = d(tr["tipo"])
        hasta = tr.get("hasta")
        if hasta is not None:
            umbral = d(hasta) * d(dias_periodo) / d(365)
            porcion = min(base, umbral) - prev
            if porcion > 0:
                cuota += porcion * tipo
            prev = umbral
            if base <= umbral:
                break
        else:                                   # último tramo: resto de base imponible
            porcion = base - prev
            if porcion > 0:
                cuota += porcion * tipo
    return float(r(cuota))


# Vector agregado GIP 2024 (cifras validadas; sin NIF/nombre, D4):
GIP_2024_AGREGADO = dict(
    resultado_contable=47105268.85, gasto_por_is=5007884.59,
    ajustes_permanentes=(124951.06 + 1086682.38 - 25790082.60 - 825986.47 - 11950581.23),
    ajustes_temporarias=0.0, reservas=0.0, bins_pendientes=98955084.10,
    incn_ejercicio_anterior=200_000_000, deducciones=-280795.19,
    pagos_fraccionados=0.0, retenciones=0.0, regimen="etve", ejercicio="2024",
)
ANCLAS_2024 = {"00552": 11068602.43, "00562": 2767150.61, "00621": 2486355.42}


def _self_test() -> int:
    out = calcular_casillas(**GIP_2024_AGREGADO)
    cas = out["casillas"]
    ok = all(abs(cas[k] - v) < 0.005 for k, v in ANCLAS_2024.items())
    print("[OK]" if ok else "[FAIL]",
          "00550:", cas["00550"], "00547:", cas["00547"],
          "| 00552:", cas["00552"], "00562:", cas["00562"], "00621:", cas["00621"])
    return 0 if ok else 1


if __name__ == "__main__":
    import sys
    if "--self-test" in sys.argv:
        raise SystemExit(_self_test())
    print("Uso: python3 motor_calculo_aeat.py --self-test")
