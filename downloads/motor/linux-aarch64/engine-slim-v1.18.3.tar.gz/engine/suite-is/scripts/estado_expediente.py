#!/usr/bin/env python3
"""Logica PURA del estado del expediente (sin IO): recorrido de 6 pasos, siguiente
accion (con checkpoints humanos) y plan de recomputo aguas abajo para marcha
atras/enriquecer. La consumen igual el copiloto (Phase 1) y la Power App (Phase 2).
"""
from __future__ import annotations

# Cada paso declara los entregables que PRODUCE (su 'output').
PASOS = [
    {"n": 0, "id": "expediente",    "nombre": "Expediente",                "entregables": []},
    {"n": 1, "id": "contabilidad",  "nombre": "Contabilidad",              "entregables": ["xml_mod200"]},
    {"n": 2, "id": "datos_modelo",  "nombre": "Datos Modelo 200",          "entregables": []},
    {"n": 3, "id": "revision_rapida", "nombre": "Revision rapida",         "entregables": []},
    {"n": 4, "id": "exportar_aeat", "nombre": "Exportar AEAT",
     "entregables": ["declaracion_dr"]},
    {"n": 5, "id": "seguimiento",   "nombre": "Seguimiento",               "entregables": []},
]
CHECKPOINTS = {2: "confirmar_datos_modelo", 3: "revision_rapida"}  # toques humanos
MAX_PASO = max(p["n"] for p in PASOS)


def paso_por_n(n: int) -> dict:
    for p in PASOS:
        if p["n"] == n:
            return p
    raise ValueError(f"paso {n} no existe")


def siguiente_accion(paso_actual: int) -> dict:
    """Siguiente accion del recorrido (o el paso final si ya esta completo)."""
    siguiente = paso_actual + 1 if paso_actual < MAX_PASO else MAX_PASO
    p = paso_por_n(siguiente)
    return {
        "paso": siguiente,
        "accion": p["nombre"],
        "requiere_humano": siguiente in CHECKPOINTS,
        "checkpoint": CHECKPOINTS.get(siguiente),
    }


def plan_recomputo(paso_modificado: int) -> dict:
    """Al modificar/enriquecer 'paso_modificado': que pasos hay que rehacer (todos los
    > modificado) y que entregables quedan obsoletos (los producidos por >= modificado)."""
    pasos_a_rehacer = [p["n"] for p in PASOS if p["n"] > paso_modificado]
    obsoletos, seen = [], set()
    for p in PASOS:
        if p["n"] >= paso_modificado:
            for e in p["entregables"]:
                if e not in seen:
                    seen.add(e)
                    obsoletos.append(e)
    return {"pasos_a_rehacer": pasos_a_rehacer, "entregables_obsoletos": obsoletos}
