#!/usr/bin/env python3
"""Motor de validaciones inter-casilla del Modelo 200 — capa M4 (F2 del motor de reglas IS).

Patrón híbrido (lección 720 Phase 1): el registro (activación, severidad, tolerancia, fundamento)
vive en `rules/aeat/validaciones_modelo200.yaml`; los checks viven AQUÍ compilados (CHECKS, clave
por id). Sin eval() en runtime. Un check devuelve None (cumple), un dict issue (incumple) o la
constante SIN_DATOS si el contexto no trae lo necesario (se surfacea informativo, nunca silencio).

Contexto esperado (dict `ctx`):
  casillas: {"00500","00550","00547","00552","00562","00592","00621", opc "00558"} (floats)
  inputs:   los de la cadena (gasto_por_is, ajustes_permanentes, ajustes_temporarias, reservas,
            bins_pendientes, incn_ejercicio_anterior, deducciones, pagos_fraccionados,
            retenciones, regimen, tipo)
  ajustes:  salida de motor_ajustes.liquidar_ajustes (opcional, para V-AJU-CUADRE)
  params:   parámetros del ejercicio (motor_calculo_aeat.cargar_parametros)
"""
import os
from decimal import Decimal, ROUND_HALF_UP

try:
    import yaml
except ImportError:  # pragma: no cover
    yaml = None

AEAT_DIR = os.path.join(
    os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "rules", "aeat"
)
Q = Decimal("0.01")
SIN_DATOS = object()


def d(x):
    return Decimal(str(x if x is not None else 0))


def r(x):
    return d(x).quantize(Q, rounding=ROUND_HALF_UP)


def cargar_registro(aeat_dir=AEAT_DIR) -> dict:
    p = os.path.join(aeat_dir, "validaciones_modelo200.yaml")
    if yaml is None or not os.path.exists(p):
        return {}
    with open(p, encoding="utf-8") as fh:
        return yaml.safe_load(fh) or {}


def _delta(nombre, esperado, declarado):
    return {"detalle": f"{nombre}: declarado {r(declarado)} != esperado {r(esperado)}",
            "delta": float(abs(r(esperado) - r(declarado)))}


# --------------------------------------------------------------------------- checks compilados
def _chk_00550(ctx, tol):
    cas, inp = ctx.get("casillas", {}), ctx.get("inputs", {})
    if "00550" not in cas or "00500" not in cas:
        return SIN_DATOS
    esperado = (d(cas["00500"]) + d(inp.get("gasto_por_is")) +
                d(inp.get("ajustes_permanentes")) + d(inp.get("ajustes_temporarias")))
    return None if abs(esperado - d(cas["00550"])) <= tol else _delta("00550", esperado, cas["00550"])


def _chk_00552(ctx, tol):
    cas, inp = ctx.get("casillas", {}), ctx.get("inputs", {})
    if not all(k in cas for k in ("00550", "00547", "00552")):
        return SIN_DATOS
    esperado = (d(cas["00550"]) + d(inp.get("reservas"))) - d(cas["00547"])
    return None if abs(esperado - d(cas["00552"])) <= tol else _delta("00552", esperado, cas["00552"])


def _chk_00562(ctx, tol):
    cas, inp = ctx.get("casillas", {}), ctx.get("inputs", {})
    tipo = cas.get("00558", cas.get("00103", inp.get("tipo")))
    if "00552" not in cas or "00562" not in cas or tipo is None:
        return SIN_DATOS
    esperado = r(max(Decimal("0"), d(cas["00552"])) * d(tipo))  # BI<0 -> cuota 0 (AFG)
    return None if abs(esperado - d(cas["00562"])) <= tol else _delta("00562", esperado, cas["00562"])


def _chk_00592(ctx, tol):
    cas, inp = ctx.get("casillas", {}), ctx.get("inputs", {})
    if "00592" not in cas or "00562" not in cas:
        return SIN_DATOS
    if d(cas["00592"]) < 0:
        return {"detalle": f"00592 negativa ({cas['00592']}): la cuota líquida tiene suelo 0.",
                "delta": float(abs(d(cas["00592"])))}
    esperado = max(Decimal("0"), d(cas["00562"]) + d(inp.get("deducciones")))
    return None if abs(esperado - d(cas["00592"])) <= tol else _delta("00592", esperado, cas["00592"])


def _chk_00621(ctx, tol):
    cas, inp = ctx.get("casillas", {}), ctx.get("inputs", {})
    if "00621" not in cas or "00592" not in cas:
        return SIN_DATOS
    esperado = d(cas["00592"]) - d(inp.get("pagos_fraccionados")) - d(inp.get("retenciones"))
    return None if abs(esperado - d(cas["00621"])) <= tol else _delta("00621", esperado, cas["00621"])


def _chk_bin_limite(ctx, tol):
    cas, inp, par = ctx.get("casillas", {}), ctx.get("inputs", {}), ctx.get("params", {})
    if "00547" not in cas or "00550" not in cas or not par:
        return SIN_DATOS
    dn = par.get("defined_names", {})
    base_pre = d(cas["00550"]) + d(inp.get("reservas"))
    if base_pre <= 0:
        return None if d(cas["00547"]) == 0 else {
            "detalle": f"00547={cas['00547']} con base previa <= 0.", "delta": float(d(cas["00547"]))}
    incn = d(inp.get("incn_ejercicio_anterior"))
    if incn >= d(dn.get("PAR_UMBRAL_ALTO", 60_000_000)):
        pct = d(dn.get("PAR_BIN_60", 0.25))
    elif incn >= d(dn.get("PAR_UMBRAL_MEDIO", 20_000_000)):
        pct = d(dn.get("PAR_BIN_2060", 0.50))
    else:
        pct = d(dn.get("PAR_BIN_20", 0.70))
    limite = max(d(dn.get("PAR_BIN_MIN", 1_000_000)), base_pre * pct)
    tope = min(limite, base_pre, d(inp.get("bins_pendientes", 0)) or limite)
    if d(cas["00547"]) - tope > tol:
        return {"detalle": f"00547={cas['00547']} excede el tope art. 26 LIS ({r(tope)}).",
                "delta": float(d(cas["00547"]) - tope)}
    return None


def _chk_aju_cuadre(ctx, tol):
    aj = ctx.get("ajustes")
    if not aj:
        return SIN_DATOS
    suma = sum(d(v["importe"]) for v in aj.get("por_casilla", {}).values())
    neto = d(aj.get("totales", {}).get("neto"))
    return None if abs(suma - neto) <= tol else _delta("ajustes por_casilla vs neto", suma, neto)


def _chk_bi_neg_cuota(ctx, tol):
    cas = ctx.get("casillas", {})
    if "00552" not in cas or "00562" not in cas:
        return SIN_DATOS
    if d(cas["00552"]) < 0 and d(cas["00562"]) != 0:
        return {"detalle": f"BI negativa ({cas['00552']}) con cuota íntegra {cas['00562']} != 0.",
                "delta": float(abs(d(cas["00562"])))}
    return None


def _chk_tipo_regimen(ctx, tol):
    cas, inp, par = ctx.get("casillas", {}), ctx.get("inputs", {}), ctx.get("params", {})
    tipo = cas.get("00558", cas.get("00103", inp.get("tipo")))
    regimen = inp.get("regimen")
    matriz = (par or {}).get("tipos_por_regimen", {})
    if tipo is None or not regimen or regimen not in matriz:
        return SIN_DATOS
    if abs(d(tipo) - d(matriz[regimen])) > Decimal("0.0001"):
        return {"detalle": f"Tipo {tipo} != {matriz[regimen]} (matriz régimen '{regimen}').",
                "delta": float(abs(d(tipo) - d(matriz[regimen])))}
    return None


CHECKS = {
    "V-CAD-00550": _chk_00550,
    "V-CAD-00552": _chk_00552,
    "V-CAD-00562": _chk_00562,
    "V-CAD-00592": _chk_00592,
    "V-CAD-00621": _chk_00621,
    "V-BIN-LIMITE": _chk_bin_limite,
    "V-AJU-CUADRE": _chk_aju_cuadre,
    "V-BI-NEG-CUOTA": _chk_bi_neg_cuota,
    "V-TIPO-REGIMEN": _chk_tipo_regimen,
}


def validar(ctx, registro=None) -> dict:
    """Ejecuta las validaciones ACTIVAS del registro sobre el contexto. Fail-closed:
    una validación registrada sin check compilado es BLOQUEANTE (registro y código divergen)."""
    registro = registro if registro is not None else cargar_registro()
    tol_def = d((registro or {}).get("tolerancia_defecto", 1.00))
    issues = []
    ejecutadas = 0
    for v in (registro or {}).get("validaciones", []):
        if not v.get("activa", False):
            continue
        vid, severidad = v["id"], v.get("severidad", "bloqueante")
        chk = CHECKS.get(vid)
        if chk is None:
            issues.append({"codigo": vid, "severidad": "bloqueante",
                           "detalle": "Validación registrada sin check compilado (divergencia "
                                      "registro/código)."})
            continue
        ejecutadas += 1
        out = chk(ctx, d(v.get("tolerancia", tol_def)))
        if out is SIN_DATOS:
            issues.append({"codigo": vid, "severidad": "informativo",
                           "detalle": "Sin datos suficientes en el contexto; no evaluada."})
        elif out is not None:
            issues.append({"codigo": vid, "severidad": severidad,
                           "detalle": out["detalle"], "delta": out.get("delta"),
                           "ref": v.get("ref", "")})
    bloqueantes = [i for i in issues if i["severidad"] == "bloqueante"]
    return {"issues": issues, "ejecutadas": ejecutadas, "apto_para_firma": not bloqueantes}


def _self_test() -> int:
    from motor_calculo_aeat import GIP_2024_AGREGADO, calcular_casillas, cargar_parametros
    out = calcular_casillas(**GIP_2024_AGREGADO)
    ctx = {"casillas": out["casillas"], "inputs": GIP_2024_AGREGADO,
           "params": cargar_parametros("2024")}
    res = validar(ctx)
    fallos = [i for i in res["issues"] if i["severidad"] == "bloqueante"]
    print("[OK]" if res["apto_para_firma"] else "[FAIL]",
          f"ejecutadas={res['ejecutadas']}",
          "issues:", [(i["codigo"], i["severidad"]) for i in res["issues"]])
    return 0 if not fallos else 1


if __name__ == "__main__":
    import sys
    if "--self-test" in sys.argv:
        raise SystemExit(_self_test())
    print("Uso: python3 motor_validaciones.py --self-test")
