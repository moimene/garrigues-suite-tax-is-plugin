#!/usr/bin/env python3
"""conversor_pgc.py — Fase 0: Sumas y Saldos (bruto) -> 'Tabla 1' agrupada a 4 dígitos PGC.

Parte DETERMINISTA del conversor (las decisiones de juicio por descripción/signo las resuelve la
skill is-conversor-pgc con revisión humana). Hace:
  * Detección de columnas (Cuenta, Descripción, Saldo Final, Debe, Haber, Saldo Inicial).
  * Truncado a 4d/3d; agrupado a 4 dígitos (3d -> 4d añadiendo '0'); formato español.
  * Naturaleza esperada por grupo y detección de anomalías (código vacío/no numérico, posible signo).
  * Cuadre (Σ Debe = Σ Haber; Σ deudor = Σ acreedor).
  * Denominación oficial desde rules/pgc/maestro_pgc.csv (si el código está).
Salida: 'Tabla 1 — Sumas y Saldos A3' (markdown, cols Cuenta|Descripción|Saldo Final|Debe|Haber|Saldo
Inicial) compatible con exportar_sys_a3.py y sys_a_inputs.py + una tabla de validación de anomalías.

Uso: python3 conversor_pgc.py --input SyS.(xls|xlsx|csv) [--maestro rules/pgc/maestro_pgc.csv] [--output tabla1.md]
"""
import argparse, os, re
from pathlib import Path

def _leer(path):
    ext=os.path.splitext(path)[1].lower()
    if ext==".xls":
        import xlrd; b=xlrd.open_workbook(path); s=b.sheet_by_index(0)
        return [[s.cell_value(i,j) for j in range(s.ncols)] for i in range(s.nrows)]
    if ext in (".xlsx",".xlsm"):
        import openpyxl; ws=openpyxl.load_workbook(path,data_only=True).worksheets[0]
        return [list(r) for r in ws.iter_rows(values_only=True)]
    import csv
    with open(path,encoding="utf-8-sig") as f:
        return [r for r in csv.reader(f, delimiter=';' if ';' in (f.readline()) else ',')] if False else list(csv.reader(open(path,encoding="utf-8-sig")))

def _n(s):
    if s is None or s=="" : return None
    if isinstance(s,(int,float)): return float(s)
    t=str(s).strip().replace(".","").replace(" ","").replace("€","")
    t=t.replace(",",".")
    try: return float(t)
    except: return None

def _fmt(x):
    if x is None: return ""
    s=f"{x:,.2f}"  # 1,234,567.89
    return s.replace(",","").replace(".",",").replace("",".")

def _norm(s): return str(s or "").strip().lower()

def detectar(filas):
    for i,row in enumerate(filas):
        cells=[_norm(c) for c in row]
        if any(c.startswith("cuenta") or c.startswith("código") or c.startswith("codigo") for c in cells) and any("descrip" in c or "concepto" in c for c in cells):
            col={}
            for j,c in enumerate(cells):
                if ("cuenta" in c or c.startswith("códig") or c.startswith("codig")) and "cuenta" not in col: col["cuenta"]=j
                elif ("descrip" in c or "concepto" in c) and "descripcion" not in col: col["descripcion"]=j
                elif "saldo" in c and ("actual" in c or "final" in c): col["saldo_final"]=j
                elif "saldo" in c and ("ant" in c or "inicial" in c): col["saldo_inicial"]=j
                elif c.startswith("debe"): col["debe"]=col.get("debe",j) if "actual" not in c else j
                elif c.startswith("haber"): col["haber"]=col.get("haber",j) if "actual" not in c else j
            if "saldo_final" not in col:
                for j,c in enumerate(cells):
                    if c.strip()=="saldo" or "importe" in c: col["saldo_final"]=j
            return i,col
    raise SystemExit("No se detectó la cabecera (Cuenta/Descripción).")

def naturaleza(cod):
    if cod[:2] in ("28","29"): return "acreedora"   # amort. acumulada / deterioro (contra-activo)
    if cod[:2] in ("13",): return "mixta/revisar"    # ajustes por cambios de valor / subvenciones
    g=cod[:1]
    if g in ("2","3","6","8"): return "deudora"
    if g in ("1","7","9"): return "acreedora"
    return "mixta/revisar"

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument("--input",required=True); ap.add_argument("--maestro")
    ap.add_argument("--output"); ap.add_argument("--validacion"); a=ap.parse_args()
    maestro={}
    mp=a.maestro or (Path(__file__).resolve().parent.parent/"rules"/"pgc"/"maestro_pgc.csv")
    try:
        import csv
        for r in csv.reader(open(mp,encoding="utf-8-sig"),delimiter=';'):
            if len(r)>=2 and r[0].strip().isdigit(): maestro[r[0].strip()]=r[1].strip()
    except Exception: pass

    filas=_leer(a.input); hidx,col=detectar(filas)
    def cell(row,key):
        j=col.get(key); return row[j] if (j is not None and j<len(row)) else None
    grupos={}; anomalias=[]
    for row in filas[hidx+1:]:
        cv=cell(row,"cuenta")
        if cv in (None,""): continue
        cod=re.sub(r"\D","",str(cv))
        desc=str(cell(row,"descripcion") or "").strip()
        sf=_n(cell(row,"saldo_final")); si=_n(cell(row,"saldo_inicial"))
        debe=_n(cell(row,"debe")) or 0.0; haber=_n(cell(row,"haber")) or 0.0
        if not cod:
            anomalias.append((str(cv),desc,_fmt(sf),"—","—","sin código / no numérico")); continue
        c4=(cod[:4]).ljust(4,"0") if len(cod)>=3 else cod
        nat=naturaleza(c4)
        if sf is not None and ((nat=="deudora" and sf<0) or (nat=="acreedora" and sf>0)):
            anomalias.append((cod,desc,_fmt(sf),nat,"+" if sf>0 else "-","posible signo equivocado"))
        if len(cod)<3:
            anomalias.append((cod,desc,_fmt(sf),nat,"","código < 3 dígitos: revisar"))
        g=grupos.setdefault(c4,{"sf":0.0,"debe":0.0,"haber":0.0,"si":0.0,"desc":maestro.get(c4) or maestro.get(c4[:3]) or desc})
        g["sf"]+=sf or 0.0; g["debe"]+=debe; g["haber"]+=haber; g["si"]+=si or 0.0

    # cuadre
    td=sum(v["debe"] for v in grupos.values()); th=sum(v["haber"] for v in grupos.values())
    sd=sum(v["sf"] for v in grupos.values() if v["sf"]>0); sa=sum(-v["sf"] for v in grupos.values() if v["sf"]<0)

    out=[]
    cols_line=f"Columnas detectadas: Código = col{col.get('cuenta')}, Descripción = col{col.get('descripcion')}, Saldo Final = col{col.get('saldo_final')}, Debe = {col.get('debe','no detectada')}, Haber = {col.get('haber','no detectada')}, Saldo Inicial = {col.get('saldo_inicial','no detectada')}"
    out.append(cols_line); out.append("")
    out.append("## Tabla 1 — Sumas y Saldos A3 (agrupado 4 dígitos)")
    out.append("| Cuenta | Descripción | Saldo Final | Debe | Haber | Saldo Inicial |")
    out.append("|---|---|---|---|---|---|")
    for c4 in sorted(grupos):
        g=grupos[c4]
        out.append(f"| {c4} | {g['desc']} | {_fmt(round(g['sf'],2))} | {_fmt(round(g['debe'],2))} | {_fmt(round(g['haber'],2))} | {_fmt(round(g['si'],2))} |")
    out.append("")
    out.append(f"Cuadre: Σ Debe = {_fmt(round(td,2))} · Σ Haber = {_fmt(round(th,2))} · "
               f"{'CUADRA' if abs(td-th)<=0.01 else 'DESCUADRE'} debe/haber · "
               f"Σ deudor = {_fmt(round(sd,2))} · Σ acreedor = {_fmt(round(sa,2))} · "
               f"{'CUADRA' if abs(sd-sa)<=0.01 else 'DESCUADRE'} deudor/acreedor")
    out.append("")
    out.append(f"## Tabla de validación (anomalías a revisar: {len(anomalias)})")
    if anomalias:
        out.append("| Código original | Descripción | Saldo observado | Naturaleza esperada | Signo | Motivo |")
        out.append("|---|---|---|---|---|---|")
        for r in anomalias: out.append("| "+" | ".join(str(x) for x in r)+" |")
    else:
        out.append("Sin anomalías estructurales (revisar igualmente código-descripción en la skill).")
    # Tabla 1 LIMPIA (solo cabecera + filas de cuenta) para downstream
    tabla1=[cols_line,"",
            "## Tabla 1 — Sumas y Saldos A3 (agrupado 4 dígitos)",
            "| Cuenta | Descripción | Saldo Final | Debe | Haber | Saldo Inicial |",
            "|---|---|---|---|---|---|"]
    for c4 in sorted(grupos):
        g=grupos[c4]
        tabla1.append(f"| {c4} | {g['desc']} | {_fmt(round(g['sf'],2))} | {_fmt(round(g['debe'],2))} | {_fmt(round(g['haber'],2))} | {_fmt(round(g['si'],2))} |")
    tabla1_txt="\n".join(tabla1)
    # Validación (anomalías) en fichero aparte
    val=[f"## Tabla de validación (anomalías a revisar: {len(anomalias)})"]
    if anomalias:
        val.append("| Código original | Descripción | Saldo observado | Naturaleza esperada | Signo | Motivo |")
        val.append("|---|---|---|---|---|---|")
        for r in anomalias: val.append("| "+" | ".join(str(x) for x in r)+" |")
    else:
        val.append("Sin anomalías estructurales.")
    val_txt="\n".join(val)
    cuadre_line=[l for l in out if l.startswith("Cuadre:")]
    if a.output:
        Path(a.output).parent.mkdir(parents=True,exist_ok=True); open(a.output,"w",encoding="utf-8").write(tabla1_txt+"\n")
        vp=a.validacion or (str(Path(a.output).with_suffix(""))+"_validacion.md")
        open(vp,"w",encoding="utf-8").write(val_txt+"\n")
        print(f"Tabla 1 (limpia): {a.output}  | Validación: {vp}")
        print(f"  {len(grupos)} cuentas a 4d, {len(anomalias)} anomalías. {cuadre_line[0] if cuadre_line else ''}")
    else:
        print(tabla1_txt+"\n\n"+(cuadre_line[0] if cuadre_line else "")+"\n\n"+val_txt)

if __name__=="__main__": main()
