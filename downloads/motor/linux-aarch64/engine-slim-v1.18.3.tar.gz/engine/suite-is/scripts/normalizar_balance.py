#!/usr/bin/env python3
"""Normaliza un balance de sumas y saldos (.xls/.xlsx) a un xlsx estándar.

Detecta la fila de cabecera (con 'Cuenta' y 'Descripción') y las columnas de saldo.
Salida: columnas [cuenta, descripcion, saldo].
Uso:
  python3 normalizar_balance.py --input sumas.xls --output 01_analisis/balance_normalizado.xlsx
"""
import argparse, os


def leer_filas(path):
    ext = os.path.splitext(path)[1].lower()
    if ext == ".xls":
        import xlrd
        b = xlrd.open_workbook(path)
        s = b.sheet_by_index(0)
        return [[s.cell_value(i, j) for j in range(s.ncols)] for i in range(s.nrows)]
    else:
        import openpyxl
        wb = openpyxl.load_workbook(path, data_only=True)
        ws = wb.worksheets[0]
        return [list(r) for r in ws.iter_rows(values_only=True)]


def norm(s):
    return str(s or "").strip().lower()


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--input", required=True)
    ap.add_argument("--output", required=True)
    a = ap.parse_args()

    filas = leer_filas(a.input)
    # localizar cabecera
    hidx, cols = None, {}
    for i, row in enumerate(filas):
        cells = [norm(c) for c in row]
        if any(c.startswith("cuenta") for c in cells) and any("descrip" in c for c in cells):
            hidx = i
            for j, c in enumerate(cells):
                if c.startswith("cuenta"):
                    cols["cuenta"] = j
                elif "descrip" in c:
                    cols["descripcion"] = j
                elif "saldo actual" in c or c == "saldo":
                    cols["saldo"] = j
            if "saldo" not in cols:
                # última columna numérica como saldo
                cols["saldo"] = len(row) - 1
            break
    if hidx is None:
        raise SystemExit("No se encontró la cabecera (Cuenta / Descripción).")

    import openpyxl
    wb = openpyxl.Workbook()
    ws = wb.active
    ws.title = "Balance normalizado"
    ws.append(["cuenta", "descripcion", "saldo"])
    n = 0
    for row in filas[hidx + 1:]:
        if len(row) <= cols["cuenta"]:
            continue
        cuenta = row[cols["cuenta"]]
        desc = row[cols.get("descripcion", 1)] if len(row) > cols.get("descripcion", 1) else ""
        saldo = row[cols["saldo"]] if len(row) > cols["saldo"] else None
        if cuenta in (None, "") and desc in (None, ""):
            continue
        try:
            saldo = float(saldo) if saldo not in (None, "") else None
        except (ValueError, TypeError):
            saldo = None
        ws.append([str(cuenta).strip(), str(desc).strip(), saldo])
        n += 1
    os.makedirs(os.path.dirname(a.output) or ".", exist_ok=True)
    wb.save(a.output)
    print(f"Balance normalizado: {a.output} ({n} cuentas)")


if __name__ == "__main__":
    main()
