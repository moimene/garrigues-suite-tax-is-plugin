#!/usr/bin/env python3
"""rellenar_estado.py — rellena el Excel-estado del IS de forma determinista.

A partir de facts.json + issues.json (+ régimen):
  * escribe las celdas-input B2:B10 de 03_Liquidacion,
  * fija PAR_TIPO_APLICABLE según el régimen (en 04_Parametros),
  * vuelca 01_Datos y 02_Issues,
  * actualiza 00_Harness (fase, estado, semáforos, validada, pendientes),
  * reporta los totales DETERMINISTAS (reutiliza calcular_liquidacion).

Las fórmulas vivas (B12:B17) recalculan lo mismo al abrir el libro. Esto es el
diferencial vs Harvey: el plugin DEJA el número calculado y trazable, no inferido.

Uso:
  python3 rellenar_estado.py --facts facts.json --issues issues.json --regimen etve \
      [--estado EXP.xlsx] --ejercicio 2024 --output EXP_estado.xlsx
"""
import argparse, json, sys
from pathlib import Path
import openpyxl
sys.path.insert(0, str(Path(__file__).resolve().parent))
import construir_plantilla as cp
import calcular_liquidacion as cl

def _suma(issues, dominio=None, signo=None):
    t=0.0
    for it in issues:
        if dominio and it.get("dominio")!=dominio: continue
        if signo and it.get("signo")!=signo: continue
        t+=float(it.get("importe") or 0)
    return round(t,2)

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument("--facts",required=True); ap.add_argument("--issues",required=True)
    ap.add_argument("--regimen"); ap.add_argument("--estado"); ap.add_argument("--ejercicio",type=int,default=2024)
    ap.add_argument("--output",required=True)
    a=ap.parse_args()
    facts=json.load(open(a.facts,encoding="utf-8"))
    idoc=json.load(open(a.issues,encoding="utf-8")); issues=idoc.get("issues",idoc) if isinstance(idoc,dict) else idoc
    regimen=(a.regimen or facts.get("regimen") or "general").lower()

    # 1) Partir de la plantilla (o de un estado existente)
    if a.estado and Path(a.estado).exists():
        wb=openpyxl.load_workbook(a.estado)
    else:
        cp.construir_plantilla(a.output, a.ejercicio); wb=openpyxl.load_workbook(a.output)

    # 2) Inputs B2:B10 (signos coherentes con las fórmulas)
    L=wb["03_Liquidacion"]
    B={2:float(facts.get("resultado_contable",0)),3:float(facts.get("gasto_por_is",0)),
       4:_suma(issues,"diferencias_permanentes","positivo")+_suma(issues,"diferencias_temporarias","positivo"),
       5:_suma(issues,"diferencias_permanentes","negativo")+_suma(issues,"diferencias_temporarias","negativo"),
       6:float(facts.get("incn_ejercicio_anterior",0)),7:float(facts.get("bins_pendientes",0)),
       8:-_suma(issues,"reduccion_bi"),9:-_suma(issues,"deduccion"),
       10:float(facts.get("retenciones",0))+float(facts.get("pagos_fraccionados",0))}
    for r,v in B.items(): L[f"B{r}"]=v

    # 3) PAR_TIPO_APLICABLE por régimen
    try:
        import yaml
        P=yaml.safe_load(open(Path(__file__).resolve().parent.parent/"rules"/"parametros"/f"{a.ejercicio}.yaml",encoding="utf-8"))
        tipo=(P.get("tipos_por_regimen") or {}).get(regimen, P["defined_names"]["PAR_TIPO_GENERAL"])
    except Exception:
        tipo=0.25
    par=wb[f"04_Parametros_{a.ejercicio}"]
    for row in par.iter_rows(min_row=2):
        if row[0].value=="PAR_TIPO_APLICABLE": row[1].value=tipo; break

    # 4) 02_Issues
    s=wb["02_Issues"]
    # limpiar filas previas (deja cabecera)
    if s.max_row>1: s.delete_rows(2, s.max_row-1)
    for it in issues:
        cas=it.get("casillas"); cas=cas[0] if isinstance(cas,list) and cas else (cas or "")
        ev=it.get("evidencia"); ev="; ".join(ev) if isinstance(ev,list) else (ev or "")
        s.append([it.get("id"),it.get("titulo"),it.get("importe"),it.get("signo"),cas,
                  it.get("criticidad"),it.get("fundamento"),ev,it.get("estado","auto"),it.get("accion_requerida") or ""])

    # 5) 01_Datos (clave)
    d=wb["01_Datos"]
    if d.max_row>1: d.delete_rows(2, d.max_row-1)
    for campo,val,orig,proc in [
        ("NIF",facts.get("nif",""),"identificacion","input_humano"),
        ("Ejercicio",a.ejercicio,"contexto","input_humano"),
        ("Regimen",regimen,"perfil","input_humano"),
        ("INCN ejercicio anterior",facts.get("incn_ejercicio_anterior",0),"decl. anterior","inferida_IA"),
        ("Resultado contable",facts.get("resultado_contable",0),"balance (grupos 6/7)","inferida_IA"),
        ("BINs pendientes",facts.get("bins_pendientes",0),"cuadro BINs","inferida_IA")]:
        d.append([campo,val,orig,proc])

    # 6) 00_Harness (semáforos/fase/pendientes)
    crit=lambda c: sum(1 for it in issues if it.get("criticidad")==c)
    rojo,amar,verde,info=crit("bloqueante"),crit("a_confirmar"),crit("verde"),crit("informativo")
    pend=[it.get("titulo","") for it in issues if it.get("criticidad") in ("bloqueante","a_confirmar")]
    H=wb["00_Harness"]; vals={"H_fase":"2-3 analisis/revision","H_estado":"bloqueada" if (rojo or amar) else "en_curso",
        "H_sem_rojo":rojo,"H_sem_amarillo_impacto":amar,"H_sem_verde":verde,"H_validada":"no",
        "pendientes_para_siguiente":" | ".join(pend) or "ninguno"}
    for row in H.iter_rows(min_row=2):
        if row[0].value in vals: row[1].value=vals[row[0].value]

    wb.save(a.output)

    # 7) Reporte determinista (Decimal, exacto) — mismo tipo por régimen que el Excel
    facts["tipo_gravamen"]=tipo
    liq=cl.calcular(facts, issues)
    print(f"Excel-estado relleno: {a.output}")
    print(f"  Regimen {regimen} · tipo aplicable {tipo}")
    print(f"  Harness: rojo={rojo} amarillo={amar} verde={verde} info={info} | estado={vals['H_estado']}")
    print(f"  Base imponible (00552): {liq['base_imponible']:,.2f}")
    print(f"  Cuota integra  (00562): {liq['cuota_integra']:,.2f}")
    print(f"  Cuota a ingresar(00621): {liq['cuota_a_ingresar']:,.2f}")
    gate = rojo==0 and amar==0
    print(f"  Gating export: {'APTO (sin rojos ni amarillos)' if gate else 'NO APTO — resolver pendientes y validar'}")

if __name__=="__main__":
    main()
