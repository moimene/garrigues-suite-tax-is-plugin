"""
gate_citas (determinista, BLOQUEANTE) — 4 estados:
  VERIFIED · EXISTS_BUT_MISMATCH · NOT_FOUND · VERIFIED_BUT_SUPERSEDED (council Opus, 4º estado).

Reglas:
- Solo una cita VERIFIED puede imprimirse en el informe.
- JAMÁS se fabrica una cita: una referencia a fuente NO CURADA no puede dar VERIFIED.
- Una resolución superada por doctrina posterior (a fecha de devengo) → VERIFIED_BUT_SUPERSEDED,
  señalando la autoridad sustituta (anti-"consulta zombie").
- Una resolución que no estaba en vigor al devengo (p.ej. criterio de 2025 para el IS-2024) →
  EXISTS_BUT_MISMATCH (time-travel: anacronismo doctrinal in peius).
"""
from __future__ import annotations

from . import contract as C
from . import retriever as R


def _norm(s) -> str:
    return " ".join(str(s or "").lower().split())


def _matchea(chunk: dict, cita: dict) -> bool:
    """¿Este chunk es CANDIDATO a la resolución citada? (por id, por numero, o por ref si la cita no
    aporta id/numero). La coherencia fina y la elección de la VERSIÓN vigente se deciden después: una
    misma norma tiene varias versiones (mismo numero/ref) con vigencias distintas (time-travel)."""
    if cita.get("id") and cita.get("id") == chunk.get("id"):
        return True
    if cita.get("numero") and _norm(cita.get("numero")) == _norm(chunk.get("numero")):
        return True
    if (not cita.get("id") and not cita.get("numero") and cita.get("ref")
            and _norm(cita.get("ref")) == _norm(chunk.get("ref"))):
        return True
    return False


def _organo_compatible(a, b) -> bool:
    a, b = _norm(a), _norm(b)
    if not a or not b:
        return True
    return a == b or a in b or b in a


def _coherente(chunk: dict, cita: dict) -> bool:
    """Anti-fabricación: cada campo NO vacío que la cita declara debe CONCORDAR con el chunk casado.
    Una cita inventada que solo toma prestado un identificador (ref/numero/id) de una resolución real
    no es coherente con el resto de sus campos -> no se verifica."""
    if cita.get("numero") and _norm(cita.get("numero")) != _norm(chunk.get("numero")):
        return False
    if cita.get("ref") and _norm(cita.get("ref")) != _norm(chunk.get("ref")):
        return False
    if cita.get("organo") and not _organo_compatible(cita.get("organo"), chunk.get("organo")):
        return False
    if cita.get("fecha") and chunk.get("fecha") and str(cita.get("fecha"))[:10] != str(chunk.get("fecha"))[:10]:
        return False
    return True


def _ambigua(corpus: list[dict], cita: dict) -> bool:
    """Si la cita no identifica unívocamente (sin numero ni id) y su ref casa con >1 chunk
    (p.ej. LIS-15-E y LIS-15-F comparten BOE), no se puede verificar a ciegas el primero."""
    if cita.get("numero") or cita.get("id"):
        return False
    ref = _norm(cita.get("ref"))
    if not ref:
        return False
    return sum(1 for c in corpus if _norm(c.get("ref")) == ref) > 1


def _superado(chunk: dict, dev) -> bool:
    """Supersession por CUALQUIER señal (no solo estado_vigencia), anterior/igual al devengo."""
    sup_desde = R._fecha(chunk.get("superseded_desde"))
    senal = (chunk.get("estado_vigencia") == "SUPERADO_POR_JURISPRUDENCIA"
             or bool(chunk.get("superseded_por"))
             or sup_desde is not None)
    if not senal:
        return False
    return sup_desde is None or sup_desde <= dev


def verificar_cita(cita: dict, corpus: list[dict], ejercicio, *, solo_curado: bool = True) -> dict:
    """GateResultado {estado, chunk_id, razon, autoridad_sustituta, degradacion}. `solo_curado` solo
    puede ENDURECER: la curación es INCONDICIONAL para VERIFIED (una fuente no curada nunca verifica)."""
    cita = cita if isinstance(cita, dict) else {}
    dev = R.devengo(ejercicio)
    candidatos = [c for c in (corpus or []) if isinstance(c, dict) and _matchea(c, cita)]

    if not candidatos:
        return {"estado": "NOT_FOUND", "chunk_id": None,
                "razon": "No existe en el corpus una resolución que case con la cita.",
                "autoridad_sustituta": None,
                "degradacion": "Cita no localizada; criterio general sin cita. El firmante debe aportar la referencia."}

    # 1) coherencia cita<->chunk (anti-fabricación): un identificador prestado no basta
    coherentes = [c for c in candidatos if _coherente(c, cita)]
    if not coherentes:
        return {"estado": "EXISTS_BUT_MISMATCH", "chunk_id": candidatos[0].get("id"),
                "razon": "La cita comparte un identificador con una resolución real pero sus campos "
                         "(órgano/número/fecha/ref) no concuerdan: no se verifica (posible cita fabricada).",
                "autoridad_sustituta": None,
                "degradacion": "Cita no coherente con la fuente; criterio general sin cita. El firmante debe verificar la referencia."}

    # 2) ambigüedad: ref compartido sin número/id que desambigüe
    if _ambigua(corpus, cita):
        return {"estado": "EXISTS_BUT_MISMATCH", "chunk_id": coherentes[0].get("id"),
                "razon": "La cita no identifica unívocamente la resolución (su ref cubre varias): ambigua.",
                "autoridad_sustituta": None,
                "degradacion": "Cita ambigua; precise el número/identificador de la resolución."}

    # 3) TIME-TRAVEL: entre los coherentes, elige la VERSIÓN EN VIGOR al devengo (no superada). Una
    #    norma tiene varias redacciones con el mismo numero; la citable para el ejercicio es la vigente.
    vigentes = [c for c in coherentes if not _superado(c, dev) and R.vigente_en(c, dev)]
    if vigentes:
        match = vigentes[0]
        # honestidad INCONDICIONAL: fuente no curada NUNCA da VERIFIED (0 citas fabricadas)
        if not match.get("fuente_curada"):
            return {"estado": "EXISTS_BUT_MISMATCH", "chunk_id": match.get("id"),
                    "razon": "Referencia presente pero PENDIENTE de curación humana (no verificable como autoridad).",
                    "autoridad_sustituta": None,
                    "degradacion": "Cita pendiente de verificación contra CENDOJ/DYCTEA-TEAC; el firmante debe confirmarla."}
        return {"estado": "VERIFIED", "chunk_id": match.get("id"),
                "razon": "Cita verificada contra texto curado, coherente y vigente en el ejercicio.",
                "autoridad_sustituta": None, "degradacion": None}

    # 4) ninguna versión vigente: ¿alguna superada por doctrina posterior? (4º estado, anti-zombie)
    superadas = [c for c in coherentes if _superado(c, dev)]
    if superadas:
        m = superadas[0]
        return {"estado": "VERIFIED_BUT_SUPERSEDED", "chunk_id": m.get("id"),
                "razon": "La resolución existe pero fue superada por doctrina posterior al devengo.",
                "autoridad_sustituta": m.get("superseded_por"),
                "degradacion": "Citar la doctrina posterior como autoridad; la anterior solo como historia."}

    # 5) existe y es coherente pero ninguna versión estaba en vigor al devengo (derogada/anacronismo)
    return {"estado": "EXISTS_BUT_MISMATCH", "chunk_id": coherentes[0].get("id"),
            "razon": f"La resolución existe pero no estaba en vigor a {dev.isoformat()} (anacronismo o vigencia no acreditada).",
            "autoridad_sustituta": None,
            "degradacion": "Criterio no vigente/acreditado en el ejercicio; no oponible (confianza legítima)."}
