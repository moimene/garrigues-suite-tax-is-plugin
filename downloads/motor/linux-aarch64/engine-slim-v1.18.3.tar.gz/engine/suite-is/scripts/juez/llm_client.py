"""
llm_client — proveedor LLM (OpenAI) para el reasoner del juez normativo.

Patrón calcado de `engine_service/ocr_client.py`: clave por entorno, `disponible()` como gate,
DEGRADACIÓN GRACEFUL (nunca lanza; devuelve None ante cualquier fallo), `_post` aislado para
monkeypatch en tests (los tests NUNCA tocan la red). Solo stdlib (urllib): cero dependencias nuevas.

Frontera de privacidad (council bloque #2): a este cliente solo llega el SEAM pseudonimizado (sin
`cuentas_detalle` ni PII) + contexto normativo público. El reasoner es el único nodo estocástico; el
gate/validator deterministas verifican y degradan su salida pase lo que pase.

OPT-IN: el reasoner usa el stub por defecto. La vía OpenAI solo se activa cuando se pide explícitamente
(`model="openai"`/`gpt-...`) Y hay clave. Así ni los tests ni el flujo por defecto gastan tokens.

Producción (datos reales): la clave vive en el entorno del MOTOR (Railway), NUNCA en `VITE_*` (público).
Para secreto profesional, configurar en la cuenta OpenAI: zero-data-retention + residencia UE + DPA.
"""
from __future__ import annotations

import json
import os
import urllib.request

OPENAI_KEY_ENV = "OPENAI_API_KEY"
OPENAI_BASE_ENV = "OPENAI_BASE_URL"      # override (gateway / endpoint de residencia UE)
OPENAI_MODEL_ENV = "JUEZ_LLM_MODELO"     # modelo a usar cuando se pide "openai"
OPENAI_EFFORT_ENV = "JUEZ_LLM_EFFORT"    # reasoning effort de los modelos pro (medium|high|xhigh); opcional
OPENAI_TIMEOUT_ENV = "JUEZ_LLM_TIMEOUT"  # timeout en s (los modelos de razonamiento son lentos)
OPENAI_ENV_FILE_ENV = "JUEZ_ENV_FILE"    # override del fichero de secretos local (ruta absoluta)
_BASE_DEFAULT = "https://api.openai.com/v1"
_MODELO_DEFAULT = "gpt-5.5"              # modelo del juez (no-pro, síncrono, verificado live); override con JUEZ_LLM_MODELO
_TIMEOUT_DEFAULT = 120.0

# repo root = .../suite-is/scripts/juez/llm_client.py -> 4 dirnames arriba
_REPO_ROOT = os.path.dirname(os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))
# ficheros de secretos locales (DEV), en orden de preferencia; `.env.local.fase2bak` = repo de secretos del usuario
_ENV_FILE_CANDIDATOS = (".env.local.fase2bak", ".env.local", ".env")


def _ficheros_secretos():
    """Ficheros de secretos a inspeccionar en DEV: override JUEZ_ENV_FILE primero, luego candidatos en repo."""
    rutas = []
    override = os.environ.get(OPENAI_ENV_FILE_ENV)
    if override:
        rutas.append(override)
    rutas += [os.path.join(_REPO_ROOT, n) for n in _ENV_FILE_CANDIDATOS]
    return rutas


def _de_env_local(nombre: str):
    """Fallback DEV: busca NOMBRE en los ficheros de secretos locales (por defecto `.env.local.fase2bak`,
    `.env.local`, `.env`; override con `JUEZ_ENV_FILE`). En producción (Railway) manda os.environ del proceso."""
    for path in _ficheros_secretos():
        try:
            with open(path, encoding="utf-8") as fh:
                for linea in fh:
                    linea = linea.strip()
                    if not linea or linea.startswith("#") or "=" not in linea:
                        continue
                    k, _, val = linea.partition("=")
                    if k.strip().replace("export ", "").strip() == nombre:
                        v = val.strip().strip('"').strip("'")
                        if v:
                            return v
        except OSError:
            continue
    return None


def _valor(nombre: str):
    return (os.environ.get(nombre) or "").strip() or _de_env_local(nombre)


def api_key():
    return _valor(OPENAI_KEY_ENV)


def base_url() -> str:
    return (_valor(OPENAI_BASE_ENV) or _BASE_DEFAULT).rstrip("/")


def modelo_por_defecto() -> str:
    return _valor(OPENAI_MODEL_ENV) or _MODELO_DEFAULT


def disponible() -> bool:
    """Gate: ¿hay clave para llamar al proveedor?"""
    return api_key() is not None


def _timeout() -> float:
    try:
        return float(_valor(OPENAI_TIMEOUT_ENV) or _TIMEOUT_DEFAULT)
    except (TypeError, ValueError):
        return _TIMEOUT_DEFAULT


def _usa_responses(model) -> bool:
    """Los modelos de razonamiento / 'pro' (gpt-5*, o-series) van por /v1/responses, no por chat
    completions (devuelven 404 'not a chat model'). El resto (gpt-4.x, gpt-3.5) por chat completions."""
    return bool(model) and str(model).startswith(("gpt-5", "o1", "o3", "o4"))


def _post(url: str, payload: dict, headers: dict, timeout: float) -> dict:
    """Aislado para monkeypatch en tests (los tests jamás llegan aquí)."""
    data = json.dumps(payload).encode("utf-8")
    req = urllib.request.Request(url, data=data, headers=headers, method="POST")
    with urllib.request.urlopen(req, timeout=timeout) as resp:  # noqa: S310 — URL fija del proveedor
        return json.loads(resp.read().decode("utf-8"))


def _texto_chat(resp):
    """Extrae el contenido de una respuesta de /chat/completions."""
    choices = resp.get("choices") if isinstance(resp, dict) else None
    msg = (choices[0].get("message") if choices and isinstance(choices[0], dict) else None) or {}
    return (msg.get("content") or None) if isinstance(msg, dict) else None


def _texto_responses(resp):
    """Extrae el texto de una respuesta de /v1/responses (output[].content[] con type 'output_text')."""
    if not isinstance(resp, dict):
        return None
    if resp.get("output_text"):
        return resp["output_text"]
    partes = []
    for item in resp.get("output") or []:
        if isinstance(item, dict) and item.get("type") == "message":
            for c in item.get("content") or []:
                if isinstance(c, dict) and c.get("type") == "output_text" and c.get("text"):
                    partes.append(c["text"])
    return "".join(partes) or None


def chat(messages: list, *, model=None, seed: int = 0, temperature: float = 0.0):
    """Pide un IracOutput en JSON al proveedor. ENRUTA por modelo: los pro/razonadores (gpt-5*, o-series)
    usan la Responses API (/v1/responses, con `input`); el resto, chat completions (`messages` +
    temperature=0 + seed). Devuelve el CONTENIDO (str) o None ante cualquier fallo (degradación graceful)."""
    key = api_key()
    if not key:
        return None
    mdl = model if (model and model not in ("openai", "stub")) else modelo_por_defecto()
    headers = {"Authorization": f"Bearer {key}", "Content-Type": "application/json"}
    try:
        if _usa_responses(mdl):
            payload = {"model": mdl, "input": messages, "text": {"format": {"type": "json_object"}}}
            effort = _valor(OPENAI_EFFORT_ENV)
            if effort:
                payload["reasoning"] = {"effort": effort}   # medium|high|xhigh (según modelo)
            resp = _post(f"{base_url()}/responses", payload, headers, _timeout())
            return _texto_responses(resp)
        payload = {"model": mdl, "messages": messages, "temperature": temperature, "seed": seed,
                   "response_format": {"type": "json_object"}}
        resp = _post(f"{base_url()}/chat/completions", payload, headers, _timeout())
        return _texto_chat(resp)
    except Exception:  # noqa: BLE001 — el proveedor JAMÁS debe tumbar el pipeline
        return None
