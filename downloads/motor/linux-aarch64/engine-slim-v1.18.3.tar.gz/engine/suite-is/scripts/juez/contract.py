"""
Contrato del seam SDB (Stochastic-Deterministic Boundary) — capa LLM "juez normativo".

Frontera de confianza:
- El motor determinista (`motor_auditoria.py`) es la REFERENCIA read-only.
- El reasoner (LLM) es el único nodo estocástico; PROPONE un `IracOutput`.
- Este módulo es 100% determinista: define los catálogos cerrados, la proyección
  pseudonimizada que cruza el seam (`hallazgo_para_juez`) y la validación dura
  (`validar_irac`). NADA aquí llama a un LLM.

Invariantes (contra el contrato del council):
- `IracOutput.calculation_fields` SIEMPRE vacío: el LLM no calcula importes/cuotas/BIN/
  materialidad ni probabilidades numéricas. Solo bandas discretas con drivers textuales.
- `conclusion.requiere_revision_humana` SIEMPRE True: el LLM propone, el colegiado firma.
- La banda de confianza debe ser COHERENTE con el `prioridad_score` del motor.
- Solo una cita con `estado_gate == "VERIFIED"` puede imprimirse en el informe.
- NO cruza PII ni `cuentas_detalle`: el importe va como BANDA discreta.

Esquema `IracOutput` (dict; serializable a JSON cerrado):
    {
      "hallazgo_id": str,
      "issue":       {"cuestion": str, "figura_juridica": <FIGURAS>, "carga_prueba": <CARGA_PRUEBA>},
      "rule":        {"norma_vigente_en_ejercicio": str, "vigencia_temporal": str,
                      "autoridades": [{"tipo_fuente": <TIPOS_FUENTE>, "id_ref": str,
                                       "ratio_o_obiter": <RATIO_OBITER>, "jerarquia_peso": float,
                                       "gate_estado": <GATE_ESTADOS>|null}],
                      "conflicto_fuentes": {"criterio_aplicable": str,
                                            "confianza_legitima_aplica": bool,
                                            "posiciones": [str]}},
      "application": {"subsuncion": str, "hechos_dudosos": [str], "contraargumento_contribuyente": str},
      "conclusion":  {"conclusion_label": <CONCLUSION_LABELS>, "requiere_revision_humana": true},
      "confidence":  {"banda": <BANDAS>, "score": int,
                      "drivers": {"solidez_cita": str, "acreditacion_hechos": str,
                                  "consolidacion_doctrina": str, "alineacion_AEAT": str,
                                  "justificacion_divergencia": str|null}},
      "citations":   [{"organo": str, "numero": str, "fecha": str, "ref": str,
                       "estado_gate": <GATE_ESTADOS>, "imprimible": bool, "degradacion": str|null}],
      "evidence_gap": [str],
      "conflict_flag": bool,
      "calculation_fields": []
    }
"""
from __future__ import annotations

import hashlib
import json
import re

# --- versionado para reproducibilidad forense (council bloque #3) ---
PROMPT_VERSION = "juez-irac-v0.1.0"
CITATION_GATE_VERSION = "gate-4estados-v0.1.0"
CORPUS_VERSION_DEFAULT = "seed-2026-06-15"

# --- catálogos cerrados (el LLM no puede salirse de aquí) ---
FIGURAS = frozenset({
    "deducibilidad", "retrib_admin", "FEAC", "vinculadas_DEMPE",
    "simulacion16", "conflicto15", "reversion_DT16", "otro",
})
CARGA_PRUEBA = frozenset({"contribuyente", "administracion", "mixta"})
CONCLUSION_LABELS = frozenset({
    "deducible", "no_deducible", "ajuste_requerido",
    "requiere_humano", "contingencia", "sin_incidencia",
})
BANDAS = frozenset({"baja", "media", "alta"})
GATE_ESTADOS = frozenset({"VERIFIED", "EXISTS_BUT_MISMATCH", "NOT_FOUND", "VERIFIED_BUT_SUPERSEDED"})
RATIO_OBITER = frozenset({"ratio", "obiter"})
TIPOS_FUENTE = frozenset({"ley", "reglamento", "STS", "AN", "TSJ", "TEAC", "TEAR", "DGT"})
ESTADOS_VIGENCIA = frozenset({"VIGENTE", "DEROGADO", "SUPERADO_POR_JURISPRUDENCIA"})

# peso jerárquico del re-ranker (council Gemini): Ley/reglamento > STS > AN > TSJ > TEAC > TEAR > DGT
PESO_JERARQUICO = {
    "ley": 10.0, "reglamento": 9.0, "STS": 8.0, "AN": 7.0,
    "TSJ": 6.5, "TEAC": 6.0, "TEAR": 5.0, "DGT": 4.0,
}

# Bandas de la confianza IRAC (council Opus): baja 0-25 · media 25-60 · alta 60-100
BANDA_RANGOS = {"baja": (0, 25), "media": (25, 60), "alta": (60, 100)}

# Mapa mínimo módulo→figura jurídica (ampliable; default "otro").
_FIGURA_POR_MODULO = {
    "03": "deducibilidad",
    "06": "deducibilidad",
    "07": "vinculadas_DEMPE",
    "09": "deducibilidad",
    "12": "FEAC",
}


def figura_de_modulo(modulo) -> str:
    return _FIGURA_POR_MODULO.get(str(modulo), "otro")


def banda_importe(importe) -> str:
    """Discretiza el importe en BANDA — NO cruza el número crudo por el seam (anti-PII)."""
    try:
        v = abs(float(importe or 0))
    except (TypeError, ValueError):
        v = 0.0
    if v >= 1_000_000:
        return ">=1M"
    if v >= 100_000:
        return "100k-1M"
    if v > 0:
        return "<100k"
    return "n/a"


def _canon(obj) -> str:
    return json.dumps(obj, sort_keys=True, ensure_ascii=False, separators=(",", ":"))


def sha256(obj) -> str:
    """Hash estable de un objeto JSON-serializable (para input_hash/output_hash)."""
    return hashlib.sha256(_canon(obj).encode("utf-8")).hexdigest()


# --- scrub de PII ESTRUCTURADA (council bloque #2; defensa en profundidad en el seam) ---
# El seam ya excluye cuentas_detalle y banda el importe; esto redacta identificadores que pudieran
# colarse en campos de texto (NIF/NIE/CIF/IBAN). La pseudonimización de NOMBRES (NER) es J1.
_PII_PATRONES = [
    re.compile(r"\bES\d{2}(?:[ \-]?[0-9A-Za-z]{4}){5}\b"),           # IBAN español (compacto o agrupado)
    re.compile(r"\b[XYZ]\d{7}[A-Za-z]\b"),                           # NIE
    re.compile(r"\b\d{8}[A-Za-z]\b"),                                # NIF / DNI
    re.compile(r"\b[A-HJ-NP-SUVWa-hj-np-suvw]\d{7}[0-9A-Ja-j]\b"),   # CIF
]


def _scrub_pii(valor):
    """Redacta PII estructurada en strings; deja intactos los no-str y el texto normativo sin PII."""
    if not isinstance(valor, str):
        return valor
    out = valor
    for pat in _PII_PATRONES:
        out = pat.sub("[PII]", out)
    return out


# --- schema CERRADO del IracOutput: claves permitidas por nivel (anti-inyección) ---
# Un reasoner (LLM en J1) no puede colar números calculados ni datos por claves ajenas al contrato:
# `revisar_schema` poda/denuncia cualquier clave fuera de esta whitelist. Refuerza calculation_fields=[].
_ESQUEMA_IRAC = {
    "": {"hallazgo_id", "issue", "rule", "application", "conclusion", "confidence",
         "citations", "evidence_gap", "conflict_flag", "calculation_fields"},
    "issue": {"cuestion", "figura_juridica", "carga_prueba"},
    "rule": {"norma_vigente_en_ejercicio", "vigencia_temporal", "autoridades", "conflicto_fuentes"},
    "rule.conflicto_fuentes": {"criterio_aplicable", "confianza_legitima_aplica", "posiciones"},
    "rule.autoridades[]": {"tipo_fuente", "id_ref", "ratio_o_obiter", "jerarquia_peso", "gate_estado"},
    "application": {"subsuncion", "hechos_dudosos", "contraargumento_contribuyente"},
    "conclusion": {"conclusion_label", "requiere_revision_humana"},
    "confidence": {"banda", "score", "drivers"},
    "confidence.drivers": {"solidez_cita", "acreditacion_hechos", "consolidacion_doctrina",
                           "alineacion_AEAT", "justificacion_divergencia"},
    "citations[]": {"organo", "numero", "fecha", "ref", "estado_gate", "imprimible",
                    "degradacion", "autoridad_sustituta"},
}


def revisar_schema(irac):
    """Devuelve (irac_limpio, claves_extra). Construye una copia con SOLO las claves del contrato;
    `claves_extra` lista las descartadas (rutas tipo 'conclusion.cuota_resultante'). No muta la entrada."""
    extra: list[str] = []

    def limpio(d, key):
        allowed = _ESQUEMA_IRAC.get(key)
        if not isinstance(d, dict) or allowed is None:
            return d
        out = {}
        for k, val in d.items():
            if k in allowed:
                out[k] = val
            else:
                extra.append(f"{key + '.' if key else ''}{k}")
        return out

    if not isinstance(irac, dict):
        return ({} if irac is None else irac), extra
    out = limpio(irac, "")
    if isinstance(out.get("issue"), dict):
        out["issue"] = limpio(out["issue"], "issue")
    if isinstance(out.get("rule"), dict):
        out["rule"] = limpio(out["rule"], "rule")
        if isinstance(out["rule"].get("conflicto_fuentes"), dict):
            out["rule"]["conflicto_fuentes"] = limpio(out["rule"]["conflicto_fuentes"], "rule.conflicto_fuentes")
        if isinstance(out["rule"].get("autoridades"), list):
            out["rule"]["autoridades"] = [limpio(a, "rule.autoridades[]") if isinstance(a, dict) else a
                                          for a in out["rule"]["autoridades"]]
    if isinstance(out.get("application"), dict):
        out["application"] = limpio(out["application"], "application")
    if isinstance(out.get("conclusion"), dict):
        out["conclusion"] = limpio(out["conclusion"], "conclusion")
    if isinstance(out.get("confidence"), dict):
        out["confidence"] = limpio(out["confidence"], "confidence")
        if isinstance(out["confidence"].get("drivers"), dict):
            out["confidence"]["drivers"] = limpio(out["confidence"]["drivers"], "confidence.drivers")
    if isinstance(out.get("citations"), list):
        out["citations"] = [limpio(c, "citations[]") if isinstance(c, dict) else c for c in out["citations"]]
    return out, extra


def hallazgo_para_juez(finding: dict, ejercicio: str, perfil: str = "preventiva") -> dict:
    """
    Proyección PSEUDONIMIZADA que cruza el seam hacia el reasoner.
    NO incluye `cuentas_detalle` ni PII; el importe va como BANDA discreta (council bloque #2).
    """
    finding = finding if isinstance(finding, dict) else {}
    dr = finding.get("documentos_requeridos")
    dr = list(dr) if isinstance(dr, (list, tuple, set)) else ([] if dr in (None, "", 0, False) else [dr])
    fig = finding.get("figura_juridica")
    fig = fig if fig in FIGURAS else figura_de_modulo(finding.get("modulo"))  # enum-guard: ni free-text ni PII
    return {
        "hallazgo_id": _scrub_pii(finding.get("id")),
        "figura_juridica": fig,
        "fundamento_determinista": _scrub_pii(finding.get("fundamento")),
        "importe_banda": banda_importe(finding.get("importe_contable")),
        "prioridad": _scrub_pii(finding.get("prioridad")),
        "prioridad_score": _scrub_pii(finding.get("prioridad_score")),
        "modulo": _scrub_pii(finding.get("modulo")),
        "ejercicio": str(ejercicio),
        "perfil_auditoria": perfil,
        "objetivo": _scrub_pii(finding.get("objetivo")),
        "documentos_requeridos": [_scrub_pii(x) for x in dr],
    }


def banda_de_score(prioridad_score) -> str:
    """Banda esperada por defecto a partir del prioridad_score determinista (ancla de coherencia)."""
    try:
        s = float(prioridad_score)
    except (TypeError, ValueError):
        return "media"
    if s >= 60:
        return "alta"
    if s >= 25:
        return "media"
    return "baja"


def validar_irac(irac: dict, prioridad_score=None) -> list[str]:
    """
    Validación DURA y determinista del IracOutput. Devuelve lista de violaciones (vacía = OK).
    No muta el objeto.
    """
    v: list[str] = []
    if not isinstance(irac, dict):
        return ["irac no es un dict"]

    # (0) schema CERRADO: ninguna clave fuera del contrato (anti-inyección de números calculados)
    _, _extra = revisar_schema(irac)
    for _p in _extra:
        v.append(f"clave no contractual fuera del schema IRAC: {_p}")

    # (a) calculation_fields invariante vacío
    cf = irac.get("calculation_fields", [])
    if cf:
        v.append(f"calculation_fields debe ir vacío; trae {cf!r}")

    # (b) enums cerrados
    issue = irac.get("issue") or {}
    if issue.get("figura_juridica") not in FIGURAS:
        v.append(f"issue.figura_juridica fuera de catálogo: {issue.get('figura_juridica')!r}")
    if issue.get("carga_prueba") not in CARGA_PRUEBA:
        v.append(f"issue.carga_prueba fuera de catálogo: {issue.get('carga_prueba')!r}")

    concl = irac.get("conclusion") or {}
    if concl.get("conclusion_label") not in CONCLUSION_LABELS:
        v.append(f"conclusion_label fuera de catálogo: {concl.get('conclusion_label')!r}")
    if concl.get("requiere_revision_humana") is not True:
        v.append("conclusion.requiere_revision_humana debe ser True (invariante)")

    conf = irac.get("confidence") or {}
    banda = conf.get("banda")
    if banda not in BANDAS:
        v.append(f"confidence.banda fuera de catálogo: {banda!r}")

    # (c) autoridades / citas con estados de gate dentro de catálogo
    for a in (irac.get("rule") or {}).get("autoridades") or []:
        if a.get("tipo_fuente") not in TIPOS_FUENTE:
            v.append(f"autoridad.tipo_fuente fuera de catálogo: {a.get('tipo_fuente')!r}")
        # ratio_o_obiter es metadato secundario y opcional (null para leyes/reglamentos); solo se exige
        # que, si viene, sea del catálogo (el validator coacciona lo inválido a None antes de llegar aquí)
        if a.get("ratio_o_obiter") is not None and a.get("ratio_o_obiter") not in RATIO_OBITER:
            v.append(f"autoridad.ratio_o_obiter fuera de catálogo: {a.get('ratio_o_obiter')!r}")

    # (d) coherencia banda <-> prioridad_score, BIDIRECCIONAL (council Sonnet §6): tanto la
    #     sub-confianza (banda baja con score alto) como la SOBRE-confianza (banda alta con score
    #     bajo) exigen justificación explícita en drivers.
    if prioridad_score is not None and banda in BANDAS:
        try:
            s = float(prioridad_score)
        except (TypeError, ValueError):
            s = None
        if s is not None:
            orden = {"baja": 0, "media": 1, "alta": 2}
            ancla = banda_de_score(s)
            justif = (conf.get("drivers") or {}).get("justificacion_divergencia")
            if abs(orden[banda] - orden[ancla]) >= 2 and not justif:
                v.append(
                    f"incoherencia banda↔prioridad: banda '{banda}' frente a ancla '{ancla}' "
                    f"(score={s:g}) sin drivers.justificacion_divergencia"
                )

    # (e) solo VERIFIED puede imprimirse
    for c in irac.get("citations") or []:
        if c.get("estado_gate") not in GATE_ESTADOS:
            v.append(f"cita con estado_gate inválido: {c.get('estado_gate')!r}")
        if c.get("imprimible") and c.get("estado_gate") != "VERIFIED":
            v.append(f"cita imprimible con estado_gate={c.get('estado_gate')!r} (solo VERIFIED imprime)")

    return v
