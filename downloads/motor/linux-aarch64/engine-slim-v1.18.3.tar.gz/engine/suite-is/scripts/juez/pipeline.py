"""
pipeline — cablea los 7 nodos del seam SDB para UN hallazgo (aislamiento por hallazgo, council #1):

  trigger → planner(retriever) → reasoner(LLM) → gate_citas → validator(degradador+hitl) → writer

`reasoner_fn` es inyectable (los tests adversariales inyectan reasoners hostiles). Por defecto usa
el stub determinista `reasoner.razonar`. El reasoner es el único nodo estocástico; el resto es puro.
"""
from __future__ import annotations

from . import contract as C
from . import gate as G
from . import planner as P
from . import reasoner as RZ
from . import retriever as R
from . import persistence as PER
from . import validator as V


def juzgar_hallazgo(finding: dict, ejercicio="2024", *, corpus: list[dict] | None = None,
                    corpus_dir: str | None = None, reasoner_fn=None, perfil: str = "preventiva",
                    model: str = "stub", seed: int = 0, temperature: float = 0.0,
                    solo_curado: bool = True, persist_dir: str | None = None) -> dict:
    reasoner_fn = reasoner_fn or RZ.razonar
    finding = finding if isinstance(finding, dict) else {}
    corpus = corpus if corpus is not None else R.cargar_corpus(corpus_dir)

    # 1-2) plan + contexto (vigente al devengo)
    seam, contexto, snapshot = P.planificar(
        finding, ejercicio, corpus=corpus, corpus_dir=corpus_dir, perfil=perfil)

    # 3) reasoner (LLM / stub) — propone el IracOutput. Para el reasoner por defecto recogemos el modelo
    #    EFECTIVO (honestidad del replay); un reasoner inyectado (tests) usa el model pedido. Blindamos la
    #    forma de salida (None / no-dict / citations / rule inesperados) antes de procesar.
    if reasoner_fn is RZ.razonar:
        irac, modelo_efectivo = RZ.razonar_meta(seam, contexto, seed=seed, model=model)
    else:
        irac = reasoner_fn(seam, contexto, seed=seed, model=model)
        modelo_efectivo = model
    if not isinstance(irac, dict):
        irac = {}
    rule = irac.get("rule")
    rule = rule if isinstance(rule, dict) else {}
    irac["rule"] = rule
    autoridades = rule.get("autoridades")
    autoridades = autoridades if isinstance(autoridades, list) else []
    citas = irac.get("citations")
    citas = [c for c in citas if isinstance(c, dict)] if isinstance(citas, list) else []
    irac["citations"] = citas

    # 4) gate de citas (contra el corpus COMPLETO, no solo el contexto vigente)
    gate_log: list[dict] = []
    for cita in citas:
        res = G.verificar_cita(cita, corpus, ejercicio, solo_curado=solo_curado)
        cita["estado_gate"] = res["estado"]
        cita["degradacion"] = res.get("degradacion")
        if res.get("autoridad_sustituta"):
            cita["autoridad_sustituta"] = res["autoridad_sustituta"]
        for a in autoridades:
            if a.get("id_ref") and a.get("id_ref") == cita.get("ref"):
                a["gate_estado"] = res["estado"]
        gate_log.append({"ref": cita.get("ref"), "numero": cita.get("numero"),
                         "estado": res["estado"], "chunk_id": res.get("chunk_id"),
                         "razon": res.get("razon")})

    # 5) validator: degrada con gracia, fuerza abstención, comprueba contrato
    irac, violaciones = V.validar_y_degradar(irac, finding.get("prioridad_score"))

    # 6) firmability pack (reproducible/forense). `modelo_efectivo` (paso 3) refleja si corrió OpenAI o
    #    el stub — el replay no debe afirmar que corrió un LLM cuando corrió el stub.
    corpus_version = (contexto[0].get("corpus_version") if contexto else None) or C.CORPUS_VERSION_DEFAULT
    pack = PER.firmability_pack(seam, irac, model=modelo_efectivo, temperature=temperature, seed=seed,
                               corpus_version=corpus_version, retrieval_snapshot_id=snapshot)

    # 7) writer (solo si se pide dir explícito)
    rutas = PER.persistir(persist_dir, seam, irac, pack, gate_log) if persist_dir else None

    return {
        "hallazgo_id": seam.get("hallazgo_id"),
        "seam": seam,
        "irac": irac,
        "gate_resultados": gate_log,
        "violaciones": violaciones,
        "firmability": pack,
        "retrieval_snapshot_id": snapshot,
        "rutas": rutas,
    }


def juzgar_cola(aud: dict, ejercicio="2024", **kw) -> list[dict]:
    """Procesa CADA hallazgo de la cola en un ciclo aislado (nunca megaprompt)."""
    corpus = kw.pop("corpus", None)
    corpus_dir = kw.get("corpus_dir")
    if corpus is None:
        corpus = R.cargar_corpus(corpus_dir)
    return [juzgar_hallazgo(f, ejercicio, corpus=corpus, **kw) for f in P.cola_revision_humana(aud)]
