"""
ingesta_boe — ingesta del corpus normativo desde la API de datos abiertos del BOE (legislación
consolidada). Convierte artículos en chunks del corpus del juez con **texto OFICIAL verbatim** y
**vigencia real por versión** (time-travel). Solo stdlib (urllib + xml.etree).

Patrón: `_get` aislado para monkeypatch — los tests parsean un FIXTURE, no tocan la red. La generación
del corpus (red) es un paso one-off que produce YAML commiteado; el motor consume el YAML, no la API.

Time-travel: cada `<version fecha_vigencia=...>` del artículo es un chunk con `fecha_vigor` y
`fecha_derogacion` (= vigencia de la versión siguiente); el retriever/gate eligen la vigente al
ejercicio. `fuente_curada=true`: es texto oficial del BOE, verificable → puede dar VERIFIED.
"""
from __future__ import annotations

import json
import time
import urllib.error
import urllib.request
import xml.etree.ElementTree as ET

_BASE = "https://www.boe.es/datosabiertos/api/legislacion-consolidada/id"
_UA = {"User-Agent": "suite-tax-is/0.1 (ingesta corpus juez)"}

# Normas soportadas: ref BOE + cómo se cita el artículo (numero + sufijo) + fecha de la norma.
NORMAS = {
    "LIS": {"ref": "BOE-A-2014-12328", "numero": "Ley 27/2014", "fecha": "2014-11-27",
            "organo": "Jefatura del Estado", "prefijo": "LIS"},
    "LSC": {"ref": "BOE-A-2010-10544", "numero": "RDLeg 1/2010", "fecha": "2010-07-02",
            "organo": "Jefatura del Estado", "prefijo": "LSC", "sufijo": "LSC"},
    "LGT": {"ref": "BOE-A-2003-23186", "numero": "Ley 58/2003", "fecha": "2003-12-17",
            "organo": "Jefatura del Estado", "prefijo": "LGT", "sufijo": "LGT"},
}


def _get(url: str, accept: str, intentos: int = 4) -> bytes:
    """Aislado para monkeypatch en tests (los tests jamás llegan aquí). Reintenta ante 5xx/429 (el BOE
    503ea bajo carga) con backoff lineal."""
    ultimo = None
    for i in range(intentos):
        try:
            req = urllib.request.Request(url, headers={**_UA, "Accept": accept})
            with urllib.request.urlopen(req, timeout=60) as r:  # noqa: S310 — URL fija del BOE
                return r.read()
        except urllib.error.HTTPError as e:
            ultimo = e
            if e.code in (429, 500, 502, 503, 504) and i < intentos - 1:
                time.sleep(2.0 * (i + 1))
                continue
            raise
        except urllib.error.URLError as e:
            ultimo = e
            if i < intentos - 1:
                time.sleep(2.0 * (i + 1))
                continue
            raise
    raise ultimo  # pragma: no cover


def indice(ref: str) -> list[dict]:
    """Lista de bloques del texto consolidado: [{id, titulo, url}, ...]."""
    d = json.loads(_get(f"{_BASE}/{ref}/texto/indice", "application/json"))
    return ((d.get("data") or [{}])[0].get("bloque")) or []


def _fecha_iso(s):
    s = (s or "").strip()
    return f"{s[:4]}-{s[4:6]}-{s[6:8]}" if len(s) == 8 and s.isdigit() else None


def _texto_version(version) -> str:
    parrafos = []
    for p in version.findall("p"):
        t = " ".join("".join(p.itertext()).split())
        if t:
            parrafos.append(t)
    return "\n".join(parrafos)


def _numero(norma: dict, art_num) -> str:
    base = f"{norma['numero']}, art. {art_num}"
    return f"{base} {norma['sufijo']}" if norma.get("sufijo") else base


def articulo_a_chunks(xml_bytes: bytes, *, norma: dict, art_num, corpus_version: str,
                      materia=None) -> list[dict]:
    """Parsea el XML de un bloque-artículo → un chunk POR VERSIÓN (texto + vigencia). PURO (sin red)."""
    root = ET.fromstring(xml_bytes)
    bloque = root.find("./data/bloque")
    if bloque is None:
        return []
    versiones = sorted(bloque.findall("version"), key=lambda v: v.get("fecha_vigencia") or "00000000")
    numero = _numero(norma, art_num)
    chunks = []
    for i, v in enumerate(versiones):
        texto = _texto_version(v)
        if not texto:
            continue
        derog = _fecha_iso(v.get("fecha_caducidad"))
        if derog is None and i + 1 < len(versiones):
            derog = _fecha_iso(versiones[i + 1].get("fecha_vigencia"))
        suf = ("-" + (v.get("fecha_vigencia") or "")) if len(versiones) > 1 else ""
        chunks.append({
            "id": f"{norma['prefijo']}-a{art_num}{suf}",
            "tipo_fuente": "ley",
            "organo": norma["organo"],
            "numero": numero,
            "fecha": norma["fecha"],
            "ref": norma["ref"],
            "materia": materia,
            "texto": texto,
            "fecha_vigor": _fecha_iso(v.get("fecha_vigencia")),
            "fecha_derogacion": derog,
            "estado_vigencia": "VIGENTE",
            "rango_jerarquico": 1,
            "fuente_curada": True,
            "corpus_version": corpus_version,
        })
    return chunks


def ingerir_articulos(clave_norma: str, arts, corpus_version: str, materias=None) -> list[dict]:
    """Descarga (RED) y convierte una lista de artículos de una norma en chunks. `materias` = {art: materia}."""
    norma = NORMAS[clave_norma]
    materias = materias or {}
    ids_existentes = {bl.get("id") for bl in indice(norma["ref"])}
    chunks = []
    for n in arts:
        bid = f"a{n}"
        if bid not in ids_existentes:
            continue
        xml_b = _get(f"{_BASE}/{norma['ref']}/texto/bloque/{bid}", "application/xml")
        chunks += articulo_a_chunks(xml_b, norma=norma, art_num=n, corpus_version=corpus_version,
                                    materia=materias.get(n))
    return chunks


def escribir_yaml(chunks: list[dict], path: str) -> None:
    import yaml
    with open(path, "w", encoding="utf-8") as fh:
        fh.write("# Corpus normativo ingerido del BOE (legislación consolidada) — texto OFICIAL verbatim.\n")
        fh.write("# Generado por juez/ingesta_boe.py; fuente_curada=true (verificable). NO editar a mano.\n")
        yaml.safe_dump(chunks, fh, allow_unicode=True, sort_keys=False, width=4000)
