"""
retriever_rag (determinista). Carga el corpus semilla, aplica el HARD-FILTER de vigencia
al devengo del ejercicio ANTES de cualquier ranking (time-travel, council bloque #5) y
reordena por peso jerárquico + recencia + solape de términos (re-ranker-lite; el híbrido
BM25+pgvector real es J2).
"""
from __future__ import annotations

import datetime
import glob
import os

from . import contract as C

try:
    import yaml
except Exception:  # pragma: no cover - se cubre con importorskip en tests
    yaml = None

CORPUS_DIR_DEFAULT = os.path.join(
    os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))),
    "rules", "corpus",
)

# Términos de consulta por figura (recall determinista del skeleton; en J2 lo da el embedding).
_TERMINOS_FIGURA = {
    "retrib_admin": ["retribu", "administrador", "15.e", "217", "249", "alta direcc", "vínculo", "consejero"],
    "deducibilidad": ["deducib", "gasto", "correlac", "15"],
}


def _fecha(s):
    if not s:
        return None
    try:
        return datetime.date.fromisoformat(str(s)[:10])
    except ValueError:
        return None


def devengo(ejercicio) -> datetime.date:
    try:
        return datetime.date(int(ejercicio), 12, 31)
    except (TypeError, ValueError):
        return datetime.date(2024, 12, 31)


def _fecha_campo(valor):
    """Devuelve (date|None, presente:bool): distingue 'fecha ausente' de 'presente pero malformada'."""
    if valor in (None, ""):
        return None, False
    return _fecha(valor), True


def vigente_en(chunk: dict, dev: datetime.date) -> bool:
    """¿El chunk estaba en vigor al devengo? FAIL-SAFE para una pasarela legal: fecha_vigor AUSENTE o
    MALFORMADA => NO vigente (no se puede acreditar la vigencia, luego no es citable como autoridad).
    No mira supersession doctrinal (eso lo decide el gate)."""
    fv, fv_presente = _fecha_campo(chunk.get("fecha_vigor"))
    if not fv_presente or fv is None:          # ausente o malformada -> no acreditado
        return False
    if fv > dev:
        return False
    fd, fd_presente = _fecha_campo(chunk.get("fecha_derogacion"))
    if fd_presente and fd is None:             # derogación presente pero malformada -> fail-safe
        return False
    if fd is not None and fd <= dev:
        return False
    return True


def cargar_corpus(corpus_dir: str | None = None) -> list[dict]:
    if yaml is None:
        return []
    base = corpus_dir or CORPUS_DIR_DEFAULT
    chunks: list[dict] = []
    for path in sorted(glob.glob(os.path.join(base, "*.yaml"))):
        with open(path, "r", encoding="utf-8") as fh:
            data = yaml.safe_load(fh) or []
        if isinstance(data, list):
            for c in data:
                if isinstance(c, dict) and c.get("id"):
                    chunks.append(c)
    return chunks


def _score(chunk: dict, figura: str, terminos: list[str]) -> float:
    blob = " ".join(str(chunk.get(k, "")) for k in ("texto", "numero", "materia", "organo")).lower()
    hits = sum(1 for t in terminos if t in blob)
    materia_match = 1.0 if str(chunk.get("materia")) == figura else 0.0
    peso = C.PESO_JERARQUICO.get(chunk.get("tipo_fuente"), 1.0)
    fecha = _fecha(chunk.get("fecha")) or datetime.date(1900, 1, 1)
    # recencia normalizada (0..1 aprox sobre ventana ~30 años)
    recencia = max(0.0, min(1.0, (fecha.year - 1995) / 30.0))
    return hits + materia_match + peso / 10.0 + recencia * 0.1


def recuperar(figura: str, ejercicio, *, corpus: list[dict] | None = None,
              corpus_dir: str | None = None, k: int = 6, terminos_extra: list[str] | None = None):
    """
    Devuelve (contexto_chunks_vigentes_rankeados, retrieval_snapshot_id).
    Solo entran chunks VIGENTES al devengo (hard-filter de vigencia ANTES del ranking).
    """
    corpus = corpus if corpus is not None else cargar_corpus(corpus_dir)
    dev = devengo(ejercicio)
    terminos = list(_TERMINOS_FIGURA.get(figura, [])) + list(terminos_extra or [])

    vigentes = [c for c in corpus if vigente_en(c, dev)]
    rankeados = sorted(
        vigentes,
        key=lambda c: (_score(c, figura, terminos), str(c.get("id"))),
        reverse=True,
    )
    top = rankeados[:k]
    corpus_version = (top[0].get("corpus_version") if top else None) or C.CORPUS_VERSION_DEFAULT
    snapshot_id = C.sha256({"ids": [c.get("id") for c in top], "corpus_version": corpus_version,
                            "ejercicio": str(ejercicio)})
    return top, snapshot_id
