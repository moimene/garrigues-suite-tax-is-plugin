"""
validator (determinista) — aplica los estados del gate al IracOutput, degrada con gracia,
fuerza la abstención cuando no hay soporte VERIFIED y comprueba el contrato (`contract.validar_irac`).

- Solo las citas VERIFIED quedan `imprimible: True`.
- Sin ninguna cita VERIFIED → conclusión `requiere_humano`, banda `baja`, evidence_gap anotado
  (abstención correcta; council "NOT_FOUND → confianza 0-25").
- VERIFIED_BUT_SUPERSEDED / EXISTS_BUT_MISMATCH / NOT_FOUND → degradacion textual accionable.
"""
from __future__ import annotations

import copy

from . import contract as C

_ABSTENCION = ("Sin cita VERIFIED en el corpus vigente al ejercicio; "
               "se requiere validación documental/colegial antes de oponer criterio.")


def validar_y_degradar(irac: dict, prioridad_score=None) -> tuple[dict, list[str]]:
    irac = copy.deepcopy(irac if isinstance(irac, dict) else {})
    # schema CERRADO (defensa en profundidad): poda toda clave ajena al contrato ANTES de persistir,
    # para que ningún número calculado por el reasoner sobreviva ni contamine el output_hash firmable.
    irac, _podadas = C.revisar_schema(irac)

    # ratio_o_obiter es metadato secundario: si el reasoner puso una descripción en vez del enum
    # 'ratio'/'obiter' (visto en vivo con gpt-5.5), se coacciona a None (output limpio) en vez de bloquear.
    for _a in (irac.get("rule") or {}).get("autoridades") or []:
        if isinstance(_a, dict) and _a.get("ratio_o_obiter") not in C.RATIO_OBITER:
            _a["ratio_o_obiter"] = None

    citations = irac.get("citations")
    citations = [c for c in citations if isinstance(c, dict)] if isinstance(citations, list) else []
    irac["citations"] = citations

    verificadas = 0
    for c in citations:
        estado = c.get("estado_gate")
        c["imprimible"] = (estado == "VERIFIED")
        if estado == "VERIFIED":
            verificadas += 1
        elif estado and estado != "VERIFIED" and not c.get("degradacion"):
            c["degradacion"] = ("Cita no verificada; criterio general sin cita. "
                                "El firmante debe completar/confirmar la referencia.")

    conf = irac.get("confidence")
    conf = conf if isinstance(conf, dict) else {}
    irac["confidence"] = conf
    concl = irac.get("conclusion")
    concl = concl if isinstance(concl, dict) else {}
    irac["conclusion"] = concl
    drivers = conf.get("drivers")
    drivers = drivers if isinstance(drivers, dict) else {}
    conf["drivers"] = drivers

    # INVARIANTES NO NEGOCIABLES forzados POR CONSTRUCCIÓN (no por cooperación del reasoner):
    # el LLM propone y el colegiado firma; el LLM no calcula.
    concl["requiere_revision_humana"] = True
    irac["calculation_fields"] = []

    if verificadas == 0:
        # abstención correcta: sin cita VERIFIED no se afirma postura fuerte
        if concl.get("conclusion_label") in ("deducible", "no_deducible", "ajuste_requerido"):
            concl["conclusion_label"] = "requiere_humano"
        eg = irac.get("evidence_gap")
        eg = eg if isinstance(eg, list) else []
        irac["evidence_gap"] = eg
        if _ABSTENCION not in eg:
            eg.append(_ABSTENCION)
        conf["banda"] = "baja"
        drivers["solidez_cita"] = "sin cita verificada"
        # la banda 'baja' forzada es coherente POR DISEÑO con el ancla -> justificarla evita un
        # falso positivo de incoherencia banda↔prioridad en validar_irac
        drivers["justificacion_divergencia"] = (
            "abstención: banda degradada a 'baja' por ausencia de cita VERIFIED (gate)")
    else:
        # con soporte verificado, la banda no puede inflarse por encima del ancla determinista
        banda_ancla = C.banda_de_score(prioridad_score)
        orden = {"baja": 0, "media": 1, "alta": 2}
        if orden.get(conf.get("banda"), 1) > orden.get(banda_ancla, 1):
            conf["banda"] = banda_ancla
        drivers["solidez_cita"] = "cita verificada (VERIFIED)"

    violaciones = C.validar_irac(irac, prioridad_score)
    if _podadas:
        violaciones.append(f"claves no contractuales podadas del IracOutput: {_podadas}")
    return irac, violaciones
