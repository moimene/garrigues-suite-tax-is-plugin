"""
planner (determinista) — toma un hallazgo, lo pseudonimiza (proyección de seam), decide la
consulta y ensambla el contexto vía retriever. NO razona jurídico. Incluye el helper de la
COLA de entrada de la capa LLM (no toca `motor_auditoria.py`: lo consume).
"""
from __future__ import annotations

from . import contract as C
from . import retriever as R


def cola_revision_humana(aud: dict) -> list[dict]:
    """Subconjunto de hallazgos marcados `requiere_revision_humana` (la cola del juez LLM)."""
    if not isinstance(aud, dict):
        return []
    return [h for h in (aud.get("hallazgos") or []) if isinstance(h, dict) and h.get("requiere_revision_humana")]


def planificar(finding: dict, ejercicio, *, corpus: list[dict] | None = None,
               corpus_dir: str | None = None, perfil: str = "preventiva", k: int = 6):
    """Devuelve (seam_dto_pseudonimizado, contexto_chunks_vigentes, retrieval_snapshot_id)."""
    seam = C.hallazgo_para_juez(finding, ejercicio, perfil)
    figura = seam.get("figura_juridica") or "otro"
    # términos extra honestos a partir del fundamento determinista (read-only)
    extra = []
    fund = str(seam.get("fundamento_determinista") or "").lower()
    for tok in ("15.e", "15.f", "217", "249", "18", "21"):
        if tok in fund:
            extra.append(tok)
    contexto, snapshot = R.recuperar(
        figura, ejercicio, corpus=corpus, corpus_dir=corpus_dir, k=k, terminos_extra=extra,
    )
    return seam, contexto, snapshot
