"""
writer (determinista) — persistencia FILESYSTEM (DEMO / pre-Supabase, respeta [D18] y la regla
dura #1: las 3 tablas Supabase van como migración draft sin aplicar). Escribe el "Firmability Pack"
(council bloque #6) y el log del gate, todo versionado para el replay forense (bloque #3).

NO escribe nada salvo que se le pase `dir` explícito (los tests usan tmp_path); por defecto, el
pipeline corre sin efectos de I/O.
"""
from __future__ import annotations

import json
import os

from . import contract as C


def firmability_pack(seam: dict, irac: dict, *, model: str, temperature: float, seed: int,
                     corpus_version: str, retrieval_snapshot_id: str) -> dict:
    """Sobre estructurada y versionada que hace el IracOutput reproducible y firmable."""
    return {
        "input_hash": C.sha256(seam),
        "output_hash": C.sha256(irac),
        "prompt_version": C.PROMPT_VERSION,
        "citation_gate_version": C.CITATION_GATE_VERSION,
        "corpus_version": corpus_version,
        "retrieval_snapshot_id": retrieval_snapshot_id,
        "model": model,
        "temperature": temperature,
        "seed": seed,
        # campos para el firmante colegiado (se rellenan en la revisión humana / J3 eIDAS):
        "revisor_colegiado": None,
        "diffs_humanos": [],
        "firmado_at": None,
    }


def persistir(dir_salida: str, seam: dict, irac: dict, pack: dict, gate_log: list[dict]) -> dict:
    """Anexa el resultado a JSONL (irac_outputs / gate_citas_log / firmability). APPEND-ONLY: NO
    deduplica (el `output_hash` permite al consumidor identificar reejecuciones idénticas en el replay)."""
    os.makedirs(dir_salida, exist_ok=True)
    rutas = {
        "irac": os.path.join(dir_salida, "irac_outputs.jsonl"),
        "gate": os.path.join(dir_salida, "gate_citas_log.jsonl"),
        "pack": os.path.join(dir_salida, "firmability.jsonl"),
    }
    registro = {"hallazgo_id": seam.get("hallazgo_id"), "output_hash": pack.get("output_hash"), "irac": irac}
    with open(rutas["irac"], "a", encoding="utf-8") as fh:
        fh.write(json.dumps(registro, ensure_ascii=False, sort_keys=True) + "\n")
    with open(rutas["gate"], "a", encoding="utf-8") as fh:
        for ev in gate_log:
            fh.write(json.dumps({"hallazgo_id": seam.get("hallazgo_id"), **ev},
                                ensure_ascii=False, sort_keys=True) + "\n")
    with open(rutas["pack"], "a", encoding="utf-8") as fh:
        fh.write(json.dumps({"hallazgo_id": seam.get("hallazgo_id"), **pack},
                            ensure_ascii=False, sort_keys=True) + "\n")
    return rutas
