"""
Capa LLM "juez normativo" — seam SDB (Stochastic-Deterministic Boundary).

Ruta SEPARADA y READ-ONLY sobre el canónico/hallazgos del motor determinista (D11; ADR-001/002):
NO toca builder / emitir_mod200 / firmar / gating / XSD. El LLM PROPONE; el colegiado firma.

API pública:
    juzgar_hallazgo(finding, ejercicio=...) -> dict   # un hallazgo → IracOutput verificado/degradado
    juzgar_cola(aud, ejercicio=...) -> [dict]          # cada hallazgo de la cola, en ciclo aislado
    cola_revision_humana(aud) -> [finding]             # subconjunto requiere_revision_humana
"""
from . import contract  # noqa: F401
from .pipeline import juzgar_hallazgo, juzgar_cola
from .planner import cola_revision_humana

__all__ = ["juzgar_hallazgo", "juzgar_cola", "cola_revision_humana", "contract"]
