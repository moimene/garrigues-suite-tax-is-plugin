#!/usr/bin/env python3
"""Genera la carta de solicitudes al cliente (.docx, branded Garrigues) desde el
bloque parseable de WF-1. Tapa el no-op del Document drafting de WF-1.

Toma el bloque de WF-1 (## ESTADO_HARNESS, ## 01_DATOS, ## 02_ISSUES) y produce una
carta que lista los issues 'a_confirmar' como solicitudes de informacion al cliente.

Uso:
  python3 carta_solicitudes.py --bloque WF1.txt --output-dir OUT/ --nif NIF --ejercicio 2025
"""
from __future__ import annotations
import argparse
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from puente_entregables_v3 import _extraer_json, brandear_docx, _leer_fuente  # noqa: E402


def parse_bloque_wf1(texto: str) -> dict:
    return {
        "harness": _extraer_json(texto, "ESTADO_HARNESS"),
        "datos": _extraer_json(texto, "01_DATOS"),
        "issues": _extraer_json(texto, "02_ISSUES"),
    }


def _dato(datos: list, campo_substr: str, default: str = "") -> str:
    for d in datos:
        if campo_substr.lower() in str(d.get("campo", "")).lower():
            v = d.get("valor")
            return default if v is None else str(v)
    return default


def solicitudes_desde_issues(issues: list) -> list:
    """Issues que requieren input del cliente (criticidad 'a_confirmar')."""
    return [
        {"id": i.get("id", ""), "titulo": i.get("titulo", ""),
         "importe": i.get("importe", 0), "fundamento": i.get("fundamento", "")}
        for i in issues if i.get("criticidad") == "a_confirmar"
    ]


def build_carta_docx(bloque: dict, nif: str, ejercicio: str, out_path: str) -> str:
    from docx import Document
    razon = _dato(bloque["datos"], "Denominaci", nif)
    nif_real = _dato(bloque["datos"], "NIF", nif)
    solicitudes = solicitudes_desde_issues(bloque["issues"])

    doc = Document()
    doc.add_heading(f"Solicitud de informacion - Impuesto sobre Sociedades {ejercicio}", level=1)
    doc.add_paragraph(f"Entidad: {razon}   -   NIF: {nif_real}")
    doc.add_paragraph(
        "En el marco de la preparacion de la declaracion del Impuesto sobre Sociedades del "
        f"ejercicio {ejercicio}, le solicitamos la informacion y documentacion necesaria para "
        "concluir el analisis de los siguientes puntos:")
    if not solicitudes:
        doc.add_paragraph("No hay puntos pendientes de confirmacion por su parte en este momento.")
    for n, s in enumerate(solicitudes, 1):
        doc.add_heading(f"S-{n:03d} - {s['titulo']}", level=2)
        p = doc.add_paragraph()
        p.add_run("Referencia interna: ").bold = True
        p.add_run(str(s["id"]))
        if s.get("fundamento"):
            doc.add_paragraph(f"Fundamento: {s['fundamento']}")
        doc.add_paragraph("Informacion solicitada: detalle y evidencia que confirme el tratamiento fiscal.")
    doc.add_paragraph("")
    doc.add_paragraph("Quedamos a su disposicion para cualquier aclaracion.")
    doc.save(out_path)
    brandear_docx(out_path, subtitulo=f"Suite Tax IS - Solicitudes al cliente - IS {ejercicio}")
    return out_path


def generar_carta(bloque_path: str, output_dir: str, nif: str, ejercicio: str) -> str:
    os.makedirs(output_dir, exist_ok=True)
    bloque = parse_bloque_wf1(_leer_fuente(bloque_path))
    out = os.path.join(output_dir, f"Solicitudes_{nif}_{ejercicio}.docx")
    return build_carta_docx(bloque, nif, ejercicio, out)


def main():
    ap = argparse.ArgumentParser(description="Carta de solicitudes desde el bloque WF-1")
    ap.add_argument("--bloque", required=True)
    ap.add_argument("--output-dir", required=True)
    ap.add_argument("--nif", required=True)
    ap.add_argument("--ejercicio", required=True)
    a = ap.parse_args()
    print(generar_carta(a.bloque, a.output_dir, a.nif, a.ejercicio))


if __name__ == "__main__":
    main()
