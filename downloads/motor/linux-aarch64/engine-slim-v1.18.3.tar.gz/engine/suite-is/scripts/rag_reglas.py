#!/usr/bin/env python3
"""Accessor de la RAG de reglas de importabilidad e IS (estudio §25).

Lee `suite-is/rules/rag/reglas_open.yaml` (3 capas: Manual/norma · Diseño de Registro · experiencia Open) y
permite consultarla por casilla, código de error, familia, id o texto libre. Determinista, sin red. Pensado
para que (a) el validador explique por qué bloquea/difiere un hallazgo y (b) la skill `analisis-respuestas-is`
responda «¿qué significa este error / qué hago?» citando la regla y su fuente.

CLI:  python3 rag_reglas.py <consulta>      (p. ej. "E25402369", "00562", "grupo_fiscal", "micropyme")
"""
import os
import sys

try:
    import yaml
except ImportError:  # pragma: no cover
    yaml = None

_HERE = os.path.dirname(os.path.abspath(__file__))
_RAG = os.path.normpath(os.path.join(_HERE, "..", "rules", "rag", "reglas_open.yaml"))


def cargar_reglas(path=None) -> list:
    """Lista de reglas del YAML. [] si falta el fichero o pyyaml no está (fail-soft: la RAG es auxiliar)."""
    p = path or _RAG
    if not (yaml and os.path.isfile(p)):
        return []
    with open(p, encoding="utf-8") as fh:
        data = yaml.safe_load(fh) or {}
    return data.get("reglas", []) or []


def _norm(s) -> str:
    return str(s or "").strip().lower()


def por_casilla(casilla, reglas=None) -> list:
    c = _norm(casilla)
    return [r for r in (reglas or cargar_reglas()) if any(c in _norm(x) for x in (r.get("casillas") or []))]


def por_error(codigo, reglas=None) -> list:
    e = _norm(codigo)
    return [r for r in (reglas or cargar_reglas()) if any(e == _norm(x) or e in _norm(x) for x in (r.get("errores") or []))]


def por_familia(familia, reglas=None) -> list:
    f = _norm(familia)
    return [r for r in (reglas or cargar_reglas()) if f == _norm(r.get("familia"))]


def buscar(query, reglas=None) -> list:
    """Búsqueda unificada: id exacto, luego error, casilla, familia y, si nada, texto libre en regla/descr."""
    q = _norm(query)
    reglas = reglas or cargar_reglas()
    if not q:
        return []
    exact = [r for r in reglas if _norm(r.get("id")) == q]
    if exact:
        return exact
    hits = []
    seen = set()
    for r in por_error(q, reglas) + por_casilla(q, reglas) + por_familia(q, reglas):
        if id(r) not in seen:
            seen.add(id(r))
            hits.append(r)
    if hits:
        return hits

    # texto libre: busca en TODOS los campos string de la regla (regla, id, familia, módulo, evidencia, test…)
    def _blob(r):
        partes = []
        for v in r.values():
            if isinstance(v, str):
                partes.append(v)
            elif isinstance(v, (list, tuple)):
                partes.extend(str(x) for x in v)
        return _norm(" ".join(partes))

    return [r for r in reglas if q in _blob(r)]


def main() -> int:  # pragma: no cover
    if len(sys.argv) < 2:
        reglas = cargar_reglas()
        print(f"RAG: {len(reglas)} reglas. Uso: rag_reglas.py <casilla|error|familia|id|texto>")
        return 0
    q = " ".join(sys.argv[1:])
    res = buscar(q)
    print(f"== '{q}': {len(res)} regla(s) ==")
    for r in res:
        print(f"\n[{r.get('id')}] familia={r.get('familia')} fuente={r.get('fuente')} "
              f"fase={r.get('fase')} modo={r.get('modo')}")
        print(f"  regla: {r.get('regla')}")
        if r.get("errores"):
            print(f"  errores: {', '.join(map(str, r['errores']))}")
        if r.get("casillas"):
            print(f"  casillas: {', '.join(map(str, r['casillas']))}")
        print(f"  módulo: {r.get('modulo')}  ·  test: {r.get('test') or '—'}  ·  evidencia: {r.get('evidencia') or '—'}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
