#!/usr/bin/env python3
"""Genera las 4 plantillas Garrigues VACIAS para el Vault del Space de Harvey.

Flujo nativo Harvey (refactor 2026-06-10): los pasos entregable_* de WF-1/WF-2
emiten cada entregable como TEXTO; el abogado lo copia (boton Copy) y lo pega
en estas plantillas branded. Hueco marcado: "PEGAR AQUI EL TEXTO DE HARVEY".

Identidad reutilizada de suite-is/scripts/puente_entregables_v3.py (G_*,
brandear_docx, _xlsx_brand_sheet). Sin datos de cliente: aptas para git/Vault.
"""
import os

G_VERDE = "004438"
G_VERDE_BR = "009A77"
G_VERDE_TENUE = "E8F0ED"
G_GRIS = "6B6B6B"
G_FONT = "Arial"
G_WORDMARK_FONT = "Cambria"
G_LEGAL = ("J&A Garrigues, S.L.P.   ·   Hermosilla 3, 28001 Madrid"
           "   ·   garrigues.com")
G_CONFID = ("Documento de trabajo — uso interno / cliente. "
            "Generado por Suite Tax IS.")

OUT = os.environ.get("PLANTILLAS_OUT", ".")
HUECO = "▶ PEGAR AQUI EL TEXTO DE HARVEY ◀"


# ---------------------------------------------------------------- DOCX ------
def _shade_cell(cell, hexcolor):
    from docx.oxml.ns import qn
    from docx.oxml import OxmlElement
    tcPr = cell._tc.get_or_add_tcPr()
    shd = OxmlElement("w:shd")
    shd.set(qn("w:val"), "clear")
    shd.set(qn("w:fill"), hexcolor)
    tcPr.append(shd)


def plantilla_docx(nombre, titulo, paso_harvey, instrucciones):
    from docx import Document
    from docx.shared import Pt, RGBColor
    from docx.enum.text import WD_ALIGN_PARAGRAPH
    verde = RGBColor(0x00, 0x44, 0x38)
    verde_br = RGBColor(0x00, 0x9A, 0x77)
    gris = RGBColor(0x6B, 0x6B, 0x6B)

    doc = Document()
    normal = doc.styles["Normal"]
    normal.font.name = G_FONT
    normal.font.size = Pt(10)

    band = doc.add_paragraph()
    rw = band.add_run("GARRIGUES")
    rw.font.name = G_WORDMARK_FONT
    rw.font.size = Pt(15)
    rw.font.color.rgb = verde

    sub = doc.add_paragraph()
    rs = sub.add_run("Suite Tax IS · Impuesto sobre Sociedades")
    rs.font.name = G_FONT
    rs.font.size = Pt(8)
    rs.font.color.rgb = verde_br

    t = doc.add_paragraph()
    rt = t.add_run(titulo)
    rt.font.name = G_FONT
    rt.font.size = Pt(16)
    rt.font.color.rgb = verde

    meta = doc.add_paragraph()
    rm = meta.add_run("Cliente / NIF: ____________    ·    Ejercicio: ______    "
                      "·    Fecha: ____________")
    rm.font.name = G_FONT
    rm.font.size = Pt(9)
    rm.font.color.rgb = gris

    ins = doc.add_paragraph()
    ri = ins.add_run("Cómo usar esta plantilla: " + instrucciones)
    ri.font.name = G_FONT
    ri.font.size = Pt(8)
    ri.font.color.rgb = gris
    ri.font.italic = True

    doc.add_paragraph()
    hueco = doc.add_paragraph()
    hueco.alignment = WD_ALIGN_PARAGRAPH.CENTER
    rh = hueco.add_run(HUECO)
    rh.font.name = G_FONT
    rh.font.size = Pt(14)
    rh.font.color.rgb = verde_br
    rh.font.bold = True
    nota = doc.add_paragraph()
    nota.alignment = WD_ALIGN_PARAGRAPH.CENTER
    rn = nota.add_run(f"(salida del paso '{paso_harvey}' — boton Copy de Harvey)")
    rn.font.name = G_FONT
    rn.font.size = Pt(9)
    rn.font.color.rgb = gris

    foot = doc.sections[0].footer.paragraphs[0]
    foot.alignment = WD_ALIGN_PARAGRAPH.CENTER
    fr = foot.add_run(G_LEGAL + "\n" + G_CONFID)
    fr.font.name = G_FONT
    fr.font.size = Pt(7)
    fr.font.color.rgb = gris

    path = os.path.join(OUT, nombre)
    doc.save(path)
    print("OK", path)


# ---------------------------------------------------------------- XLSX ------
def _xlsx_brand_sheet(ws, titulo, headers, n_cols, paso_harvey):
    from openpyxl.styles import Font, PatternFill, Alignment
    from openpyxl.utils import get_column_letter
    verde_fill = PatternFill("solid", fgColor=G_VERDE)
    verde_font = Font(name=G_FONT, bold=True, color="FFFFFF", size=10)
    last_col = get_column_letter(n_cols)

    ws.merge_cells(f"A1:{last_col}1")
    c = ws["A1"]; c.value = "GARRIGUES"
    c.font = Font(name=G_WORDMARK_FONT, size=16, color=G_VERDE)
    ws.merge_cells(f"A2:{last_col}2")
    c2 = ws["A2"]; c2.value = titulo
    c2.font = Font(name=G_FONT, size=12, color=G_VERDE)
    ws.merge_cells(f"A3:{last_col}3")
    c3 = ws["A3"]
    c3.value = "NIF: ________    ·    Ejercicio: ______    ·    Suite Tax IS"
    c3.font = Font(name=G_FONT, size=9, color=G_GRIS)
    HDR = 5
    for j, h in enumerate(headers, 1):
        cell = ws.cell(row=HDR, column=j, value=h)
        cell.fill = verde_fill
        cell.font = verde_font
        cell.alignment = Alignment(vertical="center", wrap_text=True)
        ws.column_dimensions[get_column_letter(j)].width = max(16, len(h) + 6)
    ws.freeze_panes = f"A{HDR + 1}"
    hueco = ws.cell(row=HDR + 1, column=1, value=HUECO)
    hueco.font = Font(name=G_FONT, size=11, color=G_VERDE_BR, bold=True)
    nota = ws.cell(row=HDR + 2, column=1,
                   value=f"(pegar aqui las filas de la tabla del paso "
                         f"'{paso_harvey}' de Harvey; una fila por linea)")
    nota.font = Font(name=G_FONT, size=8, color=G_GRIS, italic=True)
    ws.oddHeader.left.text = "&\"Arial\"&K004438 GARRIGUES"
    ws.oddFooter.center.text = ("&\"Arial,Regular\"&8&K6B6B6B "
                                "J&A Garrigues, S.L.P.  -  garrigues.com  -  &P")


def plantilla_modelo200():
    import openpyxl
    wb = openpyxl.Workbook()
    wa = wb.active
    wa.title = "Modelo_200_Casilla_Importe"
    _xlsx_brand_sheet(wa, "Modelo 200 — Vista limpia (AEAT)",
                      ["Casilla", "Concepto", "Importe (€)"], 3,
                      "entregable_modelo200 · TABLA A")
    wb_ws2 = wb.create_sheet("Mapping_Detallado_Normativa")
    _xlsx_brand_sheet(wb_ws2, "Modelo 200 — Mapping detallado con normativa",
                      ["Casilla", "Concepto", "Importe (€)", "Origen del dato",
                       "Referencia normativa"], 5,
                      "entregable_modelo200 · TABLA B")
    path = os.path.join(OUT, "Modelo_200.xlsx")
    wb.save(path)
    print("OK", path)


def plantilla_sys_a3():
    import openpyxl
    wb = openpyxl.Workbook()
    ws = wb.active
    ws.title = "SyS_A3"
    _xlsx_brand_sheet(ws, "Sumas y Saldos — formato A3 (spec importación Wolters Kluwer)",
                      ["Cuenta", "Descripción", "Saldo Final", "Debe",
                       "Haber", "Saldo Inicial"], 6,
                      "TABLA A3 (WF-1 carta_solicitudes_texto / "
                      "WF-2 entregable_modelo200)")
    path = os.path.join(OUT, "SyS_A3.xlsx")
    wb.save(path)
    print("OK", path)


if __name__ == "__main__":
    plantilla_docx(
        "Memoria.docx",
        "Memoria Técnica Fiscal — Impuesto sobre Sociedades",
        "entregable_memoria (WF-2)",
        "ejecuta WF-2 en Harvey, copia el texto del paso entregable_memoria "
        "con el boton Copy y pegalo sustituyendo el hueco. Revisa formato y "
        "completa cabecera antes de entregar.")
    plantilla_docx(
        "Liquidacion.docx",
        "Liquidación definitiva — Impuesto sobre Sociedades",
        "entregable_liquidacion (WF-2)",
        "ejecuta WF-2 en Harvey, copia el texto del paso entregable_liquidacion "
        "con el boton Copy y pegalo sustituyendo el hueco. Revisa formato y "
        "completa cabecera antes de entregar.")
    plantilla_docx(
        "Carta_Solicitudes.docx",
        "Solicitudes de Información al Cliente — IS",
        "carta_solicitudes_texto (WF-1)",
        "ejecuta WF-1 en Harvey, copia el texto del paso carta_solicitudes_texto "
        "(hasta la linea FIN CARTA) y pegalo sustituyendo el hueco.")
    plantilla_modelo200()
    plantilla_sys_a3()
