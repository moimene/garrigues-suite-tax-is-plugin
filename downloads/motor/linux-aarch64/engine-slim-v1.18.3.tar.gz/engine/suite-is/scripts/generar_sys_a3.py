#!/usr/bin/env python3
"""Generador determinista de Sumas y Saldos ficticio para importación A3 — sustituye al
"WF Stefano" de Harvey (decisión 2026-06-11).

Antes: Harvey leía el Plan General Contable ÍNTEGRO en cada ejecución y "hacía contabilidad"
en prompt. Ahora: el motor genera el SyS con código contra dos fuentes de datos del repo —
`rules/pgc/maestro_pgc.csv` (904 cuentas oficiales, RD 1514/2007) y
`rules/pgc/mapeo_partidas_sys_a3.yaml` (partida -> cuenta 4d, el "PGC mínimo"). Harvey solo
aporta los importes de Balance/PyG y recibe las tres tablas del WF como texto.

Reglas del WF (conservadas):
  - Solo cuentas de 4 dígitos que existen en el PGC (4d exactos del maestro o subcuenta a cero
    de una cuenta madre de 3 dígitos del maestro).
  - Cada cuenta aparece UNA sola vez (los duplicados se agregan).
  - Total Debe == Total Haber y Total saldos deudores == Total saldos acreedores.
  - Activo deudor / pasivo y PN acreedor / gastos deudor / ingresos acreedor.
  - Saldos acreedores en NEGATIVO (convención A3); un pasivo positivo NO se convierte en
    activo (queda acreedor) y un activo negativo NO se convierte en pasivo (queda en su cuenta).
  - Cuadre, si hace falta, con cuentas razonables (reservas/bancos/clientes/proveedores/
    acreedores/HP). La 1290 NO cuadra saldos: la spec A3 la exige SIN saldo final.

Salida: filas en el formato del exportador A3 legacy (`exportar_sys_a3.py`, D7 — reutilizado
como FALLBACK vivo), las tres tablas del WF en markdown y el XLSX con la cabecera del template
real (Nif Sociedad / Nombre Sociedad / cabeceras / datos).

Rol en la suite: FALLBACK del SyS real — cuando no hay XLS real de sumas y saldos, este SyS
sintético alimenta el mismo pipeline (EPC -> canónico 4d -> XML Fase A contra XSD).
"""
from __future__ import annotations

import csv
import os
import unicodedata

try:
    import yaml
except ImportError:  # pragma: no cover
    yaml = None

from exportar_sys_a3 import HEADERS_A3, normalizar, validar

_PGC_DIR = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))),
                        "rules", "pgc")
TOL = 0.01


def _norm(s):
    return unicodedata.normalize("NFKD", str(s or "").strip().lower()) \
        .encode("ascii", "ignore").decode()


def cargar_maestro(pgc_dir=_PGC_DIR) -> dict:
    p = os.path.join(pgc_dir, "maestro_pgc.csv")
    with open(p, encoding="utf-8") as fh:
        return {f["codigo"]: f["denominacion"]
                for f in csv.DictReader(fh, delimiter=";")}


def cargar_mapeo(pgc_dir=_PGC_DIR) -> dict:
    p = os.path.join(pgc_dir, "mapeo_partidas_sys_a3.yaml")
    if yaml is None or not os.path.exists(p):
        return {}
    with open(p, encoding="utf-8") as fh:
        return yaml.safe_load(fh) or {}


def resolver_cuenta(cuenta: str, maestro: dict) -> tuple:
    """(cuenta4, denominacion, valida). Válida si 4d exacto en maestro o su madre 3d existe."""
    c = "".join(ch for ch in str(cuenta) if ch.isdigit()).zfill(4)[:4]
    if c in maestro:
        return c, maestro[c], True
    if c[:3] in maestro:
        return c, maestro[c[:3]], True
    return c, "", False


def generar_sys(partidas, nif="", nombre="", maestro=None, mapeo=None) -> dict:
    """Genera el SyS ficticio cuadrado. `partidas`: lista de dicts con `importe` y
    (`partida` del mapeo | `cuenta` explícita 4d [+ `naturaleza`]). Importe en magnitud de los
    estados financieros (positivo = valor normal de la partida).
    """
    maestro = maestro or cargar_maestro()
    mapeo = mapeo or cargar_mapeo()
    mapa = { _norm(k): v for k, v in (mapeo.get("partidas") or {}).items() }
    lados = mapeo.get("naturalezas") or {}
    issues, tabla3 = [], []
    acum = {}   # cuenta -> {"descripcion","saldo": signed}

    for p in partidas or []:
        importe = float(p.get("importe") or 0)
        nombre_partida = p.get("partida")
        if nombre_partida is not None:
            cfg = mapa.get(_norm(nombre_partida))
            if not cfg:
                issues.append({"codigo": "PARTIDA_SIN_MAPEO", "severidad": "bloqueante",
                               "detalle": f"Partida '{nombre_partida}' no está en el mapeo "
                                          "PGC mínimo (mapeo_partidas_sys_a3.yaml)."})
                continue
            cuenta, naturaleza = cfg["cuenta"], cfg["naturaleza"]
        else:
            cuenta, naturaleza = p.get("cuenta"), p.get("naturaleza", "activo")

        c4, denom, valida = resolver_cuenta(cuenta, maestro)
        if not valida:
            issues.append({"codigo": "CUENTA_FUERA_PGC", "severidad": "bloqueante",
                           "detalle": f"Cuenta {c4} no existe en el PGC (ni su madre 3d)."})
            continue
        # Regla A3 de la 129: el resultado NO va con saldo a la 1290 (balance antes del cierre).
        # Si llega como partida de balance, se representa en grupos 6/7 con cuenta razonable
        # (beneficio -> 7780 ingresos excepcionales; pérdida -> 6780 gastos excepcionales) y A3
        # lo reconstruye. Mantiene los dos cuadres que A3 exige.
        if c4.startswith("129"):
            naturaleza = "ingreso" if importe >= 0 else "gasto"
            c4 = "7780" if importe >= 0 else "6780"
            importe = abs(importe)
            denom = maestro.get(c4, maestro.get(c4[:3], ""))
            issues.append({"codigo": "RESULTADO_VIA_PYG", "severidad": "informativo",
                           "detalle": "Resultado del ejercicio representado en grupos 6/7 "
                                      f"({c4}) — A3 exige la 129 sin saldo final."})
        lado = lados.get(naturaleza, "deudor")
        # signo del saldo: deudor-natural conserva el signo del importe;
        # acreedor-natural lo invierte (acreedor en negativo, convención A3).
        saldo = importe if lado == "deudor" else -importe
        fila = acum.setdefault(c4, {"descripcion": p.get("descripcion") or denom,
                                    "saldo": 0.0, "naturaleza": naturaleza})
        fila["saldo"] += saldo
        tabla3.append({"partida": nombre_partida or f"cuenta {c4}", "cuenta": c4,
                       "descripcion": fila["descripcion"], "importe": round(importe, 2)})

    # Cuadre con cuentas razonables (nunca 1290: A3 la exige sin saldo final)
    desbalance = round(sum(f["saldo"] for f in acum.values()), 2)
    if abs(desbalance) > TOL:
        for candidata in (mapeo.get("cuadre") or {}).get("preferencia", []):
            if candidata not in acum:
                c4, denom, _ = resolver_cuenta(candidata, maestro)
                acum[c4] = {"descripcion": denom, "saldo": -desbalance,
                            "naturaleza": "cuadre"}
                tabla3.append({"partida": "cuadre del balance", "cuenta": c4,
                               "descripcion": denom, "importe": round(-desbalance, 2)})
                break
        else:
            issues.append({"codigo": "CUADRE_IMPOSIBLE", "severidad": "bloqueante",
                           "detalle": f"Descuadre {desbalance} y todas las cuentas de cuadre "
                                      "ya están en uso."})

    # Filas A3: movimientos ficticios de una pasada (saldo inicial 0)
    filas = []
    for c4 in sorted(acum):
        s = round(acum[c4]["saldo"], 2)
        filas.append({"cuenta": c4, "descripcion": acum[c4]["descripcion"],
                      "saldo_final": s, "debe": s if s > 0 else 0.0,
                      "haber": -s if s < 0 else 0.0, "saldo_inicial": 0.0})
    filas, avisos = normalizar(filas)          # regla A3 de la 1290
    for a in avisos:
        issues.append({"codigo": "A3_1290_SIN_SALDO", "severidad": "informativo", "detalle": a})

    bloqueantes = [i for i in issues if i["severidad"] == "bloqueante"]
    control = None
    if not bloqueantes and filas:
        control = validar(filas)               # cuadres exigidos por A3 (lanza si descuadra)
        control["resultado_contable"] = round(
            sum(-f["saldo"] for f in acum.values() if f["naturaleza"] == "ingreso")
            - sum(f["saldo"] for f in acum.values() if f["naturaleza"] == "gasto"), 2)
        control["cuentas_unicas"] = len({f["cuenta"] for f in filas}) == len(filas)

    return {"filas": filas, "control": control, "issues": issues, "tabla3": tabla3,
            "nif": nif, "nombre": nombre,
            "apto": not bloqueantes and bool(filas) and bool(control)}


# --------------------------------------------------------------------------- salidas
def _fmt_es(v) -> str:
    """Formato numérico español (1.234,56) — el que parsea el exportador A3 legacy."""
    if v is None:
        return ""
    return f"{v:,.2f}".replace(",", "§").replace(".", ",").replace("§", ".")


def tablas_markdown(res: dict) -> str:
    """Las tres tablas del WF, como texto (entregable Harvey). Números en formato español."""
    out = ["### Tabla 1: Sumas y Saldos A3", "",
           "| Cuenta | Descripción | Saldo Final | Debe | Haber | Saldo Inicial |",
           "|---|---|---:|---:|---:|---:|"]
    for f in res["filas"]:
        out.append(f"| {f['cuenta']} | {f['descripcion']} | {_fmt_es(f['saldo_final'])} "
                   f"| {_fmt_es(f['debe'])} | {_fmt_es(f['haber'])} "
                   f"| {_fmt_es(f['saldo_inicial'])} |")
    c = res["control"] or {}
    out += ["", "### Tabla 2: Comprobación", "",
            "| Total Debe | Total Haber | Total Saldo Deudor | Total Saldo Acreedor | "
            "Resultado contable | Nº de cuentas | Cuentas únicas |",
            "|---:|---:|---:|---:|---:|---:|---|",
            f"| {_fmt_es(c.get('total_debe', 0))} | {_fmt_es(c.get('total_haber', 0))} "
            f"| {_fmt_es(c.get('saldo_deudor', 0))} | {_fmt_es(c.get('saldo_acreedor', 0))} "
            f"| {_fmt_es(c.get('resultado_contable', 0))} | {c.get('n_cuentas', 0)} "
            f"| {'Sí' if c.get('cuentas_unicas') else 'NO'} |",
            "", "### Tabla 3: Mapeo PGC", "",
            "| Partida del balance o PyG | Cuenta utilizada | Descripción | Importe |",
            "|---|---|---|---:|"]
    for t in res["tabla3"]:
        out.append(f"| {t['partida']} | {t['cuenta']} | {t['descripcion']} "
                   f"| {_fmt_es(t['importe'])} |")
    return "\n".join(out)


def build_xlsx_template_a3(res: dict, out_path: str) -> str:
    """XLSX con la estructura EXACTA del template real subido 2026-06-11:
    fila 1 'Nif Sociedad', fila 2 'Nombre Sociedad', fila 3 cabeceras, datos después."""
    import openpyxl
    wb = openpyxl.Workbook()
    ws = wb.active
    ws.title = "Sheet1"
    ws.append(["Nif Sociedad", res.get("nif") or ""])
    ws.append(["Nombre Sociedad", res.get("nombre") or ""])
    ws.append(HEADERS_A3)
    for f in res["filas"]:
        ws.append([f["cuenta"], f["descripcion"] or "",
                   f["saldo_final"], f["debe"], f["haber"], f["saldo_inicial"]])
    for col, w in {"A": 12, "B": 42, "C": 16, "D": 16, "E": 16, "F": 16}.items():
        ws.column_dimensions[col].width = w
    for r in range(4, ws.max_row + 1):
        ws[f"A{r}"].number_format = "@"
        for col in ("C", "D", "E", "F"):
            cell = ws[f"{col}{r}"]
            if isinstance(cell.value, (int, float)):
                cell.number_format = "#,##0.00"
    wb.save(out_path)
    return out_path


DEMO_PARTIDAS = [
    {"partida": "Inmovilizado material", "importe": 120000},
    {"partida": "Clientes", "importe": 45000},
    {"partida": "Tesorería", "importe": 30000},
    {"partida": "Capital social", "importe": 100000},
    {"partida": "Deudas largo plazo entidades credito", "importe": 40000},
    {"partida": "Proveedores", "importe": 25000},
    {"partida": "Ventas", "importe": 200000},
    {"partida": "Compras", "importe": 110000},
    {"partida": "Sueldos y salarios", "importe": 60000},
]


def _self_test() -> int:
    res = generar_sys(DEMO_PARTIDAS, nif="B00000000", nombre="DEMO SL")
    ok = res["apto"] and res["control"]["cuadra_debe_haber"] \
        and res["control"]["cuadra_deudor_acreedor"] and res["control"]["cuentas_unicas"]
    print("[OK]" if ok else "[FAIL]", "control:", res["control"],
          "| issues:", [(i["codigo"], i["severidad"]) for i in res["issues"]])
    return 0 if ok else 1


if __name__ == "__main__":
    import sys
    if "--self-test" in sys.argv:
        raise SystemExit(_self_test())
    if "--demo" in sys.argv:
        res = generar_sys(DEMO_PARTIDAS, nif="B00000000", nombre="DEMO SL")
        print(tablas_markdown(res))
        out = build_xlsx_template_a3(res, "/tmp/SyS_A3_demo.xlsx")
        print("\nXLSX:", out)
        raise SystemExit(0)
    print("Uso: python3 generar_sys_a3.py --self-test | --demo")
