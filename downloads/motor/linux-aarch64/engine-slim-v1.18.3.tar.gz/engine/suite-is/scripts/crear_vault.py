#!/usr/bin/env python3
"""Crea la estructura de carpeta (vault) de un cliente/ejercicio para el ciclo IS.

Uso:
  python3 crear_vault.py --base /ruta/CLIENTES --nif B00000000 --razon "SOCIEDAD EJEMPLO SL" --ejercicio 2024
"""
import argparse, os, re, datetime


def slug(s):
    s = re.sub(r"[^A-Za-z0-9 ]", "", s).strip().replace(" ", "_")
    return s[:60]


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--base", required=True)
    ap.add_argument("--nif", required=True)
    ap.add_argument("--razon", required=True)
    ap.add_argument("--ejercicio", required=True)
    a = ap.parse_args()

    cliente = f"{a.nif}_{slug(a.razon)}"
    root = os.path.join(a.base, cliente)
    ej = os.path.join(root, "ejercicios", str(a.ejercicio))
    subdirs = ["00_intake/otros_soportes", "01_analisis", "02_revision/respuestas_cliente",
               "03_export", "pagos_fraccionados"]
    for s in subdirs:
        os.makedirs(os.path.join(ej, s), exist_ok=True)

    perfil = os.path.join(root, "_perfil_cliente.md")
    if not os.path.exists(perfil):
        with open(perfil, "w", encoding="utf-8") as f:
            f.write(f"""# Perfil del cliente

- **Razón social:** {a.razon}
- **NIF:** {a.nif}
- **CNAE:** (pendiente)
- **Régimen:** (general | etve | pymes | socimi | fondos)
- **Tipología / caracteres declaración:** (p. ej. ETVE 00011, matriz grupo 00082)
- **Tipo de gravamen:** (p. ej. 0.25)
- **Grupo de consolidación fiscal:** (sí/no — perímetro)

> Estos campos determinan qué reglas (rules/regimenes/) se activan y qué casillas de carácter se marcan.
""")

    bit = os.path.join(ej, "_bitacora.md")
    if not os.path.exists(bit):
        hoy = datetime.date.today().isoformat()
        with open(bit, "w", encoding="utf-8") as f:
            f.write(f"# Bitácora del expediente IS {a.ejercicio}\n\n- {hoy} — Vault creado.\n")

    chk = os.path.join(ej, "00_intake", "checklist_intake.md")
    if not os.path.exists(chk):
        with open(chk, "w", encoding="utf-8") as f:
            f.write(f"""# Checklist de intake — IS {a.ejercicio}

Estados: ✅ disponible · ⚠️ incompleto · ⛔ falta (bloqueante)

| Documento | Estado | Notas |
|---|---|---|
| Balance de sumas y saldos (cierre) | ⛔ | |
| Cuentas anuales (balance + PyG + memoria) | ⛔ | |
| Informe de auditoría | ⚠️ | si aplica |
| Identificación (NIF, CNAE, régimen, tipología) | ⚠️ | |
| Declaración IS ejercicio anterior | ⛔ | para arrastres |
| Cuadro de BINs pendientes | ⛔ | |
| Gasto financiero pendiente (art. 16) | ⚠️ | |
| Deducciones pendientes de aplicar | ⚠️ | |

## Saldos de arrastre
| Concepto | Importe | Origen |
|---|---|---|
| BINs pendientes | | |
| GF neto pendiente | | |
| Deducciones pendientes | | |
""")
    print(f"Vault creado: {root}")
    print(f"  Ejercicio: {ej}")


if __name__ == "__main__":
    main()
