#!/usr/bin/env python3
"""Fachada unica del motor determinista ('listo para hospedar').

Recibe un dict de inputs (rutas + metadatos) y devuelve un dict con las rutas de los
entregables generados. En Phase 1 lo llama el copiloto; en Phase 2 lo envolvera una
Azure Function (mismo codigo).

inputs = {
  "nif": str, "ejercicio": str, "output_dir": str,
  "sys_tabla1": ruta|None,   # -> export A3
  "bloque_wf1": ruta|None,   # -> carta de solicitudes
  "bloque_wf2": ruta|None,   # -> memoria + liquidacion + modelo_200
}
salida = {"entregables": {clave: ruta}, "avisos": [str]}
"""
from __future__ import annotations
import argparse
import json
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import exportar_sys_a3
import carta_solicitudes
import puente_entregables_v3


def generar_paquete(inputs: dict) -> dict:
    nif = inputs["nif"]
    ejercicio = inputs["ejercicio"]
    out = inputs["output_dir"]
    os.makedirs(out, exist_ok=True)
    res = {"entregables": {}, "avisos": []}

    if inputs.get("sys_tabla1"):
        # Fail-closed de cuadre (B3): exportar_sys_a3.validar cuadra por céntimos exactos (tol=0) y lanza si
        # descuadra. Se captura para SUPRIMIR solo el A3 (no el resto de entregables) -> un SyS descuadrado
        # (incl. 0,01) NO deja un A3 numérico importable en el paquete.
        try:
            r = exportar_sys_a3.exportar(inputs["sys_tabla1"], out, nif, ejercicio)
            res["entregables"]["a3"] = r["fichero"]
            res["avisos"].extend(r.get("avisos", []))
        except Exception as e:  # noqa: BLE001
            res["avisos"].append(f"A3 (SyS) NO generado: SyS descuadrado — {e}")
            res["contabilidad_descuadrada"] = True   # B3: la contabilidad base (SyS) no cuadra (lo lee engines)

    if inputs.get("bloque_wf1"):
        res["entregables"]["carta"] = carta_solicitudes.generar_carta(
            inputs["bloque_wf1"], out, nif, ejercicio)

    if inputs.get("bloque_wf2"):
        paq = puente_entregables_v3.generar_entregables(
            inputs["bloque_wf2"], out, nif, ejercicio)
        res["entregables"].update(paq)  # modelo_200, liquidacion, memoria
        res["avisos"].append("XML mod200: pendiente de integrar (caveat XSD 2025).")

    return res


def main():
    ap = argparse.ArgumentParser(description="Fachada del motor: bloques + SyS -> entregables")
    ap.add_argument("--inputs-json", required=True, help="Ruta a un JSON con los inputs")
    a = ap.parse_args()
    with open(a.inputs_json, encoding="utf-8") as fh:
        inputs = json.load(fh)
    print(json.dumps(generar_paquete(inputs), ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
