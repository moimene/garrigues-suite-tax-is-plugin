#!/usr/bin/env python3
# LEGACY (ADR-001 Nivel 0, 2026-06-06 — "A3 fuera"). Se CONSERVA (cableado vivo del plugin v0.5)
# pero el nuevo puente del seam (engine_service/seam.py: 00500 -> B2) lo sustituye hacia delante.
# No borrar. Ver RECONCILIACION_REGLAS.md §6 y DECISIONES.md D7.
"""Exportador determinista de Sumas y Saldos al fichero de importación de A3.

Cierra el downstream del round-trip Suite IS ↔ A3: toma un Balance de Sumas y
Saldos (p.ej. la "Tabla 1 — Sumas y Saldos A3" que produce el conversor de
Stefano, o cualquier SyS estructurado) y emite el **Excel exacto que A3
(a3ASESOR | soc) importa** en "Sumas y Saldos", aplicando las reglas oficiales:

Spec A3 confirmada (Wolters Kluwer a3responde — importación de SyS en Excel):
  - 6 columnas EXACTAS, en este orden y con estas cabeceras (NO modificar):
        Cuenta | Descripción | Saldo Final | Debe | Haber | Saldo Inicial
  - Cuenta = código PGC a 4 dígitos (rellenar con ceros a la izquierda).
  - Descripción puede ir vacía, pero la columna debe existir.
  - Saldo Final / Saldo Inicial: numéricos CON signo → saldos ACREEDORES en negativo.
  - Debe / Haber: numéricos ≥ 0 (importes acumulados).
  - Cuenta 1290 (Pérdidas y Ganancias): SIN saldo final (balance antes del cierre;
    A3 reconstruye el resultado desde el SyS).
  - Validaciones de cuadre (A3 las exige): Total Debe = Total Haber y
    Total Saldos Deudores = Total Saldos Acreedores.

NOTA: este fichero es la **plantilla A3 pura** (sin marca Garrigues): A3 advierte
que no se altere su estructura. Los entregables al cliente sí van branded (ver
puente_entregables_v3.py); esto es interoperabilidad técnica con A3.

Uso:
  python3 exportar_sys_a3.py --tabla1 TABLA1.(txt|md|docx) \
      --output-dir OUT/ --nif GIP --ejercicio 2025
"""
from __future__ import annotations
import argparse
import os
import re

HEADERS_A3 = ["Cuenta", "Descripción", "Saldo Final", "Debe", "Haber", "Saldo Inicial"]
TOL = 0.01


# ----------------------------------------------------------------------------
# Parsing de números en formato español ("1.234.567,89", "-1.234,56", "")
# ----------------------------------------------------------------------------
def _num(s):
    if s is None:
        return None
    s = str(s).strip().replace("€", "").replace(" ", " ").strip()
    if s == "" or s in {"-", "—", "n/a", "N/A"}:
        return None
    neg = s.startswith("(") and s.endswith(")")
    if neg:
        s = s[1:-1]
    s = s.replace(".", "").replace(",", ".")
    try:
        v = float(s)
    except ValueError:
        return None
    return -v if neg else v


def _cuenta4(c):
    """Normaliza el código de cuenta a (al menos) 4 dígitos PGC."""
    c = re.sub(r"\D", "", str(c or ""))
    if not c:
        return ""
    return c.zfill(4)


# ----------------------------------------------------------------------------
# Lectura de la "Tabla 1 — Sumas y Saldos A3" desde texto/markdown/docx
# ----------------------------------------------------------------------------
def _leer_fuente(path: str) -> str:
    if path.lower().endswith(".docx"):
        from docx import Document
        d = Document(path)
        out = []
        for p in d.paragraphs:
            out.append(p.text)
        for t in d.tables:
            for row in t.rows:
                out.append(" | ".join(c.text for c in row.cells))
        return "\n".join(out)
    with open(path, "r", encoding="utf-8") as fh:
        return fh.read()


def parse_tabla1(texto: str) -> list:
    """Extrae filas de cuenta desde la 'Tabla 1 — Sumas y Saldos A3'.

    Tolerante: localiza filas tipo tabla con >=6 celdas cuya 1ª celda parece un
    código de cuenta (dígitos), e ignora cabeceras/separadores.
    """
    filas = []
    for linea in texto.splitlines():
        if "|" not in linea:
            continue
        celdas = [c.strip() for c in linea.strip().strip("|").split("|")]
        if len(celdas) < 6:
            continue
        cab = celdas[0].lower()
        if cab.startswith("cuenta") or set(celdas[0]) <= set("-: "):
            continue  # cabecera o separador markdown
        if not re.search(r"\d", celdas[0]):
            continue  # no parece código de cuenta
        cuenta = _cuenta4(celdas[0])
        if not cuenta:
            continue
        filas.append({
            "cuenta": cuenta,
            "descripcion": celdas[1],
            "saldo_final": _num(celdas[2]),
            "debe": _num(celdas[3]) or 0.0,
            "haber": _num(celdas[4]) or 0.0,
            "saldo_inicial": _num(celdas[5]),
        })
    return filas


# ----------------------------------------------------------------------------
# Normalización (regla A3 de la 1290) y validación de cuadre
# ----------------------------------------------------------------------------
def normalizar(filas: list) -> tuple:
    """Aplica la regla A3 de la 1290 (sin saldo final). Devuelve (filas, avisos)."""
    avisos = []
    for f in filas:
        if f["cuenta"].startswith("129"):
            if f.get("saldo_final"):
                avisos.append(
                    f"Cuenta {f['cuenta']} (PyG) traía saldo final "
                    f"{f['saldo_final']}; se deja VACÍO (A3 exige balance antes "
                    f"del cierre y reconstruye el resultado).")
            f["saldo_final"] = None
    return filas, avisos


def validar(filas: list) -> dict:
    """Comprueba el cuadre que A3 exige. Lanza ValueError si descuadra.

    Cuadre por CÉNTIMOS EXACTOS (B3, tol=0): un descuadre de 0,01 NO emite el A3 (antes TOL=0,01 era un
    allowlist). Se cuantiza cada importe (Decimal) antes de sumar -> sin ruido float."""
    from decimal import Decimal, ROUND_HALF_UP

    def _c(x):
        return Decimal(str(x or 0)).quantize(Decimal("0.01"), rounding=ROUND_HALF_UP)
    total_debe = sum((_c(f["debe"]) for f in filas), Decimal("0"))
    total_haber = sum((_c(f["haber"]) for f in filas), Decimal("0"))
    sf = [_c(f["saldo_final"]) for f in filas if f["saldo_final"] is not None]
    saldo_deudor = sum((v for v in sf if v > 0), Decimal("0"))
    saldo_acreedor = sum((-v for v in sf if v < 0), Decimal("0"))
    ctrl = {
        "total_debe": float(total_debe),
        "total_haber": float(total_haber),
        "saldo_deudor": float(saldo_deudor),
        "saldo_acreedor": float(saldo_acreedor),
        "n_cuentas": len(filas),
        "cuadra_debe_haber": total_debe == total_haber,
        "cuadra_deudor_acreedor": saldo_deudor == saldo_acreedor,
    }
    if not ctrl["cuadra_debe_haber"]:
        raise ValueError(
            f"Descuadre Debe/Haber: {ctrl['total_debe']} vs {ctrl['total_haber']}")
    if not ctrl["cuadra_deudor_acreedor"]:
        raise ValueError(
            f"Descuadre Deudor/Acreedor: {ctrl['saldo_deudor']} vs "
            f"{ctrl['saldo_acreedor']}")
    return ctrl


# ----------------------------------------------------------------------------
# Escritura del Excel A3 (plantilla pura, sin marca)
# ----------------------------------------------------------------------------
def build_a3_xlsx(filas: list, out_path: str) -> str:
    import openpyxl
    wb = openpyxl.Workbook()
    ws = wb.active
    ws.title = "Sumas y Saldos"
    ws.append(HEADERS_A3)  # fila 1: cabeceras EXACTAS, sin alterar
    for f in filas:
        ws.append([
            f["cuenta"],
            f["descripcion"] or "",
            f["saldo_final"] if f["saldo_final"] is not None else None,
            f["debe"], f["haber"],
            f["saldo_inicial"] if f["saldo_inicial"] is not None else None,
        ])
    for col, w in {"A": 10, "B": 40, "C": 16, "D": 16, "E": 16, "F": 16}.items():
        ws.column_dimensions[col].width = w
    for r in range(2, ws.max_row + 1):
        for col in ("C", "D", "E", "F"):
            cell = ws[f"{col}{r}"]
            if isinstance(cell.value, (int, float)):
                cell.number_format = "#,##0.00"
        ws[f"A{r}"].number_format = "@"  # cuenta como texto
    wb.save(out_path)
    return out_path


# ----------------------------------------------------------------------------
# Orquestación
# ----------------------------------------------------------------------------
def exportar(tabla1_path: str, output_dir: str, nif: str, ejercicio: str) -> dict:
    filas = parse_tabla1(_leer_fuente(tabla1_path))
    if not filas:
        raise ValueError("No se encontraron filas de cuenta en la Tabla 1.")
    filas, avisos = normalizar(filas)
    ctrl = validar(filas)
    os.makedirs(output_dir, exist_ok=True)
    out = os.path.join(output_dir, f"SyS_A3_{nif}_{ejercicio}.xlsx")
    build_a3_xlsx(filas, out)
    return {"fichero": out, "control": ctrl, "avisos": avisos, "filas": filas}


def main():
    ap = argparse.ArgumentParser(
        description="Exporta un SyS al fichero de importación de A3 (Sumas y Saldos)")
    ap.add_argument("--tabla1", required=True,
                    help="Ruta a la Tabla 1 del conversor (.txt/.md/.docx)")
    ap.add_argument("--output-dir", required=True)
    ap.add_argument("--nif", default="CLIENTE")
    ap.add_argument("--ejercicio", default="2025")
    args = ap.parse_args()
    r = exportar(args.tabla1, args.output_dir, args.nif, args.ejercicio)
    c = r["control"]
    print(f"FICHERO A3 -> {r['fichero']}")
    print(f"Cuentas: {c['n_cuentas']}")
    print(f"Debe={c['total_debe']:,.2f}  Haber={c['total_haber']:,.2f}  "
          f"(cuadra: {c['cuadra_debe_haber']})")
    print(f"Deudor={c['saldo_deudor']:,.2f}  Acreedor={c['saldo_acreedor']:,.2f}  "
          f"(cuadra: {c['cuadra_deudor_acreedor']})")
    for a in r["avisos"]:
        print("AVISO:", a)


if __name__ == "__main__":
    main()
