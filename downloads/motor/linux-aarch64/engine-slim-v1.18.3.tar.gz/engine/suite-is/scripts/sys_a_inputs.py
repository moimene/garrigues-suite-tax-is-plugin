#!/usr/bin/env python3
# LEGACY (ADR-001 Nivel 0, 2026-06-06 — "A3 fuera"). Se CONSERVA (cableado vivo del plugin v0.5)
# pero el nuevo puente del seam (engine_service/seam.py: 00500 -> B2) lo sustituye hacia delante.
# No borrar. Ver RECONCILIACION_REGLAS.md §6 y DECISIONES.md D7.
"""FASE A — mapeo determinista: Sumas y Saldos (PGC) -> inputs de liquidación + hooks de issues.

Núcleo determinista del Paso A de la integración con el conversor → A3: toma la
"Tabla 1 — Sumas y Saldos A3" (la salida de TEXTO del conversor de Stefano, o
cualquier SyS) y deriva, SIN inventar, la parte CONTABLE de los inputs B2:B10 de
WF-1, además de marcar las cuentas PGC que el motor de issues debe revisar.

Separación de responsabilidades (clave del diseño):
  - DETERMINISTA aquí (pura aritmética de cuentas):
        B2  resultado contable (00500) = -(Σ saldo_final de grupos 6 y 7)
        B3  corrección IS cta. 630*  (00301) = Σ saldo_final de cta. 630*
        B10 retenciones y pagos cta. 473* (00595) = Σ saldo_final de cta. 473*
  - JUICIO FISCAL (lo resuelve la IA de WF-1 + motor de issues, NO el SyS):
        B4 ajustes positivos · B5 exenciones art.21 · B8 reserva cap. · B9 DDI
  - EJERCICIO ANTERIOR (del Modelo 200 previo, NO el SyS):
        B6 INCN anterior · B7 BINs pendientes
  - HOOKS: cuentas PGC que disparan revisión de issue (con artículo LIS).

Uso:
  python3 sys_a_inputs.py --tabla1 TABLA1.(txt|md|docx) [--resultado-tabla2 N]
"""
from __future__ import annotations
import argparse
import json
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from exportar_sys_a3 import parse_tabla1, validar, _leer_fuente, _num  # noqa: E402

TOL = 0.01

# Cuentas PGC que el motor de issues debe revisar (prefijo -> issue + artículo)
ISSUE_HOOKS = [
    ("678", "ISSUE-SANCIONES", "Art. 15 LIS",
     "Gastos excepcionales: revisar multas, sanciones, recargos y donativos no deducibles"),
    ("631", "ISSUE-TRIBUTOS", "Art. 15.1.c LIS",
     "Otros tributos: recargos y sanciones no son deducibles"),
    ("66", "ISSUE-GFN", "Art. 16 LIS",
     "Gastos financieros: posible limitación de GFN (>1M€ o 30% beneficio operativo)"),
    ("760", "ISSUE-ART21", "Art. 21 LIS",
     "Ingresos por participaciones en instrumentos de patrimonio (posible exención)"),
    ("761", "ISSUE-ART21", "Art. 21 LIS",
     "Ingresos de valores representativos de deuda (revisar tratamiento)"),
    ("762", "ISSUE-DDI", "Arts. 31-32 LIS",
     "Ingresos de créditos (posible deducción por doble imposición internacional)"),
]


def _suma(filas, pred):
    return round(sum(f["saldo_final"] for f in filas
                     if f["saldo_final"] is not None and pred(f)), 2)


def derive_inputs(filas: list, resultado_tabla2: float | None = None) -> dict:
    # B2 resultado contable (00500) = -(Σ saldo_final de grupos 6 y 7)
    b2 = -_suma(filas, lambda f: f["cuenta"][:1] in ("6", "7"))
    # B3 corrección IS = Σ saldo_final de cta. 630* (impuesto corriente/diferido)
    b3 = _suma(filas, lambda f: f["cuenta"].startswith("630"))
    # B10 retenciones y pagos a cuenta = Σ saldo_final de cta. 473*
    b10 = _suma(filas, lambda f: f["cuenta"].startswith("473"))

    # Hooks de issues: cuentas con saldo que disparan revisión
    hooks = []
    for f in filas:
        if not f["saldo_final"]:
            continue
        for prefijo, issue, art, desc in ISSUE_HOOKS:
            if f["cuenta"].startswith(prefijo):
                hooks.append({
                    "cuenta": f["cuenta"], "descripcion": f["descripcion"],
                    "importe": round(abs(f["saldo_final"]), 2),
                    "issue": issue, "articulo": art, "motivo": desc,
                })
                break

    # Cuadre del SyS (lo que A3 también valida)
    try:
        cuadre = validar(filas)
        cuadre_ok = True
    except ValueError as e:
        cuadre = {"error": str(e)}
        cuadre_ok = False

    out = {
        "deterministico_del_sys": {
            "B2_resultado_contable": round(b2, 2),
            "B3_correccion_is_6300": b3,
            "B10_retenciones_pagos": b10,
        },
        "requiere_juicio_fiscal_o_ejercicio_anterior": {
            "B4_ajustes_positivos": "motor de issues (ajustes extracontables)",
            "B5_exenciones_art21_negativo": "motor de issues (art.21)",
            "B6_incn_ejercicio_anterior": "Modelo 200 del ejercicio anterior",
            "B7_bins_pendientes": "Modelo 200 del ejercicio anterior",
            "B8_reserva_capitalizacion": "decisión del abogado/cliente (art.25)",
            "B9_ddi_internacional": "motor de issues + ejercicio anterior (arts.31-32)",
        },
        "issue_hooks": hooks,
        "cuadre_sys": cuadre,
        "cuadre_ok": cuadre_ok,
    }
    if resultado_tabla2 is not None:
        out["control_resultado"] = {
            "resultado_tabla2": round(resultado_tabla2, 2),
            "resultado_calculado_b2": round(b2, 2),
            "coincide": abs(resultado_tabla2 - b2) <= TOL,
        }
    return out


def main():
    ap = argparse.ArgumentParser(
        description="FASE A: SyS (Tabla 1) -> inputs contables B2/B3/B10 + hooks de issues")
    ap.add_argument("--tabla1", required=True, help="Tabla 1 del conversor (.txt/.md/.docx)")
    ap.add_argument("--resultado-tabla2", type=float, default=None,
                    help="(opcional) Resultado contable de la Tabla 2, para cuadre")
    args = ap.parse_args()
    filas = parse_tabla1(_leer_fuente(args.tabla1))
    res = derive_inputs(filas, args.resultado_tabla2)
    print(json.dumps(res, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
