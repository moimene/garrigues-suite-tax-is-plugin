# Capa de criterio (playbook)

`playbook_reglas_is_fuente.csv` es la fuente original del playbook de reglas fiscales (18 reglas,
formato posición estándar / desviaciones aceptables / desviaciones inaceptables / guía).

Su contenido se ha integrado en el catálogo determinista (`rules/catalogo/`) como capa de **criterio**:
cada regla incorpora `posicion_estandar`, `desviaciones_aceptables`, `desviaciones_inaceptables`,
`criticidad` y `ref`. El `revisor-fiscal` (Fase 2) y `is-lista-criticidad` (Fase 3) usan esta capa para
enjuiciar cada issue, no solo detectarlo.

## Correcciones aplicadas en la integración (no ingerir el CSV tal cual)
- **Tramos de compensación de BINs**: el CSV es incorrecto (>20M→25%, 1-20M→50%, <1M→70%).
  Se descartan esos umbrales y se mantiene el correcto (Art. 26 LIS + DA 15ª): 70% con mínimo 1M€
  (INCN <20M), 50% (20-60M), 25% (≥60M). Ver `rules/catalogo/bins.yaml`.
- **Reserva de capitalización y tipos de gravamen**: parametrizados por ejercicio (Ley 7/2024),
  no fijados al valor del CSV. Ver `reservas.yaml` y `cuota.yaml`.
