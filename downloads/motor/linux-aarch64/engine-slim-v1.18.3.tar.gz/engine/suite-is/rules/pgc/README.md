# Maestro PGC

`maestro_pgc.csv` (código;denominación) es el **cuadro de cuentas OFICIAL completo** del Plan General de
Contabilidad (RD 1514/2007, Texto refundido 2021), Cuarta Parte — **904 cuentas** (9 grupos, 77 subgrupos,
421 de 3 dígitos, 397 de 4 dígitos). Lo usan `scripts/conversor_pgc.py` y la skill `is-conversor-pgc`
para asignar la denominación oficial y validar que un código existe en el PGC.

Fuente: "Texto refundido PGC 2021" (normativa vigente). Cubre también el PGC de PYMES, que es un
subconjunto con la misma numeración (un PYMES usa un subconjunto de estos códigos). El conversor NO
inventa códigos: los no presentes se marcan para revisión humana.
Para un ejercicio con cambios normativos en el cuadro de cuentas, actualizar este fichero desde la
versión vigente del PGC.
