# Rule IR — modelo de reglas + taxonomía de especialidades

**Qué es.** El modelo canónico, neutral-de-lenguaje, de una **regla / ruleset** fiscal del IS,
más la **taxonomía de dominios y especialidades**. Es el *espejo editable* de las reglas: el
**admin de rulesets de la web** y el **motor Python** comparten este contrato.

**De dónde sale.** Extraído del motor de reglas **anterior** (repo `legal-eagle-logic`,
`src/lib/rule-engine/` — `types.ts` + `domain-pipeline.ts`) y normalizado. Ese motor TS se
**retiró** como calculador/validador fiscal (ver `ADR-002`): no era defendible mantener un
forward-chainer TS calculando el número en paralelo al motor Python.

**Contrato (ADR-001 / ADR-002).**
- El **número lo FIRMA el motor Python** ("cerebro GIP", cuadrado al céntimo en GIP 2024).
- La **detección de issues** vive en el **WF-1 de Harvey** (+ checkpoint humano "validar issues").
- Este IR **no ejecuta** la liquidación: es el **esquema** para (1) editar reglas en el admin y
  (2) catalogar/validar/etiquetar las reglas que ejecuta Python. "Reglas = unión": cada regla lleva
  `source.origin` (`python_engine` | `console` | `manual`) y `source.validatedInGip`.

## Ficheros

| Fichero | Rol |
|---|---|
| `rule_ir.schema.json` | **Fuente de verdad.** JSON Schema (draft 2020-12) de `RuleSet`/`Rule`/`RuleCondition`/`RuleAction`. |
| `taxonomy.json` | **Dato canónico.** Dominios + orden del pipeline, especialidades→dominios/namespace, operadores, funciones de fórmula, severidades. |
| `rule_ir.py` | Espejo Python: dataclasses + `build_domain_pipeline()` + `validate_ruleset()` + `load_ruleset()`. Sólo stdlib. |
| `../../../src/engine/ruleIR.ts` | Espejo TS para el **admin** (tipos + pipeline + mapas legacy→canónico). |
| `examples/ruleset_200_2024_core.example.json` | Ruleset de ejemplo (datos sintéticos) que valida contra el schema. |

## Uso

**Python**
```bash
python3 suite-is/rules/ir/rule_ir.py          # self-check: imprime pipelines + valida el ejemplo
```
```python
from rule_ir import load_ruleset, build_domain_pipeline
rs = load_ruleset("suite-is/rules/ir/examples/ruleset_200_2024_core.example.json")
build_domain_pipeline(["tp", "compliance"])   # → ['general','tp',...,'compliance','validacion']
```

**Admin web (TS)**
```ts
import { buildDomainPipeline, LEGACY_OPERATOR_TO_CANONICAL, type RuleSet } from '@/engine/ruleIR'
```

## Modelo (resumen)

- **Condición**: `factCode` `operator` (`eq|neq|gt|gte|lt|lte|in|not_in|is_null|is_not_null|matches`)
  contra un `value` **o** contra otra casilla (`compareToFact`). Se combinan con `combineWith` (`and|or`).
- **Acción**: `set_fact` (valor literal) · `calculate` (fórmula `FACT.<code>` + funciones en lista
  blanca: `MAX MIN ABS ROUND FLOOR CEIL SUM AVG IF REDONDEO_CENTIMOS REDONDEO_EUROS PORCENTAJE`) ·
  `validate` (emite issue con `severity` + `messageTemplate` interpolando `{{code}}`) · `log`.
- **Pipeline determinista**: `general → [especialidades normales] → liquidacion → ajustes →
  deducciones → base_imponible → cuota → pagos_fraccionados → [socimi/iic opcionales] →
  [compliance tardío] → validacion`. La validación **siempre** va al final.
- **Especialidades** conmutables por declaración (TP, consolidación, reestructuraciones, I+D+i,
  internacional, regímenes especiales, valoración de activos, financiera, compliance) → activan
  dominios condicionales y **namespaces** de hechos (gestión de *stale* al desactivar).

## Mapeo desde el motor retirado (legacy)

El IR canónico usa las formas del motor **original** (más rico). Los tipos del **port retirado**
(`src/types/index.ts`) se migran con los mapas de `ruleIR.ts`:

| Legacy (`src/types/index.ts`) | Canónico (IR) |
|---|---|
| operadores `== != < > <= >= exists not_exists` | `eq neq lt gt lte gte is_not_null is_null` |
| severidades `ERROR WARNING INFO` | `error warning info` |
| acciones `SET_FACT(formula) · RAISE_VALIDATION` | `calculate · validate` |
| `RuleSetStatus DRAFT/ACTIVE/RETIRED` | `draft/active/deprecated` |

> ⚠️ El port retirado evaluaba fórmulas con `new Function()` crudo y sustitución ingenua de
> variables (ver `ADR-002`). En el IR las fórmulas son `calculate` con funciones en lista blanca;
> **nunca** se debe portar el eval crudo.
