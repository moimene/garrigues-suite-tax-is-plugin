"""Suite IS — Rule IR (Intermediate Representation) — lado Python.

Modelo canónico de regla/ruleset fiscal, extraído del motor anterior
(repo ``legal-eagle-logic`` / ``src/lib/rule-engine``) y normalizado como
ESPEJO EDITABLE bajo ADR-001 / ADR-002:

  - Este IR **NO** ejecuta el número fiscal. El motor Python ("cerebro GIP")
    lo FIRMA. Aquí sólo (1) modelamos/validamos reglas y (2) construimos el
    pipeline de dominios determinista, idéntico al de la web (admin rulesets).

Sin dependencias externas (sólo stdlib), igual que ``parser_core``.
El contrato neutral-de-lenguaje vive en ``rule_ir.schema.json`` y la
taxonomía en ``taxonomy.json`` (canónica; este módulo la lee, no la duplica).
"""

from __future__ import annotations

import json
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

_HERE = Path(__file__).resolve().parent
_TAXONOMY_PATH = _HERE / "taxonomy.json"
_SCHEMA_PATH = _HERE / "rule_ir.schema.json"

# --- Enumeraciones canónicas (espejo de rule_ir.schema.json $defs) ------------
OPERATORS = frozenset(
    {"eq", "neq", "gt", "gte", "lt", "lte", "in", "not_in", "is_null", "is_not_null", "matches"}
)
SEVERITIES = frozenset({"error", "warning", "info"})
ACTION_TYPES = frozenset({"set_fact", "calculate", "validate", "log"})
RULE_DOMAINS = frozenset(
    {
        "general", "liquidacion", "ajustes", "deducciones", "base_imponible", "cuota",
        "pagos_fraccionados", "socimi", "iic", "validacion",
        "tp", "consolidacion", "reestructuraciones", "deducciones_idi", "internacional",
        "regimenes_especiales", "valoracion_activos", "compliance", "financiera",
    }
)
MODEL_TYPES = frozenset({"200", "202", "222"})
RULESET_STATUS = frozenset({"draft", "active", "deprecated"})
FORMULA_FUNCTIONS = frozenset(
    {"MAX", "MIN", "ABS", "ROUND", "FLOOR", "CEIL", "SUM", "AVG", "IF",
     "REDONDEO_CENTIMOS", "REDONDEO_EUROS", "PORCENTAJE"}
)


# =============================================================================
# Dataclasses del IR
# =============================================================================
@dataclass
class RuleCondition:
    fact_code: str
    operator: str
    value: Any = None
    compare_to_fact: str | None = None
    combine_with: str | None = None  # 'and' | 'or' (con la SIGUIENTE condición)

    @classmethod
    def from_dict(cls, d: dict) -> "RuleCondition":
        return cls(
            fact_code=d["factCode"],
            operator=d["operator"],
            value=d.get("value"),
            compare_to_fact=d.get("compareToFact"),
            combine_with=d.get("combineWith"),
        )


@dataclass
class RuleAction:
    type: str
    target_fact_code: str | None = None
    formula: str | None = None
    value: Any = None
    message_template: str | None = None
    severity: str | None = None
    target_namespace: str | None = None

    @classmethod
    def from_dict(cls, d: dict) -> "RuleAction":
        return cls(
            type=d["type"],
            target_fact_code=d.get("targetFactCode"),
            formula=d.get("formula"),
            value=d.get("value"),
            message_template=d.get("messageTemplate"),
            severity=d.get("severity"),
            target_namespace=d.get("targetNamespace"),
        )


@dataclass
class Rule:
    code: str
    domain: str
    priority: int
    enabled: bool
    conditions: list[RuleCondition] = field(default_factory=list)
    actions: list[RuleAction] = field(default_factory=list)
    id: str | None = None
    name: str | None = None
    description: str | None = None
    ruleset_id: str | None = None
    severity: str | None = None
    tags: list[str] = field(default_factory=list)
    source: dict | None = None

    @classmethod
    def from_dict(cls, d: dict) -> "Rule":
        return cls(
            code=d["code"],
            domain=d["domain"],
            priority=int(d["priority"]),
            enabled=bool(d["enabled"]),
            conditions=[RuleCondition.from_dict(c) for c in d.get("conditions", [])],
            actions=[RuleAction.from_dict(a) for a in d.get("actions", [])],
            id=d.get("id"),
            name=d.get("name"),
            description=d.get("description"),
            ruleset_id=d.get("rulesetId"),
            severity=d.get("severity"),
            tags=d.get("tags", []),
            source=d.get("source"),
        )


@dataclass
class RuleSet:
    name: str
    model_type: str
    tax_year: int
    regime: str
    territory: str
    version: str
    status: str
    rules: list[Rule] = field(default_factory=list)
    id: str | None = None

    @classmethod
    def from_dict(cls, d: dict) -> "RuleSet":
        return cls(
            name=d["name"],
            model_type=d["modelType"],
            tax_year=int(d["taxYear"]),
            regime=d["regime"],
            territory=d["territory"],
            version=d["version"],
            status=d["status"],
            rules=[Rule.from_dict(r) for r in d.get("rules", [])],
            id=d.get("id"),
        )


# =============================================================================
# Taxonomía / pipeline (lee taxonomy.json — canónico)
# =============================================================================
def load_taxonomy() -> dict:
    with open(_TAXONOMY_PATH, encoding="utf-8") as fh:
        return json.load(fh)


def specialty_for_domain(domain: str, taxonomy: dict | None = None) -> str | None:
    tax = taxonomy or load_taxonomy()
    for sp in tax["specialties"]:
        if domain in sp["domains"]:
            return sp["code"]
    return None


def namespace_for_domain(domain: str, taxonomy: dict | None = None) -> str:
    """Espejo de InferenceEngine.getNamespaceForDomain: nunca 'default'."""
    tax = taxonomy or load_taxonomy()
    override = tax.get("namespaceOverrides", {}).get(domain)
    if override:
        return override
    return specialty_for_domain(domain, tax) or "core"


def build_domain_pipeline(
    enabled_specialties: list[str],
    include_optional_core: bool = False,
    taxonomy: dict | None = None,
) -> list[str]:
    """Puerto fiel de domain-pipeline.ts::buildDomainPipeline.

    general → [especialidades normales] → core_end → [opcionales] →
    [especialidades tardías] → validacion (siempre la última, sin duplicados).
    """
    tax = taxonomy or load_taxonomy()
    pl = tax["pipeline"]
    late_codes = set(pl["lateSpecialties"])
    sp_domains = {sp["code"]: sp["domains"] for sp in tax["specialties"]}

    normal = [c for c in enabled_specialties if c not in late_codes]
    late = [c for c in enabled_specialties if c in late_codes]

    normal_domains = [d for c in normal for d in sp_domains.get(c, [])]
    late_domains = [d for c in late for d in sp_domains.get(c, [])]

    pipeline = [
        *pl["coreStart"],
        *normal_domains,
        *pl["coreEnd"],
        *(pl["optionalCore"] if include_optional_core else []),
        *late_domains,
        pl["always_last"],
    ]
    # quitar duplicados preservando orden
    seen: set[str] = set()
    out: list[str] = []
    for d in pipeline:
        if d not in seen:
            seen.add(d)
            out.append(d)
    return out


# =============================================================================
# Validación estructural ligera (sin jsonschema; suficiente para el espejo)
# =============================================================================
def validate_ruleset(data: dict) -> list[str]:
    """Devuelve lista de errores (vacía = válido). No sustituye al schema JSON,
    pero cubre lo esencial sin dependencias."""
    errors: list[str] = []

    for k in ("name", "modelType", "taxYear", "regime", "territory", "version", "status", "rules"):
        if k not in data:
            errors.append(f"ruleset: falta campo obligatorio '{k}'")
    if data.get("modelType") not in MODEL_TYPES:
        errors.append(f"ruleset.modelType '{data.get('modelType')}' no es {sorted(MODEL_TYPES)}")
    if data.get("status") not in RULESET_STATUS:
        errors.append(f"ruleset.status '{data.get('status')}' no es {sorted(RULESET_STATUS)}")

    for i, r in enumerate(data.get("rules", [])):
        loc = f"rules[{i}] ({r.get('code', '?')})"
        for k in ("code", "domain", "priority", "enabled", "conditions", "actions"):
            if k not in r:
                errors.append(f"{loc}: falta campo obligatorio '{k}'")
        if r.get("domain") not in RULE_DOMAINS:
            errors.append(f"{loc}: domain '{r.get('domain')}' desconocido")
        if not r.get("actions"):
            errors.append(f"{loc}: debe tener al menos una acción")
        for j, c in enumerate(r.get("conditions", [])):
            if c.get("operator") not in OPERATORS:
                errors.append(f"{loc}.conditions[{j}]: operador '{c.get('operator')}' inválido")
            if "factCode" not in c:
                errors.append(f"{loc}.conditions[{j}]: falta 'factCode'")
        for j, a in enumerate(r.get("actions", [])):
            t = a.get("type")
            if t not in ACTION_TYPES:
                errors.append(f"{loc}.actions[{j}]: type '{t}' inválido")
            elif t == "calculate" and not (a.get("targetFactCode") and a.get("formula")):
                errors.append(f"{loc}.actions[{j}]: 'calculate' exige targetFactCode + formula")
            elif t == "set_fact" and not (a.get("targetFactCode") and "value" in a):
                errors.append(f"{loc}.actions[{j}]: 'set_fact' exige targetFactCode + value")
            elif t == "validate" and not (a.get("messageTemplate") and a.get("severity")):
                errors.append(f"{loc}.actions[{j}]: 'validate' exige messageTemplate + severity")
            if a.get("severity") and a["severity"] not in SEVERITIES:
                errors.append(f"{loc}.actions[{j}]: severity '{a['severity']}' inválida")
    return errors


def load_ruleset(path: str | Path) -> RuleSet:
    with open(path, encoding="utf-8") as fh:
        data = json.load(fh)
    errs = validate_ruleset(data)
    if errs:
        raise ValueError("Ruleset inválido:\n  - " + "\n  - ".join(errs))
    return RuleSet.from_dict(data)


# =============================================================================
# Demo / self-check
# =============================================================================
if __name__ == "__main__":
    print("Pipeline (sin especialidades):")
    print("  " + " → ".join(build_domain_pipeline([])))
    print("Pipeline (TP + consolidación + compliance, con socimi/iic):")
    print("  " + " → ".join(build_domain_pipeline(
        ["tp", "consolidacion", "compliance"], include_optional_core=True)))

    example = _HERE / "examples" / "ruleset_200_2024_core.example.json"
    if example.exists():
        rs = load_ruleset(example)
        print(f"\nRuleset de ejemplo OK: {rs.name} (modelo {rs.model_type}/{rs.tax_year}), "
              f"{len(rs.rules)} reglas, estado={rs.status}")
        for r in rs.rules:
            print(f"  · [{r.domain}] {r.code} (prio {r.priority}) "
                  f"{len(r.conditions)} cond / {len(r.actions)} acc")
