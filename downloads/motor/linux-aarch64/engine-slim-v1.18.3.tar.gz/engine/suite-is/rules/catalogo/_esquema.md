# Esquema de una regla del catálogo

Cada regla es un objeto YAML con estos campos:

```yaml
- id: STRING                  # identificador estable (clave del issue)
  dominio: STRING             # resultado | diferencias_permanentes | diferencias_temporarias |
                              # compensacion | limitacion | reduccion_bi | deduccion | informacion
  signo: positivo|negativo|neutro
  titulo: STRING
  aplica_si:
    regimenes: [general, etve, pymes, socimi, fondos]   # en qué regímenes está activa
    condicion: STRING         # condición legible sobre facts.json (la evalúa el revisor-fiscal)
  parametros: { ... }         # parámetros numéricos (porcentajes, límites)
  formula: STRING             # cómo se calcula el importe (sobre facts.json)
  casillas: [STRING]          # casilla(s) del Modelo 200
  requiere_confirmacion: [STRING]   # qué soporte hay que pedir al cliente (si aplica)
  fundamento: STRING          # artículo LIS / norma
  criticidad_default: bloqueante|a_confirmar|verde|informativo
  evidencia_origen: [STRING]  # dónde buscar el soporte
```

Convención de signo en la liquidación: los ajustes `positivo` (aumentos) suman a la base; los
`negativo` (disminuciones) restan. El catálogo se versiona por ejercicio; los importes nunca se
calculan fuera de estas fórmulas.

---

## Capa de criterio (playbook) — campos adicionales (opcionales)

A partir de v0.2.0 cada regla puede incorporar la capa de criterio del playbook:

```yaml
  posicion_estandar: STRING          # cuál es la posición correcta/estándar
  desviaciones_aceptables: STRING    # qué desviación es tolerable (y por qué)
  desviaciones_inaceptables: STRING  # qué desviación NO es admisible
  criticidad: bloqueante|alto|medio|bajo   # criticidad del playbook (mapea a 🔴🟡🟢⚪)
  ref: STRING                        # referencia normativa (artículo LIS, RD, etc.)
```

Mapeo criticidad playbook → graduación del expediente:
`bloqueante → 🔴` · `alto → 🟡 (a confirmar)` · `medio → 🟡/🟢 según soporte` · `bajo → 🟢/⚪`.

Parámetros que cambian por ejercicio (reserva de capitalización, tipos de gravamen, límites) se
expresan con bloques `*_por_ejercicio` y el motor elige según el ejercicio del expediente.

---

## Capa de AUDITORÍA (Fase 4 / EPIC C) — campos `deteccion` + `accion`

Las reglas del catálogo de **auditoría** (`rules/auditoria/*.yaml`, ruta read-only D11) añaden dos campos
que las hacen **máquina-detectables** sobre el canónico, sin tocar Python. El motor (`motor_auditoria.py`,
paso 4 data-driven) recorre TODAS las reglas que lleven un bloque `deteccion`, citando la cuenta y el
importe REALES del canónico (nunca inventa), y dedup por `id` frente a los 6 detectores hardcoded.

```yaml
  deteccion:
    tipo: prefijo | prefijo_umbral   # prefijo: emite si hay cuentas que casan; prefijo_umbral: solo si Σ|saldo| > umbral
    prefijos: [STRING]               # prefijos de cuenta PGC (startswith sobre la cuenta del canónico)
    umbral: NUMBER                   # (solo prefijo_umbral) mínimo de Σ|saldo| para emitir
    signo: deudor | acreedor         # (opcional) filtra por signo del saldo (deudor>0 / acreedor<0)
  accion: STRING                     # qué hacer con el hallazgo (ajuste, casilla, documentación a pedir)
```

Hallazgo emitido (forma): `{id, titulo, dominio, casillas, criticidad, semaforo, fundamento (art. LIS),
accion, cuentas:[str], cuentas_detalle:[{cuenta, importe_contable=|saldo|, saldo (con signo), _fuente}],
importe_contable, requiere_confirmacion, posicion_estandar}`. **Identidad verificable** ("nunca inventar"):
`importe_contable` (cabecera) == Σ `cuentas_detalle.importe_contable`. Los `🟡` no se auto-resuelven: el
abogado confirma el criterio fino (la `condicion` en prosa) sobre el `aplica_si`.
