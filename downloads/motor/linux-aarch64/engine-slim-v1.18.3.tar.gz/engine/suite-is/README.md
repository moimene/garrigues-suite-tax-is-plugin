# Suite IS — Plugin de preparación del Impuesto sobre Sociedades

Asistente que ejecuta el ciclo completo del Impuesto sobre Sociedades (Modelos **200 / 202 / 222**)
**trabajando sobre la carpeta del cliente**. No requiere servidor ni base de datos: la carpeta *es*
el estado del expediente y cada paso se escribe como un artefacto verificable.

## Las 4 fases

1. **Gestión de información** (`is-intake`) — recoge el mínimo para arrancar (sumas y saldos, CCAA,
   identificación, saldos de arrastre) y deja explícito qué falta.
2. **Verificación + motor de issues** (`is-motor-issues` + `is-liquidacion`) — valida los datos y
   levanta todos los issues con efecto fiscal (ajustes a BI, exenciones, BINs, limitación GF, deducciones).
3. **Lista por criticidad** (`is-lista-criticidad`) — lista priorizada (🔴 bloqueante / 🟡 a confirmar /
   🟢 verde / ⚪ informativo) para el abogado y solicitudes para el cliente.
4. **Cierre y export** (`is-export-modelo200` + `is-memoria-tecnica`) — incorpora respuestas y genera el
   XLS de liquidación y el export mapeado a casillas del Modelo 200, **adaptado por tipología de sociedad**.

## Componentes

| Tipo | Nombre | Función |
|---|---|---|
| Skill | `is-orquestador` | Detecta la fase del expediente y dirige el flujo |
| Skill | `is-intake` | Fase 1 — gestión de información |
| Skill | `is-motor-issues` | Fase 2 — verificación + reglas → issues |
| Skill | `is-liquidacion` | Cálculo determinista de la liquidación |
| Skill | `is-lista-criticidad` | Fase 3 — lista priorizada + solicitudes |
| Skill | `is-export-modelo200` | Fase 4 — export por tipología |
| Skill | `is-memoria-tecnica` | Documentación auditable |
| Skill | `is-pagos-fraccionados` | Modelos 202/222 |
| Agente | `analista-contable` | Parsea SyS/CCAA y normaliza |
| Agente | `revisor-fiscal` | Aplica reglas y redacta issues |
| Agente | `qa-fiscal` | Verificación independiente de cuadres |

## Motor híbrido

- **Determinista** (`rules/`): catálogo YAML versionado por ejercicio/régimen. Todo importe que llega a
  una casilla sale de una regla con fórmula explícita → trazable y auditable.
- **Razonado** (Claude): localiza en la documentación qué reglas aplican y redacta el fundamento.
- **Capa de criterio (playbook)**: cada regla incorpora `posicion_estandar`, `desviaciones_aceptables`,
  `desviaciones_inaceptables`, `criticidad` y `ref` para *enjuiciar* el issue, no solo detectarlo.
  El catálogo cubre verificación (cuadres), ajustes permanentes (art. 15), exenciones (art. 21),
  BINs (art. 26 + DA 15ª), gastos financieros (art. 16), DDI (arts. 31-32), reservas (arts. 25/105),
  tipo de gravamen (art. 29), pagos fraccionados (art. 40) y operaciones vinculadas (art. 18).
  Parámetros móviles (reserva de capitalización, tipos) versionados por ejercicio (Ley 7/2024).

## Scripts incluidos (funcionales)

- `scripts/crear_vault.py` — crea la estructura de carpeta de un cliente/ejercicio.
- `scripts/normalizar_balance.py` — parsea sumas y saldos (.xls/.xlsx) → balance normalizado.
- `scripts/calcular_liquidacion.py` — calcula la liquidación determinista (`liquidacion.json`).
- `scripts/generar_export_modelo200.py` — genera el XLS de export con casillas.

## Uso

Instala el plugin y di, por ejemplo:
- *"Arranca el IS de este cliente"* → `is-orquestador`
- *"Crea el expediente IS 2024 para [cliente]"* → `is-intake`
- *"Levanta los issues fiscales"* → `is-motor-issues`
- *"Genera el export del Modelo 200"* → `is-export-modelo200`

## Alcance MVP

Multi-régimen (general, ETVE, PYMES, SOCIMI, fondos). Caso de referencia validado: **GIP 2024**
(la liquidación reproducida cuadra con casillas 00552 y 00562 del Modelo 200 presentado).
Sin integración con AEAT: genera ficheros y checklist de presentación manual.
